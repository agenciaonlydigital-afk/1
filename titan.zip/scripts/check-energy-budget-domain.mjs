import assert from 'node:assert/strict';
import { estimateNASEM2023Eer } from '../src/domains/profile/domain/rules/goal-calculator.ts';
import { estimateRestingMetabolicRate } from '../src/domains/profile/domain/rules/resting-metabolic-rate.ts';

let checked = 0;
let minMargin = Number.POSITIVE_INFINITY;
let minCase = null;
for (const sex of ['male', 'female']) {
  for (let age = 19; age <= 105; age += 1) {
    for (let heightCm = 110; heightCm <= 245; heightCm += 5) {
      for (let weightKg = 30; weightKg <= 300; weightKg += 5) {
        const rmr = estimateRestingMetabolicRate({ sex, age, heightCm, weightKg, method: 'mifflin_st_jeor' }).kcalPerDay;
        for (const activityCategory of ['inactive', 'low_active', 'active', 'very_active']) {
          const tdee = estimateNASEM2023Eer({ sex, age, heightCm, weightKg, activityCategory });
          const margin = tdee - rmr;
          assert.ok(tdee >= rmr, `NASEM TDEE fell below RMR for ${JSON.stringify({ sex, age, heightCm, weightKg, activityCategory, tdee, rmr })}`);
          if (margin < minMargin) {
            minMargin = margin;
            minCase = { sex, age, heightCm, weightKg, activityCategory, tdee, rmr };
          }
          checked += 1;
        }
      }
    }
  }
}
console.log(`Energy domain boundary PASS: ${checked.toLocaleString('en-US')} adult profile/activity combinations; minimum TDEE-RMR margin ${minMargin} kcal (${JSON.stringify(minCase)}).`);
