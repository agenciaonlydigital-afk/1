import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../src/shared/graphics/fluid-shader-engine.ts', import.meta.url), 'utf8');
assert.match(source, /int energyAdaptiveVolumeStepCount\(float segmentLength\)/,
  'plasma volume march must expose a deterministic segment-length step policy');
assert.match(source, /const int MAX_VOL_STEPS = 16;/,
  'the shader must keep a statically bounded GLSL loop');
assert.match(source, /int volumeSteps = energyAdaptiveVolumeStepCount\(segLen\);/,
  'the volume march must use adaptive sample count');
assert.match(source, /if \(stepIdx >= volumeSteps\) break;/,
  'the bounded loop must stop at the selected quality');
assert.match(source, /float ds = segLen \/ float\(volumeSteps\);/,
  'integration step length must preserve the full ray segment');
assert.doesNotMatch(source, /const int VOL_STEPS = 12;/,
  'fixed 12-step march must be removed');
console.log('Adaptive plasma ray-march contract passed.');
