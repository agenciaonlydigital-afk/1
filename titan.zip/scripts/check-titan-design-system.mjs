import { readFileSync } from 'node:fs';

const read = (path) => readFileSync(new URL(path, import.meta.url), 'utf8');
const css = read('../src/index.css');
const tokens = read('../src/shared/design-system/tokens.ts');
const anatomyRenderer = read('../src/domains/anatomy/engine/renderer/anatomy-renderer.ts');
const anatomyPicker = read('../src/domains/anatomy/engine/picking/muscle-picking.ts');
const shader = read('../src/domains/anatomy/engine/shaders/anatomy-material-shader.ts');
const anatomyBuilder = read('../src/domains/anatomy/engine/scene/build-anatomy-body.ts');
const chart = read('../src/domains/evolution/components/EvolutionTrendChart.tsx');
const chartSeries = read('../src/domains/evolution/domain/rules/evolution-chart.ts');
const evolution = read('../src/domains/evolution/screens/EvolutionScreen.tsx');
const errors = [];

function hexToLuminance(hex) {
  const raw = hex.replace('#', '');
  if (!/^[0-9a-fA-F]{6}$/.test(raw)) throw new Error(`Invalid hex color: ${hex}`);
  const channels = [0, 2, 4].map((index) => parseInt(raw.slice(index, index + 2), 16) / 255);
  const linear = channels.map((value) => value <= 0.04045 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4);
  return 0.2126 * linear[0] + 0.7152 * linear[1] + 0.0722 * linear[2];
}

function contrast(a, b) {
  const values = [hexToLuminance(a), hexToLuminance(b)].sort((x, y) => y - x);
  return (values[0] + 0.05) / (values[1] + 0.05);
}

const palette = {
  canvas: '#0E1412',
  surface: '#171E1B',
  raised: '#202925',
  elevated: '#29332D',
  primary: '#F1F0E8',
  secondary: '#B7C1BA',
  muted: '#9DA9A1',
  sage: '#A0B7A8',
  champagne: '#C8AD7A',
  info: '#91AFBE',
  copper: '#B89579',
  success: '#8FB69F',
  warning: '#C8AD7A',
  error: '#D28F87',
};

for (const [role, hex] of Object.entries(palette)) {
  if (!css.toLowerCase().includes(hex.toLowerCase()) && !tokens.toLowerCase().includes(hex.toLowerCase())) {
    errors.push(`Color token ${role} (${hex}) is not present in the design system.`);
  }
}

for (const foreground of ['primary', 'secondary', 'muted']) {
  for (const background of ['canvas', 'surface', 'raised', 'elevated']) {
    const ratio = contrast(palette[foreground], palette[background]);
    if (ratio < 4.5) errors.push(`${foreground} on ${background} has contrast ${ratio.toFixed(2)}:1 (< 4.5:1).`);
  }
}

for (const foreground of ['sage', 'champagne', 'info', 'copper', 'success', 'warning', 'error']) {
  for (const background of ['canvas', 'surface', 'raised', 'elevated']) {
    const ratio = contrast(palette[foreground], palette[background]);
    if (ratio < 4.5) errors.push(`${foreground} on ${background} has contrast ${ratio.toFixed(2)}:1 (< 4.5:1).`);
  }
}

for (const required of [
  '--titan-bg-canvas', '--titan-surface-raised', '--titan-surface-elevated',
  '--titan-text-primary', '--titan-text-secondary', '--titan-text-muted',
  '--titan-macro-protein', '--titan-macro-carbs', '--titan-macro-fat',
  '--titan-water-deep', '--titan-water-light', '--titan-shadow-flat', '--titan-motion-fast',
  '.titan-surface[data-elevation="0"]', '.titan-surface[data-elevation="2"]', '.titan-surface.titan-surface--hero[data-elevation="2"]',
  '.titan-page-heading', '.titan-anatomy-stage', '.titan-chart-line',
]) {
  if (!css.includes(required)) errors.push(`Missing CSS contract: ${required}`);
}

if (!tokens.includes('waterDeep') || !tokens.includes('macroFat') || !tokens.includes('typographyScale')) {
  errors.push('Design token source is missing water, macro-category or typography roles.');
}
if (!css.includes('min-height: 44px;') || !css.includes('font-size: max(16px, 1rem);')) {
  errors.push('Editable controls must retain 44px touch height and a 16px mobile text floor.');
}
if (evolution.includes('text-[var(--titan-accent)] mt-0.5 font-mono-metric')) {
  errors.push('Raw weight/waist deltas must not be colored as positive without a goal interpretation.');
}
if (!anatomyRenderer.includes('new MusclePicker()') || !anatomyRenderer.includes("canvas.addEventListener('pointerup', this.handlePointerUp)")) {
  errors.push('Anatomy pointer selection is not connected to the renderer.');
}
if (!anatomyRenderer.includes('this.callbacks.onMusclePick(hit.muscleId, hit.side)')) {
  errors.push('Anatomy picker hits are not forwarded to application state.');
}
if (!anatomyPicker.includes('if (!ancestor.visible) return false')) {
  errors.push('Anatomy picker must ignore meshes hidden by an ancestor layer.');
}
if (!shader.includes('MeshStandardMaterial') && !shader.includes('applyAnatomyMaterialEnhancements')) {
  errors.push('Anatomy material shader must extend the standard physically based material pipeline.');
}
if (!anatomyBuilder.includes('smoothCrossSections') || (!anatomyBuilder.includes('buildEvaluatedHumanMeshGeometries') && !anatomyBuilder.includes('addShellEllipsoid'))) {
  errors.push('Anatomy procedural body must keep smoothed lofts and complete hand/foot silhouette geometry.');
}
if (!chartSeries.includes('validRecords.map((record, index)') || !chartSeries.includes('Number.isFinite(record[metricKey])') || !chart.includes('sem estimativas ou projeções')) {
  errors.push('Evolution chart must plot only recorded measurements and disclose its scope.');
}
if (!evolution.includes('<EvolutionTrendChart records={records} />')) {
  errors.push('Evolution chart is not integrated into the evolution screen.');
}

if (errors.length) {
  console.error('TITAN design-system checks failed:\n' + errors.join('\n'));
  process.exitCode = 1;
} else {
  console.log('TITAN design-system checks passed (tokens, contrast, anatomy picking and observed-data chart).');
}
