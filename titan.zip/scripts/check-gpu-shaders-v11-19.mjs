import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { execFileSync } from 'node:child_process';
import { applyAnatomyMaterialEnhancements } from '../src/domains/anatomy/engine/shaders/anatomy-material-shader.ts';

const fluid = readFileSync(new URL('../src/shared/graphics/fluid-shader-engine.ts', import.meta.url), 'utf8');
const metalOptics = readFileSync(new URL('../src/shared/graphics/metal-optics-spectrum.ts', import.meta.url), 'utf8');
const compositor = readFileSync(new URL('../src/domains/anatomy/engine/renderer/dual-body-compositor.ts', import.meta.url), 'utf8');
const constants = new Map([...fluid.matchAll(/const\s+([A-Z0-9_]+)\s*=\s*`([\s\S]*?)`\s*;/g)].map(m => [m[1], m[2]]));
const spectralSource = metalOptics.match(/export const METAL_SPECTRAL_FRESNEL_GLSL\s*=\s*`([\s\S]*?)`;\s*$/)?.[1];
assert.ok(spectralSource, 'could not extract measured metal spectral GLSL source');
constants.set('METAL_SPECTRAL_FRESNEL_GLSL', spectralSource);
function resolve(name, stack = []) {
  assert.ok(constants.has(name), `missing GLSL source ${name}`);
  assert.ok(!stack.includes(name), `cyclic GLSL interpolation ${[...stack, name].join(' -> ')}`);
  return constants.get(name).replace(/\$\{([A-Z0-9_]+)\}/g, (_m, dep) => resolve(dep, [...stack, name]));
}
const fragmentNames = [
  'DROPLET_FRAGMENT_300', 'TANK_FRAGMENT_300', 'CARD_DROPLETS_FRAGMENT_300',
  'LIQUID_GLASS_FRAGMENT_300', 'HDR_TONEMAP_FRAGMENT_300',
  'ENERGY_FRAGMENT_300', 'METAL_FRAGMENT_300'
];
const fluidFragments = Object.fromEntries(fragmentNames.map(n => [n, resolve(n)]));
const compositorFragment = compositor.match(/fragmentShader:\s*`([\s\S]*?)`\s*,\s*transparent:/)?.[1];
assert.ok(compositorFragment, 'could not extract dual-body compositor fragment shader');

// Build a real custom body-material shader from the project's onBeforeCompile
// injector. The test substitutes only the surrounding Three.js chunks/attributes;
// the injected TITAN vertex/fragment GLSL is preserved and compiled by WebGL2.
const colorUniform = { value: { r: 0.7, g: 0.5, b: 0.4 } };
const anatomyUniforms = {
  uActiveMusclesMask: { value: 0 }, uPrimaryMusclesMask: { value: 0 }, uSecondaryMusclesMask: { value: 0 },
  uSelectedMuscleIndex: { value: 0 }, uSelectedMuscleSide: { value: 0 }, uSelectedSideAny: { value: 1 },
  uHasSelection: { value: 0 }, uMuscleRestingColor: colorUniform, uMuscleDimmedColor: colorUniform,
  uMusclePrimaryColor: colorUniform, uMuscleSecondaryColor: colorUniform, uMuscleSelectedColor: colorUniform,
  uSweepY: { value: 1.0 }, uHologramMode: { value: 0.0 }, uHologramTint: colorUniform,
  uHologramAccent: colorUniform, uScanPhase: { value: 0.0 }, uTime: { value: 0.0 },
  uBodyRole: { value: 0.0 }, uBacklightOrigin: { value: { x: 0, y: 1.6, z: -1.1 } },
  uSkinScatteringMap: { value: {} }, uKeyLightDirection: { value: { x: -0.50, y: 0.65, z: 0.57 } },
};
const bodyMaterial = { onBeforeCompile: null, customProgramCacheKey: null };
applyAnatomyMaterialEnhancements(bodyMaterial, anatomyUniforms, 'body');
const bodyShader = {
  uniforms: {},
  vertexShader: '#include <common>\n#include <begin_vertex>\n#include <project_vertex>',
  fragmentShader: '#include <common>\n#include <color_fragment>\n#include <emissivemap_fragment>',
};
bodyMaterial.onBeforeCompile(bodyShader);
const bodyVertex = bodyShader.vertexShader
  .replace('#include <common>', '')
  .replace('#include <begin_vertex>', 'vec3 transformed = position;')
  .replace('#include <project_vertex>', 'gl_Position = projectionMatrix * modelViewMatrix * vec4(transformed, 1.0);')
  .replace(/\bvarying\b/g, 'out');
const bodyFragment = bodyShader.fragmentShader
  .replaceAll('#include <common>', '')
  .replaceAll('#include <color_fragment>', '')
  .replaceAll('#include <emissivemap_fragment>', '')
  .replace(/\bvarying\b/g, 'in')
  .replace(/\btexture2D\b/g, 'texture');
const anatomyVertex = `#version 300 es\nprecision highp float;\nin vec3 position;\nin vec3 objectNormal;\nuniform mat4 modelMatrix;\nuniform mat4 modelViewMatrix;\nuniform mat4 projectionMatrix;\nout vec2 vMapUv;\nout vec3 normal;\nout vec3 vViewPosition;\nvoid main(){ vMapUv=vec2(0.5); normal=normalize(mat3(modelViewMatrix)*objectNormal); vViewPosition=-(modelViewMatrix*vec4(position,1.0)).xyz; ${bodyVertex} }`;
const anatomyFragment = `#version 300 es\nprecision highp float;\nin vec2 vMapUv;\nin vec3 normal;\nin vec3 vViewPosition;\nuniform vec3 cameraPosition;\nout vec4 fragColor;\nvoid main(){ vec4 diffuseColor=vec4(0.78,0.62,0.52,1.0); vec3 totalEmissiveRadiance=vec3(0.0); ${bodyFragment} fragColor=vec4(diffuseColor.rgb+totalEmissiveRadiance,1.0); }`;

const payload = { fluidFragments, compositorFragment, anatomyVertex, anatomyFragment };
const html = `<!doctype html><meta charset="utf-8"><title>shader compile</title><pre id="result">pending</pre>
<script>
const payload = ${JSON.stringify(payload)};
const results = [];
function compile(gl, type, source, label) {
  const shader = gl.createShader(type);
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) throw new Error(label + ': ' + gl.getShaderInfoLog(shader));
  return shader;
}
function link(gl, vs, fs, label) {
  const program = gl.createProgram(); gl.attachShader(program, vs); gl.attachShader(program, fs); gl.linkProgram(program);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw new Error(label + ': link: ' + gl.getProgramInfoLog(program));
  return program;
}
try {
  const canvas = document.createElement('canvas');
  const gl2 = canvas.getContext('webgl2', {antialias:false, alpha:true});
  if (!gl2) throw new Error('WebGL2 context unavailable in headless Chromium');
  const vs2 = compile(gl2, gl2.VERTEX_SHADER, '#version 300 es\\nprecision highp float;\\nout vec2 v_uv;\\nvoid main(){ vec2 p=vec2(float((gl_VertexID<<1)&2),float(gl_VertexID&2)); v_uv=p*0.5; gl_Position=vec4(p*2.0-1.0,0.0,1.0); }', 'WebGL2 vertex');
  const anatomyVs = compile(gl2, gl2.VERTEX_SHADER, payload.anatomyVertex, 'TITAN anatomy body vertex');
  const anatomyFs = compile(gl2, gl2.FRAGMENT_SHADER, payload.anatomyFragment, 'TITAN anatomy body fragment');
  link(gl2, anatomyVs, anatomyFs, 'TITAN anatomy body material');
  results.push({name:'TITAN anatomy body material', status:'compiled'});
  for (const [name, fsSource] of Object.entries(payload.fluidFragments)) {
    const fs = compile(gl2, gl2.FRAGMENT_SHADER, fsSource, name);
    link(gl2, vs2, fs, name);
    results.push({name, status:'compiled'});
  }
  const gl1 = canvas.getContext('webgl', {antialias:false, alpha:true});
  if (!gl1) throw new Error('WebGL1 context unavailable for compositor');
  const vs1 = compile(gl1, gl1.VERTEX_SHADER, 'precision highp float; attribute vec2 position; varying vec2 vUv; void main(){ vUv=position*0.5+0.5; gl_Position=vec4(position,0.0,1.0); }', 'WebGL1 compositor vertex');
  const fs1 = compile(gl1, gl1.FRAGMENT_SHADER, 'precision highp float;\\n' + payload.compositorFragment, 'dual-body compositor');
  link(gl1, vs1, fs1, 'dual-body compositor');
  results.push({name:'dual-body compositor', status:'compiled'});
  document.getElementById('result').textContent = JSON.stringify({ok:true,results});
} catch (e) {
  document.getElementById('result').textContent = JSON.stringify({ok:false,error:String(e),results});
}
</script>`;
const dir = join(tmpdir(), `titan-shader-check-v11-21-${process.pid}`);
const file = join(dir, 'index.html');
import { mkdirSync } from 'node:fs';
mkdirSync(dir, {recursive:true}); writeFileSync(file, html);
try {
  const chromePath = process.env.CHROME_BIN || 'chromium';
  const output = execFileSync(chromePath, [
    '--headless=new', '--no-sandbox', '--disable-dev-shm-usage', '--enable-webgl',
    '--ignore-gpu-blocklist', '--enable-unsafe-swiftshader', '--use-gl=angle', '--use-angle=swiftshader',
    '--disable-background-networking', '--disable-extensions', '--disable-sync', '--dump-dom', `file://${file}`
  ], {encoding:'utf8', timeout:18000, stdio:['ignore','pipe','pipe']});
  const match = output.match(/<pre id="result">([\s\S]*?)<\/pre>/);
  assert.ok(match, 'Chromium did not return shader compilation result');
  const result = JSON.parse(match[1].replace(/&quot;/g, '"').replace(/&amp;/g, '&'));
  assert.equal(result.ok, true, JSON.stringify(result));
  assert.equal(result.results.length, 9);
  console.log(`V11.21 GPU shader compilation passed: ${result.results.map(x => x.name).join(', ')}`);
} catch (error) {
  if (error?.code === 'ETIMEDOUT' || error?.code === 'ENOENT' || /WebGL2 context unavailable|WebGL1 context unavailable/.test(String(error))) {
    console.log(`SKIPPED: Chromium headless não inicializou WebGL/SwiftShader neste host (${error?.code ?? error?.message ?? 'contexto indisponível'}); execute em runner/browser com WebGL2. Nenhum shader foi declarado compilado.`);
  } else {
    throw error;
  }
} finally { rmSync(dir, {recursive:true, force:true}); }
