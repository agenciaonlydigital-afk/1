import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { getLocalDateKey, isValidLocalDateKey } from '../../../shared/utils/local-date';
import { safeStorageAdapter } from '../../../infrastructure/storage/local-storage';
import { INITIAL_HYDRATION_ENTRIES } from '../data/repositories/hydration-seed';
import type { HydrationLogEntry } from '../domain/entities/hydration-entry';
import { getHydrationSummary } from '../domain/rules/hydration-summary';
import { mergeHydrationPersistedState, type HydrationPersistedState } from './hydration-persistence';

export type { HydrationLogEntry } from '../domain/entities/hydration-entry';
export { getHydrationSummary };

interface HydrationState extends HydrationPersistedState {
  logWater: (amountMl: number, dateKey?: string) => void;
  correctLastEntry: (newAmountMl: number, dateKey?: string) => void;
  removeEntry: (entryId: string) => void;
  setDailyGoalMl: (goalMl: number) => void;
  addCup: () => void;
}

const INITIAL_HYDRATION_STATE: HydrationPersistedState = {
  dailyGoalMl: 2500,
  entries: INITIAL_HYDRATION_ENTRIES,
  lastEventSeq: 3,
};

export const useHydrationStore = create<HydrationState>()(persist<HydrationState, [], [], HydrationPersistedState>(
  (set) => ({
    ...INITIAL_HYDRATION_STATE,

    logWater: (amountMl, dateKey = getLocalDateKey()) =>
      set((state) => {
        if (!Number.isFinite(amountMl) || amountMl < 10 || amountMl > 5000 || !isValidLocalDateKey(dateKey)) return state;
        const safeMl = Math.round(amountMl);
        const now = new Date();
        const timeLabel = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
        return {
          lastEventSeq: state.lastEventSeq + 1,
          entries: [
            ...state.entries,
            {
              id: `hyd-${Date.now()}-${state.lastEventSeq + 1}`,
              dateKey,
              amountMl: safeMl,
              timeLabel,
            },
          ],
        };
      }),

    correctLastEntry: (newAmountMl, dateKey = getLocalDateKey()) =>
      set((state) => {
        if (!Number.isFinite(newAmountMl) || newAmountMl < 0 || newAmountMl > 5000 || !isValidLocalDateKey(dateKey)) return state;
        const safeMl = Math.round(newAmountMl);
        const idx = [...state.entries].reverse().findIndex((entry) => entry.dateKey === dateKey);
        if (idx === -1) return state;
        const targetIndex = state.entries.length - 1 - idx;
        if (safeMl === 0) {
          return {
            lastEventSeq: state.lastEventSeq + 1,
            entries: state.entries.filter((_, i) => i !== targetIndex),
          };
        }
        return {
          lastEventSeq: state.lastEventSeq + 1,
          entries: state.entries.map((entry, i) =>
            i === targetIndex ? { ...entry, amountMl: safeMl } : entry,
          ),
        };
      }),

    removeEntry: (entryId) =>
      set((state) => {
        if (!state.entries.some((entry) => entry.id === entryId)) return state;
        return {
          lastEventSeq: state.lastEventSeq + 1,
          entries: state.entries.filter((entry) => entry.id !== entryId),
        };
      }),

    setDailyGoalMl: (goalMl) => {
      if (!Number.isFinite(goalMl) || goalMl < 500 || goalMl > 8000) return;
      set({ dailyGoalMl: Math.round(goalMl) });
    },

    addCup: () =>
      set((state) => {
        const now = new Date();
        const timeLabel = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
        return {
          lastEventSeq: state.lastEventSeq + 1,
          entries: [
            ...state.entries,
            {
              id: `hyd-${Date.now()}-${state.lastEventSeq + 1}`,
              dateKey: getLocalDateKey(now),
              amountMl: 250,
              timeLabel,
            },
          ],
        };
      }),
  }),
  {
    name: 'titan:hydration:v1',
    version: 1,
    storage: createJSONStorage(() => safeStorageAdapter),
    partialize: (state) => ({
      dailyGoalMl: state.dailyGoalMl,
      entries: state.entries,
      lastEventSeq: state.lastEventSeq,
    }),
    migrate: (persisted) => mergeHydrationPersistedState(persisted, INITIAL_HYDRATION_STATE),
    merge: (persisted, current) => ({
      ...current,
      ...mergeHydrationPersistedState(persisted, current),
    }),
  },
));
