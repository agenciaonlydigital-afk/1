import assert from 'node:assert/strict';
import { DRI_REFERENCE_PROFILES } from '../dri-profiles.ts';

const cases = [
  ['adult_male_19_30', 'magnesium', 350, 'supplements_and_medications'],
  ['adult_female_19_30', 'magnesium', 350, 'supplements_and_medications'],
  ['adult_male_51_70', 'vitamin_d', 100, 'total_intake'],
  ['adult_male_71_plus', 'vitamin_d', 100, 'total_intake'],
  ['adult_female_51_70', 'vitamin_d', 100, 'total_intake'],
  ['adult_female_51_70', 'vitamin_b6', 100, 'total_intake'],
  ['adult_female_51_70', 'iron', 45, 'total_intake'],
  ['adult_female_71_plus', 'vitamin_d', 100, 'total_intake'],
  ['adult_female_71_plus', 'vitamin_b6', 100, 'total_intake'],
  ['adult_female_71_plus', 'iron', 45, 'total_intake'],
  ['adult_female_51_plus', 'vitamin_b6', 100, 'total_intake'],
  ['adult_female_51_plus', 'iron', 45, 'total_intake'],
];

for (const [profileId, nutrientId, expectedUpperLimit, expectedScope] of cases) {
  const entry = DRI_REFERENCE_PROFILES[profileId].entries[nutrientId];
  assert.equal(entry.upperLimit, expectedUpperLimit, `${profileId}.${nutrientId} must preserve the adult UL`);
  assert.equal(entry.upperLimitScope, expectedScope, `${profileId}.${nutrientId} must preserve the correct source scope`);
}

assert.equal(DRI_REFERENCE_PROFILES.adult_51_plus.entries.phosphorus.upperLimit, undefined,
  'a broad 51+ profile must not invent one phosphorus UL across distinct age bands');
assert.equal(DRI_REFERENCE_PROFILES.adult_female_51_plus.entries.phosphorus.upperLimit, undefined,
  'the legacy female 51+ profile must leave age-dependent phosphorus UL unresolved');
console.log('DRI profile UL inheritance tests passed.');
