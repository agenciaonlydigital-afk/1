import type { FoodSourceItem, NutrientId } from '../../domain/entities/nutrient';
import {
  ensureCompactTbcaCatalogAsync,
  isCompactTbcaCatalogLoaded,
  readInitialCompactTbcaCatalogSync,
  type CompactTbcaCatalogRow,
} from './tbca-catalog-source.node.ts';

/**
 * TBCA 7.2 (Tabela Brasileira de Composição de Alimentos - FCF/USP)
 * Valores por 100 g de parte comestível, preservando 'trace' (tr) e 'not_analyzed' (NA).
 */
const LEGACY_TBCA_FOODS: Record<string, FoodSourceItem> = {
  'tbca-ovo-mexido': {
    food_id: 'tbca-ovo-mexido',
    name: 'Ovo de galinha mexido',
    source_id: 'TBCA',
    source_record_id: 'BRC0042A',
    source_version: 'TBCA 7.2',
    quality_status: 'verified_lab',
    macros: {
      kcalPerBasis: 158,
      proteinGPerBasis: 12.1,
      carbsGPerBasis: 1.4,
      fatGPerBasis: 11.4,
      basisQuantityG: 100,
    },
    micronutrients: {
      vitamin_a: {
        original_value: 149,
        original_unit: 'µg RAE',
        normalized_value: 149,
        normalized_unit: 'µg RAE',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct_rae',
      },
      vitamin_c: {
        original_value: null,
        original_unit: 'mg',
        normalized_value: null,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'trace',
        conversion_method: 'direct',
      },
      vitamin_d: {
        original_value: 1.8,
        original_unit: 'µg',
        normalized_value: 1.8,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_e: {
        original_value: 1.1,
        original_unit: 'mg',
        normalized_value: 1.1,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_k: {
        original_value: 0.3,
        original_unit: 'µg',
        normalized_value: 0.3,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b1: {
        original_value: 0.05,
        original_unit: 'mg',
        normalized_value: 0.05,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b2: {
        original_value: 0.42,
        original_unit: 'mg',
        normalized_value: 0.42,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b3: {
        original_value: 0.08,
        original_unit: 'mg',
        normalized_value: 0.08,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'preformed_niacin_only',
      },
      vitamin_b5: {
        original_value: 1.4,
        original_unit: 'mg',
        normalized_value: 1.4,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b6: {
        original_value: 0.14,
        original_unit: 'mg',
        normalized_value: 0.14,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b7: {
        original_value: 20,
        original_unit: 'µg',
        normalized_value: 20,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b9: {
        original_value: 44,
        original_unit: 'µg',
        normalized_value: 44,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b12: {
        original_value: 1.1,
        original_unit: 'µg',
        normalized_value: 1.1,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      calcium: {
        original_value: 56,
        original_unit: 'mg',
        normalized_value: 56,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      copper: {
        original_value: 0.07,
        original_unit: 'mg',
        normalized_value: 70,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'unit_scale',
      },
      iron: {
        original_value: 1.6,
        original_unit: 'mg',
        normalized_value: 1.6,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      phosphorus: {
        original_value: 192,
        original_unit: 'mg',
        normalized_value: 192,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      magnesium: {
        original_value: 12,
        original_unit: 'mg',
        normalized_value: 12,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      manganese: {
        original_value: 0.03,
        original_unit: 'mg',
        normalized_value: 0.03,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      potassium: {
        original_value: 132,
        original_unit: 'mg',
        normalized_value: 132,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      selenium: {
        original_value: 27,
        original_unit: 'µg',
        normalized_value: 27,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      sodium: {
        original_value: 198,
        original_unit: 'mg',
        normalized_value: 198,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      zinc: {
        original_value: 1.25,
        original_unit: 'mg',
        normalized_value: 1.25,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
    },
  },
  'tbca-pao-integral': {
    food_id: 'tbca-pao-integral',
    name: 'Pão de forma integral',
    source_id: 'TBCA',
    source_record_id: 'BRC0114C',
    source_version: 'TBCA 7.2',
    quality_status: 'verified_lab',
    macros: {
      kcalPerBasis: 253,
      proteinGPerBasis: 9.4,
      carbsGPerBasis: 47.5,
      fatGPerBasis: 3.1,
      basisQuantityG: 100,
    },
    micronutrients: {
      vitamin_a: {
        original_value: null,
        original_unit: 'µg RAE',
        normalized_value: null,
        normalized_unit: 'µg RAE',
        basis_quantity: 100,
        data_status: 'trace',
        conversion_method: 'direct_rae',
      },
      vitamin_b1: {
        original_value: 0.34,
        original_unit: 'mg',
        normalized_value: 0.34,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b2: {
        original_value: 0.16,
        original_unit: 'mg',
        normalized_value: 0.16,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b3: {
        original_value: 3.8,
        original_unit: 'mg',
        normalized_value: 3.8,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'preformed_niacin_only',
      },
      vitamin_b6: {
        original_value: 0.19,
        original_unit: 'mg',
        normalized_value: 0.19,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b7: {
        original_value: null,
        original_unit: 'µg',
        normalized_value: null,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'not_analyzed',
        conversion_method: 'unavailable',
      },
      vitamin_b9: {
        original_value: 82,
        original_unit: 'µg',
        normalized_value: 82,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      calcium: {
        original_value: 98,
        original_unit: 'mg',
        normalized_value: 98,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      iron: {
        original_value: 2.8,
        original_unit: 'mg',
        normalized_value: 2.8,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      magnesium: {
        original_value: 68,
        original_unit: 'mg',
        normalized_value: 68,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      phosphorus: {
        original_value: 194,
        original_unit: 'mg',
        normalized_value: 194,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      potassium: {
        original_value: 245,
        original_unit: 'mg',
        normalized_value: 245,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      manganese: {
        original_value: 1.45,
        original_unit: 'mg',
        normalized_value: 1.45,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      selenium: {
        original_value: 22,
        original_unit: 'µg',
        normalized_value: 22,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      sodium: {
        original_value: 448,
        original_unit: 'mg',
        normalized_value: 448,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      zinc: {
        original_value: 1.7,
        original_unit: 'mg',
        normalized_value: 1.7,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
    },
  },
  'tbca-mamao-aveia': {
    food_id: 'tbca-mamao-aveia',
    name: 'Mamão formosa com aveia em flocos',
    source_id: 'TITAN_LEGACY',
    source_record_id: 'TITAN-LEGACY-MAMAO-AVEIA',
    source_version: 'TITAN local legacy composite snapshot v1',
    quality_status: 'unverified',
    food_type: 'PREPARACAO_COMPOSTA',
    macros: {
      kcalPerBasis: 108,
      proteinGPerBasis: 3.1,
      carbsGPerBasis: 21.8,
      fatGPerBasis: 1.3,
      basisQuantityG: 100,
    },
    micronutrients: {
      vitamin_a: {
        original_value: 95,
        original_unit: 'µg RAE',
        normalized_value: 95,
        normalized_unit: 'µg RAE',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct_rae',
      },
      vitamin_c: {
        original_value: 52,
        original_unit: 'mg',
        normalized_value: 52,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_e: {
        original_value: 0.72,
        original_unit: 'mg',
        normalized_value: 0.72,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_k: {
        original_value: 3.8,
        original_unit: 'µg',
        normalized_value: 3.8,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b1: {
        original_value: 0.14,
        original_unit: 'mg',
        normalized_value: 0.14,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b5: {
        original_value: 0.42,
        original_unit: 'mg',
        normalized_value: 0.42,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b9: {
        original_value: 36,
        original_unit: 'µg',
        normalized_value: 36,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      calcium: {
        original_value: 31,
        original_unit: 'mg',
        normalized_value: 31,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      copper: {
        original_value: 0.12,
        original_unit: 'mg',
        normalized_value: 120,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'unit_scale',
      },
      magnesium: {
        original_value: 44,
        original_unit: 'mg',
        normalized_value: 44,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      manganese: {
        original_value: 0.68,
        original_unit: 'mg',
        normalized_value: 0.68,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      potassium: {
        original_value: 218,
        original_unit: 'mg',
        normalized_value: 218,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      sodium: {
        original_value: 4,
        original_unit: 'mg',
        normalized_value: 4,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      zinc: {
        original_value: 0.72,
        original_unit: 'mg',
        normalized_value: 0.72,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
    },
  },
  'tbca-frango-arroz-legumes': {
    food_id: 'tbca-frango-arroz-legumes',
    name: 'Peito de frango grelhado, arroz e legumes',
    source_id: 'TITAN_LEGACY',
    source_record_id: 'TITAN-LEGACY-FRANGO-ARROZ-LEGUMES',
    source_version: 'TITAN local legacy composite snapshot v1',
    quality_status: 'unverified',
    food_type: 'PREPARACAO_COMPOSTA',
    macros: {
      kcalPerBasis: 155,
      proteinGPerBasis: 11.25,
      carbsGPerBasis: 17.5,
      fatGPerBasis: 4.5,
      basisQuantityG: 100,
    },
    micronutrients: {
      vitamin_a: {
        original_value: 78,
        original_unit: 'µg RAE',
        normalized_value: 78,
        normalized_unit: 'µg RAE',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct_rae',
      },
      vitamin_c: {
        original_value: 14.5,
        original_unit: 'mg',
        normalized_value: 14.5,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_e: {
        original_value: 0.95,
        original_unit: 'mg',
        normalized_value: 0.95,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_k: {
        original_value: 22.5,
        original_unit: 'µg',
        normalized_value: 22.5,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b1: {
        original_value: 0.09,
        original_unit: 'mg',
        normalized_value: 0.09,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b2: {
        original_value: 0.08,
        original_unit: 'mg',
        normalized_value: 0.08,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b3: {
        original_value: 4.8,
        original_unit: 'mg',
        normalized_value: 4.8,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'preformed_niacin_only',
      },
      vitamin_b5: {
        original_value: 0.65,
        original_unit: 'mg',
        normalized_value: 0.65,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b6: {
        original_value: 0.34,
        original_unit: 'mg',
        normalized_value: 0.34,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b9: {
        original_value: 24,
        original_unit: 'µg',
        normalized_value: 24,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b12: {
        original_value: 0.18,
        original_unit: 'µg',
        normalized_value: 0.18,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      calcium: {
        original_value: 24,
        original_unit: 'mg',
        normalized_value: 24,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      copper: {
        original_value: 0.08,
        original_unit: 'mg',
        normalized_value: 80,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'unit_scale',
      },
      iron: {
        original_value: 0.72,
        original_unit: 'mg',
        normalized_value: 0.72,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      phosphorus: {
        original_value: 118,
        original_unit: 'mg',
        normalized_value: 118,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      magnesium: {
        original_value: 28,
        original_unit: 'mg',
        normalized_value: 28,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      manganese: {
        original_value: 0.24,
        original_unit: 'mg',
        normalized_value: 0.24,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      potassium: {
        original_value: 245,
        original_unit: 'mg',
        normalized_value: 245,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      selenium: {
        original_value: 12.5,
        original_unit: 'µg',
        normalized_value: 12.5,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      sodium: {
        original_value: 162,
        original_unit: 'mg',
        normalized_value: 162,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      zinc: {
        original_value: 0.85,
        original_unit: 'mg',
        normalized_value: 0.85,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
    },
  },
  'tbca-salmao-batata-doce': {
    food_id: 'tbca-salmao-batata-doce',
    name: 'Salmão assado, batata-doce e brócolis',
    source_id: 'TITAN_LEGACY',
    source_record_id: 'TITAN-LEGACY-SALMAO-BATATA-DOCE',
    source_version: 'TITAN local legacy composite snapshot v1',
    quality_status: 'unverified',
    food_type: 'PREPARACAO_COMPOSTA',
    macros: {
      kcalPerBasis: 168,
      proteinGPerBasis: 11.4,
      carbsGPerBasis: 16.2,
      fatGPerBasis: 6.1,
      basisQuantityG: 100,
    },
    micronutrients: {
      vitamin_a: {
        original_value: 215,
        original_unit: 'µg RAE',
        normalized_value: 215,
        normalized_unit: 'µg RAE',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct_rae',
      },
      vitamin_c: {
        original_value: 24,
        original_unit: 'mg',
        normalized_value: 24,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_d: {
        original_value: 6.4,
        original_unit: 'µg',
        normalized_value: 6.4,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_e: {
        original_value: 1.45,
        original_unit: 'mg',
        normalized_value: 1.45,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_k: {
        original_value: 32,
        original_unit: 'µg',
        normalized_value: 32,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b1: {
        original_value: 0.15,
        original_unit: 'mg',
        normalized_value: 0.15,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b2: {
        original_value: 0.16,
        original_unit: 'mg',
        normalized_value: 0.16,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b3: {
        original_value: 4.1,
        original_unit: 'mg',
        normalized_value: 4.1,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'preformed_niacin_only',
      },
      vitamin_b5: {
        original_value: 0.92,
        original_unit: 'mg',
        normalized_value: 0.92,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b6: {
        original_value: 0.36,
        original_unit: 'mg',
        normalized_value: 0.36,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b9: {
        original_value: 28,
        original_unit: 'µg',
        normalized_value: 28,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b12: {
        original_value: 1.95,
        original_unit: 'µg',
        normalized_value: 1.95,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      calcium: {
        original_value: 32,
        original_unit: 'mg',
        normalized_value: 32,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      copper: {
        original_value: 0.11,
        original_unit: 'mg',
        normalized_value: 110,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'unit_scale',
      },
      iron: {
        original_value: 0.65,
        original_unit: 'mg',
        normalized_value: 0.65,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      phosphorus: {
        original_value: 142,
        original_unit: 'mg',
        normalized_value: 142,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      magnesium: {
        original_value: 29,
        original_unit: 'mg',
        normalized_value: 29,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      manganese: {
        original_value: 0.19,
        original_unit: 'mg',
        normalized_value: 0.19,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      potassium: {
        original_value: 365,
        original_unit: 'mg',
        normalized_value: 365,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      selenium: {
        original_value: 19,
        original_unit: 'µg',
        normalized_value: 19,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      sodium: {
        original_value: 78,
        original_unit: 'mg',
        normalized_value: 78,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      zinc: {
        original_value: 0.55,
        original_unit: 'mg',
        normalized_value: 0.55,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
    },
  },
  'tbca-banana-prata': {
    food_id: 'tbca-banana-prata',
    name: 'Banana prata crua',
    source_id: 'TBCA',
    source_record_id: 'BRC0018B',
    source_version: 'TBCA 7.2',
    quality_status: 'verified_lab',
    macros: {
      kcalPerBasis: 98,
      proteinGPerBasis: 1.3,
      carbsGPerBasis: 26,
      fatGPerBasis: 0.1,
      basisQuantityG: 100,
    },
    micronutrients: {
      vitamin_a: {
        original_value: 8,
        original_unit: 'µg RE',
        normalized_value: null,
        normalized_unit: 'µg RAE',
        basis_quantity: 100,
        data_status: 'not_analyzed',
        conversion_method: 'tbca_re_preserved_unconverted',
      },
      vitamin_c: {
        original_value: 21.6,
        original_unit: 'mg',
        normalized_value: 21.6,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b6: {
        original_value: 0.36,
        original_unit: 'mg',
        normalized_value: 0.36,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      magnesium: {
        original_value: 28,
        original_unit: 'mg',
        normalized_value: 28,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      manganese: {
        original_value: 0.58,
        original_unit: 'mg',
        normalized_value: 0.58,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      potassium: {
        original_value: 358,
        original_unit: 'mg',
        normalized_value: 358,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      sodium: {
        original_value: null,
        original_unit: 'mg',
        normalized_value: null,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'trace',
        conversion_method: 'direct',
      },
    },
  },
};


type CompactTbcaFoodRow = [
  string, string, string | null, string | null, string | null, string | null, string | null,
  [number, number, number, number, number, number | null, number | null, number | null, number | null],
  Array<number | null>,
];

type NutrientMetaSpec = {
  id: NutrientId;
  originalUnit: string;
  normalizedUnit: string;
  conversion: 'direct' | 'direct_rae' | 'unit_scale';
};

const TBCA_NUTRIENT_COLUMNS: ReadonlyArray<NutrientMetaSpec> = [
  { id: 'vitamin_a', originalUnit: 'µg RAE', normalizedUnit: 'µg RAE', conversion: 'direct_rae' },
  { id: 'vitamin_c', originalUnit: 'mg', normalizedUnit: 'mg', conversion: 'direct' },
  { id: 'vitamin_d', originalUnit: 'µg', normalizedUnit: 'µg', conversion: 'direct' },
  { id: 'vitamin_e', originalUnit: 'mg', normalizedUnit: 'mg', conversion: 'direct' },
  { id: 'vitamin_b1', originalUnit: 'mg', normalizedUnit: 'mg', conversion: 'direct' },
  { id: 'vitamin_b2', originalUnit: 'mg', normalizedUnit: 'mg', conversion: 'direct' },
  { id: 'vitamin_b3', originalUnit: 'mg', normalizedUnit: 'mg', conversion: 'direct' },
  { id: 'vitamin_b6', originalUnit: 'mg', normalizedUnit: 'mg', conversion: 'direct' },
  { id: 'vitamin_b9', originalUnit: 'µg DFE', normalizedUnit: 'µg DFE', conversion: 'direct' },
  { id: 'vitamin_b12', originalUnit: 'µg', normalizedUnit: 'µg', conversion: 'direct' },
  { id: 'calcium', originalUnit: 'mg', normalizedUnit: 'mg', conversion: 'direct' },
  { id: 'copper', originalUnit: 'mg', normalizedUnit: 'µg', conversion: 'unit_scale' },
  { id: 'iron', originalUnit: 'mg', normalizedUnit: 'mg', conversion: 'direct' },
  { id: 'phosphorus', originalUnit: 'mg', normalizedUnit: 'mg', conversion: 'direct' },
  { id: 'magnesium', originalUnit: 'mg', normalizedUnit: 'mg', conversion: 'direct' },
  { id: 'manganese', originalUnit: 'mg', normalizedUnit: 'mg', conversion: 'direct' },
  { id: 'potassium', originalUnit: 'mg', normalizedUnit: 'mg', conversion: 'direct' },
  { id: 'selenium', originalUnit: 'µg', normalizedUnit: 'µg', conversion: 'direct' },
  { id: 'sodium', originalUnit: 'mg', normalizedUnit: 'mg', conversion: 'direct' },
  { id: 'zinc', originalUnit: 'mg', normalizedUnit: 'mg', conversion: 'direct' },
];

type TbcaNutrientCell = FoodSourceItem['micronutrients'][NutrientId];

const UNAVAILABLE_COL_ENTRIES: readonly TbcaNutrientCell[] = TBCA_NUTRIENT_COLUMNS.map((spec) => ({
  original_value: null,
  original_unit: spec.originalUnit,
  normalized_value: null,
  normalized_unit: spec.normalizedUnit,
  basis_quantity: 100,
  data_status: 'not_analyzed',
  conversion_method: 'unavailable',
}));

const UNAVAILABLE_VITAMIN_K: TbcaNutrientCell = {
  original_value: null,
  original_unit: 'µg',
  normalized_value: null,
  normalized_unit: 'µg',
  basis_quantity: 100,
  data_status: 'not_analyzed',
  conversion_method: 'unavailable',
};
const UNAVAILABLE_VITAMIN_B5: TbcaNutrientCell = {
  original_value: null,
  original_unit: 'mg',
  normalized_value: null,
  normalized_unit: 'mg',
  basis_quantity: 100,
  data_status: 'not_analyzed',
  conversion_method: 'unavailable',
};
const UNAVAILABLE_VITAMIN_B7: TbcaNutrientCell = {
  original_value: null,
  original_unit: 'µg',
  normalized_value: null,
  normalized_unit: 'µg',
  basis_quantity: 100,
  data_status: 'not_analyzed',
  conversion_method: 'unavailable',
};

function mapCompactTbcaFood(row: CompactTbcaFoodRow): FoodSourceItem {
  const [code, name, group, foodType, state, preparation, sourceUrl, macroValues, nutrientValues] = row;
  const [kcal, protein, carbs, fat, basis, fiber, saturatedFat, cholesterol, sodium] = macroValues;
  const micronutrients: FoodSourceItem['micronutrients'] = {
    vitamin_k: UNAVAILABLE_VITAMIN_K,
    vitamin_b5: UNAVAILABLE_VITAMIN_B5,
    vitamin_b7: UNAVAILABLE_VITAMIN_B7,
  };
  for (let index = 0; index < TBCA_NUTRIENT_COLUMNS.length; index += 1) {
    const spec = TBCA_NUTRIENT_COLUMNS[index]!;
    const originalValue = nutrientValues[index] ?? null;
    micronutrients[spec.id] =
      originalValue === null
        ? UNAVAILABLE_COL_ENTRIES[index]!
        : {
            original_value: originalValue,
            original_unit: spec.originalUnit,
            normalized_value: spec.conversion === 'unit_scale' ? originalValue * 1000 : originalValue,
            normalized_unit: spec.normalizedUnit,
            basis_quantity: 100,
            data_status: 'quantified',
            conversion_method: spec.conversion,
          };
  }
  return {
    food_id: `tbca:${code}`,
    name,
    source_id: 'TBCA',
    source_record_id: code,
    source_version: 'TBCA 7.2 · Planejamento_Nutricional_Final',
    quality_status: 'reference_database',
    source_url: sourceUrl ?? undefined,
    source_group: group ?? undefined,
    food_type: foodType ?? undefined,
    state: state ?? undefined,
    preparation: preparation ?? undefined,
    search_text: [name, group, foodType, state, preparation].filter(Boolean).join(' ').toLowerCase(),
    macros: {
      kcalPerBasis: kcal,
      proteinGPerBasis: protein,
      carbsGPerBasis: carbs,
      fatGPerBasis: fat,
      basisQuantityG: basis,
      fiberGPerBasis: fiber,
      saturatedFatGPerBasis: saturatedFat,
      cholesterolMgPerBasis: cholesterol,
      sodiumMgPerBasis: sodium,
    },
    micronutrients,
  };
}

const TBCA_LEGACY_CANONICAL_ALIASES: Readonly<Record<string, string>> = {
  // Historical IDs remain stable for saved recipes; data and provenance now come from canonical TBCA rows.
  'tbca-ovo-mexido': 'tbca:BRC0065J',
  'tbca-pao-integral': 'tbca:BRC0149A',
  'tbca-banana-prata': 'tbca:BRC0011C',
};

const COMPACT_ROW_BY_FOOD_ID = new Map<string, CompactTbcaFoodRow>();
const HYDRATED_TBCA_CACHE = new Map<string, FoodSourceItem>(Object.entries(LEGACY_TBCA_FOODS));
const ALL_TBCA_KEYS: string[] = Object.keys(LEGACY_TBCA_FOODS).filter((key) => !(key in TBCA_LEGACY_CANONICAL_ALIASES));
const TBCA_LOADED_LISTENERS = new Set<() => void>();
let compactRowsPopulated = false;

function registerCompactRows(rows: readonly CompactTbcaCatalogRow[]): boolean {
  if (compactRowsPopulated || rows.length === 0) return false;
  for (const row of rows) {
    const key = `tbca:${row[0]}`;
    if (!COMPACT_ROW_BY_FOOD_ID.has(key)) {
      COMPACT_ROW_BY_FOOD_ID.set(key, row);
      ALL_TBCA_KEYS.push(key);
    }
  }
  compactRowsPopulated = true;
  return true;
}

registerCompactRows(readInitialCompactTbcaCatalogSync());

export function isTbcaCatalogLoaded(): boolean {
  return compactRowsPopulated || isCompactTbcaCatalogLoaded();
}

export function onTbcaCatalogLoaded(listener: () => void): () => void {
  TBCA_LOADED_LISTENERS.add(listener);
  return () => {
    TBCA_LOADED_LISTENERS.delete(listener);
  };
}

export async function ensureTbcaCatalogLoaded(): Promise<boolean> {
  if (compactRowsPopulated) return false;
  const rows = await ensureCompactTbcaCatalogAsync();
  const changed = registerCompactRows(rows);
  if (changed) {
    for (const listener of TBCA_LOADED_LISTENERS) {
      listener();
    }
  }
  return changed;
}

function getTbcaFoodByKey(foodId: string): FoodSourceItem | undefined {
  const canonicalAlias = TBCA_LEGACY_CANONICAL_ALIASES[foodId];
  if (canonicalAlias) {
    const aliasCached = HYDRATED_TBCA_CACHE.get(foodId);
    if (aliasCached?.source_record_id === 'BRC0065J' || aliasCached?.source_record_id === 'BRC0149A' || aliasCached?.source_record_id === 'BRC0011C') {
      return aliasCached;
    }
    const canonicalRow = COMPACT_ROW_BY_FOOD_ID.get(canonicalAlias);
    if (!canonicalRow) return undefined;
    const canonicalFood = mapCompactTbcaFood(canonicalRow);
    const aliasFood = { ...canonicalFood, food_id: foodId };
    HYDRATED_TBCA_CACHE.set(foodId, aliasFood);
    return aliasFood;
  }
  const cached = HYDRATED_TBCA_CACHE.get(foodId);
  if (cached) return cached;
  const row = COMPACT_ROW_BY_FOOD_ID.get(foodId);
  if (!row) return undefined;
  const item = mapCompactTbcaFood(row);
  HYDRATED_TBCA_CACHE.set(foodId, item);
  return item;
}

/** 5,830 TBCA source rows plus compatibility aliases and explicitly attributed local legacy composite snapshots. */
export const TBCA_FOODS: Record<string, FoodSourceItem> = new Proxy<Record<string, FoodSourceItem>>(
  {},
  {
    get(_target, prop) {
      if (typeof prop !== 'string') return undefined;
      return getTbcaFoodByKey(prop);
    },
    has(_target, prop) {
      if (typeof prop !== 'string') return false;
      return HYDRATED_TBCA_CACHE.has(prop) || COMPACT_ROW_BY_FOOD_ID.has(prop);
    },
    ownKeys() {
      return ALL_TBCA_KEYS;
    },
    getOwnPropertyDescriptor(_target, prop) {
      if (typeof prop !== 'string') return undefined;
      const value = getTbcaFoodByKey(prop);
      if (!value) return undefined;
      return {
        enumerable: true,
        configurable: true,
        writable: false,
        value,
      };
    },
  },
);
