import assert from 'node:assert/strict';
import { parseUsdaFdcFoods, registerUsdaFdcFoods, getRegisteredUsdaFdcFood, getRegisteredUsdaFdcFoods } from '../usda-fdc-adapter.ts';
import { resolveFoodById } from '../../../domain/rules/nutrition-calculator.ts';

const raw = [{
  fdcId: 12345, description: 'Test food', dataType: 'Foundation', publicationDate: '2026-10-29',
  foodNutrients: [
    { nutrient: { id: 1003, number: '203', name: 'Protein', unitName: 'g' }, amount: 12 },
    { nutrient: { id: 1004, number: '204', name: 'Total lipid (fat)', unitName: 'g' }, amount: 4 },
    { nutrient: { id: 1005, number: '205', name: 'Carbohydrate, by difference', unitName: 'g' }, amount: 20 },
    { nutrient: { id: 2048, number: '958', name: 'Energy (Atwater Specific Factors)', unitName: 'kcal' }, amount: 164 },
    { nutrient: { id: 1087, number: '301', name: 'Calcium, Ca', unitName: 'mg' }, amount: 33 },
    { nutrient: { id: 1106, number: '320', name: 'Vitamin A, RAE', unitName: 'µg' }, amount: 12 },
    { nutrient: { id: 1190, number: '435', name: 'Folate, DFE', unitName: 'µg' }, amount: 41 },
    { nutrient: { id: 1098, number: '312', name: 'Copper, Cu', unitName: 'mg' }, amount: 1 },
    { nutrient: { id: 1167, number: '406', name: 'Niacin', unitName: 'mg' }, amount: 5 },
    { nutrient: { id: 1185, number: '430', name: 'Vitamin K (phylloquinone)', unitName: 'µg' }, amount: 18 },
    { nutrient: { id: 999999, number: '99999', name: 'Unknown nutrient', unitName: 'mg' }, amount: 7 },
    { nutrient: { id: 1089, number: '303', name: 'Iron, Fe', unitName: 'µg' }, amount: 1.2 },
  ],
}];
const parsed = parseUsdaFdcFoods(raw, { releaseVersion: '2026-10-29', dataType: 'Foundation' });
assert.equal(parsed.foods.length, 1);
assert.equal(parsed.foods[0].food_id, 'usda-fdc:12345');
assert.equal(parsed.foods[0].macros.kcalPerBasis, 164);
assert.equal(parsed.foods[0].macros.basisQuantityG, 100);
assert.equal(parsed.foods[0].micronutrients.calcium.normalized_value, 33);
assert.equal(parsed.foods[0].micronutrients.iron.data_status, 'unit_mismatch');
assert.equal(parsed.quarantinedNutrients.length, 4);
assert.equal(parsed.quarantinedNutrients.some((n) => n.nutrientId === 999999), true);
assert.equal(parsed.foods[0].source_id, 'USDA_FDC');
assert.equal(parsed.rejectedFoods.length, 0);
assert.throws(() => parseUsdaFdcFoods(raw, { releaseVersion: 'v', dataType: 'Foundation', sourceUrl: 'javascript:alert(1)' }));
assert.throws(() => parseUsdaFdcFoods(raw, { releaseVersion: 'v', dataType: 'Foundation', sourceUrl: 'https://fdc.nal.usda.gov.attacker.example/dataset.zip' }),
  'USDA provenance must be pinned to the official FDC hostname, not an arbitrary HTTPS URL');

const atwaterGeneralFallback = parseUsdaFdcFoods([{
  ...raw[0], fdcId: 12353,
  foodNutrients: raw[0].foodNutrients.filter((item) => item.nutrient.number !== '958').concat([
    { nutrient: { id: 2047, number: '957', name: 'Energy (Atwater General Factors)', unitName: 'kcal' }, amount: 158 },
  ]),
}], { releaseVersion: '2026-10-29', dataType: 'Foundation' });
assert.equal(atwaterGeneralFallback.foods[0].macros.kcalPerBasis, 158,
  'Atwater general factors are preferred over the generic energy row when specific factors are absent');

const genericEnergyFallback = parseUsdaFdcFoods([{
  ...raw[0], fdcId: 12354,
  foodNutrients: raw[0].foodNutrients.filter((item) => item.nutrient.number !== '958').concat([
    { nutrient: { id: 1008, number: '208', name: 'Energy', unitName: 'kcal' }, amount: 151 },
  ]),
}], { releaseVersion: '2026-10-29', dataType: 'Foundation' });
assert.equal(genericEnergyFallback.foods[0].macros.kcalPerBasis, 151,
  'when specific/general Atwater rows are absent, an actual generic Energy row is the fallback');

const missingEnergy = parseUsdaFdcFoods([{
  ...raw[0], fdcId: 12355,
  foodNutrients: raw[0].foodNutrients.filter((item) => !['958', '957', '208'].includes(item.nutrient.number)),
}], { releaseVersion: '2026-10-29', dataType: 'Foundation' });
assert.equal(missingEnergy.foods.length, 0,
  'missing energy must reject the record rather than fabricate 0 kcal');
assert.equal(missingEnergy.rejectedFoods[0].reason, 'required_macro_or_energy_missing');

const wrongDatatype = parseUsdaFdcFoods([{ ...raw[0], fdcId: 4, dataType: 'SR Legacy' }], { releaseVersion: 'v', dataType: 'Foundation' });
assert.equal(wrongDatatype.foods.length, 0);
assert.equal(wrongDatatype.rejectedFoods[0].reason, 'dataset_data_type_mismatch');
const missingMacros = parseUsdaFdcFoods([{ fdcId: 2, description: 'Incomplete', foodNutrients: [] }], { releaseVersion: 'v', dataType: 'Foundation' });
assert.equal(missingMacros.foods.length, 0);
assert.equal(missingMacros.rejectedFoods[0].reason, 'required_macro_or_energy_missing');
registerUsdaFdcFoods(parsed.foods);
assert.equal(getRegisteredUsdaFdcFood('usda-fdc:12345')?.source_record_id, '12345');
assert.equal(resolveFoodById('usda-fdc:12345')?.source_id, 'USDA_FDC');
console.log('USDA FDC adapter tests passed.');
assert.equal(parsed.foods[0].micronutrients.vitamin_a.normalized_unit, 'µg RAE',
  'USDA vitamin A values are expressed as retinol activity equivalents in the canonical nutrient model');
assert.equal(parsed.foods[0].micronutrients.vitamin_b9.normalized_unit, 'µg DFE',
  'USDA folate DFE must retain the DFE basis');
assert.equal(parsed.foods[0].micronutrients.copper.normalized_value, 1000,
  'USDA copper mg values must be scaled into the canonical µg unit');
assert.equal(parsed.foods[0].micronutrients.vitamin_b3, undefined,
  'USDA niacin mass alone cannot be treated as total niacin equivalents');
assert.equal(parsed.foods[0].micronutrients.vitamin_k, undefined,
  'phylloquinone alone is not an unqualified total vitamin K value');

const wrongEnvelope = parseUsdaFdcFoods({ FoundationFoods: raw }, { releaseVersion: '2026-10-29', dataType: 'SR Legacy' });
assert.equal(wrongEnvelope.foods.length, 0, 'USDA dataset envelope must match declared source dataType');
assert.equal(wrongEnvelope.rejectedFoods[0].reason, 'dataset_envelope_data_type_mismatch');
assert.throws(() => parseUsdaFdcFoods(raw, { releaseVersion: 'v', dataType: 'Foundation', datasetSha256: 'not-a-sha' }));

const conflictingMicronutrients = parseUsdaFdcFoods([{
  ...raw[0], fdcId: 12346,
  foodNutrients: [...raw[0].foodNutrients,
    { nutrient: { id: 1087, number: '301', name: 'Calcium, Ca', unitName: 'mg' }, amount: 99 }],
}], { releaseVersion: '2026-10-29', dataType: 'Foundation' });
assert.equal(conflictingMicronutrients.foods.length, 1);
assert.equal(conflictingMicronutrients.foods[0].micronutrients.calcium.data_status, 'unit_mismatch',
  'conflicting duplicate nutrient values must never be resolved by array order');
assert.equal(conflictingMicronutrients.foods[0].micronutrients.calcium.normalized_value, null);
assert.equal(conflictingMicronutrients.quarantinedNutrients.filter((item) => item.fdcId === '12346' && item.nutrientId === 1087).length, 2);
assert.ok(conflictingMicronutrients.quarantinedNutrients.some((item) => item.reason === 'duplicate_conflict'));

const conflictingMacros = parseUsdaFdcFoods([{
  ...raw[0], fdcId: 12347,
  foodNutrients: [...raw[0].foodNutrients,
    { nutrient: { id: 1003, number: '203', name: 'Protein', unitName: 'g' }, amount: 18 }],
}], { releaseVersion: '2026-10-29', dataType: 'Foundation' });
assert.equal(conflictingMacros.foods.length, 0,
  'conflicting duplicate macro rows must reject the food instead of selecting the first row');
assert.equal(conflictingMacros.rejectedFoods[0].reason, 'duplicate_macro_conflict');

const identicalDuplicates = parseUsdaFdcFoods([{
  ...raw[0], fdcId: 12348,
  foodNutrients: [...raw[0].foodNutrients,
    { nutrient: { id: 1087, number: '301', name: 'Calcium, Ca', unitName: 'mg' }, amount: 33 }],
}], { releaseVersion: '2026-10-29', dataType: 'Foundation' });
assert.equal(identicalDuplicates.foods[0].micronutrients.calcium.normalized_value, 33,
  'identical duplicate source rows can be collapsed deterministically');
assert.equal(identicalDuplicates.quarantinedNutrients.length, 4);


const enrichedFood = parseUsdaFdcFoods([{
  ...raw[0], fdcId: 12347,
  foodNutrients: [...raw[0].foodNutrients,
    { nutrient: { id: 1079, number: '291', name: 'Fiber, total dietary', unitName: 'g' }, amount: 2.5 },
    { nutrient: { id: 1258, number: '606', name: 'Fatty acids, total saturated', unitName: 'g' }, amount: 1.2 },
    { nutrient: { id: 1253, number: '601', name: 'Cholesterol', unitName: 'mg' }, amount: 12 },
    { nutrient: { id: 1093, number: '307', name: 'Sodium, Na', unitName: 'mg' }, amount: 320 },
  ],
}], { releaseVersion: '2026-10-29', dataType: 'Foundation' });
assert.equal(enrichedFood.foods[0].macros.fiberGPerBasis, 2.5,
  'USDA fiber must populate the existing dietary metric field');
assert.equal(enrichedFood.foods[0].macros.saturatedFatGPerBasis, 1.2,
  'USDA saturated fat must populate the existing dietary metric field');
assert.equal(enrichedFood.foods[0].macros.cholesterolMgPerBasis, 12,
  'USDA cholesterol must populate the existing dietary metric field');
assert.equal(enrichedFood.foods[0].macros.sodiumMgPerBasis, 320,
  'USDA sodium must populate the existing preparation metric field');
assert.equal(enrichedFood.foods[0].micronutrients.sodium.normalized_value, 320,
  'sodium remains a canonical micronutrient as well as a food macro metric');


const mismatchedPermanentId = parseUsdaFdcFoods([{
  ...raw[0], fdcId: 12351,
  foodNutrients: [...raw[0].foodNutrients,
    { nutrient: { id: 1089, number: '301', name: 'Calcium, Ca', unitName: 'mg' }, amount: 44 }],
}], { releaseVersion: '2026-10-29', dataType: 'Foundation' });
assert.equal(mismatchedPermanentId.foods[0].micronutrients.calcium.data_status, 'unit_mismatch',
  'the permanent FDC nutrient ID and historical nutrient number must both match the reviewed crosswalk');
assert.ok(mismatchedPermanentId.quarantinedNutrients.some((item) =>
  item.fdcId === '12351' && item.nutrientId === 1089 && item.nutrientNumber === '301' && item.reason === 'id_number_mismatch'));

const legacyNumberUsedAsPermanentId = parseUsdaFdcFoods([{
  ...raw[0], fdcId: 12352,
  foodNutrients: raw[0].foodNutrients.map((item) => item.nutrient.number === '203'
    ? { ...item, nutrient: { ...item.nutrient, id: 203 } }
    : item),
}], { releaseVersion: '2026-10-29', dataType: 'Foundation' });
assert.equal(legacyNumberUsedAsPermanentId.foods.length, 0,
  'legacy nutrient number 203 must not be mistaken for the permanent FDC nutrient ID 1003');

const duplicateFoodIdentity = parseUsdaFdcFoods([
  { ...raw[0], fdcId: 12348 },
  { ...raw[0], fdcId: 12348, description: 'Conflicting duplicate source row' },
], { releaseVersion: '2026-10-29', dataType: 'Foundation' });
assert.equal(duplicateFoodIdentity.foods.length, 0,
  'all copies of a duplicated FDC identity must be rejected rather than selecting by row order');
assert.equal(duplicateFoodIdentity.rejectedFoods.filter((food) => food.reason === 'duplicate_fdc_id').length, 2);

const duplicateIdAfterRejectedRow = parseUsdaFdcFoods([
  { fdcId: 12349, description: 'First incomplete version', dataType: 'Foundation', foodNutrients: [] },
  { ...raw[0], fdcId: 12349, description: 'Second competing version' },
], { releaseVersion: '2026-10-29', dataType: 'Foundation' });
assert.equal(duplicateIdAfterRejectedRow.foods.length, 0,
  'a rejected row must still reserve its FDC ID; later competing rows cannot silently replace it');
assert.ok(duplicateIdAfterRejectedRow.rejectedFoods.some((food) => food.fdcId === '12349' && food.reason === 'duplicate_fdc_id'));

const optionalMacroConflict = parseUsdaFdcFoods([{
  ...raw[0], fdcId: 12349,
  foodNutrients: [...raw[0].foodNutrients,
    { nutrient: { id: 1079, number: '291', name: 'Fiber, total dietary', unitName: 'g' }, amount: 2.5 },
    { nutrient: { id: 1079, number: '291', name: 'Fiber, total dietary', unitName: 'g' }, amount: 4.0 },
  ],
}], { releaseVersion: '2026-10-29', dataType: 'Foundation' });
assert.equal(optionalMacroConflict.foods[0].macros.fiberGPerBasis, null,
  'conflicting optional macro values must remain explicitly unquantified');
assert.ok(optionalMacroConflict.quarantinedNutrients.some((item) =>
  item.nutrientId === 1079 && item.reason === 'duplicate_conflict'));
assert.equal(enrichedFood.foods[0].source_url, 'https://fdc.nal.usda.gov/food-details/12347/nutrients',
  'food provenance points to the individual FDC record, not the dataset download landing page');

assert.throws(() => registerUsdaFdcFoods([{
  ...parsed.foods[0], macros: { ...parsed.foods[0].macros, proteinGPerBasis: Number.POSITIVE_INFINITY },
}]), /Registro USDA inválido/i,
'public catalog registration must revalidate source identity and the numeric composition boundary');
assert.equal(getRegisteredUsdaFdcFood('usda-fdc:12345')?.macros.proteinGPerBasis, 12,
  'a rejected runtime catalog replacement must not clear the last valid catalog');

const secondRegisteredFood = parseUsdaFdcFoods([{ ...raw[0], fdcId: 12350, description: 'Second data source food' }], {
  releaseVersion: '2026-10-29', dataType: 'Foundation',
}).foods;
registerUsdaFdcFoods(secondRegisteredFood);
assert.ok(getRegisteredUsdaFdcFood('usda-fdc:12345'), 'registering a later batch must not erase earlier registered FDC data');
assert.ok(getRegisteredUsdaFdcFood('usda-fdc:12350'));
assert.equal(getRegisteredUsdaFdcFoods().filter((food) => food.food_id === 'usda-fdc:12345' || food.food_id === 'usda-fdc:12350').length, 2);
assert.throws(() => registerUsdaFdcFoods([secondRegisteredFood[0], secondRegisteredFood[0]]), /duplicado/i,
  'duplicate identities in one registration batch must be rejected before mutating the active catalog');
assert.ok(getRegisteredUsdaFdcFood('usda-fdc:12350'), 'a rejected registration batch must not mutate the active catalog');

const additionalMinerals = parseUsdaFdcFoods([{
  ...raw[0], fdcId: 12360,
  foodNutrients: [
    ...raw[0].foodNutrients.filter((row) => [1003, 1004, 1005, 2048].includes(row.nutrient.id)),
    { nutrient: { id: 1096, number: '310', name: 'Chromium, Cr', unitName: 'µg' }, amount: 12 },
    { nutrient: { id: 1099, number: '313', name: 'Fluoride, F', unitName: 'µg' }, amount: 18 },
    { nutrient: { id: 1100, number: '314', name: 'Iodine, I', unitName: 'µg' }, amount: 22 },
    { nutrient: { id: 1102, number: '316', name: 'Molybdenum, Mo', unitName: 'µg' }, amount: 8 },
  ],
}], { releaseVersion: '2026-10-29', dataType: 'Foundation' });
assert.equal(additionalMinerals.foods[0].micronutrients.chromium.normalized_value, 12,
  'FDC chromium ID/number/name/unit must map to the canonical micronutrient');
assert.equal(additionalMinerals.foods[0].micronutrients.fluoride.normalized_value, 18,
  'FDC fluoride ID/number/name/unit must map to the canonical micronutrient');
assert.equal(additionalMinerals.foods[0].micronutrients.iodine.normalized_value, 22,
  'FDC iodine ID/number/name/unit must map to the canonical micronutrient');
assert.equal(additionalMinerals.foods[0].micronutrients.molybdenum.normalized_value, 8,
  'FDC molybdenum ID/number/name/unit must map to the canonical micronutrient');

const fdcNutrient = (id, number, name, unitName, amount) => ({
  nutrient: { id, number, name, unitName }, amount,
});
const parseNiacinFixture = (fdcId, componentRows) => parseUsdaFdcFoods([{
  ...raw[0], fdcId,
  foodNutrients: [
    ...raw[0].foodNutrients.filter((item) => item.nutrient.number !== '406'),
    ...componentRows,
  ],
}], { releaseVersion: '2026-10-29', dataType: 'Foundation' });

const tryptophanDerived = parseNiacinFixture(12401, [
  fdcNutrient(1167, '406', 'Niacin', 'mg', 5),
  fdcNutrient(1210, '501', 'Tryptophan', 'g', 0.6),
]);
assert.equal(tryptophanDerived.foods[0].micronutrients.vitamin_b3.normalized_value, 15,
  '5 mg niacin + 0.6 g tryptophan must equal 15 mg NE per 100 g');
assert.equal(tryptophanDerived.foods[0].micronutrients.vitamin_b3.normalized_unit, 'mg NE');
assert.equal(tryptophanDerived.foods[0].micronutrients.vitamin_b3.conversion_method, 'niacin_equivalent_from_components');
assert.equal(tryptophanDerived.foods[0].micronutrients.vitamin_b3.derivation.components.length, 2,
  'the computed NE must retain both exact FDC source components');
assert.equal(tryptophanDerived.foods[0].micronutrients.vitamin_b3.derivation.components[1].fdc_nutrient_id, 1210);

const fdcMeasuredNiacinEquivalent = parseNiacinFixture(12402, [
  fdcNutrient(1167, '406', 'Niacin', 'mg', 5),
  fdcNutrient(1168, '407', 'Niacin from tryptophan, determined', 'mg', 2.5),
  fdcNutrient(1210, '501', 'Tryptophan', 'g', 0.6),
]);
assert.equal(fdcMeasuredNiacinEquivalent.foods[0].micronutrients.vitamin_b3.normalized_value, 7.5,
  'FDC N407 is already the tryptophan-derived equivalent and must not be added to N501 again');
assert.equal(fdcMeasuredNiacinEquivalent.foods[0].micronutrients.vitamin_b3.derivation.components.length, 2);

const directNiacinEquivalent = parseNiacinFixture(12403, [
  fdcNutrient(1167, '406', 'Niacin', 'mg', 5),
  fdcNutrient(1168, '407', 'Niacin from tryptophan, determined', 'mg', 2.5),
  fdcNutrient(1169, '409', 'Niacin equivalent N406 +N407', 'mg', 9.25),
]);
assert.equal(directNiacinEquivalent.foods[0].micronutrients.vitamin_b3.normalized_value, 9.25,
  'explicit USDA N409 takes precedence over derivation from its components');
assert.equal(directNiacinEquivalent.foods[0].micronutrients.vitamin_b3.conversion_method, 'direct');
assert.equal(directNiacinEquivalent.foods[0].micronutrients.vitamin_b3.derivation, undefined);
assert.deepEqual(directNiacinEquivalent.foods[0].micronutrients.vitamin_b3.source_evidence, {
  fdc_nutrient_id: 1169, nutrient_number: '409', nutrient_name: 'Niacin equivalent N406 +N407', value: 9.25, unit: 'mg',
}, 'direct N409 values must retain the exact source nutrient identity for runtime revalidation');
registerUsdaFdcFoods(directNiacinEquivalent.foods);
assert.equal(getRegisteredUsdaFdcFood('usda-fdc:12403')?.micronutrients.vitamin_b3.normalized_value, 9.25,
  'direct N409 evidence must survive the runtime catalog boundary');
assert.throws(() => registerUsdaFdcFoods([{
  ...directNiacinEquivalent.foods[0],
  micronutrients: { ...directNiacinEquivalent.foods[0].micronutrients, vitamin_b3: {
    ...directNiacinEquivalent.foods[0].micronutrients.vitamin_b3,
    source_evidence: { ...directNiacinEquivalent.foods[0].micronutrients.vitamin_b3.source_evidence, fdc_nutrient_id: 9999 },
  } },
}]), /Registro USDA inválido/i, 'runtime registration must reject forged direct N409 evidence');
assert.throws(() => registerUsdaFdcFoods([{
  ...directNiacinEquivalent.foods[0],
  micronutrients: { ...directNiacinEquivalent.foods[0].micronutrients, vitamin_b3: {
    ...directNiacinEquivalent.foods[0].micronutrients.vitamin_b3,
    source_evidence: undefined,
  } },
}]), /Registro USDA inválido/i, 'runtime registration must not trust a direct mg NE value without a source identity');
assert.throws(() => registerUsdaFdcFoods([{
  ...directNiacinEquivalent.foods[0],
  micronutrients: { ...directNiacinEquivalent.foods[0].micronutrients, vitamin_b3: {
    ...directNiacinEquivalent.foods[0].micronutrients.vitamin_b3,
    conversion_method: 'unit_scale',
    source_evidence: undefined,
  } },
}]), /Registro USDA inválido/i,
'no other conversion method may bypass the FDC 409 or component evidence requirement for mg NE');

const mismatchedNiacinNumber = parseNiacinFixture(12413, [
  fdcNutrient(1167, '406.1', 'Niacin', 'mg', 5),
  fdcNutrient(1210, '501', 'Tryptophan', 'g', 0.6),
]);
assert.equal(mismatchedNiacinNumber.foods[0].micronutrients.vitamin_b3, undefined,
  'the FDC historical nutrient number must exactly match permanent ID 1167');
assert.ok(mismatchedNiacinNumber.quarantinedNutrients.some((row) => row.nutrientNumber === '406.1' && row.reason === 'id_number_mismatch'));

const mismatchedNiacinName = parseNiacinFixture(12408, [
  fdcNutrient(1167, '406', 'Niacin, added', 'mg', 5),
  fdcNutrient(1210, '501', 'Tryptophan', 'g', 0.6),
]);
assert.equal(mismatchedNiacinName.foods[0].micronutrients.vitamin_b3, undefined,
  'a similar but different FDC nutrient name must not be accepted as preformed niacin');
assert.ok(mismatchedNiacinName.quarantinedNutrients.some((row) => row.nutrientNumber === '406' && row.reason === 'name_or_unit_mismatch'));

const mismatchedDirectNiacinId = parseNiacinFixture(12409, [
  fdcNutrient(9999, '409', 'Niacin equivalent N406 +N407', 'mg', 9.25),
]);
assert.equal(mismatchedDirectNiacinId.foods[0].micronutrients.vitamin_b3, undefined,
  'a mismatched permanent nutrient ID must not be accepted for direct N409');
assert.ok(mismatchedDirectNiacinId.quarantinedNutrients.some((row) => row.nutrientNumber === '409' && row.reason === 'id_number_mismatch'));

const preformedNiacinOnly = parseNiacinFixture(12410, [fdcNutrient(1167, '406', 'Niacin', 'mg', 5)]);
assert.equal(preformedNiacinOnly.foods[0].micronutrients.vitamin_b3, undefined,
  'preformed niacin by itself must not be promoted to total mg NE');
assert.ok(preformedNiacinOnly.quarantinedNutrients.some((row) => row.nutrientNumber === '406' && row.reason === 'unsupported_semantic_mapping'));

const invalidNiacinAmount = parseNiacinFixture(12411, [
  fdcNutrient(1167, '406', 'Niacin', 'mg', -1),
  fdcNutrient(1210, '501', 'Tryptophan', 'g', 0.6),
]);
assert.equal(invalidNiacinAmount.foods[0].micronutrients.vitamin_b3, undefined,
  'negative source nutrient values must not participate in the NE formula');
assert.ok(invalidNiacinAmount.quarantinedNutrients.some((row) => row.nutrientNumber === '406' && row.reason === 'invalid_amount'));

const nonFiniteTryptophanAmount = parseNiacinFixture(12412, [
  fdcNutrient(1167, '406', 'Niacin', 'mg', 5),
  fdcNutrient(1210, '501', 'Tryptophan', 'g', Number.POSITIVE_INFINITY),
]);
assert.equal(nonFiniteTryptophanAmount.foods[0].micronutrients.vitamin_b3, undefined,
  'non-finite source nutrient values must not participate in the NE formula');
assert.ok(nonFiniteTryptophanAmount.quarantinedNutrients.some((row) => row.nutrientNumber === '501' && row.reason === 'invalid_amount'));

const overflowMeasuredNiacin = parseNiacinFixture(12414, [
  fdcNutrient(1167, '406', 'Niacin', 'mg', 1e308),
  fdcNutrient(1168, '407', 'Niacin from tryptophan, determined', 'mg', 1e308),
]);
assert.equal(overflowMeasuredNiacin.foods[0].micronutrients.vitamin_b3, undefined,
  'a finite component pair whose sum overflows must not emit infinite niacin equivalents');
assert.ok(overflowMeasuredNiacin.quarantinedNutrients.some((row) => row.nutrientNumber === '406' && row.reason === 'invalid_amount'));

const overflowTryptophanNiacin = parseNiacinFixture(12415, [
  fdcNutrient(1167, '406', 'Niacin', 'mg', 5),
  fdcNutrient(1210, '501', 'Tryptophan', 'g', 1e308),
]);
assert.equal(overflowTryptophanNiacin.foods[0].micronutrients.vitamin_b3, undefined,
  'tryptophan unit conversion overflow must fail closed');
assert.ok(overflowTryptophanNiacin.quarantinedNutrients.some((row) => row.nutrientNumber === '501' && row.reason === 'invalid_amount'));

const overflowPreferredWithFallback = parseNiacinFixture(12416, [
  fdcNutrient(1167, '406', 'Niacin', 'mg', 1e308),
  fdcNutrient(1168, '407', 'Niacin from tryptophan, determined', 'mg', 1e308),
  fdcNutrient(1210, '501', 'Tryptophan', 'g', 0.6),
]);
assert.equal(overflowPreferredWithFallback.foods[0].micronutrients.vitamin_b3, undefined,
  'overflow in the preferred measured 406+407 path must not be hidden by falling back to 406+501');
assert.ok(overflowPreferredWithFallback.quarantinedNutrients.some((row) => row.nutrientNumber === '407' && row.reason === 'invalid_amount'));

const tryptophanOnly = parseNiacinFixture(12404, [fdcNutrient(1210, '501', 'Tryptophan', 'g', 0.6)]);
assert.equal(tryptophanOnly.foods[0].micronutrients.vitamin_b3, undefined,
  'tryptophan alone must not imply preformed niacin is zero');
assert.ok(tryptophanOnly.quarantinedNutrients.some((row) => row.nutrientNumber === '501' && row.reason === 'unsupported_semantic_mapping'));

const mismatchedTryptophanUnit = parseNiacinFixture(12405, [
  fdcNutrient(1167, '406', 'Niacin', 'mg', 5),
  fdcNutrient(1210, '501', 'Tryptophan', 'mg', 600),
]);
assert.equal(mismatchedTryptophanUnit.foods[0].micronutrients.vitamin_b3, undefined,
  'a tryptophan unit mismatch must not enter the NE formula');
assert.ok(mismatchedTryptophanUnit.quarantinedNutrients.some((row) => row.nutrientNumber === '501' && row.reason === 'name_or_unit_mismatch'));

const duplicateTryptophanConflict = parseNiacinFixture(12406, [
  fdcNutrient(1167, '406', 'Niacin', 'mg', 5),
  fdcNutrient(1210, '501', 'Tryptophan', 'g', 0.6),
  fdcNutrient(1210, '501', 'Tryptophan', 'g', 0.8),
]);
assert.equal(duplicateTryptophanConflict.foods[0].micronutrients.vitamin_b3, undefined,
  'conflicting duplicated tryptophan measurements must never be resolved by array order');
assert.ok(duplicateTryptophanConflict.quarantinedNutrients.some((row) => row.nutrientNumber === '501' && row.reason === 'duplicate_conflict'));

const mismatchedTryptophanId = parseNiacinFixture(12407, [
  fdcNutrient(1167, '406', 'Niacin', 'mg', 5),
  fdcNutrient(1211, '501', 'Tryptophan', 'g', 0.6),
]);
assert.equal(mismatchedTryptophanId.foods[0].micronutrients.vitamin_b3, undefined,
  'the permanent FDC nutrient ID must agree with nutrient number 501');
assert.ok(mismatchedTryptophanId.quarantinedNutrients.some((row) => row.nutrientNumber === '501' && row.reason === 'id_number_mismatch'));

assert.throws(() => registerUsdaFdcFoods([{
  ...tryptophanDerived.foods[0],
  micronutrients: {
    ...tryptophanDerived.foods[0].micronutrients,
    vitamin_b3: {
      ...tryptophanDerived.foods[0].micronutrients.vitamin_b3,
      derivation: {
        ...tryptophanDerived.foods[0].micronutrients.vitamin_b3.derivation,
        components: [{ ...tryptophanDerived.foods[0].micronutrients.vitamin_b3.derivation.components[0], fdc_nutrient_id: 9999 }],
      },
    },
  },
}]), /Registro USDA inválido/i,
'catalog registration must reject ungrounded or malformed nutrient derivation evidence');

registerUsdaFdcFoods(tryptophanDerived.foods);
assert.equal(getRegisteredUsdaFdcFood('usda-fdc:12401')?.micronutrients.vitamin_b3.normalized_value, 15,
  'valid niacin-equivalent derivation evidence must survive the catalog registration boundary');
assert.throws(() => registerUsdaFdcFoods([{
  ...tryptophanDerived.foods[0],
  micronutrients: {
    ...tryptophanDerived.foods[0].micronutrients,
    vitamin_b3: {
      ...tryptophanDerived.foods[0].micronutrients.vitamin_b3,
      normalized_value: 99,
    },
  },
}]), /Registro USDA inválido/i,
'catalog registration must recompute derivation arithmetic instead of trusting a caller-supplied normalized value');
