import assert from 'node:assert/strict';
import { registerUsdaFdcFoods } from '../usda-fdc-adapter.ts';
import { getSharedFoodSearchIndex, getSharedFoodSearchVersion } from '../food-search-index.ts';
import { searchFoodIndex } from '../../../domain/rules/food-search.ts';

const versionBefore = getSharedFoodSearchVersion();
const oldIndex = getSharedFoodSearchIndex();
const food = {
  food_id: 'usda-fdc:987654', name: 'USDA Fixture Purple Sweet Potato', source_id: 'USDA_FDC',
  source_record_id: '987654', source_version: 'USDA FDC Foundation fixture', quality_status: 'reference_database',
  source_url: 'https://fdc.nal.usda.gov/food-details/987654/nutrients', food_type: 'Foundation',
  macros: { kcalPerBasis: 86, proteinGPerBasis: 1.6, carbsGPerBasis: 20.1, fatGPerBasis: 0.1, basisQuantityG: 100 },
  micronutrients: {},
};
registerUsdaFdcFoods([food]);
assert.ok(getSharedFoodSearchVersion() > versionBefore, 'USDA registration invalidates the shared search index revision');
const refreshedIndex = getSharedFoodSearchIndex();
assert.notEqual(refreshedIndex, oldIndex, 'the cached index is rebuilt after USDA registration');
assert.deepEqual(searchFoodIndex(refreshedIndex, 'purple sweet potato').map((item) => item.food_id), ['usda-fdc:987654']);
console.log('USDA food search integration tests passed.');
