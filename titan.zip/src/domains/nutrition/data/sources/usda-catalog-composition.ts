import type { FoodSourceItem } from '../../domain/entities/nutrient.ts';

export interface USDAFdcCatalogSource {
  manifest: { dataType?: string | null; status?: string };
  foods: readonly FoodSourceItem[];
}

/** Compose independently validated release catalogs without source-ID overwrite. */
export function composeUsdaCatalogs(sources: readonly USDAFdcCatalogSource[]): FoodSourceItem[] {
  if (!Array.isArray(sources)) throw new TypeError('USDA sources deve ser um array.');
  const foods: FoodSourceItem[] = [];
  const seen = new Map<string, string>();
  for (const source of sources) {
    if (!source || !Array.isArray(source.foods) || !source.manifest || typeof source.manifest !== 'object') {
      throw new TypeError('Cada catálogo USDA precisa de manifest e foods[].');
    }
    for (const food of source.foods) {
      if (!food || typeof food.food_id !== 'string' || food.source_id !== 'USDA_FDC') {
        throw new TypeError('Registro USDA inválido na composição de catálogos.');
      }
      const previous = seen.get(food.food_id);
      if (previous) {
        throw new Error(`FDC food_id duplicado entre releases/tipos USDA: ${food.food_id} (${previous} / ${source.manifest.dataType ?? 'unknown'}).`);
      }
      seen.set(food.food_id, source.manifest.dataType ?? 'unknown');
      foods.push(food);
    }
  }
  return foods;
}
