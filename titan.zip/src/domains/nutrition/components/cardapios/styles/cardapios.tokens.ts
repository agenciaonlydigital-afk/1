import type { CellDisplayStatus } from '../types/cardapios.types.ts';

/**
 * Paleta preservada e imutável do contrato Cardápios (4 materiais opacos).
 */
export const cardapiosTokens = {
  canvasPrimary: '#101719',
  surfacePrimary: '#171F22',
  surfaceRaised: '#202B2E',
  surfaceInteractive: '#29373A',
  borderSubtle: '#344448',
  textPrimary: '#F2F0E8',
  textSecondary: '#B7C1BD',
  textMuted: '#8E9B96',
  accentPrimary: '#A7C9BE',
  accentSurface: '#253936',
} as const;

export const cardapiosMaterials = {
  /** Obsidian Ceramic Hardcoat: contêiner externo do cardápio (opaco, fosco-acetinado, filete discreto) */
  cardapioShell: {
    backgroundColor: cardapiosTokens.surfacePrimary,
    borderColor: cardapiosTokens.borderSubtle,
    boxShadow: '0 8px 20px rgba(0, 0, 0, 0.28), inset 0 1px 0 rgba(242, 240, 232, 0.035)',
  },
  /** Satin Graphite: superfície interna da receita (opaca, micro-satin sem textura bitmap) */
  recipeSurface: {
    backgroundColor: cardapiosTokens.surfaceRaised,
    borderColor: cardapiosTokens.borderSubtle,
    boxShadow: 'inset 0 1px 0 rgba(242, 240, 232, 0.04)',
  },
  /** Anti-glare Graphite Display: matriz TBCA opaca */
  nutritionMatrix: {
    backgroundColor: cardapiosTokens.surfaceRaised,
    headerBackgroundColor: cardapiosTokens.surfacePrimary,
    borderColor: cardapiosTokens.borderSubtle,
  },
  /** Mineral Satin Enamel: ação Receita e Preparo (Sage sólido acetinado discreto) */
  primaryAction: {
    backgroundColor: cardapiosTokens.accentPrimary,
    color: cardapiosTokens.canvasPrimary,
    boxShadow: 'inset 0 1px 0 rgba(242, 240, 232, 0.22)',
  },
} as const;

const intFormatter = new Intl.NumberFormat('pt-BR', {
  maximumFractionDigits: 0,
});

const oneDecimalFormatter = new Intl.NumberFormat('pt-BR', {
  minimumFractionDigits: 0,
  maximumFractionDigits: 1,
});

const twoDecimalFormatter = new Intl.NumberFormat('pt-BR', {
  minimumFractionDigits: 0,
  maximumFractionDigits: 2,
});

export function formatNutrientNumberPtBr(value: number, unit: string | null): string {
  if (!Number.isFinite(value)) return '—';
  if (unit === 'kcal') {
    return intFormatter.format(Math.round(value));
  }
  const abs = Math.abs(value);
  if (abs === 0) return '0';
  if (abs < 1) return twoDecimalFormatter.format(value);
  if (abs < 100) return oneDecimalFormatter.format(value);
  return intFormatter.format(Math.round(value));
}

export function formatMacroSummaryValue(
  value: number | null,
  status: CellDisplayStatus,
  unit: 'g' | 'kcal',
): string {
  if (status === 'true-zero') return unit === 'kcal' ? '0 kcal' : '0 g';
  if (status === 'trace') return 'Traços';
  if (status === 'not-detected') return 'Não detect.';
  if (status === 'not-analyzed') return 'Não analis.';
  if (status === 'not-applicable') return 'N/A';
  if (status === 'withheld') return 'Indisp.';
  if (value === null || !Number.isFinite(value)) return '—';
  return `${formatNutrientNumberPtBr(value, unit)} ${unit}`;
}

export function formatMatrixCellDisplay(
  value: number | null,
  status: CellDisplayStatus,
  unit: string | null,
): { text: string; title?: string } {
  switch (status) {
    case 'measured':
      return {
        text: value !== null && Number.isFinite(value) ? formatNutrientNumberPtBr(value, unit) : '—',
      };
    case 'true-zero':
      return {
        text: '0',
        title: 'Zero explícito quantificado na fonte',
      };
    case 'trace':
      return {
        text: 'Traços',
        title: 'Presença residual (traços) na fonte',
      };
    case 'not-detected':
      return {
        text: 'Não detectado',
        title: 'Abaixo do limite de detecção na fonte',
      };
    case 'not-analyzed':
      return {
        text: 'Não analisado',
        title: 'Nutriente não analisado para este alimento',
      };
    case 'not-in-source':
      return {
        text: '—',
        title: 'Não fornecido pela fonte',
      };
    case 'not-applicable':
      return {
        text: 'N/A',
        title: 'Não aplicável',
      };
    case 'withheld':
      return {
        text: 'Indisponível',
        title: 'Valor indisponível ou restrito na fonte',
      };
  }
}
