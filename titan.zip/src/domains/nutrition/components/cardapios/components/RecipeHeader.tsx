import { memo, useState } from 'react';
import { cardapiosTokens } from '../styles/cardapios.tokens';
import type { RecipeCardViewModel } from '../types/cardapios.types';
import { MacroSummary } from './MacroSummary';
import { MatrixDisclosure } from './MatrixDisclosure';
import { RecipePhoto } from './RecipePhoto';

interface RecipeHeaderProps {
  recipe: RecipeCardViewModel;
  matrixId: string;
  bodyId: string;
  isCardOpen: boolean;
  onToggleCard: () => void;
  isMatrixExpanded: boolean;
  onToggleMatrix: () => void;
}

export const RecipeHeader = memo(function RecipeHeader({
  recipe,
  matrixId,
  bodyId,
  isCardOpen,
  onToggleCard,
  isMatrixExpanded,
  onToggleMatrix,
}: RecipeHeaderProps) {
  const [titleHovered, setTitleHovered] = useState(false);
  const [titlePressed, setTitlePressed] = useState(false);

  return (
    <div className="flex items-start gap-3.5 sm:gap-4">
      {/* Foto antes do título (posição congelada) */}
      <RecipePhoto image={recipe.image} />

      <div className="min-w-0 flex-1 flex flex-col justify-between gap-2">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2 sm:gap-4">
          <h3 className="min-w-0 m-0 text-[15px] sm:text-[16px] font-semibold leading-snug">
            <button
              type="button"
              onClick={onToggleCard}
              onMouseEnter={() => setTitleHovered(true)}
              onMouseLeave={() => {
                setTitleHovered(false);
                setTitlePressed(false);
              }}
              onPointerDown={() => setTitlePressed(true)}
              onPointerUp={() => setTitlePressed(false)}
              onPointerCancel={() => setTitlePressed(false)}
              aria-expanded={isCardOpen}
              aria-controls={bodyId}
              aria-label={`Recolher receita ${recipe.title}`}
              className="text-left min-h-[44px] -mx-2 px-2 py-1 rounded-[8px] transition-colors focus-visible:outline-2 focus-visible:outline-offset-2"
              style={{
                color: cardapiosTokens.textPrimary,
                backgroundColor:
                  titlePressed || titleHovered
                    ? cardapiosTokens.surfaceInteractive
                    : 'transparent',
                outlineColor: cardapiosTokens.textPrimary,
              }}
            >
              {recipe.title}
            </button>
          </h3>

          {/* Macros no canto superior direito: Prot. · Gord. · Carb. · kcal */}
          <div className="shrink-0 sm:pt-1">
            <MacroSummary macros={recipe.macros} />
          </div>
        </div>

        {/* Ver mais → no canto inferior direito do cabeçalho */}
        <div className="flex items-center justify-end">
          <MatrixDisclosure
            recipeTitle={recipe.title}
            matrixId={matrixId}
            isExpanded={isMatrixExpanded}
            onToggle={onToggleMatrix}
          />
        </div>
      </div>
    </div>
  );
});
