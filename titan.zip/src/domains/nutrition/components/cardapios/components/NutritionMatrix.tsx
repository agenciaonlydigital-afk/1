import { memo, useMemo } from 'react';
import {
  cardapiosMaterials,
  cardapiosTokens,
  formatMatrixCellDisplay,
} from '../styles/cardapios.tokens';
import type { NutritionGroupId, NutritionMatrixViewModel } from '../types/cardapios.types';

interface NutritionMatrixProps {
  matrixId: string;
  recipeTitle: string;
  matrix: NutritionMatrixViewModel;
}

interface ColumnGroupSpan {
  groupId: NutritionGroupId;
  groupLabel: string;
  colSpan: number;
  widthPx: number;
}

export const NutritionMatrix = memo(function NutritionMatrix({
  matrixId,
  recipeTitle,
  matrix,
}: NutritionMatrixProps) {
  const { columns, rows, sourceLabel } = matrix;

  const groupSpans = useMemo<ColumnGroupSpan[]>(() => {
    const spans: ColumnGroupSpan[] = [];
    for (const col of columns) {
      const last = spans[spans.length - 1];
      if (last && last.groupId === col.groupId) {
        last.colSpan += 1;
        last.widthPx += col.widthPx;
      } else {
        spans.push({
          groupId: col.groupId,
          groupLabel: col.groupLabel,
          colSpan: 1,
          widthPx: col.widthPx,
        });
      }
    }
    return spans;
  }, [columns]);

  const totalTableWidth = useMemo(
    () => columns.reduce((sum, col) => sum + col.widthPx, 0),
    [columns],
  );

  return (
    <div
      id={matrixId}
      className="mt-3 rounded-[10px] border overflow-hidden"
      style={{
        backgroundColor: cardapiosMaterials.nutritionMatrix.backgroundColor,
        borderColor: cardapiosMaterials.nutritionMatrix.borderColor,
      }}
    >
      <div className="overflow-x-auto">
        <table
          className="border-collapse text-left"
          style={{ width: `${totalTableWidth}px`, tableLayout: 'fixed' }}
        >
          <caption className="sr-only">
            Matriz nutricional TBCA de {recipeTitle}
          </caption>
          <colgroup>
            {columns.map((col) => (
              <col key={col.nutrientId} style={{ width: `${col.widthPx}px` }} />
            ))}
          </colgroup>
          <thead>
            <tr
              className="border-b"
              style={{
                backgroundColor: cardapiosMaterials.nutritionMatrix.headerBackgroundColor,
                borderColor: cardapiosTokens.borderSubtle,
              }}
            >
              {groupSpans.map((group) => (
                <th
                  key={group.groupId}
                  colSpan={group.colSpan}
                  scope="colgroup"
                  className="px-3 py-2 text-[11px] font-semibold tracking-wide border-r last:border-r-0"
                  style={{
                    color: cardapiosTokens.textSecondary,
                    borderColor: cardapiosTokens.borderSubtle,
                    backgroundColor: cardapiosMaterials.nutritionMatrix.headerBackgroundColor,
                  }}
                >
                  {group.groupLabel}
                </th>
              ))}
            </tr>
            <tr
              className="border-b"
              style={{
                backgroundColor: cardapiosMaterials.nutritionMatrix.headerBackgroundColor,
                borderColor: cardapiosTokens.borderSubtle,
              }}
            >
              {columns.map((col, idx) => {
                const isNumeric = idx >= 2;
                return (
                  <th
                    key={col.nutrientId}
                    scope="col"
                    className={`px-3 py-2 text-[11px] font-medium align-bottom border-r last:border-r-0 ${
                      isNumeric ? 'text-right' : 'text-left'
                    }`}
                    style={{
                      color: cardapiosTokens.textPrimary,
                      borderColor: cardapiosTokens.borderSubtle,
                      backgroundColor: cardapiosMaterials.nutritionMatrix.headerBackgroundColor,
                    }}
                  >
                    <span className="block leading-tight">{col.label}</span>
                    {col.unit && (
                      <span
                        className="block text-[10px] font-normal mt-0.5"
                        style={{ color: cardapiosTokens.textMuted }}
                      >
                        ({col.unit})
                      </span>
                    )}
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr
                key={row.ingredientId}
                className="border-b last:border-b-0"
                style={{ borderColor: cardapiosTokens.borderSubtle }}
              >
                {columns.map((col, idx) => {
                  if (col.nutrientId === 'food') {
                    return (
                      <th
                        key={col.nutrientId}
                        scope="row"
                        className="px-3 py-2.5 text-[12px] font-medium text-left align-top border-r"
                        style={{
                          color: cardapiosTokens.textPrimary,
                          borderColor: cardapiosTokens.borderSubtle,
                        }}
                      >
                        {row.foodName}
                      </th>
                    );
                  }
                  if (col.nutrientId === 'quantity') {
                    return (
                      <td
                        key={col.nutrientId}
                        className="px-3 py-2.5 text-[12px] font-mono-metric tabular-nums text-left align-top whitespace-nowrap border-r"
                        style={{
                          color: cardapiosTokens.textSecondary,
                          borderColor: cardapiosTokens.borderSubtle,
                        }}
                      >
                        {row.quantityDisplay}
                      </td>
                    );
                  }

                  const cell = row.cells[col.nutrientId];
                  const formatted = cell
                    ? formatMatrixCellDisplay(cell.value, cell.status, cell.unit)
                    : { text: '—', title: 'Não fornecido pela fonte' };
                  const isUnquantified =
                    !cell || (cell.status !== 'measured' && cell.status !== 'true-zero');

                  return (
                    <td
                      key={col.nutrientId}
                      title={formatted.title}
                      aria-label={formatted.title ? `${col.label}: ${formatted.title}` : undefined}
                      className={`px-3 py-2.5 text-[12px] font-mono-metric tabular-nums align-top whitespace-nowrap border-r last:border-r-0 ${
                        idx >= 2 ? 'text-right' : 'text-left'
                      }`}
                      style={{
                        color: isUnquantified
                          ? cardapiosTokens.textMuted
                          : cardapiosTokens.textPrimary,
                        borderColor: cardapiosTokens.borderSubtle,
                      }}
                    >
                      {formatted.text}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div
        className="px-3 py-2 border-t flex flex-wrap items-center justify-between gap-2 text-[11px]"
        style={{
          backgroundColor: cardapiosMaterials.nutritionMatrix.headerBackgroundColor,
          borderColor: cardapiosTokens.borderSubtle,
          color: cardapiosTokens.textMuted,
        }}
      >
        <span>Fonte: {sourceLabel}</span>
        <span>Zero real (0) distinto de Traços, Não analisado e ausência (—)</span>
      </div>
    </div>
  );
});
