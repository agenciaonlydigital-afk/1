import { memo } from 'react';
import { motion } from 'motion/react';
import type { MacroFitProposalSnapshot } from '../../../application/macro-target-fit-service';
import { TITAN_MOTION_VARIANTS } from '../../../../../shared/motion/titan-motion';
import { cardapiosMaterials, cardapiosTokens } from '../styles/cardapios.tokens';

interface MacroFitProposalBannerProps {
  snapshot: MacroFitProposalSnapshot;
  canUndo: boolean;
  justApplied: boolean;
  errorFeedback?: string | null;
  onApply: () => void;
  onDismiss: () => void;
  onUndo: () => void;
}

function formatGap(diff: number, unit: string): string {
  const rounded = Math.round(diff);
  if (rounded === 0) return `0 ${unit}`;
  return `${rounded > 0 ? '+' : ''}${rounded} ${unit}`;
}

export const MacroFitProposalBanner = memo(function MacroFitProposalBanner({
  snapshot,
  canUndo,
  justApplied,
  errorFeedback,
  onApply,
  onDismiss,
  onUndo,
}: MacroFitProposalBannerProps) {
  const hasVisibleStatus =
    snapshot.status !== 'idle' || justApplied || Boolean(errorFeedback);

  if (!hasVisibleStatus) {
    return null;
  }

  const result = snapshot.result;
  const hasMeaningfulAdjustment =
    result !== null && result.proposal.adjustedCount > 0;

  let statusLabel = 'Proposta de ajuste proporcional pronta';
  if (justApplied && snapshot.status === 'idle') {
    statusLabel = 'Ajuste aplicado ao cardápio';
  } else if (snapshot.status === 'scheduled') {
    statusLabel = 'Recálculo proporcional agendado…';
  } else if (snapshot.status === 'calculating') {
    statusLabel = 'Recalculando escalas por receita…';
  } else if (snapshot.status === 'stale') {
    statusLabel = 'Proposta desatualizada após edição manual';
  } else if (snapshot.status === 'infeasible') {
    statusLabel = 'Restrições atuais impedem o ajuste automático';
  } else if (snapshot.status === 'failed') {
    statusLabel = 'Falha ao recalcular o cardápio';
  } else if (result?.status === 'insufficient_data') {
    statusLabel = 'Aproximação parcial (ingredientes sem quantidade ou dados incompletos)';
  } else if (result?.status === 'approximate_feasible') {
    statusLabel = 'Aproximação proporcional viável (preserva proporções das receitas)';
  }

  return (
    <motion.section
      layout="position"
      initial={TITAN_MOTION_VARIANTS.enter.initial}
      animate={TITAN_MOTION_VARIANTS.enter.animate}
      exit={TITAN_MOTION_VARIANTS.exit}
      aria-live="polite"
      aria-label="Proposta automática de ajuste nutricional"
      className="rounded-[14px] border px-4 py-3.5 space-y-2.5"
      style={{
        backgroundColor: cardapiosMaterials.cardapioShell.backgroundColor,
        borderColor: cardapiosMaterials.cardapioShell.borderColor,
        boxShadow: cardapiosMaterials.cardapioShell.boxShadow,
      }}
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
        <div className="space-y-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <span
              className="inline-block w-2 h-2 rounded-full shrink-0"
              style={{ backgroundColor: cardapiosTokens.accentPrimary }}
              aria-hidden="true"
            />
            <p
              className="text-[13px] font-semibold leading-snug m-0"
              style={{ color: cardapiosTokens.textPrimary }}
            >
              {statusLabel}
            </p>
            <span
              className="text-[11px] font-medium px-2 py-0.5 rounded-[6px]"
              style={{
                backgroundColor: cardapiosTokens.accentSurface,
                color: cardapiosTokens.accentPrimary,
              }}
            >
              Proporções das receitas preservadas
            </span>
          </div>

          {result ? (
            <p
              className="text-[12px] leading-relaxed m-0"
              style={{ color: cardapiosTokens.textSecondary }}
            >
              {Math.round(result.beforeSummary.macros.kcal)} →{' '}
              <strong style={{ color: cardapiosTokens.textPrimary }}>
                {Math.round(result.afterSummary.macros.kcal)} kcal
              </strong>{' '}
              · P {Math.round(result.beforeSummary.macros.proteinG)}→
              {Math.round(result.afterSummary.macros.proteinG)}g · C{' '}
              {Math.round(result.beforeSummary.macros.carbsG)}→
              {Math.round(result.afterSummary.macros.carbsG)}g · G{' '}
              {Math.round(result.beforeSummary.macros.fatG)}→
              {Math.round(result.afterSummary.macros.fatG)}g
              {' · '}
              <span style={{ color: cardapiosTokens.textMuted }}>
                Desvio final: {formatGap(result.afterGaps.kcalDiff, 'kcal')},{' '}
                {formatGap(result.afterGaps.proteinDiffG, 'g P')}
              </span>
            </p>
          ) : null}

          {errorFeedback || snapshot.errorMessage ? (
            <p
              className="text-[12px] leading-snug m-0"
              style={{ color: cardapiosTokens.textSecondary }}
            >
              {errorFeedback ?? snapshot.errorMessage}
            </p>
          ) : null}
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          {snapshot.status === 'ready' && result && hasMeaningfulAdjustment ? (
            <button
              type="button"
              onClick={onApply}
              className="min-h-[38px] px-3.5 py-1.5 rounded-[10px] text-[12px] font-semibold transition-colors cursor-pointer"
              style={{
                backgroundColor: cardapiosMaterials.primaryAction.backgroundColor,
                color: cardapiosMaterials.primaryAction.color,
                boxShadow: cardapiosMaterials.primaryAction.boxShadow,
              }}
            >
              Aplicar ajuste
            </button>
          ) : null}

          {canUndo ? (
            <button
              type="button"
              onClick={onUndo}
              className="min-h-[38px] px-3 py-1.5 rounded-[10px] border text-[12px] font-medium transition-colors cursor-pointer"
              style={{
                backgroundColor: cardapiosTokens.surfaceRaised,
                borderColor: cardapiosTokens.borderSubtle,
                color: cardapiosTokens.textPrimary,
              }}
            >
              Desfazer
            </button>
          ) : null}

          {snapshot.status !== 'idle' ? (
            <button
              type="button"
              onClick={onDismiss}
              className="min-h-[38px] px-3 py-1.5 rounded-[10px] border text-[12px] font-medium transition-colors cursor-pointer"
              style={{
                backgroundColor: cardapiosTokens.surfaceRaised,
                borderColor: cardapiosTokens.borderSubtle,
                color: cardapiosTokens.textSecondary,
              }}
            >
              Descartar
            </button>
          ) : null}
        </div>
      </div>

      {result && result.recipeScales.length > 0 ? (
        <div className="flex flex-wrap gap-1.5 pt-0.5">
          {result.recipeScales.map((rs) => (
            <span
              key={`${rs.slotId}-${rs.recipeId}`}
              className="text-[11px] px-2.5 py-1 rounded-[8px] border"
              style={{
                backgroundColor: cardapiosTokens.surfaceRaised,
                borderColor: cardapiosTokens.borderSubtle,
                color: cardapiosTokens.textSecondary,
              }}
            >
              {rs.recipeName}:{' '}
              <strong style={{ color: cardapiosTokens.textPrimary }}>
                {rs.scalePercent}%
              </strong>
            </span>
          ))}
        </div>
      ) : null}
    </motion.section>
  );
});
