import { memo } from 'react';
import { cardapiosMaterials, cardapiosTokens } from '../styles/cardapios.tokens';
import type { MenuGroupViewModel } from '../types/cardapios.types';
import { RecipeCard } from './RecipeCard';

interface MenuGroupProps {
  menu: MenuGroupViewModel;
  isCardExpanded: (recipeId: string, defaultExpanded: boolean) => boolean;
  onToggleCard: (recipeId: string, defaultExpanded: boolean) => void;
  isRecipeExpanded: (recipeId: string) => boolean;
  onToggleMatrix: (recipeId: string) => void;
}

export const MenuGroup = memo(function MenuGroup({
  menu,
  isCardExpanded,
  onToggleCard,
  isRecipeExpanded,
  onToggleMatrix,
}: MenuGroupProps) {
  return (
    <section
      aria-label={`${menu.code} — ${menu.title}`}
      className="rounded-[18px] border p-4 sm:p-5 space-y-4"
      style={{
        backgroundColor: cardapiosMaterials.cardapioShell.backgroundColor,
        borderColor: cardapiosMaterials.cardapioShell.borderColor,
        boxShadow: cardapiosMaterials.cardapioShell.boxShadow,
      }}
    >
      <header className="flex flex-wrap items-baseline justify-between gap-2 pb-1">
        <div className="flex flex-wrap items-baseline gap-2.5">
          <h2
            className="text-[15px] font-semibold tracking-wide uppercase"
            style={{ color: cardapiosTokens.accentPrimary }}
          >
            {menu.code}
          </h2>
          <span aria-hidden="true" style={{ color: cardapiosTokens.textMuted }}>
            ·
          </span>
          <p
            className="text-[14px] font-medium"
            style={{ color: cardapiosTokens.textSecondary }}
          >
            {menu.title}
          </p>
        </div>
      </header>

      <div className="space-y-3">
        {menu.recipes.map((recipe) => (
          <RecipeCard
            key={recipe.recipeId}
            recipe={recipe}
            isCardOpen={isCardExpanded(recipe.recipeId, recipe.isNextToConsume)}
            isMatrixExpanded={isRecipeExpanded(recipe.recipeId)}
            onToggleCard={onToggleCard}
            onToggleMatrix={onToggleMatrix}
          />
        ))}
      </div>
    </section>
  );
});
