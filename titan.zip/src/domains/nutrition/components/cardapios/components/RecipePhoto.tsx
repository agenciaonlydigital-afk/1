import { memo, useEffect, useState } from 'react';
import { Utensils } from 'lucide-react';
import { cardapiosTokens } from '../styles/cardapios.tokens';
import type { RecipeCardViewModel } from '../types/cardapios.types';

interface RecipePhotoProps {
  image: RecipeCardViewModel['image'];
  sizePx?: number;
}

export const RecipePhoto = memo(function RecipePhoto({ image, sizePx }: RecipePhotoProps) {
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    setHasError(false);
  }, [image.uri]);

  const showPlaceholder = !image.uri || hasError;
  const width = sizePx ?? image.width;
  const height = sizePx ?? image.height;

  return (
    <div
      className="shrink-0 overflow-hidden rounded-[12px] border"
      style={{
        width,
        height,
        backgroundColor: cardapiosTokens.surfacePrimary,
        borderColor: cardapiosTokens.borderSubtle,
      }}
    >
      {showPlaceholder ? (
        <div
          className="w-full h-full flex items-center justify-center"
          role="img"
          aria-label={image.accessibilityLabel}
          style={{
            backgroundColor: cardapiosTokens.surfacePrimary,
            color: cardapiosTokens.textMuted,
          }}
        >
          <Utensils className="w-5 h-5" strokeWidth={1.6} aria-hidden="true" />
        </div>
      ) : (
        <img
          src={image.uri as string}
          alt={image.accessibilityLabel}
          width={width}
          height={height}
          loading="lazy"
          decoding="async"
          referrerPolicy="no-referrer"
          onError={() => setHasError(true)}
          className="w-full h-full object-cover block"
        />
      )}
    </div>
  );
});
