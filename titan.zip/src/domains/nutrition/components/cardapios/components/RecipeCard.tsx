import { memo, useCallback, useId, useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { TITAN_MOTION_VARIANTS } from '../../../../../shared/motion/titan-motion';
import { cardapiosMaterials, cardapiosTokens } from '../styles/cardapios.tokens';
import type { RecipeCardViewModel } from '../types/cardapios.types';
import { IngredientList } from './IngredientList';
import { MacroSummary } from './MacroSummary';
import { NutritionMatrixDisclosure } from './NutritionMatrixDisclosure';
import { RecipeHeader } from './RecipeHeader';
import { RecipePhoto } from './RecipePhoto';
import { RecipePreparationAction } from './RecipePreparationAction';

interface RecipeCardProps {
  recipe: RecipeCardViewModel;
  isCardOpen: boolean;
  isMatrixExpanded: boolean;
  onToggleCard: (recipeId: string, defaultOpen: boolean) => void;
  onToggleMatrix: (recipeId: string) => void;
}

export const RecipeCard = memo(function RecipeCard({
  recipe,
  isCardOpen,
  isMatrixExpanded,
  onToggleCard,
  onToggleMatrix,
}: RecipeCardProps) {
  const matrixId = useId();
  const bodyId = useId();
  const [closedHovered, setClosedHovered] = useState(false);
  const [closedPressed, setClosedPressed] = useState(false);

  const handleToggleCard = useCallback(() => {
    onToggleCard(recipe.recipeId, recipe.isNextToConsume);
  }, [onToggleCard, recipe.recipeId, recipe.isNextToConsume]);

  const handleToggleMatrix = useCallback(() => {
    onToggleMatrix(recipe.recipeId);
  }, [onToggleMatrix, recipe.recipeId]);

  if (!isCardOpen) {
    return (
      <motion.article
        layout="position"
        transition={TITAN_MOTION_VARIANTS.layout.transition}
        className="rounded-[14px] p-3.5 sm:p-4"
        style={{
          backgroundColor:
            closedPressed || closedHovered
              ? cardapiosTokens.surfaceInteractive
              : cardapiosMaterials.recipeSurface.backgroundColor,
          boxShadow: cardapiosMaterials.recipeSurface.boxShadow,
        }}
        aria-label={recipe.title}
      >
        <div className="flex items-center gap-3.5">
          <RecipePhoto image={recipe.image} sizePx={56} />

          <div className="min-w-0 flex-1 flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 sm:gap-4">
            <h3 className="min-w-0 m-0 text-[14px] sm:text-[15px] font-semibold leading-snug">
              <button
                type="button"
                onClick={handleToggleCard}
                onMouseEnter={() => setClosedHovered(true)}
                onMouseLeave={() => {
                  setClosedHovered(false);
                  setClosedPressed(false);
                }}
                onPointerDown={() => setClosedPressed(true)}
                onPointerUp={() => setClosedPressed(false)}
                onPointerCancel={() => setClosedPressed(false)}
                aria-expanded={false}
                aria-controls={bodyId}
                aria-label={`Abrir receita ${recipe.title}`}
                className="w-full text-left min-h-[44px] -mx-2 px-2 py-1 rounded-[8px] inline-flex items-center justify-between gap-2 focus-visible:outline-2 focus-visible:outline-offset-2"
                style={{
                  color: cardapiosTokens.textPrimary,
                  outlineColor: cardapiosTokens.textPrimary,
                }}
              >
                <span>{recipe.title}</span>
                <ChevronDown
                  className="w-4 h-4 shrink-0 sm:hidden"
                  style={{ color: cardapiosTokens.accentPrimary }}
                  aria-hidden="true"
                />
              </button>
            </h3>

            <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0">
              <MacroSummary macros={recipe.macros} />
              <ChevronDown
                className="hidden sm:block w-4 h-4 shrink-0"
                style={{ color: cardapiosTokens.accentPrimary }}
                aria-hidden="true"
              />
            </div>
          </div>
        </div>
      </motion.article>
    );
  }

  return (
    <motion.article
      layout="position"
      transition={TITAN_MOTION_VARIANTS.layout.transition}
      className="rounded-[14px] p-4 sm:p-5 space-y-3.5"
      style={{
        backgroundColor: cardapiosMaterials.recipeSurface.backgroundColor,
        boxShadow: cardapiosMaterials.recipeSurface.boxShadow,
      }}
      aria-label={recipe.title}
    >
      <RecipeHeader
        recipe={recipe}
        matrixId={matrixId}
        bodyId={bodyId}
        isCardOpen={isCardOpen}
        onToggleCard={handleToggleCard}
        isMatrixExpanded={isMatrixExpanded}
        onToggleMatrix={handleToggleMatrix}
      />

      <AnimatePresence initial={false}>
        <motion.div
          key="recipe-body"
          id={bodyId}
          initial={TITAN_MOTION_VARIANTS.enter.initial}
          animate={TITAN_MOTION_VARIANTS.enter.animate}
          exit={TITAN_MOTION_VARIANTS.exit}
          className="space-y-3.5"
        >
          <IngredientList ingredients={recipe.ingredients} />

          <NutritionMatrixDisclosure
            matrixId={matrixId}
            recipeTitle={recipe.title}
            matrix={recipe.nutritionMatrix}
            isExpanded={isMatrixExpanded}
          />

          <RecipePreparationAction
            recipeTitle={recipe.title}
            preparation={recipe.preparation}
          />
        </motion.div>
      </AnimatePresence>
    </motion.article>
  );
});
