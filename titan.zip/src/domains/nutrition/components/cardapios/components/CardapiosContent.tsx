import { memo, useEffect, useMemo } from 'react';
import { AnimatePresence, MotionConfig } from 'motion/react';
import type { MacroFitProposalSnapshot } from '../../../application/macro-target-fit-service';
import { useRecipeCardExpansion } from '../hooks/useRecipeCardExpansion';
import { useRecipeMatrixExpansion } from '../hooks/useRecipeMatrixExpansion';
import { cardapiosTokens } from '../styles/cardapios.tokens';
import type { CardapiosViewModel } from '../types/cardapios.types';
import { MacroFitProposalBanner } from './MacroFitProposalBanner';
import { MealHistory } from './MealHistory';
import { MenuGroup } from './MenuGroup';

interface MacroFitControlProps {
  snapshot: MacroFitProposalSnapshot;
  canUndo: boolean;
  justApplied: boolean;
  errorFeedback?: string | null;
  onApply: () => void;
  onDismiss: () => void;
  onUndo: () => void;
}

interface CardapiosContentProps {
  viewModel: CardapiosViewModel;
  macroFitControl?: MacroFitControlProps | null;
}

export const CardapiosContent = memo(function CardapiosContent({
  viewModel,
  macroFitControl,
}: CardapiosContentProps) {
  const { isCardExpanded, toggleCardExpansion, pruneRemovedCards } = useRecipeCardExpansion();
  const { isRecipeExpanded, toggleRecipeMatrix, pruneRemovedMatrices } = useRecipeMatrixExpansion();

  const activeRecipeIds = useMemo(
    () => viewModel.menus.flatMap((menu) => menu.recipes.map((recipe) => recipe.recipeId)),
    [viewModel.menus],
  );

  useEffect(() => {
    pruneRemovedCards(activeRecipeIds);
    pruneRemovedMatrices(activeRecipeIds);
  }, [activeRecipeIds, pruneRemovedCards, pruneRemovedMatrices]);

  return (
    <MotionConfig reducedMotion="user">
      <div
        className="-mx-[14px] -mt-[14px] px-[14px] pt-[14px] pb-24 md:-mx-[28px] md:-mt-[24px] md:px-[28px] md:pt-[24px] md:pb-12 min-h-full space-y-6"
        style={{ backgroundColor: cardapiosTokens.canvasPrimary }}
      >
        <header className="titan-page-heading titan-page-heading--compact">
          <h1
            className="text-2xl sm:text-3xl font-semibold tracking-tight uppercase"
            style={{ color: cardapiosTokens.textPrimary }}
          >
            Cardápios
          </h1>
        </header>

        <AnimatePresence initial={false}>
          {macroFitControl ? (
            <MacroFitProposalBanner
              key="macro-fit-proposal-banner"
              snapshot={macroFitControl.snapshot}
              canUndo={macroFitControl.canUndo}
              justApplied={macroFitControl.justApplied}
              errorFeedback={macroFitControl.errorFeedback}
              onApply={macroFitControl.onApply}
              onDismiss={macroFitControl.onDismiss}
              onUndo={macroFitControl.onUndo}
            />
          ) : null}
        </AnimatePresence>

        <div className="space-y-6">
          {viewModel.menus.map((menu) => (
            <MenuGroup
              key={menu.menuId}
              menu={menu}
              isCardExpanded={isCardExpanded}
              onToggleCard={toggleCardExpansion}
              isRecipeExpanded={isRecipeExpanded}
              onToggleMatrix={toggleRecipeMatrix}
            />
          ))}
        </div>

        <MealHistory rows={viewModel.history} />
      </div>
    </MotionConfig>
  );
});
