import { memo, useId, useState } from 'react';
import { cardapiosMaterials, cardapiosTokens } from '../styles/cardapios.tokens';
import type { PreparationViewModel } from '../types/cardapios.types';

interface RecipePreparationActionProps {
  recipeTitle: string;
  preparation: PreparationViewModel | null;
}

export const RecipePreparationAction = memo(function RecipePreparationAction({
  recipeTitle,
  preparation,
}: RecipePreparationActionProps) {
  const [open, setOpen] = useState(false);
  const [hovered, setHovered] = useState(false);
  const [pressed, setPressed] = useState(false);
  const panelId = useId();

  return (
    <div className="pt-3 border-t" style={{ borderColor: cardapiosTokens.borderSubtle }}>
      <button
        type="button"
        onClick={() => setOpen((prev) => !prev)}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => {
          setHovered(false);
          setPressed(false);
        }}
        onPointerDown={() => setPressed(true)}
        onPointerUp={() => setPressed(false)}
        onPointerCancel={() => setPressed(false)}
        aria-expanded={open}
        aria-controls={panelId}
        aria-label={`Receita e Preparo de ${recipeTitle}`}
        className="w-full sm:w-auto min-h-[44px] px-5 py-2.5 rounded-[10px] text-[13px] font-semibold tracking-tight inline-flex items-center justify-center transition-opacity focus-visible:outline-2 focus-visible:outline-offset-2"
        style={{
          backgroundColor: cardapiosMaterials.primaryAction.backgroundColor,
          color: cardapiosMaterials.primaryAction.color,
          boxShadow: cardapiosMaterials.primaryAction.boxShadow,
          opacity: pressed ? 0.86 : hovered ? 0.93 : 1,
          outlineColor: cardapiosTokens.textPrimary,
        }}
      >
        Receita e Preparo
      </button>

      {open && (
        <div
          id={panelId}
          className="mt-3 pt-3 border-t text-[13px] leading-relaxed"
          style={{
            borderColor: cardapiosTokens.borderSubtle,
            color: cardapiosTokens.textSecondary,
          }}
        >
          {preparation && preparation.steps.length > 0 ? (
            <ol className="list-decimal list-inside space-y-1.5">
              {preparation.steps.map((step) => (
                <li key={step.stepNumber} style={{ color: cardapiosTokens.textPrimary }}>
                  {step.instruction}
                </li>
              ))}
            </ol>
          ) : (
            <p style={{ color: cardapiosTokens.textSecondary }}>
              Modo de preparo não cadastrado na ficha técnica desta receita.
              {preparation?.totalPortionDisplay
                ? ` Porção total composta: ${preparation.totalPortionDisplay}.`
                : ''}
            </p>
          )}
        </div>
      )}
    </div>
  );
});
