import { memo } from 'react';
import { cardapiosTokens, formatMacroSummaryValue } from '../styles/cardapios.tokens';
import type { RecipeMacroSummary } from '../types/cardapios.types';

interface MacroSummaryProps {
  macros: RecipeMacroSummary;
}

export const MacroSummary = memo(function MacroSummary({ macros }: MacroSummaryProps) {
  const items = [
    {
      key: 'prot',
      label: 'Prot.',
      text: formatMacroSummaryValue(macros.protein.value, macros.protein.status, 'g'),
    },
    {
      key: 'gord',
      label: 'Gord.',
      text: formatMacroSummaryValue(macros.fat.value, macros.fat.status, 'g'),
    },
    {
      key: 'carb',
      label: 'Carb.',
      text: formatMacroSummaryValue(macros.carbohydrate.value, macros.carbohydrate.status, 'g'),
    },
    {
      key: 'kcal',
      label: 'kcal',
      text: formatMacroSummaryValue(macros.energyKcal.value, macros.energyKcal.status, 'kcal'),
    },
  ] as const;

  return (
    <dl
      className="flex flex-wrap items-baseline justify-end gap-x-2.5 gap-y-1 text-right tabular-nums"
      aria-label="Resumo de macronutrientes e energia da receita"
    >
      {items.map((item, idx) => (
        <div key={item.key} className="inline-flex items-baseline gap-1">
          {idx > 0 && (
            <span
              aria-hidden="true"
              className="mr-1.5 select-none text-xs"
              style={{ color: cardapiosTokens.textSecondary }}
            >
              ·
            </span>
          )}
          {item.key !== 'kcal' && (
            <dt className="text-[11px] font-medium" style={{ color: cardapiosTokens.textSecondary }}>
              {item.label}
            </dt>
          )}
          <dd
            className={
              item.key === 'kcal'
                ? 'text-[13px] font-semibold font-mono-metric'
                : 'text-[13px] font-medium font-mono-metric'
            }
            style={{
              color:
                item.key === 'kcal'
                  ? cardapiosTokens.textPrimary
                  : cardapiosTokens.textSecondary,
            }}
          >
            {item.text}
          </dd>
        </div>
      ))}
    </dl>
  );
});
