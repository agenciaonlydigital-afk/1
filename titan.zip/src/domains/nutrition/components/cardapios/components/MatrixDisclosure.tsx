import { memo, useState } from 'react';
import { cardapiosTokens } from '../styles/cardapios.tokens';

interface MatrixDisclosureProps {
  recipeTitle: string;
  matrixId: string;
  isExpanded: boolean;
  onToggle: () => void;
}

export const MatrixDisclosure = memo(function MatrixDisclosure({
  recipeTitle,
  matrixId,
  isExpanded,
  onToggle,
}: MatrixDisclosureProps) {
  const [hovered, setHovered] = useState(false);
  const [pressed, setPressed] = useState(false);

  const showInteractiveSurface = isExpanded || hovered || pressed;

  return (
    <button
      type="button"
      onClick={onToggle}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => {
        setHovered(false);
        setPressed(false);
      }}
      onPointerDown={() => setPressed(true)}
      onPointerUp={() => setPressed(false)}
      onPointerCancel={() => setPressed(false)}
      aria-expanded={isExpanded}
      aria-controls={matrixId}
      aria-label={
        isExpanded
          ? `Ocultar matriz nutricional TBCA de ${recipeTitle}`
          : `Ver mais informações nutricionais TBCA de ${recipeTitle}`
      }
      className="inline-flex items-center justify-end gap-1.5 min-h-[44px] px-2.5 -mr-2.5 rounded-[8px] text-[13px] font-medium whitespace-nowrap shrink-0 transition-colors focus-visible:outline-2 focus-visible:outline-offset-2"
      style={{
        color: cardapiosTokens.accentPrimary,
        backgroundColor: showInteractiveSurface
          ? cardapiosTokens.surfaceInteractive
          : 'transparent',
        outlineColor: cardapiosTokens.textPrimary,
      }}
    >
      <span>{isExpanded ? 'Ver menos' : 'Ver mais →'}</span>
    </button>
  );
});
