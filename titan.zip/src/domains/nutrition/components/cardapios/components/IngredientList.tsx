import { memo } from 'react';
import { cardapiosTokens } from '../styles/cardapios.tokens';
import type { IngredientRowViewModel } from '../types/cardapios.types';

interface IngredientListProps {
  ingredients: readonly IngredientRowViewModel[];
}

export const IngredientList = memo(function IngredientList({ ingredients }: IngredientListProps) {
  return (
    <ul
      aria-label="Ingredientes da receita"
      className="divide-y"
      style={{ borderColor: cardapiosTokens.borderSubtle }}
    >
      {ingredients.map((ingredient) => (
        <li
          key={ingredient.ingredientId}
          className="flex items-baseline justify-between gap-4 py-2 first:pt-1 last:pb-1"
          style={{ borderColor: cardapiosTokens.borderSubtle }}
        >
          <span
            className="text-[13px] leading-snug min-w-0"
            style={{ color: cardapiosTokens.textPrimary }}
          >
            {ingredient.foodDisplayName}
          </span>
          <span
            className="text-[13px] font-mono-metric tabular-nums shrink-0 whitespace-nowrap"
            style={{
              color:
                ingredient.quantity.value === null
                  ? cardapiosTokens.textMuted
                  : cardapiosTokens.textSecondary,
            }}
          >
            {ingredient.quantity.display}
          </span>
        </li>
      ))}
    </ul>
  );
});
