import { memo } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { TITAN_MOTION_VARIANTS } from '../../../../../shared/motion/titan-motion';
import type { NutritionMatrixViewModel } from '../types/cardapios.types';
import { NutritionMatrix } from './NutritionMatrix';

interface NutritionMatrixDisclosureProps {
  matrixId: string;
  recipeTitle: string;
  matrix: NutritionMatrixViewModel;
  isExpanded: boolean;
}

export const NutritionMatrixDisclosure = memo(function NutritionMatrixDisclosure({
  matrixId,
  recipeTitle,
  matrix,
  isExpanded,
}: NutritionMatrixDisclosureProps) {
  return (
    <AnimatePresence initial={false}>
      {isExpanded ? (
        <motion.div
          key="tbca-matrix"
          initial={TITAN_MOTION_VARIANTS.panel.initial}
          animate={TITAN_MOTION_VARIANTS.panel.animate}
          exit={TITAN_MOTION_VARIANTS.panel.exit}
          className="overflow-hidden"
        >
          <NutritionMatrix
            matrixId={matrixId}
            recipeTitle={recipeTitle}
            matrix={matrix}
          />
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
});
