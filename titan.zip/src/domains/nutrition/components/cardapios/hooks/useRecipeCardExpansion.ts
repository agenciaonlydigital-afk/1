import { useCallback, useState } from 'react';

export function useRecipeCardExpansion() {
  const [cardOverrides, setCardOverrides] = useState<Record<string, boolean>>({});

  const isCardExpanded = useCallback(
    (recipeId: string, defaultExpanded: boolean): boolean =>
      cardOverrides[recipeId] ?? defaultExpanded,
    [cardOverrides],
  );

  const toggleCardExpansion = useCallback((recipeId: string, defaultExpanded: boolean) => {
    setCardOverrides((prev) => {
      const current = prev[recipeId] ?? defaultExpanded;
      return {
        ...prev,
        [recipeId]: !current,
      };
    });
  }, []);

  const pruneRemovedCards = useCallback((activeRecipeIds: readonly string[]) => {
    const activeSet = new Set(activeRecipeIds);
    setCardOverrides((prev) => {
      const keys = Object.keys(prev);
      if (keys.every((key) => activeSet.has(key))) {
        return prev;
      }
      const next: Record<string, boolean> = {};
      for (const key of keys) {
        if (activeSet.has(key)) {
          next[key] = prev[key]!;
        }
      }
      return next;
    });
  }, []);

  return {
    isCardExpanded,
    toggleCardExpansion,
    pruneRemovedCards,
  };
}
