import assert from 'node:assert/strict';
import { buildInitialComposerPlans } from '../../../domain/rules/cardapio-composer-engine.ts';
import { buildMealFromCardapioSlot } from '../../../domain/rules/recipe-engine.ts';
import { ensureTbcaCatalogLoaded } from '../../../data/sources/tbca-adapter.ts';
import { buildCardapiosViewModel } from '../view-models/cardapios.mapper.ts';

await ensureTbcaCatalogLoaded();

const dateKey = '2026-11-26';
const meals = [
  buildMealFromCardapioSlot({
    id: 'meal-1',
    dateKey,
    time: '07:30',
    title: 'Café da manhã',
    recipeId: 'rec-cafe-completo',
    status: 'planned',
  }),
  buildMealFromCardapioSlot({
    id: 'meal-2',
    dateKey,
    time: '12:30',
    title: 'Almoço',
    recipeId: 'rec-almoco-frango',
    status: 'consumed',
  }),
  buildMealFromCardapioSlot({
    id: 'meal-3',
    dateKey,
    time: '16:00',
    title: 'Lanche da tarde',
    recipeId: 'rec-lanche-iogurte',
    status: 'consumed',
  }),
  buildMealFromCardapioSlot({
    id: 'meal-4',
    dateKey,
    time: '20:30',
    title: 'Jantar',
    recipeId: 'rec-jantar-salmao',
    status: 'planned',
  }),
];

const plans = buildInitialComposerPlans(
  dateKey,
  { kcal: 2550, proteinG: 170, carbsG: 285, fatG: 76 },
  meals,
);

const vm = buildCardapiosViewModel(plans, dateKey, meals);

// Cardápio A e B mantêm agrupamento e receitas independentes
assert.equal(vm.menus.length, 2);
assert.equal(vm.menus[0].code, 'Cardápio A');
assert.equal(vm.menus[1].code, 'Cardápio B');
assert.ok(vm.menus[0].recipes.length >= 3);
assert.ok(vm.menus[1].recipes.length >= 3);

// IDs únicos por receita e menu
const allRecipeIds = vm.menus.flatMap((m) => m.recipes.map((r) => r.recipeId));
assert.equal(new Set(allRecipeIds).size, allRecipeIds.length);

// Somente a próxima receita a ser consumida no cardápio ativo é marcada como isNextToConsume
const nextRecipes = vm.menus.flatMap((m) => m.recipes).filter((r) => r.isNextToConsume);
assert.equal(nextRecipes.length, 1);
assert.equal(nextRecipes[0].menuId, vm.menus[0].menuId);
assert.equal(nextRecipes[0].consumptionStatus, 'planned');
assert.equal(nextRecipes[0].mealTime, '07:30');

// Quando meal-1 é consumida, a próxima receita a consumir passa a ser meal-4 (20:30)
const updatedMeals = meals.map((m) =>
  m.id === 'meal-1' ? { ...m, status: 'consumed' } : m,
);
const vmAfterBreakfast = buildCardapiosViewModel(plans, dateKey, updatedMeals);
const nextAfterBreakfast = vmAfterBreakfast.menus
  .flatMap((m) => m.recipes)
  .filter((r) => r.isNextToConsume);
assert.equal(nextAfterBreakfast.length, 1);
assert.equal(nextAfterBreakfast[0].mealTime, '20:30');

// Ordem fixa das 6 primeiras colunas e ausência de kJ
for (const recipe of vm.menus[0].recipes) {
  const firstSix = recipe.nutritionMatrix.columns.slice(0, 6).map((c) => c.label);
  assert.deepEqual(firstSix, [
    'Alimento',
    'Quantidade',
    'kcal',
    'Proteínas',
    'Carboidratos',
    'Gorduras',
  ]);
  assert.equal(
    recipe.nutritionMatrix.columns.some((c) => c.unit === 'kJ' || c.label.toLowerCase() === 'kj'),
    false,
  );
}

// Preserva status de ausência/não analisado sem colapsar para zero
const yogurtRecipe = vm.menus[0].recipes.find((r) => r.title.includes('Iogurte'));
assert.ok(yogurtRecipe, 'Yogurt recipe should exist');
const yogurtRow = yogurtRecipe.nutritionMatrix.rows.find((row) =>
  row.foodName.includes('Iogurte'),
);
assert.ok(yogurtRow);
assert.equal(yogurtRow.cells.vitamin_d?.status, 'not-in-source');
assert.equal(yogurtRow.cells.vitamin_k?.status, 'not-in-source');

// Histórico abaixo dos cardápios diferencia planejada vs confirmada
assert.equal(vm.history.length, 4);
const plannedRow = vm.history.find((h) => h.mealId === 'meal-1');
const consumedRow = vm.history.find((h) => h.mealId === 'meal-2');
assert.equal(plannedRow?.syncStatus, 'pending');
assert.equal(plannedRow?.statusLabel, 'Planejada');
assert.equal(consumedRow?.syncStatus, 'confirmed');
assert.equal(consumedRow?.statusLabel, 'Confirmada');

console.log('Cardápios view-model and TBCA matrix tests passed.');
