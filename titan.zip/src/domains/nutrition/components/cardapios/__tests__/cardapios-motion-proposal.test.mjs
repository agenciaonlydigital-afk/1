import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import esbuild from 'esbuild';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { ensureTbcaCatalogLoaded } from '../../../data/sources/tbca-adapter.ts';
import { buildInitialComposerPlans } from '../../../domain/rules/cardapio-composer-engine.ts';
import { solveMacroTargetFitQP } from '../../../domain/rules/macro-target-fit.ts';
import { buildMealFromCardapioSlot } from '../../../domain/rules/recipe-engine.ts';
import { buildCardapiosViewModel } from '../view-models/cardapios.mapper.ts';

await ensureTbcaCatalogLoaded();

const tmpRoot = path.resolve('node_modules');
await fs.mkdir(tmpRoot, { recursive: true });
const tmpDir = await fs.mkdtemp(path.join(tmpRoot, '.tmp-cardapios-motion-'));

try {
  await esbuild.build({
    entryPoints: [
      path.resolve('src/shared/motion/titan-motion.ts'),
      path.resolve('src/domains/nutrition/components/cardapios/components/CardapiosContent.tsx'),
      path.resolve('src/domains/nutrition/components/cardapios/components/MacroFitProposalBanner.tsx'),
      path.resolve('src/domains/nutrition/components/cardapios/components/NutritionMatrixDisclosure.tsx'),
    ],
    outdir: tmpDir,
    bundle: true,
    format: 'esm',
    platform: 'node',
    jsx: 'automatic',
    external: ['react', 'react-dom', 'lucide-react', 'motion/react', 'motion'],
    outExtension: { '.js': '.mjs' },
  });

  const { TITAN_MOTION_VARIANTS } = await import(
    pathToFileURL(path.join(tmpDir, 'shared/motion/titan-motion.mjs')).href
  );
  assert.ok(TITAN_MOTION_VARIANTS, 'titan-motion must export centralized TITAN_MOTION_VARIANTS');
  assert.ok(TITAN_MOTION_VARIANTS.enter && TITAN_MOTION_VARIANTS.exit && TITAN_MOTION_VARIANTS.panel && TITAN_MOTION_VARIANTS.reduced);

  const { MacroFitProposalBanner } = await import(
    pathToFileURL(path.join(tmpDir, 'domains/nutrition/components/cardapios/components/MacroFitProposalBanner.mjs')).href
  );

  const dateKey = '2026-11-26';
  const meals = [
    buildMealFromCardapioSlot({
      id: 'meal-1',
      dateKey,
      time: '07:30',
      title: 'Café da manhã',
      recipeId: 'rec-cafe-completo',
      status: 'planned',
    }),
  ];
  const plans = buildInitialComposerPlans(dateKey, { kcal: 2550, proteinG: 170, carbsG: 285, fatG: 76 }, meals);
  const dayPlan = plans[0].days[dateKey];
  const targets = { kcal: 2150, proteinG: 165, carbsG: 220, fatG: 68 };
  const result = solveMacroTargetFitQP(dayPlan, targets);

  // 1. Ready proposal banner renders aria-live="polite", before/after info, recipe scale %, Aplicar / Descartar buttons, zero prohibited CSS
  const readyHtml = renderToStaticMarkup(
    React.createElement(MacroFitProposalBanner, {
      snapshot: {
        status: 'ready',
        requestId: 2,
        planId: plans[0].id,
        dateKey,
        planRevision: plans[0].revision,
        inputsRevision: 2,
        scaleMode: 'preserve_recipe_ratios',
        result,
        errorMessage: null,
      },
      canUndo: false,
      justApplied: false,
      onApply: () => {},
      onDismiss: () => {},
      onUndo: () => {},
    }),
  );

  assert.ok(readyHtml.includes('aria-live="polite"'), 'status banner must expose aria-live="polite"');
  assert.ok(readyHtml.includes('Aplicar ajuste'), 'ready banner must show Aplicar ajuste action');
  assert.ok(readyHtml.includes('Descartar'), 'ready banner must show Descartar action');
  assert.ok(readyHtml.includes('%'), 'ready banner must summarize per-recipe scale percentage');
  assert.ok(!readyHtml.includes('backdrop-blur'));
  assert.ok(!readyHtml.includes('linear-gradient'));

  // 2. Undo button appears cleanly when canUndo is true after application
  const appliedHtml = renderToStaticMarkup(
    React.createElement(MacroFitProposalBanner, {
      snapshot: {
        status: 'idle',
        requestId: 2,
        planId: plans[0].id,
        dateKey,
        planRevision: plans[0].revision + 1,
        inputsRevision: 3,
        scaleMode: 'preserve_recipe_ratios',
        result: null,
        errorMessage: null,
      },
      canUndo: true,
      justApplied: true,
      onApply: () => {},
      onDismiss: () => {},
      onUndo: () => {},
    }),
  );
  assert.ok(appliedHtml.includes('Desfazer'), 'post-apply banner must expose atomic Desfazer button');

  console.log('cardapios-motion-proposal.test.mjs: PASS');
} finally {
  await fs.rm(tmpDir, { recursive: true, force: true });
}
