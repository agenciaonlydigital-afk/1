import assert from 'node:assert/strict';
import {
  aggregateDailyMacros,
  computePortionsMacrosWithQuality,
  aggregateDailyMicronutrients,
  getEffectiveConsumedPortions,
  normalizeNutrientEntry,
  resolveFoodById,
  resolveNutrientDisplay,
  resolveReferenceProfile,
} from '../domain/rules/nutrition-calculator';
import type { MealItem } from '../domain/entities/nutrient';

const TEST_DATE = '2026-11-21';

// 1. Planned meal must NOT count toward consumed daily energy/macros
const sampleMeals: MealItem[] = [
  {
    id: 'm1',
    dateKey: TEST_DATE,
    time: '08:00',
    title: 'Café',
    description: 'Banana',
    planned_quantity: 100,
    consumed_quantity: 100,
    planned_foods: [{ foodId: 'tbca-banana-prata', quantityG: 100 }],
    consumed_foods: [{ foodId: 'tbca-banana-prata', quantityG: 100 }],
    status: 'consumed',
  },
  {
    id: 'm2',
    dateKey: TEST_DATE,
    time: '12:30',
    title: 'Almoço',
    description: 'Frango, arroz e legumes',
    planned_quantity: 400,
    consumed_quantity: 0,
    planned_foods: [{ foodId: 'tbca-frango-arroz-legumes', quantityG: 400 }],
    consumed_foods: [],
    status: 'planned',
  },
];

const totalsWithPlanned = aggregateDailyMacros(sampleMeals, TEST_DATE);
assert.equal(Math.round(totalsWithPlanned.kcal), 107, 'canonical TBCA banana prata is 107 kcal per 100 g; the previous alias resolved to an unrelated onion record');

// 2. Canonical banana sodium is a quantified zero, not the old alias's unrelated trace state
const aggregated = aggregateDailyMicronutrients(
  sampleMeals,
  TEST_DATE,
  'adult_male_19_50',
);
assert.equal(aggregated.sodium.dataStatus, 'quantified');
assert.equal(aggregated.sodium.consumedValue, 0);

// 3. Canonical TBCA banana has a direct RAE measurement
const banana = resolveFoodById('tbca-banana-prata');
assert.ok(banana);
const vitARecord = normalizeNutrientEntry(banana, 'vitamin_a');
assert.equal(vitARecord.original_unit, 'µg RAE');
assert.equal(vitARecord.conversion_method, 'direct_rae');
assert.equal(vitARecord.data_status, 'quantified');

// 4. Partial meal scales proportionally
const baseLunch = sampleMeals[1];
assert.ok(baseLunch);
const partialMeals: MealItem[] = [
  {
    ...baseLunch,
    status: 'partial',
    consumed_quantity: 200,
    consumed_foods: [{ foodId: 'tbca-frango-arroz-legumes', quantityG: 200 }],
  },
];
const partialTotals = aggregateDailyMacros(partialMeals, TEST_DATE);
assert.equal(Math.round(partialTotals.kcal), 310);

// 5. Sodium AI and CDRR are distinct: AI is not a maximum, CDRR is the limit
const profile = resolveReferenceProfile('adult_male_19_50');
const sodiumDisplay = resolveNutrientDisplay(
  {
    nutrientId: 'sodium',
    consumedValue: 2800,
    unit: 'mg',
    dataStatus: 'quantified',
    contributions: [],
    hasUnquantifiedSources: false,
  },
  profile.entries.sodium,
  profile,
);
assert.equal(sodiumDisplay.isLimitMetric, false, 'sodium AI is an adequacy reference, not a limit metric');
assert.equal(sodiumDisplay.referenceKind, 'AI');
assert.equal(sodiumDisplay.referenceValue, 1500);
assert.equal(sodiumDisplay.limitKind, 'CDRR');
assert.equal(sodiumDisplay.limitValue, 2300);
assert.equal(sodiumDisplay.isLimitExceeded, true);
assert.equal(sodiumDisplay.isExceeded, false);
assert.equal(profile.entries.sodium.upperLimit, undefined, 'CDRR must not be encoded as a UL');
assert.equal(sodiumDisplay.barPercent, 100);
assert.ok((sodiumDisplay.rawPercent ?? 0) > 100);
const sodiumBelowCdrr = resolveNutrientDisplay(
  { nutrientId: 'sodium', consumedValue: 2000, unit: 'mg', dataStatus: 'quantified', contributions: [], hasUnquantifiedSources: false },
  profile.entries.sodium,
  profile,
);
assert.equal(sodiumBelowCdrr.isLimitExceeded, false, 'intake above the AI but below the CDRR is not an exceeded limit');
assert.equal(sodiumBelowCdrr.isExceeded, false);
assert.equal(sodiumBelowCdrr.rawPercent, 133);

// Macro calculations retain fractional gram precision and disclose missing-food coverage.
const quality = computePortionsMacrosWithQuality([
  { foodId: 'tbca-banana-prata', quantityG: 37.5 },
  { foodId: 'missing-food-id', quantityG: 12.5 },
]);
assert.equal(quality.requestedGrams, 50);
assert.equal(quality.quantifiedGrams, 37.5);
assert.equal(quality.coveragePercent, 75);
assert.deepEqual(quality.unresolvedFoodIds, ['missing-food-id']);
assert.ok(quality.macros.kcal > 0);
assert.equal(computePortionsMacrosWithQuality([]).coveragePercent, 0, 'empty recipes must not claim full data coverage');

// The final workbook's 5,830 eligible TBCA rows are loaded without converting NA to zero.
const avocado = resolveFoodById('tbca:BRC0001C');
assert.ok(avocado);
assert.equal(avocado.source_record_id, 'BRC0001C');
assert.equal(avocado.macros.basisQuantityG, 100);
assert.equal(avocado.macros.kcalPerBasis, 76);
assert.equal(avocado.micronutrients.vitamin_k?.data_status, 'not_analyzed');
assert.equal(avocado.micronutrients.vitamin_c?.data_status, 'quantified');
assert.ok(avocado.source_url?.includes('tbca.net.br'));

// Exact consumed ingredient mass takes precedence over rounded portion display values.
const fractionalPartial: MealItem = {
  ...sampleMeals[0]!, status: 'partial', planned_quantity: 1, consumed_quantity: 1,
  planned_foods: [{ foodId: 'tbca-banana-prata', quantityG: 1 }],
  consumed_foods: [{ foodId: 'tbca-banana-prata', quantityG: 0.375 }],
};
assert.equal(getEffectiveConsumedPortions(fractionalPartial)[0]?.quantityG, 0.375);
