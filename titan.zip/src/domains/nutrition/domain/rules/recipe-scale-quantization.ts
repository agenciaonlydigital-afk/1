import type {
  ComposerDayPlan,
  ComposerMacroTotals,
  MicronutrientOptimizationResult,
  MicronutrientOptimizationStatus,
  OptimizationProposal,
  ProposedIngredientChange,
  SolverCertificate,
  NutritionTargets,
} from '../entities/nutrient.ts';
import {
  MICRONUTRIENT_PT_LABELS,
  cloneDayPlan,
  computeDayNutrition,
  roundGramsHalf,
  type ComposerNutritionSummary,
} from './cardapio-composer-engine.ts';
import type { PreparedRecipeScaleModel } from './recipe-scale-model.ts';

export type MacroFitStatus =
  | 'target_met'
  | 'approximate_feasible'
  | 'infeasible'
  | 'insufficient_data';

export interface RecipeScaleAppliedSummary {
  slotId: string;
  slotTitle: string;
  recipeId: string;
  recipeName: string;
  continuousScale: number;
  effectiveScale: number;
  scalePercent: number;
  minScale: number;
  maxScale: number;
}

export interface MacroGapSnapshot {
  kcalDiff: number;
  proteinDiffG: number;
  carbsDiffG: number;
  fatDiffG: number;
}

export interface RecipeScaleQuantizationResult {
  status: MacroFitStatus;
  proposal: OptimizationProposal;
  beforeSummary: ComposerNutritionSummary;
  afterSummary: ComposerNutritionSummary;
  beforeGaps: MacroGapSnapshot;
  afterGaps: MacroGapSnapshot;
  recipeScales: RecipeScaleAppliedSummary[];
  blockReason: string | null;
}

function clampIngredientGrams(value: number, minG: number, maxG: number): number {
  const effectiveMin = Math.max(1, Math.min(2000, minG));
  const effectiveMax = Math.max(effectiveMin, Math.min(2000, maxG));
  const rounded = roundGramsHalf(value);
  const clamped = Math.max(effectiveMin, Math.min(effectiveMax, rounded));
  // Ensure clamped respects >= effectiveMin and <= effectiveMax on 0.5g grid if possible
  const grid = roundGramsHalf(clamped);
  if (grid < effectiveMin) return Math.min(effectiveMax, Math.ceil(effectiveMin * 2) / 2);
  if (grid > effectiveMax) return Math.max(effectiveMin, Math.floor(effectiveMax * 2) / 2);
  return grid;
}

function computeMacroGapSnapshot(
  macros: ComposerMacroTotals,
  targets: NutritionTargets,
): MacroGapSnapshot {
  return {
    kcalDiff: Number((macros.kcal - targets.kcal).toFixed(1)),
    proteinDiffG: Number((macros.proteinG - targets.proteinG).toFixed(1)),
    carbsDiffG: Number((macros.carbsG - targets.carbsG).toFixed(1)),
    fatDiffG: Number((macros.fatG - targets.fatG).toFixed(1)),
  };
}

function isWithinTargetCorridors(
  macros: ComposerMacroTotals,
  targets: NutritionTargets,
): boolean {
  const kcalMin = targets.kcalMin ?? targets.kcal - Math.max(55, targets.kcal * 0.03);
  const kcalMax = targets.kcalMax ?? targets.kcal + Math.max(55, targets.kcal * 0.03);
  const pMin = targets.proteinMinG ?? targets.proteinG - Math.max(8, targets.proteinG * 0.06);
  const pMax = targets.proteinMaxG ?? targets.proteinG + Math.max(8, targets.proteinG * 0.06);
  const cMin = targets.carbsMinG ?? targets.carbsG - Math.max(12, targets.carbsG * 0.07);
  const cMax = targets.carbsMaxG ?? targets.carbsG + Math.max(12, targets.carbsG * 0.07);
  const fMin = targets.fatMinG ?? targets.fatG - Math.max(6, targets.fatG * 0.08);
  const fMax = targets.fatMaxG ?? targets.fatG + Math.max(6, targets.fatG * 0.08);

  return (
    macros.kcal >= kcalMin - 1e-6 &&
    macros.kcal <= kcalMax + 1e-6 &&
    macros.proteinG >= pMin - 1e-6 &&
    macros.proteinG <= pMax + 1e-6 &&
    macros.carbsG >= cMin - 1e-6 &&
    macros.carbsG <= cMax + 1e-6 &&
    macros.fatG >= fMin - 1e-6 &&
    macros.fatG <= fMax + 1e-6
  );
}

export function quantizeAndValidateRecipeScaleProposal(
  dayPlan: ComposerDayPlan,
  targets: NutritionTargets,
  model: PreparedRecipeScaleModel,
  solvedScales: readonly number[],
  solveDurationMs: number,
  options: {
    solverEngine: string;
    hasSolverWarning?: boolean;
    warningReason?: string;
    hasInfeasibleError?: boolean;
  },
): RecipeScaleQuantizationResult {
  const beforeSummary = model.beforeSummary;
  const proposedMap = new Map<string, number>();
  const changes: ProposedIngredientChange[] = [];

  // Clamped continuous scales per recipe decision var
  const clampedScales = model.vars.map((recipeVar, idx) => {
    const raw = solvedScales[idx] ?? recipeVar.refScale;
    const finite = Number.isFinite(raw) ? raw : recipeVar.refScale;
    return Math.max(recipeVar.minScale, Math.min(recipeVar.maxScale, finite));
  });

  // Per-recipe quantized ingredient arrays (parallel to model.vars[r].ingredients)
  const quantizedByRecipe: number[][] = model.vars.map((recipeVar, rIdx) => {
    const s = clampedScales[rIdx]!;
    return recipeVar.ingredients.map((ing) => clampIngredientGrams(ing.baselineG * s, ing.minG, ing.maxG));
  });

  // Clone micronutrient constraints so caller model is not mutated in-place
  const clonedMicroConstraints = model.micronutrientConstraints.map((c) => ({
    ...c,
    coefficients: [...c.coefficients],
  }));

  // Post-rounding UL audit & ratio-preserving scale repair:
  // If rounding pushed an applied UL over, step down offending recipe scales slightly while preserving ratios.
  for (const constraint of clonedMicroConstraints) {
    if (constraint.status !== 'applied' || constraint.upperLimit === null) continue;

    const computeMicroTotal = () => {
      let total = constraint.fixedValue;
      for (let r = 0; r < model.vars.length; r += 1) {
        const recipeVar = model.vars[r]!;
        const qArr = quantizedByRecipe[r]!;
        for (let j = 0; j < recipeVar.ingredients.length; j += 1) {
          const perG = recipeVar.ingredients[j]!.micronutrientsPerG[constraint.nutrientId] ?? 0;
          total += perG * qArr[j]!;
        }
      }
      return total;
    };

    let total = computeMicroTotal();
    if (total <= constraint.upperLimit + 1e-6) continue;

    // Sort recipes by micro contribution per unit scale descending
    const recipeCandidates = model.vars
      .map((recipeVar, rIdx) => {
        const coeff = constraint.coefficients[rIdx] ?? 0;
        const curScale = clampedScales[rIdx]!;
        return {
          rIdx,
          coeff,
          availableScale: curScale - recipeVar.minScale,
        };
      })
      .filter((c) => c.coeff > 0)
      .sort((a, b) => b.coeff - a.coeff);

    for (const candidate of recipeCandidates) {
      if (total <= constraint.upperLimit + 1e-6) break;
      const recipeVar = model.vars[candidate.rIdx]!;
      const excess = total - constraint.upperLimit;
      const deltaScaleNeeded = excess / candidate.coeff;
      const nextScale = Math.max(
        recipeVar.minScale,
        clampedScales[candidate.rIdx]! - deltaScaleNeeded * 1.02,
      );
      clampedScales[candidate.rIdx] = nextScale;
      quantizedByRecipe[candidate.rIdx] = recipeVar.ingredients.map((ing) =>
        clampIngredientGrams(ing.baselineG * nextScale, ing.minG, ing.maxG),
      );
      total = computeMicroTotal();
      // Fine step down at 0.5g resolution if discrete rounding left tiny residual
      let guard = 0;
      while (total > constraint.upperLimit + 1e-6 && guard < 24) {
        guard += 1;
        let reducedAny = false;
        const qArr = quantizedByRecipe[candidate.rIdx]!;
        // Find ingredient in this recipe with positive micro coeff that can drop by 0.5g
        for (let j = 0; j < recipeVar.ingredients.length; j += 1) {
          const ing = recipeVar.ingredients[j]!;
          const perG = ing.micronutrientsPerG[constraint.nutrientId] ?? 0;
          const minAllowed = Math.max(1, ing.minG);
          if (perG > 0 && qArr[j]! - 0.5 >= minAllowed - 1e-9) {
            qArr[j] = clampIngredientGrams(qArr[j]! - 0.5, ing.minG, ing.maxG);
            reducedAny = true;
          }
        }
        if (!reducedAny) break;
        total = computeMicroTotal();
      }
    }

    if (total > constraint.upperLimit + 1e-6) {
      constraint.status = 'infeasible_upper_limit';
      constraint.reason =
        'Não foi possível manter o UL após o arredondamento em 0,5 g sem violar os limites mínimos dos ingredientes.';
    }
  }

  let atBoundCount = 0;
  const recipeScales: RecipeScaleAppliedSummary[] = [];

  for (let r = 0; r < model.vars.length; r += 1) {
    const recipeVar = model.vars[r]!;
    const qArr = quantizedByRecipe[r]!;
    let sumCurrent = 0;
    let sumProposed = 0;

    for (let j = 0; j < recipeVar.ingredients.length; j += 1) {
      const ing = recipeVar.ingredients[j]!;
      const rounded = qArr[j]!;
      const key = `${ing.slotId}::${ing.recipeId}::${ing.ingredientId}`;
      proposedMap.set(key, rounded);

      sumCurrent += ing.currentG;
      sumProposed += rounded;

      const effectiveMin = Math.max(1, ing.minG);
      const effectiveMax = Math.min(2000, ing.maxG);
      const atLowerBound = Math.abs(rounded - effectiveMin) <= 0.5;
      const atUpperBound = Math.abs(rounded - effectiveMax) <= 0.5;
      if (atLowerBound || atUpperBound) atBoundCount += 1;

      changes.push({
        slotId: ing.slotId,
        slotTitle: recipeVar.slotTitle,
        recipeId: ing.recipeId,
        recipeName: recipeVar.recipeName,
        ingredientId: ing.ingredientId,
        foodId: ing.foodId,
        foodName: ing.foodName,
        currentQuantityG: ing.currentG,
        proposedQuantityG: rounded,
        referenceQuantityG: ing.templateRefG,
        deltaG: Number((rounded - ing.currentG).toFixed(1)),
        atLowerBound,
        atUpperBound,
      });
    }

    const effectiveScale =
      recipeVar.totalBaselineGrams > 0 ? sumProposed / recipeVar.totalBaselineGrams : clampedScales[r]!;
    recipeScales.push({
      slotId: recipeVar.slotId,
      slotTitle: recipeVar.slotTitle,
      recipeId: recipeVar.recipeId,
      recipeName: recipeVar.recipeName,
      continuousScale: Number(clampedScales[r]!.toFixed(4)),
      effectiveScale: Number(effectiveScale.toFixed(4)),
      scalePercent: Math.round(effectiveScale * 100),
      minScale: Number(recipeVar.minScale.toFixed(4)),
      maxScale: Number(recipeVar.maxScale.toFixed(4)),
    });
  }

  // Reconstruct proposed day plan without modifying locked / missing / to_taste / unresolved ingredients
  const proposedDayPlan = cloneDayPlan(dayPlan);
  const scaleByRecipeKey = new Map<string, RecipeScaleAppliedSummary>();
  for (const rs of recipeScales) {
    scaleByRecipeKey.set(`${rs.slotId}::${rs.recipeId}`, rs);
  }

  for (const slot of proposedDayPlan.slots) {
    for (const recipe of slot.recipes) {
      for (const ingredient of recipe.ingredients) {
        if (
          ingredient.mode === 'locked' ||
          ingredient.quantityStatus !== 'known' ||
          ingredient.currentQuantityG === null
        ) {
          continue;
        }
        const key = `${slot.id}::${recipe.id}::${ingredient.id}`;
        const nextQ = proposedMap.get(key);
        if (nextQ !== undefined) {
          ingredient.currentQuantityG = nextQ;
        }
      }
      const scaleSummary = scaleByRecipeKey.get(`${slot.id}::${recipe.id}`);
      if (scaleSummary) {
        const baseServ =
          Number.isFinite(recipe.targetServings) && recipe.targetServings > 0
            ? recipe.targetServings
            : 1;
        // Scale servings proportionally relative to baselineSource
        const factor =
          model.baselineSource === 'templateBaseline'
            ? scaleSummary.effectiveScale
            : baseServ * scaleSummary.effectiveScale;
        recipe.targetServings = Number(Math.max(0.25, Math.min(4, factor)).toFixed(2));
      }
    }
  }

  // Mandatory full recomputation from persisted grams
  const afterSummary = computeDayNutrition(proposedDayPlan);

  const micronutrientResults: MicronutrientOptimizationResult[] = clonedMicroConstraints.map(
    (constraint) => {
      const beforeMetric = beforeSummary.micronutrients[constraint.nutrientId];
      const afterMetric = afterSummary.micronutrients[constraint.nutrientId];
      const canReportValues =
        constraint.status !== 'insufficient_data' &&
        constraint.status !== 'not_applicable_scope' &&
        beforeMetric.dataStatus === 'quantified' &&
        afterMetric.dataStatus === 'quantified';
      const beforeValue = canReportValues ? beforeMetric.value : null;
      const afterValue = canReportValues ? afterMetric.value : null;
      const withinUpperLimit =
        constraint.upperLimit !== null && afterValue !== null
          ? afterValue <= constraint.upperLimit + 1e-6
          : null;
      const nextStatus: MicronutrientOptimizationStatus =
        constraint.status === 'applied' && withinUpperLimit === false
          ? 'infeasible_upper_limit'
          : constraint.status;
      return {
        nutrientId: constraint.nutrientId,
        unit: constraint.unit,
        status: nextStatus,
        reason:
          nextStatus === 'infeasible_upper_limit' && !constraint.reason
            ? 'A porção final ultrapassou o limite superior após o arredondamento em 0,5 g.'
            : constraint.reason,
        minimum: constraint.minimum,
        minimumKind: constraint.minimumKind,
        preferredMaximum: constraint.preferredMaximum,
        upperLimit: constraint.upperLimit,
        beforeValue,
        afterValue,
        meetsMinimum:
          constraint.minimum !== null && afterValue !== null ? afterValue >= constraint.minimum : null,
        withinPreferredMaximum:
          constraint.preferredMaximum !== null && afterValue !== null
            ? afterValue <= constraint.preferredMaximum
            : null,
        withinUpperLimit,
      };
    },
  );

  const ulViolation = micronutrientResults.find(
    (result) =>
      result.upperLimit !== null &&
      (result.withinUpperLimit === false || result.status === 'infeasible_upper_limit'),
  );
  const blockReason = ulViolation
    ? `${MICRONUTRIENT_PT_LABELS[ulViolation.nutrientId]?.label ?? ulViolation.nutrientId}: a proposta ultrapassa o limite superior aplicável (${ulViolation.upperLimit} ${ulViolation.unit}) e não pode ser aplicada.`
    : model.hasContradictoryBounds
      ? 'Limites mínimos e máximos contraditórios impedem o ajuste proporcional seguro.'
      : null;

  const hasIncompleteNutritionData =
    model.hasIncompleteNutritionData ||
    afterSummary.unresolvedFoodIds.length > 0 ||
    afterSummary.lowConfidenceFoodIds.length > 0 ||
    afterSummary.missingIngredientsCount > 0 ||
    afterSummary.toTasteIngredientsCount > 0 ||
    afterSummary.coveragePercent < 99.99 ||
    micronutrientResults.some((result) => result.status === 'insufficient_data');

  const hasUnmetMicronutrientPreferences = micronutrientResults.some(
    (result) =>
      result.status === 'applied' &&
      (result.meetsMinimum === false || result.withinPreferredMaximum === false),
  );

  const targetsCloselyMet = isWithinTargetCorridors(afterSummary.macros, targets);

  let status: MacroFitStatus = 'target_met';
  let certificate: SolverCertificate = 'optimal';
  let explanation =
    model.slotTargets.length > 0
      ? 'Escala proporcional por receita aplicada respeitando metas diárias, distribuição por refeição e limites culinários.'
      : 'Escala proporcional por receita aplicada dentro dos limites culinários, preservando a proporção interna dos ingredientes.';

  if (options.hasInfeasibleError || model.hasContradictoryBounds || ulViolation !== undefined) {
    status = 'infeasible';
    certificate = 'feasible';
    explanation =
      blockReason ??
      'As restrições rígidas de porção ou limites superiores de micronutrientes tornaram o ajuste inviável.';
  } else if (hasIncompleteNutritionData) {
    status = 'insufficient_data';
    certificate = 'approximate';
    explanation =
      'Resultado aproximado: existem ingredientes sem quantidade definida ou composição nutricional completa. Apenas a parcela quantificada foi ajustada.';
  } else if (options.hasSolverWarning) {
    status = 'approximate_feasible';
    certificate = 'approximate';
    explanation =
      options.warningReason ??
      'Aproximação numérica gerada preservando as proporções das receitas.';
  } else if (!targetsCloselyMet || hasUnmetMicronutrientPreferences) {
    status = 'approximate_feasible';
    certificate = 'feasible';
    const reasons: string[] = [];
    if (atBoundCount > 0) {
      reasons.push(`${atBoundCount} ingrediente(s) atingiram limite mínimo/máximo de porção`);
    }
    if (model.lockedIngredientsCount > 0) {
      reasons.push(`${model.lockedIngredientsCount} ingrediente(s) travado(s)`);
    }
    explanation =
      reasons.length > 0
        ? `Melhor escala proporcional viável (${reasons.join(' · ')}). Para fechar totalmente os 4 macros sem distorcer receitas, avalie trocas discretas ou adicione receitas complementares.`
        : 'Melhor escala proporcional viável preservando a identidade de cada receita. Como cada receita escala em bloco, algumas metas simultâneas de P/C/G ficam em aproximação.';
  }

  const adjustedCount = changes.filter((c) => Math.abs(c.deltaG) >= 0.5).length;

  const proposal: OptimizationProposal = {
    id: `opt-${Date.now().toString(36)}`,
    certificate,
    solverEngine: options.solverEngine,
    explanation,
    beforeMacros: beforeSummary.macros,
    afterMacros: afterSummary.macros,
    targets: { ...targets },
    weightedDeviationBeforePercent: beforeSummary.weightedDeviationPercent,
    weightedDeviationAfterPercent: afterSummary.weightedDeviationPercent,
    adjustedCount,
    lockedCount: model.lockedIngredientsCount,
    proportionalCount: changes.length,
    micronutrientResults,
    changes,
    proposedDayPlan,
    solveDurationMs: Number(solveDurationMs.toFixed(2)),
  };

  return {
    status,
    proposal,
    beforeSummary,
    afterSummary,
    beforeGaps: computeMacroGapSnapshot(beforeSummary.macros, targets),
    afterGaps: computeMacroGapSnapshot(afterSummary.macros, targets),
    recipeScales,
    blockReason,
  };
}
