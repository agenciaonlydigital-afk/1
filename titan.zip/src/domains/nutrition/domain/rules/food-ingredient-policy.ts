import type { FoodSourceItem } from '../entities/nutrient.ts';

export type RecipeIngredientEligibilityReason =
  | 'eligible'
  | 'tbca_composite_preparation'
  | 'tbca_unknown_food_type'
  | 'titan_legacy_not_canonical';

export interface RecipeIngredientEligibility {
  eligible: boolean;
  reason: RecipeIngredientEligibilityReason;
}

function normalizeFoodType(foodType: string | undefined): string {
  return (foodType ?? '').trim().toLocaleUpperCase('pt-BR');
}

/** Trust the source's typed food classification; never infer composition from its display name. */
export function isCompositeFood(food: FoodSourceItem | null | undefined): boolean {
  return normalizeFoodType(food?.food_type) === 'PREPARACAO_COMPOSTA';
}

/**
 * Recipe ingredient policy is intentionally source-aware:
 * - TBCA only allows rows explicitly classified as ALIMENTO.
 * - TBCA preparations and unclassified TBCA rows fail closed.
 * - Local legacy meal snapshots are not canonical ingredient records.
 * - Other providers are not guessed from product names; they retain the current policy.
 */
export function evaluateRecipeIngredientEligibility(
  food: FoodSourceItem | null | undefined,
): RecipeIngredientEligibility {
  if (!food) return { eligible: false, reason: 'titan_legacy_not_canonical' };
  if (food.source_id === 'TBCA') {
    const foodType = normalizeFoodType(food.food_type);
    if (foodType === 'ALIMENTO') return { eligible: true, reason: 'eligible' };
    if (foodType === 'PREPARACAO_COMPOSTA') {
      return { eligible: false, reason: 'tbca_composite_preparation' };
    }
    return { eligible: false, reason: 'tbca_unknown_food_type' };
  }
  if (food.source_id === 'TITAN_LEGACY') {
    return { eligible: false, reason: 'titan_legacy_not_canonical' };
  }
  return { eligible: true, reason: 'eligible' };
}

export function isEligibleRecipeIngredient(food: FoodSourceItem | null | undefined): boolean {
  return evaluateRecipeIngredientEligibility(food).eligible;
}
