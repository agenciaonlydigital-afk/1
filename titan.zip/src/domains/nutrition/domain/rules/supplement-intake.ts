import { isValidLocalDateKey } from '../../../../shared/utils/local-date.ts';
import { MICRONUTRIENT_ORDER, type NutrientId, type UpperLimitScope } from '../entities/nutrient.ts';

export const SUPPLEMENT_CHEMICAL_FORMS = [
  'retinol', 'retinyl_acetate', 'retinyl_palmitate', 'beta_carotene',
  'folic_acid', 'methylfolate', 'food_folate', 'synthetic_niacin', 'nicotinic_acid', 'niacinamide',
  'synthetic_vitamin_d', 'natural_alpha_tocopherol', 'synthetic_alpha_tocopherol', 'magnesium_salt',
  'synthetic_form', 'other', 'unspecified',
] as const;
export type SupplementChemicalForm = typeof SUPPLEMENT_CHEMICAL_FORMS[number];

export interface SupplementMicronutrientIntake {
  id: string;
  dateKey: string;
  time: string;
  productName: string;
  nutrientId: NutrientId;
  amount: number;
  unit: string;
  chemicalForm: SupplementChemicalForm;
  sourceName: string;
  sourceVersion: string;
  sourceRecordId: string;
  sourceUrl?: string;
  recordedAt: string;
}

export interface SupplementExposureSummary {
  nutrientId: NutrientId;
  value: number | null;
  unit: string;
  status: 'not_logged' | 'quantified' | 'unit_mismatch' | 'form_unresolved' | 'source_scope_incomplete' | 'supplement_component_only';
  eventCount: number;
  excludedUnknownFormCount: number;
}

const NUTRIENT_IDS = new Set<string>(MICRONUTRIENT_ORDER);
const CHEMICAL_FORMS = new Set<string>(SUPPLEMENT_CHEMICAL_FORMS);
const COMMON_FORMS: ReadonlySet<SupplementChemicalForm> = new Set(['unspecified', 'other', 'synthetic_form']);
const MASS_TO_MG: Readonly<Record<string, number>> = { g: 1000, mg: 1, 'µg': 0.001, 'μg': 0.001, mcg: 0.001 };
const NUTRIENT_SPECIFIC_FORMS: Partial<Record<NutrientId, ReadonlySet<SupplementChemicalForm>>> = {
  vitamin_a: new Set(['retinol', 'retinyl_acetate', 'retinyl_palmitate', 'beta_carotene']),
  vitamin_b3: new Set(['synthetic_niacin', 'nicotinic_acid', 'niacinamide']),
  vitamin_b9: new Set(['folic_acid', 'methylfolate', 'food_folate']),
  vitamin_d: new Set(['synthetic_vitamin_d']),
  vitamin_e: new Set(['natural_alpha_tocopherol', 'synthetic_alpha_tocopherol']),
  magnesium: new Set(['magnesium_salt']),
};

const PREDEFINED_FORMS: ReadonlySet<SupplementChemicalForm> = new Set([
  'folic_acid', 'synthetic_niacin', 'nicotinic_acid', 'niacinamide',
]);

/** Forms that can be selected for a nutrient without creating a semantically invalid record. */
export function getAllowedSupplementChemicalForms(nutrientId: NutrientId): readonly SupplementChemicalForm[] {
  const specific = NUTRIENT_SPECIFIC_FORMS[nutrientId];
  return SUPPLEMENT_CHEMICAL_FORMS.filter((form) => COMMON_FORMS.has(form) || Boolean(specific?.has(form)));
}

export function convertSupplementMassUnit(amount: number, fromUnit: string, toUnit: string): number | null {
  if (!Number.isFinite(amount) || amount < 0) return null;
  if (fromUnit === toUnit) return amount;
  const from = MASS_TO_MG[fromUnit];
  const to = MASS_TO_MG[toUnit];
  if (from === undefined || to === undefined) return null;
  return amount * from / to;
}

export function isValidSupplementMicronutrientIntake(value: unknown): value is SupplementMicronutrientIntake {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const item = value as Record<string, unknown>;
  const timeValid = typeof item.time === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(item.time);
  const dateValid = typeof item.dateKey === 'string' && isValidLocalDateKey(item.dateKey);
  const sourceUrlValid = item.sourceUrl === undefined || (
    typeof item.sourceUrl === 'string' && item.sourceUrl.length <= 2048 && /^https:\/\//i.test(item.sourceUrl)
  );
  const nutrientId = typeof item.nutrientId === 'string' ? item.nutrientId as NutrientId : null;
  const chemicalForm = typeof item.chemicalForm === 'string' ? item.chemicalForm as SupplementChemicalForm : null;
  const allowedForms = nutrientId ? NUTRIENT_SPECIFIC_FORMS[nutrientId] : undefined;
  const chemicalFormCompatible = chemicalForm !== null && CHEMICAL_FORMS.has(chemicalForm) &&
    (COMMON_FORMS.has(chemicalForm) || Boolean(allowedForms?.has(chemicalForm)));
  return chemicalFormCompatible && typeof item.id === 'string' && item.id.trim().length > 0 && item.id.length <= 120 &&
    dateValid && timeValid &&
    typeof item.productName === 'string' && item.productName.trim().length > 0 && item.productName.length <= 160 &&
    typeof item.nutrientId === 'string' && NUTRIENT_IDS.has(item.nutrientId) &&
    typeof item.amount === 'number' && Number.isFinite(item.amount) && item.amount > 0 && item.amount <= 100_000 &&
    typeof item.unit === 'string' && item.unit.trim().length > 0 && item.unit.length <= 24 &&
    typeof item.chemicalForm === 'string' && CHEMICAL_FORMS.has(item.chemicalForm) &&
    typeof item.sourceName === 'string' && item.sourceName.trim().length > 0 && item.sourceName.length <= 120 &&
    typeof item.sourceVersion === 'string' && item.sourceVersion.trim().length > 0 && item.sourceVersion.length <= 80 &&
    typeof item.sourceRecordId === 'string' && item.sourceRecordId.trim().length > 0 && item.sourceRecordId.length <= 180 &&
    typeof item.recordedAt === 'string' && Number.isFinite(Date.parse(item.recordedAt)) && sourceUrlValid;
}

function matchesScope(form: SupplementChemicalForm, scope: UpperLimitScope): boolean | null {
  if (scope === 'supplements_only' || scope === 'total_intake' || scope === 'supplements_and_medications') return true;
  if (form === 'unspecified' || form === 'other' || form === 'synthetic_form') return null;
  if (scope === 'preformed_only') return ['retinol', 'retinyl_acetate', 'retinyl_palmitate'].includes(form);
  if (scope === 'synthetic_forms_only') return PREDEFINED_FORMS.has(form);
  return null;
}

/**
 * Aggregates supplement exposure only. It never creates a total-intake UL verdict:
 * food forms and food-derived exposure must be independently qualified first.
 */
export function aggregateSupplementMicronutrientExposure(
  events: readonly SupplementMicronutrientIntake[],
  dateKey: string,
  nutrientId: NutrientId,
  targetUnit: string,
  scope: UpperLimitScope,
): SupplementExposureSummary {
  const relevant = events.filter((event) => event.dateKey === dateKey && event.nutrientId === nutrientId);
  if (relevant.length === 0) return { nutrientId, value: null, unit: targetUnit, status: 'not_logged', eventCount: 0, excludedUnknownFormCount: 0 };
  if (scope === 'supplements_and_fortified_foods') {
    return { nutrientId, value: null, unit: targetUnit, status: 'source_scope_incomplete', eventCount: relevant.length, excludedUnknownFormCount: 0 };
  }
  let total = 0;
  let included = 0;
  let unknownForms = 0;
  let unitMismatch = false;
  for (const event of relevant) {
    const scopeMatch = matchesScope(event.chemicalForm, scope);
    if (scopeMatch === null) { unknownForms += 1; continue; }
    if (!scopeMatch) continue;
    const converted = convertSupplementMassUnit(event.amount, event.unit, targetUnit);
    if (converted === null) { unitMismatch = true; continue; }
    total += converted;
    included += 1;
  }
  if (unitMismatch) return { nutrientId, value: null, unit: targetUnit, status: 'unit_mismatch', eventCount: relevant.length, excludedUnknownFormCount: unknownForms };
  if (unknownForms > 0) return { nutrientId, value: null, unit: targetUnit, status: 'form_unresolved', eventCount: relevant.length, excludedUnknownFormCount: unknownForms };
  if (included === 0) return { nutrientId, value: null, unit: targetUnit, status: 'not_logged', eventCount: relevant.length, excludedUnknownFormCount: 0 };
  return { nutrientId, value: Number(total.toFixed(6)), unit: targetUnit, status: 'supplement_component_only', eventCount: included, excludedUnknownFormCount: 0 };
}
