import type { FoodSourceItem } from '../entities/nutrient';

export interface FoodMacroValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
}

/** Structural food-data checks inspired by wger's import sanity checks. */
export function validateFoodMacroComposition(food: FoodSourceItem): FoodMacroValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];
  const macros = food.macros;
  const required: Array<[string, number]> = [
    ['kcalPerBasis', macros.kcalPerBasis],
    ['proteinGPerBasis', macros.proteinGPerBasis],
    ['carbsGPerBasis', macros.carbsGPerBasis],
    ['fatGPerBasis', macros.fatGPerBasis],
    ['basisQuantityG', macros.basisQuantityG],
  ];
  for (const [field, value] of required) {
    if (!Number.isFinite(value) || value < 0) errors.push(`${field}_must_be_finite_and_non_negative`);
  }
  if (Number.isFinite(macros.basisQuantityG) && macros.basisQuantityG <= 0) {
    errors.push('basisQuantityG_must_be_positive');
  }

  const optional: Array<[string, number | null | undefined]> = [
    ['fiberGPerBasis', macros.fiberGPerBasis],
    ['saturatedFatGPerBasis', macros.saturatedFatGPerBasis],
    ['cholesterolMgPerBasis', macros.cholesterolMgPerBasis],
    ['sodiumMgPerBasis', macros.sodiumMgPerBasis],
  ];
  for (const [field, value] of optional) {
    if (value !== undefined && value !== null && (!Number.isFinite(value) || value < 0)) {
      errors.push(`${field}_must_be_finite_and_non_negative_when_present`);
    }
  }

  if (Number.isFinite(macros.basisQuantityG) && macros.basisQuantityG > 0 &&
      [macros.proteinGPerBasis, macros.carbsGPerBasis, macros.fatGPerBasis].every((value) => Number.isFinite(value) && value >= 0)) {
    const macroMassPer100g = ((macros.proteinGPerBasis + macros.carbsGPerBasis + macros.fatGPerBasis) / macros.basisQuantityG) * 100;
    if (macroMassPer100g > 105) errors.push('protein_carbohydrate_fat_mass_exceeds_105g_per_100g');
  }

  if (macros.saturatedFatGPerBasis !== undefined && macros.saturatedFatGPerBasis !== null &&
      Number.isFinite(macros.saturatedFatGPerBasis) && Number.isFinite(macros.fatGPerBasis) &&
      macros.saturatedFatGPerBasis > macros.fatGPerBasis + 0.1) {
    errors.push('saturated_fat_exceeds_total_fat');
  }

  if (Number.isFinite(macros.basisQuantityG) && macros.basisQuantityG > 0 &&
      [macros.kcalPerBasis, macros.proteinGPerBasis, macros.carbsGPerBasis, macros.fatGPerBasis].every((value) => Number.isFinite(value) && value >= 0)) {
    const reportedKcalPer100g = (macros.kcalPerBasis / macros.basisQuantityG) * 100;
    const atwaterKcalPer100g = ((4 * macros.proteinGPerBasis + 4 * macros.carbsGPerBasis + 9 * macros.fatGPerBasis) / macros.basisQuantityG) * 100;
    const tolerance = Math.max(80, reportedKcalPer100g * 0.3);
    if (Math.abs(reportedKcalPer100g - atwaterKcalPer100g) > tolerance) {
      warnings.push('reported_energy_differs_from_simple_atwater_estimate');
    }
  }

  return { valid: errors.length === 0, errors, warnings };
}

