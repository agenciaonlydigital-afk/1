import assert from 'node:assert/strict';
import { buildFoodSearchIndex, normalizeFoodSearchText, searchFoodIndex } from '../food-search.ts';

const food = (food_id, name, search_text = '', source_record_id = food_id, source_id = 'TBCA') => ({
  food_id,
  name,
  search_text,
  source_record_id,
  source_id,
  source_version: 'fixture',
  quality_status: 'verified_lab',
  macros: { kcalPerBasis: 0, proteinGPerBasis: 0, carbsGPerBasis: 0, fatGPerBasis: 0, basisQuantityG: 100 },
  micronutrients: {},
});

const foods = [
  food('3', 'Banana prata', 'fruta banana fresca', 'FR003'),
  food('2', 'Feijão carioca cozido', 'leguminosa preparo cozido', 'FJ002'),
  food('1', 'Pão francês', 'farinha de trigo', 'PN001'),
  food('4', 'Banana', 'banana nanica', 'FR004'),
  food('5', 'Iogurte natural', 'leite fermentado', '789-XYZ', 'OPEN_FOOD_FACTS'),
  { ...food('6', 'Cogumelo inconsistente'), macros: { kcalPerBasis: 51, proteinGPerBasis: 2.91, carbsGPerBasis: 219, fatGPerBasis: 1.69, basisQuantityG: 100 } },
];
const index = buildFoodSearchIndex(foods);

assert.equal(normalizeFoodSearchText('  AÇÚCAR   DE   MAÇÃ '), 'acucar de maca');
assert.deepEqual(searchFoodIndex(index, 'pao frances').map((item) => item.food_id), ['1']);
assert.deepEqual(searchFoodIndex(index, 'FEIJAO cozido').map((item) => item.food_id), ['2']);
assert.deepEqual(searchFoodIndex(index, '789 xyz').map((item) => item.food_id), ['5']);
assert.deepEqual(searchFoodIndex(index, 'banana').map((item) => item.food_id), ['4', '3']);
assert.deepEqual(searchFoodIndex(index, '').map((item) => item.name), ['Banana', 'Banana prata', 'Feijão carioca cozido', 'Iogurte natural', 'Pão francês']);
assert.equal(searchFoodIndex(index, '', 1).length, 1);
assert.equal(searchFoodIndex(index, '', -1).length, 0);
assert.equal(searchFoodIndex(index, 'nao existe').length, 0);
assert.equal(searchFoodIndex(index, 'cogumelo inconsistente').length, 0, 'invalid macro source records must not appear as selectable foods');

console.log('food-search: PASS');
