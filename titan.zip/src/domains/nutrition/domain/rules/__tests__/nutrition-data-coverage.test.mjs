import assert from 'node:assert/strict';
import { buildNutritionDataCoverage } from '../nutrition-data-coverage.ts';

const foods = [
  {
    food_id: 'tbca-ok', source_id: 'TBCA', micronutrients: {
      iron: { normalized_value: 2.4, normalized_unit: 'mg', basis_quantity: 100, data_status: 'quantified' },
    },
  },
  {
    food_id: 'tbca-wrong-unit', source_id: 'TBCA', micronutrients: {
      iron: { normalized_value: 2400, normalized_unit: 'µg', basis_quantity: 100, data_status: 'quantified' },
    },
  },
  {
    food_id: 'tbca-negative', source_id: 'TBCA', micronutrients: {
      iron: { normalized_value: -1, normalized_unit: 'mg', basis_quantity: 100, data_status: 'quantified' },
    },
  },
  {
    food_id: 'off-trace', source_id: 'OPEN_FOOD_FACTS', micronutrients: {
      iron: { normalized_value: 0, normalized_unit: 'mg', basis_quantity: 100, data_status: 'trace' },
    },
  },
  {
    food_id: 'off-not-analyzed', source_id: 'OPEN_FOOD_FACTS', micronutrients: {
      iron: { normalized_value: null, normalized_unit: 'mg', basis_quantity: 100, data_status: 'not_analyzed' },
    },
  },
  {
    food_id: 'tbca-not-in-schema', source_id: 'TBCA', micronutrients: {},
  },
  {
    food_id: 'off-missing', source_id: 'OPEN_FOOD_FACTS', micronutrients: {},
  },
];

const report = buildNutritionDataCoverage(foods, [{ nutrientId: 'iron', unit: 'mg' }]);
const iron = report[0];
assert.equal(iron.totalFoodRecords, 7);
assert.equal(iron.quantifiedFoodRecords, 1, 'only finite, non-negative, positive-basis and unit-matched values count');
assert.equal(iron.coveragePercent, 14.3);
assert.equal(iron.statusCounts.quantified, 1);
assert.equal(iron.statusCounts.unit_mismatch, 1);
assert.equal(iron.statusCounts.invalid_value, 1);
assert.equal(iron.statusCounts.trace, 1);
assert.equal(iron.statusCounts.not_analyzed, 2, 'missing nutrient fields in the TBCA source schema are explicitly not_analyzed');
assert.equal(iron.statusCounts.missing, 1);
assert.equal(iron.bySource.TBCA.quantifiedFoodRecords, 1);
assert.equal(iron.bySource.TBCA.statusCounts.not_analyzed, 1);
assert.equal(iron.bySource.OPEN_FOOD_FACTS.quantifiedFoodRecords, 0);

const usdaReport = buildNutritionDataCoverage([{ food_id: 'usda-1', source_id: 'USDA_FDC', micronutrients: { iron: { normalized_value: 1.2, normalized_unit: 'mg', basis_quantity: 100, data_status: 'quantified' } } }], [{ nutrientId: 'iron', unit: 'mg' }]);
assert.equal(usdaReport[0].bySource.USDA_FDC.quantifiedFoodRecords, 1, 'USDA FDC records are tracked independently from TBCA and Open Food Facts');

const noSources = buildNutritionDataCoverage([], [{ nutrientId: 'iodine', unit: 'µg' }]);
assert.equal(noSources[0].totalFoodRecords, 0);
assert.equal(noSources[0].coveragePercent, 0);

console.log('nutrition data coverage tests passed');

const tbcaTypeBreakdown = buildNutritionDataCoverage([
  { food_id: 'ingredient', source_id: 'TBCA', food_type: 'ALIMENTO', micronutrients: { iron: { normalized_value: 2, normalized_unit: 'mg', basis_quantity: 100, data_status: 'quantified' } } },
  { food_id: 'composite', source_id: 'TBCA', food_type: 'PREPARACAO_COMPOSTA', micronutrients: {} },
  { food_id: 'unknown-type', source_id: 'TBCA', micronutrients: {} },
  { food_id: 'off-record', source_id: 'OPEN_FOOD_FACTS', food_type: 'UNCLASSIFIED', micronutrients: {} },
], [{ nutrientId: 'iron', unit: 'mg' }])[0];
assert.equal(tbcaTypeBreakdown.byTbcaFoodType.ALIMENTO.totalFoodRecords, 1);
assert.equal(tbcaTypeBreakdown.byTbcaFoodType.ALIMENTO.quantifiedFoodRecords, 1);
assert.equal(tbcaTypeBreakdown.byTbcaFoodType.PREPARACAO_COMPOSTA.totalFoodRecords, 1);
assert.equal(tbcaTypeBreakdown.byTbcaFoodType.UNKNOWN.totalFoodRecords, 1,
  'TBCA records missing food_type must fail closed into TBCA UNKNOWN');
assert.equal(tbcaTypeBreakdown.byTbcaFoodType.ALIMENTO.totalFoodRecords +
  tbcaTypeBreakdown.byTbcaFoodType.PREPARACAO_COMPOSTA.totalFoodRecords +
  tbcaTypeBreakdown.byTbcaFoodType.UNKNOWN.totalFoodRecords, tbcaTypeBreakdown.bySource.TBCA.totalFoodRecords,
'TBCA type buckets must reconcile to TBCA source totals');
assert.equal(tbcaTypeBreakdown.byTbcaFoodType.UNKNOWN.totalFoodRecords, 1,
  'non-TBCA source rows must not be counted as TBCA unknowns');
