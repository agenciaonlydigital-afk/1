import assert from 'node:assert/strict';
import {
  aggregateSupplementMicronutrientExposure,
  convertSupplementMassUnit,
  isValidSupplementMicronutrientIntake,
  getAllowedSupplementChemicalForms,
} from '../supplement-intake.ts';

const base = {
  id: 'supp-1', dateKey: '2026-11-26', time: '08:30', productName: 'Magnesium citrate',
  nutrientId: 'magnesium', amount: 200, unit: 'mg', chemicalForm: 'unspecified',
  sourceName: 'User-entered product label', sourceVersion: 'manual-entry-v1',
  sourceRecordId: 'label-1', recordedAt: '2026-11-26T11:30:00.000Z',
};
assert.equal(isValidSupplementMicronutrientIntake(base), true);
assert.equal(isValidSupplementMicronutrientIntake({ ...base, amount: Number.NaN }), false);
assert.equal(isValidSupplementMicronutrientIntake({ ...base, sourceUrl: 'javascript:alert(1)' }), false);
assert.equal(convertSupplementMassUnit(1, 'g', 'mg'), 1000);
assert.equal(convertSupplementMassUnit(1000, 'µg', 'mg'), 1);
assert.equal(convertSupplementMassUnit(1, 'IU', 'µg'), null);
assert.equal(convertSupplementMassUnit(1, 'µg RAE', 'mg'), null);

const magnesium = aggregateSupplementMicronutrientExposure([base], '2026-11-26', 'magnesium', 'mg', 'supplements_only');
assert.equal(magnesium.value, 200);
assert.equal(magnesium.status, 'supplement_component_only');
const retinolOnly = aggregateSupplementMicronutrientExposure([
  { ...base, nutrientId: 'vitamin_a', amount: 500, unit: 'µg', chemicalForm: 'retinol' },
  { ...base, id: 'supp-2', nutrientId: 'vitamin_a', amount: 900, unit: 'µg', chemicalForm: 'beta_carotene' },
], '2026-11-26', 'vitamin_a', 'µg', 'preformed_only');
assert.equal(retinolOnly.value, 500);
const unresolved = aggregateSupplementMicronutrientExposure([
  { ...base, nutrientId: 'vitamin_a', amount: 500, unit: 'µg', chemicalForm: 'unspecified' },
], '2026-11-26', 'vitamin_a', 'µg', 'preformed_only');
assert.equal(unresolved.value, null);
assert.equal(unresolved.status, 'form_unresolved');
const retinolIsNotProvenSynthetic = aggregateSupplementMicronutrientExposure([
  { ...base, nutrientId: 'vitamin_a', chemicalForm: 'retinol', amount: 500, unit: 'µg' },
], '2026-11-26', 'vitamin_a', 'µg', 'synthetic_forms_only');
assert.equal(retinolIsNotProvenSynthetic.value, null);
assert.equal(retinolIsNotProvenSynthetic.status, 'not_logged');
const folicAcidSynthetic = aggregateSupplementMicronutrientExposure([
  { ...base, nutrientId: 'vitamin_b9', chemicalForm: 'folic_acid', amount: 400, unit: 'µg' },
], '2026-11-26', 'vitamin_b9', 'µg', 'synthetic_forms_only');
assert.equal(folicAcidSynthetic.value, 400);
const noEvents = aggregateSupplementMicronutrientExposure([], '2026-11-26', 'magnesium', 'mg', 'supplements_only');
assert.equal(noEvents.value, null);
assert.equal(noEvents.status, 'not_logged');
assert.equal(isValidSupplementMicronutrientIntake({ ...base, nutrientId: 'magnesium', chemicalForm: 'retinol' }), false,
  'chemical forms must be compatible with the recorded nutrient');
assert.equal(isValidSupplementMicronutrientIntake({ ...base, nutrientId: 'vitamin_b9', chemicalForm: 'folic_acid' }), true);
assert.equal(isValidSupplementMicronutrientIntake({ ...base, nutrientId: 'vitamin_b3', chemicalForm: 'niacinamide' }), true);
assert.equal(isValidSupplementMicronutrientIntake({ ...base, nutrientId: 'vitamin_e', chemicalForm: 'synthetic_alpha_tocopherol' }), true);
assert.equal(isValidSupplementMicronutrientIntake({ ...base, nutrientId: 'vitamin_b3', chemicalForm: 'folic_acid' }), false);
console.log('Supplement nutrient exposure tests passed.');

const fortifiedScope = aggregateSupplementMicronutrientExposure([base], '2026-11-26', 'magnesium', 'mg', 'supplements_and_fortified_foods');
assert.equal(fortifiedScope.status, 'source_scope_incomplete', 'supplement-only ledger cannot certify a supplement-plus-fortified-food scope');
assert.equal(isValidSupplementMicronutrientIntake({ ...base, nutrientId: 'vitamin_b9', chemicalForm: 'methylfolate' }), true,
  'methylfolate is a valid vitamin B9 chemical form');

const totalIntakeStillMeansSupplementComponent = aggregateSupplementMicronutrientExposure(
  [base], '2026-11-26', 'magnesium', 'mg', 'total_intake',
);
assert.equal(totalIntakeStillMeansSupplementComponent.value, 200);
assert.equal(totalIntakeStillMeansSupplementComponent.status, 'supplement_component_only',
  'a supplement ledger must never claim to be total daily intake');

assert.ok(getAllowedSupplementChemicalForms('vitamin_a').includes('retinol'));
assert.ok(!getAllowedSupplementChemicalForms('magnesium').includes('retinol'));
assert.ok(getAllowedSupplementChemicalForms('vitamin_b9').includes('methylfolate'));

const genericSyntheticForm = aggregateSupplementMicronutrientExposure([
  { ...base, nutrientId: 'vitamin_b9', chemicalForm: 'synthetic_form', amount: 400, unit: 'µg' },
], '2026-11-26', 'vitamin_b9', 'µg', 'synthetic_forms_only');
assert.equal(genericSyntheticForm.value, null,
  'a generic synthetic form cannot be assumed to match a nutrient-specific synthetic UL');
assert.equal(genericSyntheticForm.status, 'form_unresolved');

for (const amount of [0.001, 0.01, 0.1, 0.333, 1, 7.5, 42, 999.9]) {
  const milligrams = convertSupplementMassUnit(amount, 'g', 'mg');
  assert.ok(milligrams !== null);
  const roundTrip = convertSupplementMassUnit(milligrams, 'mg', 'g');
  assert.ok(roundTrip !== null && Math.abs(roundTrip - amount) < 1e-10,
    `mass conversion must round-trip for ${amount} g`);
}
const mixedUnitEvents = [
  { ...base, id: 'unit-a', amount: 0.25, unit: 'g' },
  { ...base, id: 'unit-b', amount: 125, unit: 'mg' },
  { ...base, id: 'unit-c', amount: 25000, unit: 'µg' },
];
const forwardTotal = aggregateSupplementMicronutrientExposure(mixedUnitEvents, '2026-11-26', 'magnesium', 'mg', 'supplements_only');
const reverseTotal = aggregateSupplementMicronutrientExposure([...mixedUnitEvents].reverse(), '2026-11-26', 'magnesium', 'mg', 'supplements_only');
assert.equal(forwardTotal.value, 400);
assert.equal(reverseTotal.value, forwardTotal.value,
  'aggregation must be invariant to source event ordering');

const fs = await import('node:fs');
const panelSource = fs.readFileSync('src/domains/nutrition/components/SupplementMicronutrientPanel.tsx', 'utf8');
assert.doesNotMatch(panelSource, /aggregateSupplementMicronutrientExposure\([\s\S]*?'supplements_only'/,
  'SupplementMicronutrientPanel must pass reference.upperLimitScope rather than hardcoding supplements_only');
assert.match(panelSource, /reference\.upperLimitScope/,
  'SupplementMicronutrientPanel must evaluate supplement summaries against reference.upperLimitScope');
