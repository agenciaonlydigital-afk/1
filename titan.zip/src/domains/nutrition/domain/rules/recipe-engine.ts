import { RECIPE_CATALOG, findRecipeById } from '../../data/recipes/recipe-catalog.ts';
import type {
  CardapioMealSlot,
  MealFoodPortion,
  MealItem,
  RecipeItem,
} from '../entities/nutrient.ts';
import {
  computePortionsMacrosWithQuality,
  resolveFoodById,
  type ComputedMealMacros,
} from './nutrition-calculator.ts';
import { isEligibleRecipeIngredient } from './food-ingredient-policy.ts';

export interface RecipeTemplateEligibility {
  eligible: boolean;
  blockedFoodIds: string[];
}

/** A recipe template is selectable only when every line resolves to an eligible ingredient. */
export function evaluateRecipeTemplateEligibility(recipe: RecipeItem): RecipeTemplateEligibility {
  const blockedFoodIds = recipe.ingredients
    .filter((line) => !isEligibleRecipeIngredient(resolveFoodById(line.ingredientId)))
    .map((line) => line.ingredientId);
  return { eligible: recipe.ingredients.length > 0 && blockedFoodIds.length === 0, blockedFoodIds };
}

export function isEligibleRecipeTemplate(recipe: RecipeItem): boolean {
  return evaluateRecipeTemplateEligibility(recipe).eligible;
}

export interface ComputedRecipeSummary {
  recipe: RecipeItem;
  totalGrams: number;
  portions: MealFoodPortion[];
  ingredientNames: string[];
  macros: ComputedMealMacros;
  dataCoveragePercent: number;
  unresolvedFoodIds: string[];
  lowConfidenceFoodIds: string[];
}

/** Resolve bottom-up: Ingredientes -> Receita */
export function computeRecipeSummary(
  recipe: RecipeItem,
  portionScale = 1,
): ComputedRecipeSummary {
  const requestedScale = Number.isFinite(portionScale) ? portionScale : 1;
  const safeScale = Math.max(0.25, Math.min(3, requestedScale));
  const portions: MealFoodPortion[] = recipe.ingredients.map((line) => ({
    foodId: line.ingredientId,
    quantityG: Number.isFinite(line.quantityG) && line.quantityG > 0
      ? line.quantityG * safeScale
      : 0,
  }));
  const totalGrams = portions.reduce((sum, p) => sum + p.quantityG, 0);
  const ingredientNames = portions
    .map((p) => resolveFoodById(p.foodId)?.name ?? p.foodId)
    .filter(Boolean);
  const quality = computePortionsMacrosWithQuality(portions);
  const macros = quality.macros;

  return {
    recipe,
    totalGrams,
    portions,
    ingredientNames,
    // Keep full precision in the domain layer; round only at the presentation boundary.
    macros,
    dataCoveragePercent: quality.coveragePercent,
    unresolvedFoodIds: quality.unresolvedFoodIds,
    lowConfidenceFoodIds: quality.lowConfidenceFoodIds,
  };
}

/** Resolve top-down: Cardápio Slot -> Receita -> Ingredientes */
export function buildMealFromCardapioSlot(slot: CardapioMealSlot): MealItem {
  const recipe = findRecipeById(slot.recipeId);
  const scale = slot.portionScale ?? 1;

  if (!recipe) {
    return {
      id: slot.id,
      dateKey: slot.dateKey,
      time: slot.time,
      title: slot.title,
      description: 'Receita não encontrada',
      recipeId: slot.recipeId,
      planned_quantity: 0,
      consumed_quantity: 0,
      planned_foods: [],
      consumed_foods: [],
      status: slot.status,
    };
  }

  const summary = computeRecipeSummary(recipe, scale);
  const isConsumed = slot.status === 'consumed';

  return {
    id: slot.id,
    dateKey: slot.dateKey,
    time: slot.time,
    title: slot.title,
    description: recipe.description,
    recipeId: recipe.id,
    imageUrl: recipe.imageUrl,
    planned_quantity: summary.totalGrams,
    consumed_quantity: isConsumed ? summary.totalGrams : 0,
    planned_foods: summary.portions,
    consumed_foods: isConsumed ? summary.portions.map((p) => ({ ...p })) : [],
    status: slot.status,
  };
}

function normalizeSearchText(text: string): string {
  return text
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim()
    .toLowerCase();
}

/** Pesquisa receitas para substituição por nome, descrição ou ingrediente */
export function searchSubstitutionRecipes(
  query: string,
  excludeRecipeId?: string,
): ComputedRecipeSummary[] {
  const normalized = normalizeSearchText(query);
  return RECIPE_CATALOG.filter(
    (recipe) => recipe.id !== excludeRecipeId && isEligibleRecipeTemplate(recipe),
  )
    .map((recipe) => computeRecipeSummary(recipe, 1))
    .filter((summary) => {
      if (!normalized) return true;
      return (
        normalizeSearchText(summary.recipe.name).includes(normalized) ||
        normalizeSearchText(summary.recipe.description).includes(normalized) ||
        summary.ingredientNames.some((name) =>
          normalizeSearchText(name).includes(normalized),
        )
      );
    });
}
