export type NutrientId =
  | 'vitamin_a'
  | 'vitamin_c'
  | 'vitamin_d'
  | 'vitamin_e'
  | 'vitamin_k'
  | 'vitamin_b1'
  | 'vitamin_b2'
  | 'vitamin_b3'
  | 'vitamin_b5'
  | 'vitamin_b6'
  | 'vitamin_b7'
  | 'vitamin_b9'
  | 'vitamin_b12'
  | 'calcium'
  | 'copper'
  | 'iron'
  | 'phosphorus'
  | 'magnesium'
  | 'manganese'
  | 'potassium'
  | 'selenium'
  | 'sodium'
  | 'zinc'
  | 'choline'
  | 'iodine'
  | 'chloride'
  | 'molybdenum'
  | 'chromium'
  | 'fluoride';

export const MICRONUTRIENT_ORDER: readonly NutrientId[] = [
  'vitamin_a',
  'vitamin_c',
  'vitamin_d',
  'vitamin_e',
  'vitamin_k',
  'vitamin_b1',
  'vitamin_b2',
  'vitamin_b3',
  'vitamin_b5',
  'vitamin_b6',
  'vitamin_b7',
  'vitamin_b9',
  'vitamin_b12',
  'calcium',
  'copper',
  'iron',
  'phosphorus',
  'magnesium',
  'manganese',
  'potassium',
  'selenium',
  'sodium',
  'zinc',
  'choline',
  'iodine',
  'chloride',
  'molybdenum',
  'chromium',
  'fluoride',
] as const;

export type FoodSourceId = 'TBCA' | 'OPEN_FOOD_FACTS' | 'USDA_FDC' | 'TITAN_LEGACY';

export type NutrientDataStatus =
  | 'quantified'
  | 'trace'
  | 'not_analyzed'
  | 'unit_mismatch'
  | 'invalid_value'
  | 'missing';

export type FoodQualityStatus =
  | 'verified_lab'
  | 'reference_database'
  | 'label_complete'
  | 'label_partial'
  | 'unverified';

export type NutrientConversionMethod =
  | 'direct'
  | 'unit_scale'
  | 'direct_rae'
  | 'tbca_re_preserved_unconverted'
  | 'preformed_niacin_only'
  | 'niacin_equivalent_from_components'
  | 'preparation_retention'
  | 'unavailable';

export interface FoodNutrientDerivationComponent {
  fdc_nutrient_id: number;
  nutrient_number: string;
  nutrient_name: string;
  value: number;
  unit: string;
}

export interface FoodNutrientDerivationEvidence {
  method: 'niacin_equivalent_1_to_60' | 'niacin_equivalent_sum_406_407';
  formula: string;
  reference_url: string;
  basis_quantity_g: 100;
  components: FoodNutrientDerivationComponent[];
}

export interface FoodNutrientRecord {
  food_id: string;
  source_id: FoodSourceId;
  source_record_id: string;
  nutrient_id: NutrientId;
  original_value: number | null;
  original_unit: string;
  normalized_value: number | null;
  normalized_unit: string;
  basis_quantity: number;
  data_status: NutrientDataStatus;
  quality_status: FoodQualityStatus;
  source_version: string;
  conversion_method: NutrientConversionMethod;
  source_evidence?: FoodNutrientDerivationComponent;
  derivation?: FoodNutrientDerivationEvidence;
}

export interface FoodMacroComposition {
  kcalPerBasis: number;
  proteinGPerBasis: number;
  carbsGPerBasis: number;
  fatGPerBasis: number;
  basisQuantityG: number;
  fiberGPerBasis?: number | null;
  saturatedFatGPerBasis?: number | null;
  cholesterolMgPerBasis?: number | null;
  sodiumMgPerBasis?: number | null;
}

export interface FoodSourceItem {
  food_id: string;
  name: string;
  source_id: FoodSourceId;
  source_record_id: string;
  source_version: string;
  quality_status: FoodQualityStatus;
  source_url?: string;
  source_group?: string;
  food_type?: string;
  state?: string;
  preparation?: string;
  search_text?: string;
  macros: FoodMacroComposition;
  preparation_conversion?: {
    method: 'explicit-food-method-retention-v1';
    sourceFoodId: string;
    startingWeightG: number;
    preparedWeightG: number;
    yieldFactor: number;
    provenance: {
      sourceName: string;
      sourceVersion: string;
      referenceUrl: string;
      retentionCode: string;
      yieldReference: string;
      retentionMethod: 'true_retention' | 'apparent_retention';
    };
    warnings: string[];
  };
  micronutrients: Partial<Record<NutrientId, Omit<FoodNutrientRecord, 'food_id' | 'source_id' | 'source_record_id' | 'source_version' | 'quality_status' | 'nutrient_id'>>>;
}

export type IngredientItem = FoodSourceItem;

export interface RecipeIngredientLine {
  ingredientId: string;
  quantityG: number;
}

export interface RecipeItem {
  id: string;
  name: string;
  description: string;
  category: 'cafe' | 'almoco' | 'lanche' | 'jantar';
  imageUrl?: string;
  ingredients: RecipeIngredientLine[];
}

export interface CardapioMealSlot {
  id: string;
  dateKey: string;
  time: string;
  title: string;
  recipeId: string;
  portionScale?: number;
  status: MealConsumptionStatus;
}

export interface MealFoodPortion {
  foodId: string;
  quantityG: number;
}

export type MealConsumptionStatus =
  | 'planned'
  | 'consumed'
  | 'partial'
  | 'substituted'
  | 'skipped';

export interface MealItem {
  id: string;
  dateKey: string;
  time: string;
  title: string;
  description: string;
  recipeId?: string;
  imageUrl?: string;
  planned_quantity: number;
  consumed_quantity: number;
  planned_foods: MealFoodPortion[];
  consumed_foods: MealFoodPortion[];
  status: MealConsumptionStatus;
  substitutionNote?: string;
}

export type ReferenceProfileId =
  | 'adult_male_19_30'
  | 'adult_female_19_30'
  | 'adult_male_19_50'
  | 'adult_female_19_50'
  | 'adult_51_plus'
  | 'adult_female_51_plus'
  | 'adult_male_51_70'
  | 'adult_female_51_70'
  | 'adult_male_71_plus'
  | 'adult_female_71_plus';

export type ReferenceKind = 'RDA' | 'AI' | 'CDRR' | 'UL';

export type UpperLimitScope =
  | 'total_intake'
  | 'supplements_only'
  | 'supplements_and_medications'
  | 'supplements_and_fortified_foods'
  | 'preformed_only'
  | 'synthetic_forms_only';

export interface DailyReferenceEntry {
  nutrientId: NutrientId;
  referenceValue: number | null;
  unit: string;
  kind: ReferenceKind | null;
  upperLimit?: number | null;
  upperLimitUnit?: string;
  upperLimitBasis?: string;
  upperLimitSourceUrl?: string;
  upperLimitScope?: UpperLimitScope | null;
  cdrrValue?: number | null;
}

export interface DailyMicronutrientOptimizationTarget {
  nutrientId: NutrientId;
  unit: string;
  minimum: number | null;
  minimumKind: 'RDA' | 'AI' | null;
  preferredMaximum: number | null;
  upperLimit: number | null;
  upperLimitUnit?: string;
  upperLimitScope: UpperLimitScope | null;
}

export type MicronutrientOptimizationStatus =
  | 'applied'
  | 'insufficient_data'
  | 'not_applicable_scope'
  | 'infeasible_upper_limit'
  | 'no_reference';

export interface MicronutrientOptimizationResult {
  nutrientId: NutrientId;
  unit: string;
  status: MicronutrientOptimizationStatus;
  reason?: string;
  minimum: number | null;
  minimumKind: 'RDA' | 'AI' | null;
  preferredMaximum: number | null;
  upperLimit: number | null;
  beforeValue: number | null;
  afterValue: number | null;
  meetsMinimum: boolean | null;
  withinPreferredMaximum: boolean | null;
  withinUpperLimit: boolean | null;
}

export interface ReferenceProfileSpec {
  id: ReferenceProfileId;
  label: string;
  systemName: string;
  systemVersion: string;
  entries: Record<NutrientId, DailyReferenceEntry>;
}

export type ComposerPlanStatus = 'draft' | 'active' | 'archived';

export type IngredientLockMode = 'proportional' | 'locked' | 'flexible';

export type IngredientQuantityStatus = 'known' | 'missing' | 'to_taste';

export type ComposerAdjustmentMode = 'proportional' | 'balanced' | 'flexible';

export interface NutritionTargets {
  kcal: number;
  proteinG: number;
  carbsG: number;
  fatG: number;
  kcalMin?: number | null;
  kcalMax?: number | null;
  proteinMinG?: number | null;
  proteinMaxG?: number | null;
  carbsMinG?: number | null;
  carbsMaxG?: number | null;
  fatMinG?: number | null;
  fatMaxG?: number | null;
  sourceLabel?: string;
}

export interface MealTargetAllocation {
  slotId: string;
  energySharePercent: number;
  proteinSharePercent?: number | null;
  carbsSharePercent?: number | null;
  fatSharePercent?: number | null;
}

export interface IngredientAdjustment {
  id: string;
  foodId: string;
  displayName?: string;
  baseQuantityG: number | null;
  currentQuantityG: number | null;
  quantityStatus: IngredientQuantityStatus;
  mode: IngredientLockMode;
  minQuantityG?: number | null;
  maxQuantityG?: number | null;
  isCompositeDish?: boolean;
}

export interface RecipeInstance {
  id: string;
  sourceRecipeId?: string;
  name: string;
  description?: string;
  category: 'cafe' | 'almoco' | 'lanche' | 'jantar';
  imageUrl?: string;
  baseServings: number;
  targetServings: number;
  adjustmentMode: ComposerAdjustmentMode;
  ingredients: IngredientAdjustment[];
}

export interface ComposerMealSlot {
  id: string;
  time: string;
  title: string;
  linkedMealId?: string;
  recipes: RecipeInstance[];
}

export interface ComposerDayPlan {
  dateKey: string;
  slots: ComposerMealSlot[];
}

export interface ComposerMacroTotals {
  kcal: number;
  proteinG: number;
  carbsG: number;
  fatG: number;
}

export interface CompositionVariant {
  id: string;
  name: string;
  createdAt: string;
  description?: string;
  dayPlan: ComposerDayPlan;
  weightedDeviationPercent: number;
  macros: ComposerMacroTotals;
}

export interface CardapioPlan {
  id: string;
  name: string;
  revision: number;
  status: ComposerPlanStatus;
  startDateKey: string;
  endDateKey: string;
  targets: NutritionTargets;
  mealAllocations: MealTargetAllocation[];
  days: Record<string, ComposerDayPlan>;
  variants: CompositionVariant[];
  activeVariantId?: string | null;
}

export type SolverCertificate = 'optimal' | 'feasible' | 'approximate';

export interface ProposedIngredientChange {
  slotId: string;
  slotTitle: string;
  recipeId: string;
  recipeName: string;
  ingredientId: string;
  foodId: string;
  foodName: string;
  currentQuantityG: number;
  proposedQuantityG: number;
  referenceQuantityG: number;
  deltaG: number;
  atLowerBound: boolean;
  atUpperBound: boolean;
}

export interface OptimizationProposal {
  id: string;
  certificate: SolverCertificate;
  solverEngine?: string;
  scaleMode?: 'preserve_recipe_ratios' | 'ingredient_flexible';
  macroFitStatus?: 'target_met' | 'approximate_feasible' | 'infeasible' | 'insufficient_data';
  recipeScales?: Array<{
    slotId: string;
    slotTitle: string;
    recipeId: string;
    recipeName: string;
    continuousScale: number;
    effectiveScale: number;
    scalePercent: number;
    minScale: number;
    maxScale: number;
  }>;
  explanation: string;
  beforeMacros: ComposerMacroTotals;
  afterMacros: ComposerMacroTotals;
  targets: NutritionTargets;
  weightedDeviationBeforePercent: number;
  weightedDeviationAfterPercent: number;
  adjustedCount: number;
  lockedCount: number;
  proportionalCount: number;
  micronutrientResults?: MicronutrientOptimizationResult[];
  changes: ProposedIngredientChange[];
  proposedDayPlan: ComposerDayPlan;
  solveDurationMs: number;
}

export interface DiscreteSubstitutionProposal {
  id: string;
  slotId: string;
  slotTitle: string;
  currentRecipeId: string;
  currentRecipeName: string;
  candidateRecipeId: string;
  candidateRecipeName: string;
  sourceSummary: string;
  deltaMacros: ComposerMacroTotals;
  projectedDayMacros: ComposerMacroTotals;
  targetGapAfter: number;
}

export interface DiscreteCombinationProposal {
  id: string;
  solverEngine: string;
  swaps: DiscreteSubstitutionProposal[];
  projectedDayMacros: ComposerMacroTotals;
  targetGapBefore: number;
  targetGapAfter: number;
  solveDurationMs: number;
}

