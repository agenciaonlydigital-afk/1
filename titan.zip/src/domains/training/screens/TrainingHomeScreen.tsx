import { BookOpen, History, Play, Copy, Trash2, Plus, X } from 'lucide-react';
import { useEffect, useMemo, useRef, useState } from 'react';
import { ExerciseRegistry } from '@/src/domains/exercise-library/application/exercise-library-public';
import { BufferedNumberInput } from '@/src/shared/ui/BufferedNumberInput';
import { Button } from '@/src/shared/ui/Button';
import { Surface } from '@/src/shared/ui/Surface';
import { getMuscleLabels } from '@/src/domains/anatomy/application/anatomy-public';
import { startWorkoutSession } from '../application/start-workout';
import { computeWorkoutCompletion } from '../domain/rules/rest-timer';
import { useTrainingSessionStore } from '../state/training-session.store';

interface TrainingHomeScreenProps {
  onStartActiveWorkout: () => void;
  onOpenLibrary: () => void;
}

export function TrainingHomeScreen({
  onStartActiveWorkout,
  onOpenLibrary,
}: TrainingHomeScreenProps) {
  const plans = useTrainingSessionStore((s) => s.plans);
  const activePlanId = useTrainingSessionStore((s) => s.activePlanId);
  const completedSessions = useTrainingSessionStore((s) => s.completedSessions);
  const createPlan = useTrainingSessionStore((s) => s.createPlan);
  const duplicatePlan = useTrainingSessionStore((s) => s.duplicatePlan);
  const deletePlan = useTrainingSessionStore((s) => s.deletePlan);
  const renamePlan = useTrainingSessionStore((s) => s.renamePlan);
  const addExerciseToPlan = useTrainingSessionStore((s) => s.addExerciseToPlan);
  const removeExerciseFromPlan = useTrainingSessionStore((s) => s.removeExerciseFromPlan);
  const updateExerciseRestSeconds = useTrainingSessionStore((s) => s.updateExerciseRestSeconds);
  const updateSetPrescription = useTrainingSessionStore((s) => s.updateSetPrescription);
  const addSetToExercise = useTrainingSessionStore((s) => s.addSetToExercise);
  const removeSetFromExercise = useTrainingSessionStore((s) => s.removeSetFromExercise);
  const moveExerciseInPlan = useTrainingSessionStore((s) => s.moveExerciseInPlan);
  const [showPlanForm, setShowPlanForm] = useState(false);
  const [newPlanTitle, setNewPlanTitle] = useState('');
  const [editingPlanId, setEditingPlanId] = useState<string | null>(null);
  const [confirmDeletePlanId, setConfirmDeletePlanId] = useState<string | null>(null);
  const [exerciseSlug, setExerciseSlug] = useState('');
  const newPlanInputRef = useRef<HTMLInputElement>(null);
  const exerciseOptions = useMemo(() => ExerciseRegistry.list(), []);

  useEffect(() => {
    if (showPlanForm) {
      newPlanInputRef.current?.focus({ preventScroll: true });
    }
  }, [showPlanForm]);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="titan-page-heading titan-page-heading--compact mb-0">
          <p className="titan-eyebrow">Força e execução</p>
          <h1 className="text-2xl font-semibold text-[var(--titan-text-primary)]">Treino</h1>
          <p className="text-xs text-[var(--titan-text-secondary)] mt-0.5">
            Divisão atual · Execução, séries e descanso automático
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <Button variant="secondary" onClick={() => setShowPlanForm((value) => !value)}>
            <Plus className="w-4 h-4" /> Nova ficha
          </Button>
          <Button variant="secondary" onClick={onOpenLibrary}>
            <BookOpen className="w-4 h-4" /> Biblioteca
          </Button>
        </div>
      </div>

      {showPlanForm && (
        <Surface className="p-4">
          <form
            className="flex flex-wrap items-end gap-3"
            onSubmit={(event) => {
              event.preventDefault();
              const trimmed = newPlanTitle.trim();
              if (!trimmed) return;
              createPlan(trimmed);
              setNewPlanTitle('');
              setShowPlanForm(false);
            }}
          >
            <label className="flex-1 min-w-[220px] text-xs text-[var(--titan-text-secondary)]">Nome da ficha
              <input ref={newPlanInputRef} maxLength={80} value={newPlanTitle} onChange={(event) => setNewPlanTitle(event.target.value)} placeholder="Ex.: PUSH A" className="mt-1 w-full rounded-xl border border-[rgba(193,204,196,0.14)] bg-[var(--titan-surface-inset)] px-3 py-2 text-sm text-[var(--titan-text-primary)]" />
            </label>
            <Button type="submit" disabled={!newPlanTitle.trim()}><Plus className="w-4 h-4" /> Criar ficha</Button>
            <Button type="button" variant="ghost" aria-label="Cancelar nova ficha" onClick={() => setShowPlanForm(false)}><X className="w-4 h-4" /></Button>
          </form>
        </Surface>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {plans.map((plan) => {
          const stats = computeWorkoutCompletion(plan);
          const isCurrent = plan.id === activePlanId;
          const isConfirmingDelete = confirmDeletePlanId === plan.id;
          const statusText =
            plan.status === 'completed'
              ? 'Concluído'
              : plan.status === 'in_progress'
              ? 'Em andamento'
              : 'Planejado';

          return (
            <Surface key={plan.id} elevation={isCurrent ? 2 : 1} className={`p-5 flex flex-col justify-between gap-4 ${isCurrent ? 'titan-focus-card' : ''}`}>
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2 text-xs text-[var(--titan-text-secondary)]">
                  <span>{plan.splitLabel}</span>
                  <span>{statusText}</span>
                </div>
                <h2 className="text-lg font-semibold text-[var(--titan-text-primary)]">{plan.title}</h2>
                <div className="text-xs text-[var(--titan-text-secondary)]">
                  {plan.exercises.length} exercícios ·{' '}
                  <span className="font-mono-metric text-[var(--titan-text-primary)]">
                    {stats.completedSets} de {stats.totalSets}
                  </span>{' '}
                  séries ({stats.percent}%)
                </div>

                <ul className="pt-2 space-y-1.5 border-t border-[var(--titan-border)]/60">
                  {plan.exercises.map((ex) => (
                    <li
                      key={ex.id}
                      className="flex items-center justify-between gap-2 text-xs"
                    >
                      <span className="text-[var(--titan-text-primary)] truncate">{ex.name}</span>
                      <span className="text-[var(--titan-text-muted)] truncate">
                        {getMuscleLabels(ex.muscles.primary).join(', ')}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <Button variant="secondary" onClick={() => setEditingPlanId(editingPlanId === plan.id ? null : plan.id)}>
                  {editingPlanId === plan.id ? 'Fechar editor' : 'Editar ficha'}
                </Button>
                <Button variant="ghost" onClick={() => duplicatePlan(plan.id)} aria-label={`Duplicar ${plan.title}`}><Copy className="w-4 h-4" /></Button>
                {plan.id.startsWith('custom-') && (
                  isConfirmingDelete ? (
                    <div className="flex items-center gap-1.5">
                      <Button variant="secondary" onClick={() => { deletePlan(plan.id); setConfirmDeletePlanId(null); }}>
                        Confirmar exclusão
                      </Button>
                      <Button variant="ghost" onClick={() => setConfirmDeletePlanId(null)}>
                        Cancelar
                      </Button>
                    </div>
                  ) : (
                    <Button variant="ghost" onClick={() => setConfirmDeletePlanId(plan.id)} aria-label={`Excluir ${plan.title}`}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )
                )}
              </div>
              <Button
                variant={isCurrent ? 'primary' : 'secondary'}
                fullWidth
                disabled={plan.exercises.length === 0}
                onClick={() => {
                  startWorkoutSession(plan.id);
                  onStartActiveWorkout();
                }}
              >
                <Play className="w-4 h-4" />
                {plan.status === 'in_progress' ? 'Continuar treino' : 'Iniciar treino'}
              </Button>
              {editingPlanId === plan.id && (
                <div className="border-t border-[rgba(193,204,196,0.10)] pt-3 space-y-3">
                  {plan.id.startsWith('custom-') && <label className="block text-xs text-[var(--titan-text-secondary)]">Nome da ficha
                    <input
                      defaultValue={plan.title}
                      key={`${plan.id}-${plan.title}`}
                      maxLength={80}
                      onBlur={(event) => {
                        const trimmed = event.target.value.trim();
                        if (!trimmed) {
                          event.target.value = plan.title;
                          return;
                        }
                        if (trimmed !== plan.title) renamePlan(plan.id, trimmed);
                      }}
                      className="mt-1 w-full rounded-xl border border-[rgba(193,204,196,0.14)] bg-[var(--titan-surface-inset)] px-3 py-2 text-sm text-[var(--titan-text-primary)]"
                    />
                  </label>}
                  {plan.id.startsWith('custom-') && <div className="flex flex-wrap gap-2 items-end">
                    <label className="flex-1 min-w-[180px] text-xs text-[var(--titan-text-secondary)]">Adicionar exercício
                      <select value={exerciseSlug} onChange={(event) => setExerciseSlug(event.target.value)} className="mt-1 w-full rounded-xl border border-[rgba(193,204,196,0.14)] bg-[var(--titan-surface-inset)] px-3 py-2 text-sm text-[var(--titan-text-primary)]">
                        <option value="">Selecione...</option>
                        {exerciseOptions.map((item) => <option key={item.slug} value={item.slug}>{item.name}</option>)}
                      </select>
                    </label>
                    <Button disabled={!exerciseSlug} onClick={() => { addExerciseToPlan(plan.id, exerciseSlug); setExerciseSlug(''); }}><Plus className="w-4 h-4" /> Adicionar</Button>
                  </div>}
                  {plan.id.startsWith('custom-') && plan.exercises.map((exercise, exerciseIndex) => <div key={exercise.id} className="titan-luxury-group p-3 space-y-2">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="text-xs font-semibold text-[var(--titan-text-primary)]">{exerciseIndex + 1}. {exercise.name}</span>
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" disabled={exerciseIndex === 0} onClick={() => moveExerciseInPlan(plan.id, exercise.id, -1)} aria-label={`Mover ${exercise.name} para cima`}>↑</Button>
                        <Button variant="ghost" disabled={exerciseIndex === plan.exercises.length - 1} onClick={() => moveExerciseInPlan(plan.id, exercise.id, 1)} aria-label={`Mover ${exercise.name} para baixo`}>↓</Button>
                        <Button variant="ghost" onClick={() => removeExerciseFromPlan(plan.id, exercise.id)} aria-label={`Remover ${exercise.name}`}><X className="w-3 h-3" /></Button>
                      </div>
                    </div>
                    <label className="block text-[11px] text-[var(--titan-text-secondary)]">Descanso alvo (segundos)
                      <BufferedNumberInput min={15} max={600} step={5} integer inputMode="numeric" value={exercise.targetRestSeconds} onCommit={(val) => updateExerciseRestSeconds(plan.id, exercise.id, val)} className="mt-1 w-full min-h-[38px] rounded-lg border border-[var(--titan-border)] bg-[var(--titan-surface)] px-2 text-sm text-[var(--titan-text-primary)]" />
                    </label>
                    <div className="space-y-2">
                      {exercise.sets.map((record) => <div key={record.id} className="grid grid-cols-[34px_1fr_1fr_1fr_32px] items-end gap-1.5">
                        <span className="pb-2 text-[11px] text-[var(--titan-text-muted)]">S{record.setNumber}</span>
                        <label className="text-[10px] text-[var(--titan-text-muted)]">Carga kg<BufferedNumberInput min={0} max={500} step={0.5} inputMode="decimal" value={record.weightKg} onCommit={(val) => updateSetPrescription(plan.id, exercise.id, record.id, { weightKg: val })} className="mt-1 w-full min-h-[36px] rounded-md border border-[var(--titan-border)] bg-[var(--titan-surface)] px-1.5 text-xs text-[var(--titan-text-primary)]" /></label>
                        <label className="text-[10px] text-[var(--titan-text-muted)]">Reps<BufferedNumberInput min={1} max={100} step={1} integer inputMode="numeric" value={record.reps} onCommit={(val) => updateSetPrescription(plan.id, exercise.id, record.id, { reps: val })} className="mt-1 w-full min-h-[36px] rounded-md border border-[var(--titan-border)] bg-[var(--titan-surface)] px-1.5 text-xs text-[var(--titan-text-primary)]" /></label>
                        <label className="text-[10px] text-[var(--titan-text-muted)]">Alvo<input type="text" maxLength={20} value={record.targetReps} onChange={(event) => updateSetPrescription(plan.id, exercise.id, record.id, { targetReps: event.target.value })} className="mt-1 w-full min-h-[36px] rounded-md border border-[var(--titan-border)] bg-[var(--titan-surface)] px-1.5 text-xs text-[var(--titan-text-primary)]" /></label>
                        <Button variant="ghost" disabled={exercise.sets.length <= 1} onClick={() => removeSetFromExercise(plan.id, exercise.id, record.id)} aria-label={`Remover série ${record.setNumber} de ${exercise.name}`}><X className="w-3 h-3" /></Button>
                      </div>)}
                    </div>
                    <Button variant="secondary" disabled={exercise.sets.length >= 20} onClick={() => addSetToExercise(plan.id, exercise.id)}><Plus className="w-3 h-3" /> Adicionar série</Button>
                  </div>)}
                </div>
              )}
            </Surface>
          );
        })}
      </div>

      {completedSessions.length > 0 && (
        <Surface className="p-4 space-y-3">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-[var(--titan-accent)]" />
            <h2 className="text-sm font-semibold text-[var(--titan-text-primary)]">Treinos recentes</h2>
          </div>
          <div className="divide-y divide-[var(--titan-border)]/60">
            {completedSessions.slice(0, 3).map((session) => (
              <div key={session.id} className="py-2.5 flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-sm font-medium text-[var(--titan-text-primary)]">{session.planTitle}</p>
                  <p className="text-[11px] text-[var(--titan-text-muted)]">{new Intl.DateTimeFormat('pt-BR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }).format(new Date(session.completedAtMs))}</p>
                </div>
                <span className="text-xs font-mono-metric text-[var(--titan-text-secondary)]">{session.completedSets}/{session.totalSets} séries</span>
              </div>
            ))}
          </div>
        </Surface>
      )}
    </div>
  );
}
