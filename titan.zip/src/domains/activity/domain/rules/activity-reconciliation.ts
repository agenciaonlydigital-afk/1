/** Canonical event reconciliation for manual, Android Health Connect and iOS HealthKit imports. */
export type ActivityOrigin = 'manual' | 'health_connect' | 'healthkit' | 'openmetabolics' | 'wearable' | 'training_app';
export type ActivityRecordKind = 'workout_session' | 'active_calories_interval' | 'exercise_sample' | 'daily_total';
export type ActivityEnergyKind = 'active' | 'gross' | 'total';
export type ActivityMeasurementQuality = 'measured' | 'estimated' | 'manual';

export interface ImportedActivityEnergyRecord {
  id: string;
  source: ActivityOrigin;
  sourceRecordId: string;
  kind: ActivityRecordKind;
  energyKind: ActivityEnergyKind;
  startTime: string;
  endTime: string;
  energyKcal: number;
  quality: ActivityMeasurementQuality;
  parentWorkoutId?: string;
  activityCode?: string;
  updatedAt?: string;
}

export interface ReconciledActivityEnergy {
  accepted: ImportedActivityEnergyRecord[];
  excluded: Array<{ record: ImportedActivityEnergyRecord; reason: string; winnerRecordId?: string }>;
  /** Partial-overlap records quarantined until source-level/manual resolution. */
  conflicted: ImportedActivityEnergyRecord[];
  totalActiveKcal: number;
  conflicts: number;
  duplicateCount: number;
  rejectedGrossOrTotalCount: number;
  warnings: string[];
}

const SOURCE_PRIORITY: Record<ActivityOrigin, number> = {
  openmetabolics: 5,
  health_connect: 4,
  healthkit: 4,
  wearable: 3,
  manual: 2,
  training_app: 1,
};
const QUALITY_PRIORITY: Record<ActivityMeasurementQuality, number> = { measured: 3, estimated: 2, manual: 1 };

function parseTime(value: string): number | null {
  const time = Date.parse(value);
  return Number.isFinite(time) ? time : null;
}
function overlapMs(a: { start: number; end: number }, b: { start: number; end: number }): number {
  return Math.max(0, Math.min(a.end, b.end) - Math.max(a.start, b.start));
}
function rank(record: ImportedActivityEnergyRecord): number {
  return QUALITY_PRIORITY[record.quality] * 10 + SOURCE_PRIORITY[record.source];
}
function isValidRecord(record: ImportedActivityEnergyRecord): boolean {
  const start = parseTime(record.startTime);
  const end = parseTime(record.endTime);
  return Boolean(record.id && record.sourceRecordId && start !== null && end !== null && end > start &&
    end - start <= 24 * 60 * 60 * 1000 && Number.isFinite(record.energyKcal) && record.energyKcal >= 0 && record.energyKcal <= 5_000);
}

/**
 * One canonical energy contributor per workout/session. Child samples from the
 * same parent are intentionally not added to the parent session aggregate.
 * Gross and total energy are never added to activity calories because they may
 * include resting expenditure already represented by daily baseline energy.
 */
export function reconcileActivityEnergyRecords(records: readonly ImportedActivityEnergyRecord[]): ReconciledActivityEnergy {
  const accepted: ImportedActivityEnergyRecord[] = [];
  const excluded: ReconciledActivityEnergy['excluded'] = [];
  const warnings: string[] = [];
  const exactKeys = new Set<string>();
  let duplicateCount = 0;
  let rejectedGrossOrTotalCount = 0;

  const candidates = [...records].sort((a, b) => rank(b) - rank(a) || (b.updatedAt ?? '').localeCompare(a.updatedAt ?? '') || a.id.localeCompare(b.id));
  for (const record of candidates) {
    if (!isValidRecord(record)) {
      excluded.push({ record, reason: 'invalid_record_or_unreasonable_energy' });
      continue;
    }
    if (record.energyKind !== 'active') {
      rejectedGrossOrTotalCount += 1;
      excluded.push({ record, reason: 'gross_or_total_energy_not_additive_to_daily_baseline' });
      continue;
    }
    const dedupKey = `${record.source}:${record.sourceRecordId}`;
    if (exactKeys.has(dedupKey)) {
      duplicateCount += 1;
      excluded.push({ record, reason: 'duplicate_source_record' });
      continue;
    }
    exactKeys.add(dedupKey);
    accepted.push(record);
  }

  // Workout summaries own their time span. Their child energy samples are not
  // independent activity sessions and would otherwise double-count calories.
  const sessionIds = new Set(
    accepted
      .filter((r) => r.kind === 'workout_session')
      .map((r) => `${r.source}:${r.sourceRecordId}`),
  );
  const sessionParentIds = new Set(
    accepted
      .filter((r) => r.kind === 'workout_session')
      .flatMap((r) => [
        `${r.source}:${r.sourceRecordId}`,
        ...(r.parentWorkoutId ? [`${r.source}:${r.parentWorkoutId}`] : []),
      ]),
  );
  const parentFiltered = accepted.filter((record) => {
    const scopedParentKey = record.parentWorkoutId
      ? `${record.source}:${record.parentWorkoutId}`
      : null;
    const childOfSession =
      record.kind !== 'workout_session' &&
      Boolean(scopedParentKey && sessionParentIds.has(scopedParentKey));
    if (childOfSession) excluded.push({ record, reason: 'child_sample_covered_by_workout_session_aggregate' });
    return !childOfSession;
  });

  // Strongly overlapping summaries from different platforms are duplicates in
  // the usual import case. Partial overlaps are retained but reported for audit.
  const intervalCandidates: ImportedActivityEnergyRecord[] = [];
  const conflictedById = new Map<string, ImportedActivityEnergyRecord>();
  let conflicts = 0;
  for (const record of parentFiltered) {
    const start = parseTime(record.startTime)!;
    const end = parseTime(record.endTime)!;
    let duplicateOf: ImportedActivityEnergyRecord | undefined;
    const partialOverlaps: ImportedActivityEnergyRecord[] = [];
    for (const winner of intervalCandidates) {
      const winnerStart = parseTime(winner.startTime)!;
      const winnerEnd = parseTime(winner.endTime)!;
      const overlap = overlapMs({ start, end }, { start: winnerStart, end: winnerEnd });
      if (overlap <= 0) continue;
      const shorter = Math.min(end - start, winnerEnd - winnerStart);
      const ratio = overlap / shorter;
      if (ratio >= 0.8) { duplicateOf = winner; break; }
      if (ratio >= 0.3) partialOverlaps.push(winner);
    }
    if (duplicateOf) {
      duplicateCount += 1;
      excluded.push({ record, reason: 'overlapping_cross_source_activity_deduplicated', winnerRecordId: duplicateOf.id });
      continue;
    }
    if (partialOverlaps.length) {
      conflicts += partialOverlaps.length;
      conflictedById.set(record.id, record);
      for (const overlap of partialOverlaps) conflictedById.set(overlap.id, overlap);
    }
    intervalCandidates.push(record);
  }

  const conflicted = [...conflictedById.values()];
  for (const record of conflicted) {
    excluded.push({ record, reason: 'partial_overlap_quarantined_pending_review' });
  }
  const intervalFiltered = intervalCandidates.filter((record) => !conflictedById.has(record.id));

  if (duplicateCount) warnings.push(`${duplicateCount} registro(s) duplicado(s) foram removidos na reconciliação entre identificadores e intervalos.`);
  if (rejectedGrossOrTotalCount) warnings.push(`${rejectedGrossOrTotalCount} registro(s) de energia bruta/total foram excluídos para evitar somá-los ao gasto basal.`);
  if (conflicts) warnings.push(`${conflicts} par(es) com sobreposição parcial foram colocados em quarentena e não entram no total até revisão.`);
  if (sessionIds.size) warnings.push('Resumos de sessão prevalecem sobre amostras filhas do mesmo treino; amostras subjacentes não são somadas novamente.');

  return {
    accepted: intervalFiltered,
    excluded,
    conflicted,
    totalActiveKcal: Math.round(intervalFiltered.reduce((sum, record) => sum + record.energyKcal, 0)),
    conflicts,
    duplicateCount,
    rejectedGrossOrTotalCount,
    warnings,
  };
}

export interface HealthConnectActivityRecordInput {
  recordType: 'ExerciseSessionRecord' | 'ActiveCaloriesBurnedRecord' | 'TotalCaloriesBurnedRecord' | 'Unknown';
  id: string;
  startTime: string;
  endTime: string;
  energyKcal?: number;
  parentWorkoutId?: string;
  activityCode?: string;
  updatedAt?: string;
  sourceRecordId?: string;
}

/** Map a native Health Connect payload into the platform-neutral event contract. */
export function normalizeHealthConnectActivityRecords(raw: readonly HealthConnectActivityRecordInput[]): ImportedActivityEnergyRecord[] {
  return raw.flatMap((item): ImportedActivityEnergyRecord[] => {
    const sourceRecordId = item.sourceRecordId ?? item.id;
    if (item.recordType === 'ExerciseSessionRecord') {
      if (item.energyKcal === undefined) return [];
      return [{ id: `hc-session-${item.id}`, source: 'health_connect', sourceRecordId, kind: 'workout_session',
        energyKind: 'active', startTime: item.startTime, endTime: item.endTime, energyKcal: item.energyKcal,
        quality: 'measured', ...(item.parentWorkoutId ? { parentWorkoutId: item.parentWorkoutId } : {}),
        ...(item.activityCode ? { activityCode: item.activityCode } : {}), ...(item.updatedAt ? { updatedAt: item.updatedAt } : {}) }];
    }
    if (item.recordType === 'ActiveCaloriesBurnedRecord' || item.recordType === 'TotalCaloriesBurnedRecord') {
      if (item.energyKcal === undefined) return [];
      const active = item.recordType === 'ActiveCaloriesBurnedRecord';
      return [{ id: `hc-calories-${item.id}`, source: 'health_connect', sourceRecordId, kind: active ? 'active_calories_interval' : 'daily_total',
        energyKind: active ? 'active' : 'total', startTime: item.startTime, endTime: item.endTime, energyKcal: item.energyKcal,
        quality: 'measured', ...(item.parentWorkoutId ? { parentWorkoutId: item.parentWorkoutId } : {}),
        ...(item.updatedAt ? { updatedAt: item.updatedAt } : {}) }];
    }
    return [];
  });
}


export interface HealthKitActivityRecordInput {
  recordType: 'ExerciseSessionRecord' | 'ActiveCaloriesBurnedRecord' | 'Unknown';
  id: string;
  startTime: string;
  endTime: string;
  energyKcal?: number | null;
  activityCode?: string | null;
  updatedAt?: string | null;
  sourceRecordId?: string;
}

/** Map native HealthKit JSON to the shared source/provenance contract. */
export function normalizeHealthKitActivityRecords(raw: readonly HealthKitActivityRecordInput[]): ImportedActivityEnergyRecord[] {
  return raw.flatMap((item): ImportedActivityEnergyRecord[] => {
    if (item.recordType !== 'ActiveCaloriesBurnedRecord' || item.energyKcal === undefined || item.energyKcal === null) return [];
    return [{
      id: `hk-active-${item.id}`, source: 'healthkit', sourceRecordId: item.sourceRecordId ?? item.id,
      kind: 'active_calories_interval', energyKind: 'active', startTime: item.startTime, endTime: item.endTime,
      energyKcal: item.energyKcal, quality: 'measured',
      ...(item.activityCode ? { activityCode: item.activityCode } : {}),
      ...(item.updatedAt ? { updatedAt: item.updatedAt } : {}),
    }];
  });
}

export interface HealthPlatformBridge {
  platform: 'android_health_connect' | 'ios_healthkit';
  isAvailable(): Promise<boolean>;
  /** Completes the native permission UX; on iOS this cannot prove that read access was granted. */
  requestReadAuthorization(): Promise<void>;
  readActivityEnergy(startIso: string, endIso: string): Promise<unknown[]>;
}

/** Safe web-side capability discovery; native wrapper must explicitly inject a bridge. */
export function getNativeHealthPlatformBridge(): HealthPlatformBridge | null {
  const host = globalThis as typeof globalThis & { titanHealthBridge?: HealthPlatformBridge };
  const bridge = host.titanHealthBridge;
  if (!bridge || !['android_health_connect', 'ios_healthkit'].includes(bridge.platform) ||
      typeof bridge.isAvailable !== 'function' || typeof bridge.requestReadAuthorization !== 'function' ||
      typeof bridge.readActivityEnergy !== 'function') return null;
  return bridge;
}
