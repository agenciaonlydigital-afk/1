import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { RectAreaLightUniformsLib } from 'three/addons/lights/RectAreaLightUniformsLib.js';
import type {
  MuscleGroupId,
  MuscleHighlightPayload,
  MuscleSide,
} from '@/src/shared/types/common';
import { ANATOMY_KEY_LIGHT_DIRECTION, ANATOMY_KEY_LIGHT_TARGET, ANATOMY_KEY_LIGHT_DISTANCE } from '../lighting/anatomy-studio-lighting';
import {
  computeBodyIdentitySignature,
  createDefaultDualBodyInput,
  type BodyComparisonMode,
  type DualBodyInput,
} from '../../domain/body-identity';
import type { AnatomicalView } from '../../mapping/muscle-registry';
import {
  computeActiveMusclesMask,
  MUSCLE_ID_TO_SHADER_INDEX,
} from '../../mapping/anatomy-identifiers';
import type { AnatomyLayerMode, FocusRegion } from '../../state/anatomy.store';
import { getAnatomyCameraPreset } from '../camera/anatomy-camera';
import { detectSoftwareWebGL } from '../lifecycle/webgl-guard';
import {
  createAnatomyMaterials,
  type AnatomyMaterialSet,
  type AnatomyShaderUniforms,
} from '../materials/anatomy-materials';
import { buildAnatomyBody, type AnatomyBodyRig } from '../scene/build-anatomy-body';
import { MusclePicker } from '../picking/muscle-picking';
import { DualBodyCompositor } from './dual-body-compositor';

export interface AnatomyEngineCallbacks {
  onStatusChange: (status: 'initializing' | 'ready' | 'fallback') => void;
  onMusclePick: (muscleId: MuscleGroupId, side: MuscleSide) => void;
}

export interface AnatomyVisualInput {
  selectedMuscleId: MuscleGroupId | null;
  selectedMuscleSide: MuscleSide | null;
  workoutHighlights: MuscleHighlightPayload;
  cameraView: AnatomicalView;
  focusRegion: FocusRegion;
  layerMode: AnatomyLayerMode;
  zoomScale: number;
  hologramMode: boolean;
  dualBody?: DualBodyInput;
  comparisonMode?: BodyComparisonMode;
}

export interface AnatomyPerformanceSnapshot {
  drawCalls: number;
  triangles: number;
  geometries: number;
  textures: number;
  pixelRatio: number;
}

export class AnatomyRendererController {
  private renderer: THREE.WebGLRenderer | null = null;
  private controls: OrbitControls | null = null;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  // Heavy geometry/material construction is deferred until the actual WebGL2 renderer exists.
  // Unsupported browsers and offscreen viewers never pay the anatomy build cost.
  private materials: AnatomyMaterialSet | null = null;
  private bodyRig: AnatomyBodyRig | null = null;
  private goalBodyRig: AnatomyBodyRig | null = null;
  private compositor: DualBodyCompositor | null = null;
  private environmentTarget: THREE.WebGLRenderTarget | null = null;
  private readonly musclePicker = new MusclePicker();
  private pointerDown: { x: number; y: number; pointerId: number } | null = null;
  private emitterResources: Array<{ dispose: () => void }> = [];
  private backdropObjects: THREE.Object3D[] = [];
  private backlightHalo: THREE.Mesh | null = null;
  private resizeObserver: ResizeObserver | null = null;
  private intersectionObserver: IntersectionObserver | null = null;

  private isSoftwareGl = false;
  private isTouchDevice = false;
  private isVisible = true;
  private pageVisible = typeof document === 'undefined' || !document.hidden;
  private contextLost = false;
  private contextGeneration = 0;
  private shaderPreparationPending = false;
  private prefersReducedMotion = false;
  private motionQuery: MediaQueryList | null = null;
  private lastCameraKey = '';
  private lastWidth = 0;
  private lastHeight = 0;
  private lastPixelRatio = 0;
  private lastSelectionKey = '';
  private lastCurrentSignature = '';
  private lastGoalSignature = '';
  private comparisonMode: BodyComparisonMode = 'dual';
  private isInteracting = false;
  private interactionRestoreTimer = 0;
  private selectionSweepStartedAt = 0;
  private rafId = 0;
  private renderDirty = false;
  private disposed = false;
  private mountStarted = false;
  private initializationAttempted = false;
  private pendingVisualInput: AnatomyVisualInput | null = null;
  private cameraTransition: {
    startedAt: number;
    durationMs: number;
    fromPos: THREE.Vector3;
    toPos: THREE.Vector3;
    fromTarget: THREE.Vector3;
    toTarget: THREE.Vector3;
  } | null = null;

  constructor(
    private readonly container: HTMLElement,
    private readonly callbacks: AnatomyEngineCallbacks,
  ) {
    this.scene = new THREE.Scene();
    this.scene.background = null;

    const width = Math.max(1, container.clientWidth);
    const height = Math.max(1, container.clientHeight);
    this.camera = new THREE.PerspectiveCamera(35, width / height, 0.1, 40);
    const preset = getAnatomyCameraPreset('frontal', 'full', 1);
    this.camera.position.copy(preset.position);
    this.camera.lookAt(preset.target);
  }

  mount(): boolean {
    if (this.disposed || this.mountStarted) return false;
    this.mountStarted = true;
    this.callbacks.onStatusChange('initializing');
    document.addEventListener('visibilitychange', this.handleDocumentVisibilityChange);
    if (typeof IntersectionObserver === 'undefined') {
      this.isVisible = true;
      this.initializeRenderer();
      return true;
    }

    this.isVisible = false;
    this.intersectionObserver = new IntersectionObserver(
      (entries) => {
        const nextVisible = entries[0]?.isIntersecting ?? false;
        const becameVisible = !this.isVisible && nextVisible;
        this.isVisible = nextVisible;
        if (!nextVisible) {
          cancelAnimationFrame(this.rafId);
          this.rafId = 0;
          return;
        }
        if (this.pageVisible && becameVisible) {
          if (!this.renderer) this.initializeRenderer();
          else this.requestRender();
        }
      },
      { rootMargin: '120px 0px', threshold: 0.01 },
    );
    this.intersectionObserver.observe(this.container);
    return true;
  }

  private initializeRenderer(): void {
    if (
      this.disposed ||
      this.initializationAttempted ||
      this.renderer ||
      !this.isVisible ||
      !this.pageVisible
    ) return;
    this.initializationAttempted = true;

    this.isTouchDevice = window.matchMedia('(pointer: coarse)').matches;
    this.motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    this.prefersReducedMotion = this.motionQuery.matches;
    this.motionQuery.addEventListener('change', this.handleMotionPreferenceChange);

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !this.isTouchDevice,
        powerPreference: 'high-performance',
        alpha: true,
        depth: true,
        stencil: false,
        preserveDrawingBuffer: false,
      });
    } catch {
      this.releaseViewportObservers();
      this.callbacks.onStatusChange('fallback');
      return;
    }
    this.isSoftwareGl = detectSoftwareWebGL(renderer.getContext());

    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.18;
    renderer.setClearColor(0x000000, 0);

    this.lastWidth = Math.max(1, this.container.clientWidth);
    this.lastHeight = Math.max(1, this.container.clientHeight);
    this.lastPixelRatio = this.getEffectivePixelRatio(this.lastWidth, this.lastHeight);
    renderer.setPixelRatio(this.lastPixelRatio);
    renderer.setSize(this.lastWidth, this.lastHeight);
    renderer.domElement.style.display = 'block';
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    renderer.domElement.style.touchAction = 'pan-y';
    renderer.domElement.style.pointerEvents = 'auto';
    renderer.domElement.style.cursor = 'grab';
    renderer.domElement.setAttribute(
      'aria-label',
      'Modelo anatômico tridimensional interativo com comparação entre físico atual e meta. Arraste para girar e toque em um músculo para selecionar.',
    );

    const initialDual = this.pendingVisualInput?.dualBody ?? createDefaultDualBodyInput();
    this.lastCurrentSignature = computeBodyIdentitySignature(initialDual.current);
    this.lastGoalSignature = computeBodyIdentitySignature(initialDual.goal);
    const lod = this.isTouchDevice || this.isSoftwareGl ? 'mid' : 'high';

    try {
      const maxAniso = this.isSoftwareGl ? 1 : Math.min(4, renderer.capabilities.getMaxAnisotropy());
      const materials = createAnatomyMaterials(maxAniso);
      this.materials = materials;
      this.bodyRig = buildAnatomyBody(materials, {
        role: 'current',
        identity: initialDual.current,
        lod,
      });
      this.goalBodyRig = buildAnatomyBody(materials, {
        role: 'goal',
        identity: initialDual.goal,
        lod,
      });
    } catch {
      this.releaseRendererToFallback(renderer);
      this.callbacks.onStatusChange('fallback');
      return;
    }

    const bodyRig = this.bodyRig;
    const goalBodyRig = this.goalBodyRig;
    if (!bodyRig || !goalBodyRig) {
      this.releaseRendererToFallback(renderer);
      this.callbacks.onStatusChange('fallback');
      return;
    }

    try {
      this.compositor = new DualBodyCompositor(
        this.lastWidth,
        this.lastHeight,
        this.lastPixelRatio,
      );
    } catch {
      this.compositor = null;
    }

    this.container.appendChild(renderer.domElement);
    this.renderer = renderer;

    this.buildStudioLighting();
    try {
      this.buildStudioEnvironment(renderer);
    } catch {
      this.scene.environment = null;
      this.environmentTarget?.dispose();
      this.environmentTarget = null;
    }

    const controls = new OrbitControls(this.camera, renderer.domElement);
    controls.target.set(0, 0.82, 0);
    controls.enableRotate = true;
    controls.enableZoom = false;
    controls.enablePan = false;
    controls.minPolarAngle = Math.PI * 0.40;
    controls.maxPolarAngle = Math.PI * 0.51;
    controls.enableDamping = !this.isSoftwareGl && !this.prefersReducedMotion;
    controls.dampingFactor = 0.065;
    controls.rotateSpeed = 0.72;
    controls.update();
    renderer.domElement.style.touchAction = 'pan-y';
    controls.addEventListener('start', this.handleControlsStart);
    controls.addEventListener('change', this.handleControlsChange);
    this.controls = controls;

    this.buildBackdropSeparation();
    // Both bodies occupy exact same center, axis, pose, and scale (zero displacement).
    this.scene.add(bodyRig.root);
    this.scene.add(goalBodyRig.root);

    this.bindEvents(renderer.domElement);

    const pendingVisualInput = this.pendingVisualInput;
    this.pendingVisualInput = null;
    if (pendingVisualInput) this.syncVisualState(pendingVisualInput);

    this.shaderPreparationPending = true;
    const compileGeneration = this.contextGeneration;
    void renderer.compileAsync(this.scene, this.camera).then(() => {
      if (this.disposed || this.renderer !== renderer || compileGeneration !== this.contextGeneration) return;
      this.shaderPreparationPending = false;
      if (this.contextLost) return;
      this.callbacks.onStatusChange('ready');
      this.requestRender();
    }).catch(() => {
      if (this.disposed || this.renderer !== renderer || compileGeneration !== this.contextGeneration) return;
      this.releaseRendererToFallback(renderer);
      this.callbacks.onStatusChange('fallback');
    });
  }

  /** Release page/viewport listeners whether or not a WebGL context was created. */
  private releaseViewportObservers(): void {
    window.removeEventListener('resize', this.handleResize);
    document.removeEventListener('visibilitychange', this.handleDocumentVisibilityChange);
    this.motionQuery?.removeEventListener('change', this.handleMotionPreferenceChange);
    this.motionQuery = null;
    this.resizeObserver?.disconnect();
    this.resizeObserver = null;
    this.intersectionObserver?.disconnect();
    this.intersectionObserver = null;
  }

  /** Release every resource after an unrecoverable WebGL or shader failure. */
  private releaseRendererToFallback(renderer: THREE.WebGLRenderer): void {
    cancelAnimationFrame(this.rafId);
    window.clearTimeout(this.interactionRestoreTimer);
    this.rafId = 0;
    this.renderDirty = false;
    this.shaderPreparationPending = false;
    this.contextLost = false;
    this.pointerDown = null;
    this.pendingVisualInput = null;

    if (this.controls) {
      this.controls.removeEventListener('start', this.handleControlsStart);
      this.controls.removeEventListener('change', this.handleControlsChange);
      this.controls.dispose();
      this.controls = null;
    }

    this.releaseViewportObservers();

    const canvas = renderer.domElement;
    canvas.removeEventListener('webglcontextlost', this.handleContextLost);
    canvas.removeEventListener('pointerdown', this.handlePointerDown);
    canvas.removeEventListener('pointerup', this.handlePointerUp);
    canvas.removeEventListener('pointercancel', this.handlePointerCancel);
    canvas.removeEventListener('webglcontextrestored', this.handleContextRestored);
    if (canvas.parentElement === this.container) this.container.removeChild(canvas);

    if (this.bodyRig) this.bodyRig.dispose();
    this.bodyRig = null;
    if (this.goalBodyRig) this.goalBodyRig.dispose();
    this.goalBodyRig = null;
    if (this.compositor) this.compositor.dispose();
    this.compositor = null;
    if (this.materials) this.materials.dispose();
    this.materials = null;
    this.emitterResources.forEach((resource) => resource.dispose());
    this.emitterResources = [];
    this.backdropObjects = [];
    this.backlightHalo = null;

    this.scene.environment = null;
    this.environmentTarget?.dispose();
    this.environmentTarget = null;
    this.scene.clear();

    if (this.renderer === renderer) this.renderer = null;
    renderer.dispose();
    renderer.forceContextLoss();
  }

  private getEffectivePixelRatio(width: number, height: number): number {
    const deviceRatio = Math.max(0.1, window.devicePixelRatio || 1);
    const maxRatio = this.isSoftwareGl ? 1 : this.isTouchDevice ? 1.35 : 1.55;
    const pixelBudget = this.isSoftwareGl
      ? 520_000
      : this.isTouchDevice
        ? 1_050_000
        : 1_850_000;
    const budgetRatio = Math.sqrt(pixelBudget / Math.max(1, width * height));
    return Math.min(deviceRatio, maxRatio, budgetRatio);
  }

  private buildStudioLighting(): void {
    // Body-only studio lights reveal anatomy; the single background halo is isolated
    // in buildBackdropSeparation(). No floor, plinth, ground projector or contact spot exists.
    const ambient = new THREE.HemisphereLight('#C8DCEA', '#0A0D0C', 0.12);

    if (this.isSoftwareGl) {
      // Conservative fallback when LTC/RectAreaLight is unavailable or too expensive.
      const key = new THREE.DirectionalLight('#FFF7EC', 2.05);
      const keyTarget = new THREE.Vector3(...ANATOMY_KEY_LIGHT_TARGET);
      const keyDirection = new THREE.Vector3(...ANATOMY_KEY_LIGHT_DIRECTION).normalize();
      key.target.position.copy(keyTarget);
      key.position.copy(keyTarget).addScaledVector(keyDirection, ANATOMY_KEY_LIGHT_DISTANCE);
      const fill = new THREE.DirectionalLight('#66838D', 0.28);
      fill.position.set(2.75, 1.15, 1.65);
      const rim = new THREE.DirectionalLight('#8CCFC7', 0.54);
      rim.position.set(1.85, 2.45, -2.35);
      this.scene.add(ambient, key, key.target, fill, rim);
      return;
    }

    // Hardware path: actual broad rectangular sources replace duplicated directional key/rim.
    RectAreaLightUniformsLib.init();
    const fill = new THREE.DirectionalLight('#66838D', 0.16);
    fill.position.set(2.75, 1.15, 1.65);

    const keySoftbox = new THREE.RectAreaLight('#FFF6EA', 1.48, 1.85, 2.65);
    const keyTarget = new THREE.Vector3(...ANATOMY_KEY_LIGHT_TARGET);
    const keyDirection = new THREE.Vector3(...ANATOMY_KEY_LIGHT_DIRECTION).normalize();
    keySoftbox.position.copy(keyTarget).addScaledVector(keyDirection, ANATOMY_KEY_LIGHT_DISTANCE);
    keySoftbox.lookAt(keyTarget);

    const rimSoftbox = new THREE.RectAreaLight('#8CCFC7', 0.44, 1.50, 2.40);
    rimSoftbox.position.set(1.65, 2.15, -1.95);
    rimSoftbox.lookAt(0, 1.10, 0);

    this.scene.add(ambient, fill, keySoftbox, rimSoftbox);
  }

  private buildStudioEnvironment(renderer: THREE.WebGLRenderer): void {
    if (this.isSoftwareGl) return;
    const generator = new THREE.PMREMGenerator(renderer);
    const room = new RoomEnvironment();
    try {
      this.environmentTarget = generator.fromScene(room, 0.04);
      this.scene.environment = this.environmentTarget.texture;
      this.scene.environmentIntensity = 0.58;
    } finally {
      room.dispose();
      generator.dispose();
    }
  }

  private buildBackdropSeparation(): void {
    // Pure atmospheric studio horizon separation behind the figures (zero floor plinth, circles, or contact shadows).
    const haloGeo = new THREE.PlaneGeometry(4.4, 2.6, 1, 1);
    const haloMat = new THREE.ShaderMaterial({
      vertexShader: `
        varying vec2 vUv;
        void main() {
          vUv = uv;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        varying vec2 vUv;
        void main() {
          float x = (vUv.x - 0.5) * 2.0;
          float y = clamp(vUv.y, 0.0, 1.0);

          float bottomSoftFade = smoothstep(0.06, 0.28, y);
          float topSoftFade = 1.0 - smoothstep(0.42, 0.94, y);
          float sideSoftFade = 1.0 - smoothstep(0.28, 0.84, abs(x));
          float quadFade = bottomSoftFade * topSoftFade * sideSoftFade;
          if (quadFade <= 0.001) discard;

          float radial = length(vec2(x * 1.15, (y - 0.46) * 1.35));
          float dome = exp(-radial * radial * 2.65);
          float intensity = clamp(dome * 0.125 * quadFade, 0.0, 0.13);
          if (intensity <= 0.002) discard;

          vec3 glowColor = mix(vec3(0.16, 0.52, 0.54), vec3(0.32, 0.34, 0.58), smoothstep(0.20, 0.78, y));
          gl_FragColor = vec4(glowColor, intensity);
        }
      `,
      transparent: true,
      depthWrite: false,
      side: THREE.DoubleSide,
      blending: THREE.CustomBlending,
      blendEquation: THREE.AddEquation,
      blendSrc: THREE.SrcAlphaFactor,
      blendDst: THREE.OneFactor,
      blendEquationAlpha: THREE.AddEquation,
      blendSrcAlpha: THREE.OneFactor,
      blendDstAlpha: THREE.OneMinusSrcAlphaFactor,
    });
    const backlightHalo = new THREE.Mesh(haloGeo, haloMat);
    backlightHalo.position.set(0, 1.08, -0.65);
    backlightHalo.renderOrder = -1;
    this.scene.add(backlightHalo);
    this.backlightHalo = backlightHalo;
    this.backdropObjects.push(backlightHalo);
    this.emitterResources.push(haloGeo, haloMat);
  }

  private updateBackdropTransform(): void {
    const cx = this.camera.position.x;
    const cz = this.camera.position.z;
    const len = Math.hypot(cx, cz) || 1;
    const nx = cx / len;
    const nz = cz / len;
    const yaw = Math.atan2(nx, nz);

    if (this.backlightHalo) {
      this.backlightHalo.position.set(-nx * 0.65, 1.08, -nz * 0.65);
      this.backlightHalo.rotation.set(0, yaw, 0);
    }
    if (this.materials) {
      // Upper-rear studio rim origin (keeps torso/shoulders sculpted cleanly without floor spill).
      this.materials.uniforms.uBacklightOrigin?.value.set(-nx * 0.95, 1.65, -nz * 1.15);
      this.materials.goalUniforms.uBacklightOrigin?.value.set(-nx * 0.95, 1.65, -nz * 1.15);
    }
  }

  private bindEvents(canvas: HTMLCanvasElement): void {
    canvas.addEventListener('webglcontextlost', this.handleContextLost);
    canvas.addEventListener('pointerdown', this.handlePointerDown);
    canvas.addEventListener('pointerup', this.handlePointerUp);
    canvas.addEventListener('pointercancel', this.handlePointerCancel);
    canvas.addEventListener('webglcontextrestored', this.handleContextRestored);
    window.addEventListener('resize', this.handleResize);
    if (typeof ResizeObserver !== 'undefined') {
      this.resizeObserver = new ResizeObserver(() => this.handleResize());
      this.resizeObserver.observe(this.container);
    }
  }

  private handleDocumentVisibilityChange = (): void => {
    this.pageVisible = !document.hidden;
    if (!this.pageVisible) {
      cancelAnimationFrame(this.rafId);
      this.rafId = 0;
      return;
    }
    if (this.isVisible && !this.renderer) {
      this.initializeRenderer();
      return;
    }
    this.requestRender();
  };

  private handleControlsStart = (): void => {
    this.cameraTransition = null;
    if (!this.isSoftwareGl && this.renderer && this.lastWidth > 0 && this.lastHeight > 0) {
      this.isInteracting = true;
      window.clearTimeout(this.interactionRestoreTimer);
      const interactiveDpr = Math.max(0.85, this.lastPixelRatio * 0.85);
      this.renderer.setPixelRatio(interactiveDpr);
      this.compositor?.resize(this.lastWidth, this.lastHeight, interactiveDpr);
    }
  };

  private handleControlsChange = (): void => {
    if (this.isInteracting && !this.isSoftwareGl && this.renderer) {
      window.clearTimeout(this.interactionRestoreTimer);
      this.interactionRestoreTimer = window.setTimeout(() => {
        if (this.disposed || !this.renderer || this.lastWidth <= 0 || this.lastHeight <= 0) return;
        this.isInteracting = false;
        this.renderer.setPixelRatio(this.lastPixelRatio);
        this.compositor?.resize(this.lastWidth, this.lastHeight, this.lastPixelRatio);
        this.requestRender();
      }, 130);
    }
    this.requestRender();
  };

  private handlePointerDown = (event: PointerEvent): void => {
    if (event.button !== 0) return;
    this.pointerDown = { x: event.clientX, y: event.clientY, pointerId: event.pointerId };
  };

  private handlePointerCancel = (): void => {
    this.pointerDown = null;
  };

  private handlePointerUp = (event: PointerEvent): void => {
    const start = this.pointerDown;
    this.pointerDown = null;
    if (!start || start.pointerId !== event.pointerId) return;
    if (Math.hypot(event.clientX - start.x, event.clientY - start.y) > 6) return;
    const renderer = this.renderer;
    const bodyRig = this.bodyRig;
    const goalBodyRig = this.goalBodyRig;
    if (!renderer || !bodyRig || this.disposed || this.contextLost) return;

    const pickables: THREE.Mesh[] = [];
    const occluders: THREE.Mesh[] = [];
    if (this.comparisonMode !== 'goal') {
      pickables.push(...bodyRig.pickableMeshes);
      occluders.push(...bodyRig.occlusionMeshes);
    }
    if (this.comparisonMode !== 'current' && goalBodyRig) {
      pickables.push(...goalBodyRig.pickableMeshes);
      occluders.push(...goalBodyRig.occlusionMeshes);
    }

    const hit = this.musclePicker.pick(
      event.clientX,
      event.clientY,
      renderer.domElement,
      this.camera,
      pickables,
      occluders,
    );
    if (hit) {
      this.callbacks.onMusclePick(hit.muscleId, hit.side);
      this.requestRender();
    }
  };

  private handleContextLost = (event: Event): void => {
    event.preventDefault();
    this.contextLost = true;
    this.contextGeneration += 1;
    cancelAnimationFrame(this.rafId);
    this.rafId = 0;
    this.callbacks.onStatusChange('fallback');
  };

  private handleContextRestored = (): void => {
    const renderer = this.renderer;
    if (!renderer || this.disposed) return;
    try {
      this.contextLost = true;
      this.shaderPreparationPending = true;
      const compileGeneration = ++this.contextGeneration;
      this.environmentTarget?.dispose();
      this.environmentTarget = null;
      this.scene.environment = null;
      try {
        this.buildStudioEnvironment(renderer);
      } catch {
        this.scene.environment = null;
      }
      void renderer.compileAsync(this.scene, this.camera).then(() => {
        if (this.disposed || this.renderer !== renderer || compileGeneration !== this.contextGeneration) return;
        this.shaderPreparationPending = false;
        this.contextLost = false;
        this.callbacks.onStatusChange('ready');
        this.requestRender();
      }).catch(() => {
        if (this.disposed || this.renderer !== renderer || compileGeneration !== this.contextGeneration) return;
        this.releaseRendererToFallback(renderer);
        this.callbacks.onStatusChange('fallback');
      });
    } catch {
      this.releaseRendererToFallback(renderer);
      this.callbacks.onStatusChange('fallback');
    }
  };

  private handleMotionPreferenceChange = (event: MediaQueryListEvent): void => {
    this.prefersReducedMotion = event.matches;
    if (this.controls) this.controls.enableDamping = !this.isSoftwareGl && !event.matches;
    if (event.matches) {
      this.selectionSweepStartedAt = 0;
      if (this.materials) {
        this.materials.uniforms.uSweepY.value = 2.05;
        this.materials.goalUniforms.uSweepY.value = 2.05;
      }
    }
    this.requestRender();
  };

  handleResize = (): void => {
    if (!this.renderer || this.disposed) return;
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    if (width <= 0 || height <= 0) return;

    const nextPixelRatio = this.getEffectivePixelRatio(width, height);
    const sizeChanged = width !== this.lastWidth || height !== this.lastHeight;
    const densityChanged = Math.abs(nextPixelRatio - this.lastPixelRatio) > 0.001;
    if (!sizeChanged && !densityChanged) return;

    this.lastWidth = width;
    this.lastHeight = height;
    if (densityChanged) {
      this.lastPixelRatio = nextPixelRatio;
      this.renderer.setPixelRatio(nextPixelRatio);
    }
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
    this.compositor?.resize(width, height, this.lastPixelRatio);
    this.requestRender();
  };

  private applyUniformMaskState(
    uniforms: AnatomyShaderUniforms,
    primaryMask: number,
    secondaryMask: number,
    activeMask: number,
    selectedIndex: number,
    selectedSide: number,
    selectedSideAny: number,
    hasSelection: number,
  ): void {
    if (uniforms.uPrimaryMusclesMask.value !== primaryMask) uniforms.uPrimaryMusclesMask.value = primaryMask;
    if (uniforms.uSecondaryMusclesMask.value !== secondaryMask) uniforms.uSecondaryMusclesMask.value = secondaryMask;
    if (uniforms.uActiveMusclesMask.value !== activeMask) uniforms.uActiveMusclesMask.value = activeMask;
    if (uniforms.uSelectedMuscleIndex.value !== selectedIndex) uniforms.uSelectedMuscleIndex.value = selectedIndex;
    if (uniforms.uSelectedMuscleSide.value !== selectedSide) uniforms.uSelectedMuscleSide.value = selectedSide;
    if (uniforms.uSelectedSideAny.value !== selectedSideAny) uniforms.uSelectedSideAny.value = selectedSideAny;
    if (uniforms.uHasSelection.value !== hasSelection) uniforms.uHasSelection.value = hasSelection;
  }

  private syncMuscleShaderState(next: AnatomyVisualInput): void {
    if (!this.materials) return;
    const primaryMask = computeActiveMusclesMask(next.workoutHighlights.primary);
    const secondaryMask = computeActiveMusclesMask(next.workoutHighlights.secondary);
    const activeIds: MuscleGroupId[] = [
      ...next.workoutHighlights.primary,
      ...next.workoutHighlights.secondary,
      ...(next.selectedMuscleId ? [next.selectedMuscleId] : []),
    ];
    const activeMask = computeActiveMusclesMask(activeIds);
    const selectedIndex = next.selectedMuscleId
      ? MUSCLE_ID_TO_SHADER_INDEX[next.selectedMuscleId]
      : 0;
    const selectedSide = next.selectedMuscleSide === 'left'
      ? 1
      : next.selectedMuscleSide === 'right'
        ? -1
        : 0;
    const selectedSideAny = next.selectedMuscleId && next.selectedMuscleSide && next.selectedMuscleSide !== 'center' ? 0 : 1;
    const hasSelection = next.selectedMuscleId ? 1 : 0;

    this.applyUniformMaskState(
      this.materials.uniforms,
      primaryMask,
      secondaryMask,
      activeMask,
      selectedIndex,
      selectedSide,
      selectedSideAny,
      hasSelection,
    );
    this.applyUniformMaskState(
      this.materials.goalUniforms,
      primaryMask,
      secondaryMask,
      activeMask,
      selectedIndex,
      selectedSide,
      selectedSideAny,
      hasSelection,
    );

    // Sync Human Atlas-inspired 16x1 GPU state texture
    const lut = this.materials.stateDataTexture.image.data as Uint8Array;
    if (lut) {
      for (let i = 1; i <= 14; i += 1) {
        const bit = 1 << i;
        const idx = i * 4;
        lut[idx] = (primaryMask & bit) !== 0 ? 255 : 0;
        lut[idx + 1] = (secondaryMask & bit) !== 0 ? 255 : 0;
        lut[idx + 2] = hasSelection && selectedIndex === i ? 255 : 0;
        lut[idx + 3] = (activeMask & bit) !== 0 ? 255 : 0;
      }
      this.materials.stateDataTexture.needsUpdate = true;
    }
  }

  private syncDualBodyMorphs(dualBody: DualBodyInput): void {
    if (!this.materials || !this.bodyRig || !this.goalBodyRig) return;
    const lod = this.isTouchDevice || this.isSoftwareGl ? 'mid' : 'high';

    const nextCurrentSig = computeBodyIdentitySignature(dualBody.current);
    if (nextCurrentSig !== this.lastCurrentSignature) {
      this.lastCurrentSignature = nextCurrentSig;
      this.scene.remove(this.bodyRig.root);
      this.bodyRig.dispose();
      this.bodyRig = buildAnatomyBody(this.materials, {
        role: 'current',
        identity: dualBody.current,
        lod,
      });
      this.scene.add(this.bodyRig.root);
    }

    const nextGoalSig = computeBodyIdentitySignature(dualBody.goal);
    if (nextGoalSig !== this.lastGoalSignature) {
      this.lastGoalSignature = nextGoalSig;
      this.scene.remove(this.goalBodyRig.root);
      this.goalBodyRig.dispose();
      this.goalBodyRig = buildAnatomyBody(this.materials, {
        role: 'goal',
        identity: dualBody.goal,
        lod,
      });
      this.scene.add(this.goalBodyRig.root);
    }
  }

  syncVisualState(next: AnatomyVisualInput): void {
    if (this.disposed) return;
    const renderer = this.renderer;
    const materials = this.materials;
    const bodyRig = this.bodyRig;
    if (!renderer || !materials || !bodyRig) {
      if (!this.initializationAttempted) this.pendingVisualInput = next;
      return;
    }

    if (next.dualBody) {
      this.syncDualBodyMorphs(next.dualBody);
    }
    this.comparisonMode = next.comparisonMode ?? 'dual';

    this.syncMuscleShaderState(next);
    const holoVal = next.hologramMode ? 1 : 0;
    materials.uniforms.uHologramMode.value = holoVal;
    materials.goalUniforms.uHologramMode.value = holoVal;

    const selectionKey = next.selectedMuscleId
      ? `${next.selectedMuscleId}:${next.selectedMuscleSide ?? 'all'}`
      : '';
    if (selectionKey && selectionKey !== this.lastSelectionKey) {
      this.selectionSweepStartedAt = this.prefersReducedMotion ? 0 : performance.now();
      const startY = this.prefersReducedMotion ? 2.05 : -0.08;
      materials.uniforms.uSweepY.value = startY;
      materials.goalUniforms.uSweepY.value = startY;
    } else if (!selectionKey) {
      this.selectionSweepStartedAt = 0;
      materials.uniforms.uSweepY.value = 2.05;
      materials.goalUniforms.uSweepY.value = 2.05;
    }
    this.lastSelectionKey = selectionKey;

    const isDeep = next.layerMode === 'deep';
    const activeRigs = [this.bodyRig, this.goalBodyRig].filter(Boolean) as AnatomyBodyRig[];
    for (const rig of activeRigs) {
      rig.shellGroup.visible = true;
      rig.superficialGroup.visible = !isDeep;
      rig.deepGroup.visible = isDeep;
    }
    if (this.bodyRig) {
      this.bodyRig.root.visible = this.comparisonMode !== 'goal';
    }
    if (this.goalBodyRig) {
      this.goalBodyRig.root.visible = this.comparisonMode !== 'current';
    }

    // With isolated offscreen compositor, each body renders with opaque depth self-occlusion
    // unless viewing deep internal layers where shell becomes translucent.
    const useDeepAlpha = isDeep || !this.compositor;
    materials.bodySurface.transparent = isDeep;
    materials.bodySurface.opacity = isDeep ? 0.16 : 1;
    materials.bodySurface.depthWrite = !isDeep;
    materials.goalBodySurface.transparent = useDeepAlpha;
    materials.goalBodySurface.opacity = isDeep ? 0.16 : !this.compositor && this.comparisonMode === 'dual' ? 0.45 : 1;
    materials.goalBodySurface.depthWrite = !isDeep && Boolean(this.compositor);

    const cameraKey = `${next.cameraView}:${next.focusRegion}:${next.zoomScale}`;
    if (cameraKey !== this.lastCameraKey) {
      const hadPreviousCamera = this.lastCameraKey !== '';
      this.lastCameraKey = cameraKey;
      const preset = getAnatomyCameraPreset(
        next.cameraView,
        next.focusRegion,
        next.zoomScale,
      );
      if (!hadPreviousCamera || this.prefersReducedMotion || this.isSoftwareGl) {
        this.cameraTransition = null;
        this.camera.position.copy(preset.position);
        if (this.controls) {
          this.controls.target.copy(preset.target);
          this.controls.update();
        } else {
          this.camera.lookAt(preset.target);
        }
      } else {
        this.cameraTransition = {
          startedAt: performance.now(),
          durationMs: 360,
          fromPos: this.camera.position.clone(),
          toPos: preset.position.clone(),
          fromTarget: (this.controls ? this.controls.target : preset.target).clone(),
          toTarget: preset.target.clone(),
        };
      }
    }

    this.requestRender();
  }

  private updateCameraTransition(now: number): boolean {
    const transition = this.cameraTransition;
    if (!transition || this.prefersReducedMotion) {
      this.cameraTransition = null;
      return false;
    }
    const progress = Math.min(1, Math.max(0, (now - transition.startedAt) / transition.durationMs));
    const eased = 1 - Math.pow(1 - progress, 3);
    this.camera.position.lerpVectors(transition.fromPos, transition.toPos, eased);
    if (this.controls) {
      this.controls.target.lerpVectors(transition.fromTarget, transition.toTarget, eased);
      this.controls.update();
    } else {
      this.camera.lookAt(transition.toTarget);
    }
    if (progress >= 1) {
      this.cameraTransition = null;
      return false;
    }
    return true;
  }

  private updateSelectionSweep(now: number): boolean {
    if (!this.materials || !this.selectionSweepStartedAt || this.prefersReducedMotion) return false;
    const progress = Math.min(1, Math.max(0, (now - this.selectionSweepStartedAt) / 420));
    const eased = 1 - Math.pow(1 - progress, 3);
    const sweepVal = -0.08 + eased * 1.95;
    this.materials.uniforms.uSweepY.value = sweepVal;
    this.materials.goalUniforms.uSweepY.value = sweepVal;
    if (progress >= 1) {
      this.materials.uniforms.uSweepY.value = 2.05;
      this.materials.goalUniforms.uSweepY.value = 2.05;
      this.selectionSweepStartedAt = 0;
      return false;
    }
    return true;
  }

  requestRender = (): void => {
    const renderer = this.renderer;
    const bodyRig = this.bodyRig;
    const materials = this.materials;
    if (
      this.disposed ||
      !renderer ||
      !bodyRig ||
      !materials ||
      !this.isVisible ||
      !this.pageVisible ||
      this.contextLost ||
      this.shaderPreparationPending
    ) return;

    this.renderDirty = true;
    if (this.rafId) return;

    this.rafId = requestAnimationFrame(() => {
      this.rafId = 0;
      if (
        this.renderer !== renderer ||
        this.bodyRig !== bodyRig ||
        this.materials !== materials ||
        this.disposed ||
        !this.isVisible ||
        !this.pageVisible ||
        this.contextLost ||
        this.shaderPreparationPending
      ) return;

      const wasDirty = this.renderDirty;
      this.renderDirty = false;
      const now = performance.now();
      const cameraAnimating = this.updateCameraTransition(now);
      const dampingActive = this.controls?.update() ?? false;
      const sweepActive = this.updateSelectionSweep(now);
      const timeSec = this.prefersReducedMotion ? 0 : now * 0.001;
      if (materials.uniforms.uTime) materials.uniforms.uTime.value = timeSec;
      if (materials.goalUniforms.uTime) materials.goalUniforms.uTime.value = timeSec;
      this.updateBackdropTransform();

      const activeMotion =
        cameraAnimating ||
        sweepActive ||
        (dampingActive && !this.isSoftwareGl);

      if (wasDirty || activeMotion) {
        if (this.compositor && this.goalBodyRig) {
          this.compositor.render(
            renderer,
            this.scene,
            this.camera,
            this.bodyRig.root,
            this.goalBodyRig.root,
            this.backdropObjects,
            this.comparisonMode,
          );
        } else {
          renderer.render(this.scene, this.camera);
        }
      }

      if (activeMotion) {
        this.requestRender();
      }
    });
  };

  getPerformanceSnapshot(): AnatomyPerformanceSnapshot {
    const info = this.renderer?.info;
    return {
      drawCalls: info?.render.calls ?? 0,
      triangles: info?.render.triangles ?? 0,
      geometries: info?.memory.geometries ?? 0,
      textures: info?.memory.textures ?? 0,
      pixelRatio: this.lastPixelRatio,
    };
  }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    cancelAnimationFrame(this.rafId);
    window.clearTimeout(this.interactionRestoreTimer);
    this.rafId = 0;
    this.cameraTransition = null;

    if (this.controls) {
      this.controls.removeEventListener('start', this.handleControlsStart);
      this.controls.removeEventListener('change', this.handleControlsChange);
      this.controls.dispose();
      this.controls = null;
    }

    this.releaseViewportObservers();

    if (this.bodyRig) this.bodyRig.dispose();
    this.bodyRig = null;
    if (this.goalBodyRig) this.goalBodyRig.dispose();
    this.goalBodyRig = null;
    if (this.compositor) this.compositor.dispose();
    this.compositor = null;
    if (this.materials) this.materials.dispose();
    this.materials = null;
    this.emitterResources.forEach((resource) => resource.dispose());
    this.emitterResources = [];
    this.backdropObjects = [];
    this.backlightHalo = null;

    if (this.renderer) {
      const renderer = this.renderer;
      const canvas = renderer.domElement;
      canvas.removeEventListener('webglcontextlost', this.handleContextLost);
      canvas.removeEventListener('pointerdown', this.handlePointerDown);
      canvas.removeEventListener('pointerup', this.handlePointerUp);
      canvas.removeEventListener('pointercancel', this.handlePointerCancel);
      canvas.removeEventListener('webglcontextrestored', this.handleContextRestored);
      if (canvas.parentElement === this.container) this.container.removeChild(canvas);
      this.scene.environment = null;
      this.environmentTarget?.dispose();
      this.environmentTarget = null;
      this.scene.clear();
      renderer.dispose();
      renderer.forceContextLoss();
      this.renderer = null;
    }

    this.pointerDown = null;
    this.pendingVisualInput = null;
    this.shaderPreparationPending = false;
  }
}
