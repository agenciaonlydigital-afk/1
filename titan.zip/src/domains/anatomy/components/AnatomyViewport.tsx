import { memo, useEffect, useMemo, useRef } from 'react';
import { ArrowDown, ArrowUp, Dumbbell, Minus } from 'lucide-react';
import { AnimatePresence, motion, TITAN_DURATIONS, TITAN_EASE } from '@/src/shared/motion/titan-motion';
import type { MuscleGroupId } from '@/src/shared/types/common';
import type { FitnessGoalType } from '@/src/shared/types/fitness-goal';
import {
  deriveDualBodyInput,
  type BodyComparisonMode,
} from '../domain/body-identity';
import { getAnatomicalSubstructuresForGroup } from '../mapping/anatomical-structure-map';
import { MUSCLE_LIST } from '../mapping/muscle-registry';
import type { AnatomicalView } from '../mapping/muscle-registry';
import { useAnatomyStore } from '../state/anatomy.store';
import type { AnatomyRendererController } from '../engine/renderer/anatomy-renderer';

const VIEW_OPTIONS: Array<{ id: AnatomicalView; label: string }> = [
  { id: 'frontal', label: 'Frontal' },
  { id: 'posterior', label: 'Posterior' },
  { id: 'lateral', label: 'Lateral' },
];

const COMPARISON_OPTIONS: Array<{ id: BodyComparisonMode; label: string }> = [
  { id: 'dual', label: 'Sobreposto' },
  { id: 'current', label: 'Atual' },
  { id: 'goal', label: 'Meta' },
];

export interface AnatomyBodyComparison {
  currentWeightKg: number | null;
  targetWeightKg: number | null;
  profileConfigured: boolean;
  sex?: 'male' | 'female';
  goal?: FitnessGoalType;
  heightCm?: number | null;
  waistCm?: number | null;
  bodyFatPercent?: number | null;
  hasObservedMeasurements?: boolean;
}

export interface AnatomyStageIndicators {
  direction: 'up' | 'down' | 'flat';
  isAlignedWithGoal: boolean;
  weeklyRateFormatted: string;
  ariaLabel: string;
}

interface AnatomyViewportProps {
  onOpenExerciseLibrary?: (muscleId: MuscleGroupId) => void;
  bodyComparison?: AnatomyBodyComparison;
  stageIndicators?: AnatomyStageIndicators;
}

export const AnatomyViewport = memo(function AnatomyViewport({
  onOpenExerciseLibrary,
  bodyComparison,
  stageIndicators,
}: AnatomyViewportProps) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const controllerRef = useRef<AnatomyRendererController | null>(null);

  const selectedMuscleId = useAnatomyStore((s) => s.selectedMuscleId);
  const selectedMuscleSide = useAnatomyStore((s) => s.selectedMuscleSide);
  const cameraView = useAnatomyStore((s) => s.cameraView);
  const focusRegion = useAnatomyStore((s) => s.focusRegion);
  const layerMode = useAnatomyStore((s) => s.layerMode);
  const zoomScale = useAnatomyStore((s) => s.zoomScale);
  const workoutHighlights = useAnatomyStore((s) => s.workoutHighlights);
  const hologramMode = useAnatomyStore((s) => s.hologramMode);
  const dualBody = useAnatomyStore((s) => s.dualBody);
  const comparisonMode = useAnatomyStore((s) => s.comparisonMode);
  const webglStatus = useAnatomyStore((s) => s.webglStatus);
  const setCameraView = useAnatomyStore((s) => s.setCameraView);
  const setFocusRegion = useAnatomyStore((s) => s.setFocusRegion);
  const setSelectedMuscle = useAnatomyStore((s) => s.setSelectedMuscle);
  const setDualBody = useAnatomyStore((s) => s.setDualBody);
  const setComparisonMode = useAnatomyStore((s) => s.setComparisonMode);
  const setWebglStatus = useAnatomyStore((s) => s.setWebglStatus);

  const selectedMuscle = useMemo(
    () => MUSCLE_LIST.find((muscle) => muscle.id === selectedMuscleId) ?? null,
    [selectedMuscleId],
  );

  const selectedSubstructures = useMemo(
    () => (selectedMuscle ? getAnatomicalSubstructuresForGroup(selectedMuscle.id) : []),
    [selectedMuscle],
  );

  useEffect(() => {
    if (!bodyComparison) return;
    const derived = deriveDualBodyInput({
      sex: bodyComparison.sex,
      goal: bodyComparison.goal === 'maintain' ||
        bodyComparison.goal === 'lose_weight' ||
        bodyComparison.goal === 'recomposition' ||
        bodyComparison.goal === 'gain_muscle'
        ? bodyComparison.goal
        : 'gain_muscle',
      currentWeightKg: bodyComparison.currentWeightKg,
      targetWeightKg: bodyComparison.targetWeightKg,
      heightCm: bodyComparison.heightCm,
      waistCm: bodyComparison.waistCm,
      bodyFatPercent: bodyComparison.bodyFatPercent,
      profileConfigured: bodyComparison.profileConfigured,
      hasObservedMeasurements: bodyComparison.hasObservedMeasurements,
    });
    setDualBody(derived);
  }, [
    bodyComparison,
    setDualBody,
  ]);

  useEffect(() => {
    let cancelled = false;
    let controller: AnatomyRendererController | null = null;

    const initializeRenderer = async () => {
      try {
        const module = await import('../engine/renderer/anatomy-renderer');
        const element = mountRef.current;
        if (cancelled || !element) return;

        controller = new module.AnatomyRendererController(element, {
          onStatusChange: setWebglStatus,
          onMusclePick: (muscleId, side) => setSelectedMuscle(muscleId, side),
        });
        controllerRef.current = controller;
        const state = useAnatomyStore.getState();
        controller.syncVisualState({
          selectedMuscleId: state.selectedMuscleId,
          selectedMuscleSide: state.selectedMuscleSide,
          workoutHighlights: state.workoutHighlights,
          cameraView: state.cameraView,
          focusRegion: state.focusRegion,
          layerMode: state.layerMode === 'skeleton' ? 'complete' : state.layerMode,
          zoomScale: state.zoomScale,
          hologramMode: state.hologramMode,
          dualBody: state.dualBody,
          comparisonMode: state.comparisonMode,
        });
        controller.mount();
      } catch {
        // A failure after controller construction must also release observers,
        // canvases and GPU resources before the 2D fallback becomes active.
        try {
          controller?.dispose();
        } catch {
          // Preserve the user-facing fallback even if a renderer cleanup fails.
        }
        if (controllerRef.current === controller) controllerRef.current = null;
        if (!cancelled) setWebglStatus('fallback');
      }
    };

    void initializeRenderer();

    return () => {
      cancelled = true;
      try {
        controller?.dispose();
      } finally {
        if (controllerRef.current === controller) controllerRef.current = null;
      }
    };
  }, [setSelectedMuscle, setWebglStatus]);

  useEffect(() => {
    controllerRef.current?.syncVisualState({
      selectedMuscleId,
      selectedMuscleSide,
      workoutHighlights,
      cameraView,
      focusRegion,
      layerMode: layerMode === 'skeleton' ? 'complete' : layerMode,
      zoomScale,
      hologramMode,
      dualBody,
      comparisonMode,
    });
  }, [
    selectedMuscleId,
    selectedMuscleSide,
    cameraView,
    focusRegion,
    layerMode,
    zoomScale,
    workoutHighlights,
    hologramMode,
    dualBody,
    comparisonMode,
  ]);

  const selectMuscle = (muscleId: (typeof MUSCLE_LIST)[number]['id']) => {
    const muscle = MUSCLE_LIST.find((entry) => entry.id === muscleId);
    if (!muscle) return;
    setCameraView(muscle.preferredView);
    setFocusRegion(muscle.zone);
    setSelectedMuscle(muscle.id, 'center');
  };

  return (
    <section aria-label="Modelo anatômico 3D" className="titan-anatomy-section space-y-2.5">
      <div className="relative w-full">
        {stageIndicators && (
          <aside
            aria-label="Indicadores de evolução corporal"
            className="pointer-events-none select-none absolute top-2 left-1 sm:top-3.5 sm:left-2 z-10 drop-shadow-[0_1px_6px_rgba(0,0,0,0.82)]"
          >
            <div
              aria-label={stageIndicators.ariaLabel}
              className={`inline-flex items-center gap-1.5 font-mono-metric text-sm sm:text-base font-semibold leading-none ${
                stageIndicators.direction === 'flat'
                  ? 'text-[var(--titan-text-secondary)]'
                  : stageIndicators.isAlignedWithGoal
                  ? 'text-[var(--titan-status-success)]'
                  : 'text-[var(--titan-status-error)]'
              }`}
            >
              {stageIndicators.direction === 'up' ? (
                <ArrowUp className="w-4 h-4 shrink-0" aria-hidden="true" />
              ) : stageIndicators.direction === 'down' ? (
                <ArrowDown className="w-4 h-4 shrink-0" aria-hidden="true" />
              ) : (
                <Minus className="w-4 h-4 shrink-0" aria-hidden="true" />
              )}
              <span>{stageIndicators.weeklyRateFormatted}</span>
            </div>
          </aside>
        )}

        <div
          ref={mountRef}
          className="titan-anatomy-stage select-none"
          role="img"
          aria-label="Modelo anatômico tridimensional duplo interativo exibindo físico atual e meta sobrepostos. Arraste para girar e toque em uma região muscular para selecioná-la."
        />
      </div>

      <div className="flex flex-col items-center gap-2 pt-0.5">
        <div className="w-full flex flex-wrap items-center justify-center gap-1.5 sm:gap-2">
          <div className="titan-segmented" role="group" aria-label="Vista anatômica">
            {VIEW_OPTIONS.map((view) => (
              <button
                key={view.id}
                type="button"
                className="titan-segment"
                aria-pressed={cameraView === view.id}
                onClick={() => setCameraView(view.id)}
              >
                {view.label}
              </button>
            ))}
          </div>

          <div className="titan-segmented" role="group" aria-label="Modo de comparação corporal">
            {COMPARISON_OPTIONS.map((mode) => (
              <button
                key={mode.id}
                type="button"
                className="titan-segment"
                aria-pressed={comparisonMode === mode.id}
                onClick={() => setComparisonMode(mode.id)}
              >
                {mode.label}
              </button>
            ))}
          </div>
        </div>

        <div
          className="flex flex-wrap items-center justify-center gap-x-3 sm:gap-x-4 gap-y-1 text-[11px] text-[var(--titan-text-muted)]"
          aria-label="Legenda de identidade corporal e destaque muscular"
        >
          <span className="inline-flex items-center gap-1.5">
            <span className="inline-block h-[3px] w-3 rounded-full bg-[#32F7EF]" aria-hidden="true" />
            <span>Atual</span>
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="inline-block h-[3px] w-3 rounded-full bg-[#C47BFF]" aria-hidden="true" />
            <span>Meta</span>
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="inline-block h-[3px] w-3 rounded-full bg-[#FB7144]" aria-hidden="true" />
            <span>Primário</span>
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="inline-block h-[3px] w-3 rounded-full bg-[#FBBF24]" aria-hidden="true" />
            <span>Secundário</span>
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="inline-block h-[3px] w-3 rounded-full bg-[#FFF3D6]" aria-hidden="true" />
            <span>Selecionado</span>
          </span>
        </div>

      </div>

      <AnimatePresence mode="wait">
        {selectedMuscle && (
          <motion.div
            key={selectedMuscle.id}
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: TITAN_DURATIONS.quick, ease: TITAN_EASE }}
            className="titan-anatomy-selected w-full"
            aria-live="polite"
          >
            <div className="min-w-0">
              <p className="titan-anatomy-muscle-name">{selectedMuscle.label}</p>
              <p className="titan-anatomy-muscle-latin">{selectedMuscle.latinName}</p>
              <p className="titan-anatomy-muscle-function">{selectedMuscle.functionSummary}</p>
              {selectedSubstructures.length > 0 && (
                <p className="text-[11px] text-[var(--titan-text-muted)] mt-1">
                  Estruturas: {selectedSubstructures.map((s) => s.label).join(' · ')}
                </p>
              )}
            </div>
            <div className="flex flex-wrap items-center gap-2 shrink-0">
              {onOpenExerciseLibrary && (
                <button
                  type="button"
                  onClick={() => onOpenExerciseLibrary(selectedMuscle.id)}
                  className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg px-3 text-xs font-semibold text-[var(--titan-accent)] hover:bg-[var(--titan-surface-raised)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-focus)]/70"
                >
                  <Dumbbell size={13} aria-hidden="true" />
                  <span>Exercícios</span>
                </button>
              )}
              <button
                type="button"
                onClick={() => setSelectedMuscle(null)}
                className="min-h-[40px] shrink-0 rounded-lg px-3 text-xs font-medium text-[var(--titan-text-muted)] hover:text-[var(--titan-text-primary)]"
              >
                Limpar
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {webglStatus === 'fallback' && (
        <div className="w-full space-y-2 pt-1">
          <p className="text-xs text-[var(--titan-text-muted)] text-center" role="status">
            Visualização 3D indisponível neste dispositivo. Selecione um grupo muscular:
          </p>
          <div className="titan-anatomy-list" aria-label="Lista acessível de grupos musculares">
            {MUSCLE_LIST.map((muscle) => (
              <button
                key={muscle.id}
                type="button"
                className="titan-anatomy-list-item"
                aria-pressed={selectedMuscleId === muscle.id}
                onClick={() => selectMuscle(muscle.id)}
              >
                {muscle.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </section>
  );
});

