export type EnergySourceKind =
  | 'equation_prediction'
  | 'indirect_calorimetry'
  | 'adaptive_kalman'
  | 'wearable_total_day'
  | 'wearable_active'
  | 'compendium_met'
  | 'openmetabolics_native'
  | 'component_composite';

export type EnergyTimeWindow = 'daily' | 'session' | 'instantaneous';

export type EnergyKind =
  | 'active_net'
  | 'gross'
  | 'total_day_estimate'
  | 'resting';

export type EnergyComponentId = 'rmr' | 'tef' | 'neat' | 'exercise_net';

export type EnergyMeasurementStatus =
  | 'measured'
  | 'estimated'
  | 'adaptive_inferred'
  | 'provider_required';

export type EnergyConfidenceLevel = 'high' | 'moderate' | 'low';

export interface EnergyProvenance {
  label: string;
  populationScope: string;
  citation?: string;
  limitations: string[];
}

export interface EnergySourceRecord {
  sourceKind: EnergySourceKind;
  methodId: string;
  sourceVersion: string;
  timeWindow: EnergyTimeWindow;
  energyKind: EnergyKind;
  componentsIncluded: readonly EnergyComponentId[];
  measurementStatus: EnergyMeasurementStatus;
  confidence: EnergyConfidenceLevel;
  unit: 'kcal/day' | 'kcal';
  kcal: number;
  uncertaintyKcal?: number;
  provenance: EnergyProvenance;
}

export type ExerciseEnergyAccountingStatus = 'already_included' | 'added_once' | 'not_reported';

export interface ComponentAwareEnergyBudgetResult {
  mode: 'total_day' | 'component_sum';
  restingMetabolicRateKcal: number;
  baseExpenditureKcal: number;
  totalDailyExpenditureKcal: number;
  nonRestingResidualKcal: number;
  exerciseNetKcal: number | null;
  exerciseAdditionalKcal: number;
  exerciseAccounting: ExerciseEnergyAccountingStatus;
  goalAdjustmentKcal: number;
  targetIntakeKcal: number;
  componentsIncluded: readonly EnergyComponentId[];
  warnings: string[];
}

export type ComponentAwareEnergyBudgetInput =
  | {
      mode: 'total_day';
      totalDayRecord: EnergySourceRecord;
      rmrRecord: EnergySourceRecord;
      exerciseNetRecord?: EnergySourceRecord | null;
      goalAdjustmentKcal: number;
    }
  | {
      mode: 'component_sum';
      rmrRecord: EnergySourceRecord;
      neatKcal: number;
      tefKcal: number;
      exerciseNetRecord?: EnergySourceRecord | null;
      goalAdjustmentKcal: number;
    };

function assertFiniteValue(value: number, label: string): void {
  if (!Number.isFinite(value)) {
    throw new RangeError(`${label} precisa ser um número finito.`);
  }
}

export function buildRmrEnergyRecord(input: {
  kcalPerDay: number;
  method: string;
  population: string;
  isMeasured: boolean;
}): EnergySourceRecord {
  assertFiniteValue(input.kcalPerDay, 'RMR');
  return {
    sourceKind: input.isMeasured ? 'indirect_calorimetry' : 'equation_prediction',
    methodId: input.method,
    sourceVersion: '1.0',
    timeWindow: 'daily',
    energyKind: 'resting',
    componentsIncluded: ['rmr'],
    measurementStatus: input.isMeasured ? 'measured' : 'estimated',
    confidence: input.isMeasured ? 'high' : 'moderate',
    unit: 'kcal/day',
    kcal: Math.round(input.kcalPerDay),
    provenance: {
      label: input.isMeasured ? 'Calorimetria indireta informada' : `Equação RMR (${input.method})`,
      populationScope: input.population,
      limitations: input.isMeasured
        ? ['Depende de protocolo, jejum e calibração do laudo']
        : ['Estimativa populacional; não substitui calorimetria indireta'],
    },
  };
}

export function buildNasemEerEnergyRecord(input: {
  kcalPerDay: number;
  activityCategory: 'inactive' | 'low_active' | 'active' | 'very_active';
  age: number;
}): EnergySourceRecord {
  assertFiniteValue(input.kcalPerDay, 'NASEM EER');
  return {
    sourceKind: 'equation_prediction',
    methodId: 'NASEM_2023_TABLE_S3',
    sourceVersion: '2023',
    timeWindow: 'daily',
    energyKind: 'total_day_estimate',
    componentsIncluded: ['rmr', 'tef', 'neat', 'exercise_net'],
    measurementStatus: 'estimated',
    confidence: 'moderate',
    unit: 'kcal/day',
    kcal: Math.round(input.kcalPerDay),
    provenance: {
      label: `NASEM 2023 EER (${input.activityCategory})`,
      populationScope: `Adultos >= 19 anos (idade informada: ${input.age})`,
      citation: 'NASEM 2023 Table S-3',
      limitations: [
        'Base de dia inteiro que já inclui atividade habitual; nunca somar treino novamente.',
        'Categoria PAL é um proxy populacional.',
      ],
    },
  };
}

export function buildAdaptiveTdeeEnergyRecord(input: {
  estimateKcal: number;
  uncertaintyKcal: number;
  confidence: 'low' | 'moderate' | 'higher';
}): EnergySourceRecord {
  assertFiniteValue(input.estimateKcal, 'TDEE adaptativo');
  return {
    sourceKind: 'adaptive_kalman',
    methodId: 'observed_adaptive_v1',
    sourceVersion: 'v2_hall_density',
    timeWindow: 'daily',
    energyKind: 'total_day_estimate',
    componentsIncluded: ['rmr', 'tef', 'neat', 'exercise_net'],
    measurementStatus: 'adaptive_inferred',
    confidence: input.confidence === 'higher' ? 'high' : input.confidence,
    unit: 'kcal/day',
    kcal: Math.round(input.estimateKcal),
    uncertaintyKcal: Math.round(input.uncertaintyKcal),
    provenance: {
      label: 'TDEE adaptativo observado (Kalman + tendência de peso)',
      populationScope: 'Individual longitudinal (ingestão + peso)',
      limitations: [
        'Inclui gasto total observado (RMR + TEF + NEAT + exercício); não somar exercício novamente.',
        'Intervalo reflete variância interna do filtro e depende da acurácia dos registros alimentares.',
      ],
    },
  };
}

export function resolveComponentAwareEnergyBudget(
  input: ComponentAwareEnergyBudgetInput,
): ComponentAwareEnergyBudgetResult {
  assertFiniteValue(input.goalAdjustmentKcal, 'Ajuste calórico do objetivo');
  assertFiniteValue(input.rmrRecord.kcal, 'RMR');
  if (input.rmrRecord.kcal <= 0 || input.rmrRecord.energyKind !== 'resting') {
    throw new RangeError('Registro de RMR inválido para o orçamento energético.');
  }
  const warnings: string[] = [];

  if (input.exerciseNetRecord) {
    assertFiniteValue(input.exerciseNetRecord.kcal, 'Exercício líquido');
    if (input.exerciseNetRecord.kcal < 0) {
      throw new RangeError('Energia líquida de exercício não pode ser negativa.');
    }
    if (input.exerciseNetRecord.energyKind !== 'active_net') {
      throw new RangeError(
        'Energia gross/total de treino não é aditiva: converter para active_net antes de usar no orçamento para evitar dupla contagem.',
      );
    }
  }

  if (input.mode === 'total_day') {
    const { totalDayRecord, rmrRecord, exerciseNetRecord } = input;
    assertFiniteValue(totalDayRecord.kcal, 'TDEE total');
    if (totalDayRecord.kcal <= 0 || totalDayRecord.energyKind !== 'total_day_estimate') {
      throw new RangeError('Modo total_day exige energyKind = total_day_estimate positivo.');
    }
    if (totalDayRecord.kcal + 0.5 < rmrRecord.kcal) {
      throw new RangeError('O TDEE total não pode ser menor que o RMR.');
    }
    const exerciseNetKcal = exerciseNetRecord ? Math.round(exerciseNetRecord.kcal) : null;
    if (exerciseNetRecord) {
      warnings.push(
        `Fonte ${totalDayRecord.methodId} já representa o dia completo (${totalDayRecord.componentsIncluded.join(' + ')}); ${Math.round(exerciseNetRecord.kcal)} kcal líquidas de exercício não foram somadas novamente.`,
      );
    }
    const totalDailyExpenditureKcal = Math.round(totalDayRecord.kcal);
    const targetIntakeKcal = Math.round(totalDailyExpenditureKcal + input.goalAdjustmentKcal);
    if (targetIntakeKcal <= 0) {
      throw new RangeError('A meta de ingestão precisa ser positiva.');
    }
    return {
      mode: 'total_day',
      restingMetabolicRateKcal: Math.round(rmrRecord.kcal),
      baseExpenditureKcal: totalDailyExpenditureKcal,
      totalDailyExpenditureKcal,
      nonRestingResidualKcal: Math.max(0, Math.round(totalDailyExpenditureKcal - rmrRecord.kcal)),
      exerciseNetKcal,
      exerciseAdditionalKcal: 0,
      exerciseAccounting: exerciseNetKcal === null ? 'not_reported' : 'already_included',
      goalAdjustmentKcal: Math.round(input.goalAdjustmentKcal),
      targetIntakeKcal,
      componentsIncluded: totalDayRecord.componentsIncluded,
      warnings,
    };
  }

  assertFiniteValue(input.neatKcal, 'NEAT');
  assertFiniteValue(input.tefKcal, 'TEF');
  if (input.neatKcal < 0 || input.tefKcal < 0) {
    throw new RangeError('NEAT e TEF não podem ser negativos.');
  }

  const baseExcludingExercise = input.rmrRecord.kcal + input.neatKcal + input.tefKcal;
  const exerciseNetKcal = input.exerciseNetRecord ? Math.round(input.exerciseNetRecord.kcal) : 0;
  const totalDailyExpenditureKcal = Math.round(baseExcludingExercise + exerciseNetKcal);
  const targetIntakeKcal = Math.round(totalDailyExpenditureKcal + input.goalAdjustmentKcal);
  if (targetIntakeKcal <= 0) {
    throw new RangeError('A meta de ingestão precisa ser positiva.');
  }

  const componentsIncluded: EnergyComponentId[] = input.exerciseNetRecord
    ? ['rmr', 'tef', 'neat', 'exercise_net']
    : ['rmr', 'tef', 'neat'];

  return {
    mode: 'component_sum',
    restingMetabolicRateKcal: Math.round(input.rmrRecord.kcal),
    baseExpenditureKcal: Math.round(baseExcludingExercise),
    totalDailyExpenditureKcal,
    nonRestingResidualKcal: Math.max(0, Math.round(totalDailyExpenditureKcal - input.rmrRecord.kcal)),
    exerciseNetKcal: input.exerciseNetRecord ? exerciseNetKcal : null,
    exerciseAdditionalKcal: exerciseNetKcal,
    exerciseAccounting: input.exerciseNetRecord ? 'added_once' : 'not_reported',
    goalAdjustmentKcal: Math.round(input.goalAdjustmentKcal),
    targetIntakeKcal,
    componentsIncluded,
    warnings,
  };
}
