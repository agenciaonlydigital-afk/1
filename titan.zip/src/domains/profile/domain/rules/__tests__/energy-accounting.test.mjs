import assert from 'node:assert/strict';
import {
  buildAdaptiveTdeeEnergyRecord,
  buildNasemEerEnergyRecord,
  buildRmrEnergyRecord,
  resolveComponentAwareEnergyBudget,
} from '../../entities/energy-accounting.ts';
import { resolveDailyEnergyBudget } from '../energy-budget.ts';
import { calculatePhysiologicalGoalTargets } from '../goal-calculator.ts';
import { estimateActivityEnergy } from '../../../../activity/domain/rules/activity-energy.ts';
import { integrateOpenMetabolicsPower } from '../../../../activity/domain/rules/openmetabolics-bridge.ts';

// 1. NASEM EER total-day record explicitly declares all 4 components -> zero double counting
const rmrRecord = buildRmrEnergyRecord({
  kcalPerDay: 1750,
  method: 'mifflin_st_jeor',
  population: 'Adultos 18-78',
  isMeasured: false,
});
assert.deepEqual(rmrRecord.componentsIncluded, ['rmr']);
assert.equal(rmrRecord.energyKind, 'resting');

const nasemRecord = buildNasemEerEnergyRecord({
  kcalPerDay: 2550,
  activityCategory: 'active',
  age: 29,
});
assert.equal(nasemRecord.energyKind, 'total_day_estimate');
assert.deepEqual(nasemRecord.componentsIncluded, ['rmr', 'tef', 'neat', 'exercise_net']);

const totalDayBudget = resolveComponentAwareEnergyBudget({
  mode: 'total_day',
  totalDayRecord: nasemRecord,
  rmrRecord,
  exerciseNetRecord: {
    sourceKind: 'wearable_active',
    methodId: 'health_connect_active',
    sourceVersion: '1.0',
    timeWindow: 'session',
    energyKind: 'active_net',
    componentsIncluded: ['exercise_net'],
    measurementStatus: 'measured',
    confidence: 'moderate',
    unit: 'kcal',
    kcal: 420,
    provenance: { label: 'Wearable active calories', populationScope: 'individual_session', limitations: [] },
  },
  goalAdjustmentKcal: -300,
});
assert.equal(totalDayBudget.totalDailyExpenditureKcal, 2550, 'total_day_estimate must never add wearable exercise again');
assert.equal(totalDayBudget.exerciseAdditionalKcal, 0);
assert.equal(totalDayBudget.exerciseAccounting, 'already_included');
assert.equal(totalDayBudget.targetIntakeKcal, 2250);

// 2. Reject gross energy mistakenly passed as additive exercise_net
assert.throws(
  () =>
    resolveComponentAwareEnergyBudget({
      mode: 'component_sum',
      rmrRecord,
      neatKcal: 400,
      tefKcal: 220,
      exerciseNetRecord: {
        sourceKind: 'compendium_met',
        methodId: 'gross_met',
        sourceVersion: '2024',
        timeWindow: 'session',
        energyKind: 'gross',
        componentsIncluded: ['rmr', 'exercise_net'],
        measurementStatus: 'estimated',
        confidence: 'low',
        unit: 'kcal',
        kcal: 450,
        provenance: { label: 'MET gross', populationScope: 'adult_19_59', limitations: [] },
      },
      goalAdjustmentKcal: 0,
    }),
  /gross|active_net|dupla contagem/i,
);

// 3. Valid explicit component_sum adds RMR + TEF + NEAT + net exercise cleanly
const componentBudget = resolveComponentAwareEnergyBudget({
  mode: 'component_sum',
  rmrRecord,
  neatKcal: 380,
  tefKcal: 210,
  exerciseNetRecord: {
    sourceKind: 'compendium_met',
    methodId: 'standard_met_net',
    sourceVersion: '2024',
    timeWindow: 'session',
    energyKind: 'active_net',
    componentsIncluded: ['exercise_net'],
    measurementStatus: 'estimated',
    confidence: 'moderate',
    unit: 'kcal',
    kcal: 360,
    provenance: { label: 'Corrida leve (MET líquido)', populationScope: 'adult_19_59', limitations: [] },
  },
  goalAdjustmentKcal: 200,
});
assert.equal(componentBudget.totalDailyExpenditureKcal, 1750 + 380 + 210 + 360);
assert.equal(componentBudget.exerciseAdditionalKcal, 360);
assert.equal(componentBudget.exerciseAccounting, 'added_once');
assert.equal(componentBudget.targetIntakeKcal, 2900);

// 4. Adaptive TDEE record carries adaptive uncertainty and excludes double-counted workout
const adaptiveRecord = buildAdaptiveTdeeEnergyRecord({
  estimateKcal: 2480,
  uncertaintyKcal: 180,
  confidence: 'higher',
});
assert.equal(adaptiveRecord.energyKind, 'total_day_estimate');
assert.equal(adaptiveRecord.measurementStatus, 'adaptive_inferred');
assert.deepEqual(adaptiveRecord.componentsIncluded, ['rmr', 'tef', 'neat', 'exercise_net']);

// 5. Goal calculator integrates structured energyAccounting contract without breaking existing fields
const targets = calculatePhysiologicalGoalTargets(
  {
    sex: 'male',
    goal: 'maintain',
    currentWeightKg: 78,
    targetWeightKg: 78,
    activityLevel: 'moderate',
    deadlineDateKey: '2027-02-01',
    heightCm: 178,
    age: 30,
  },
  '2026-11-26',
  null,
  { exerciseNetKcal: 400 },
);
assert.equal(targets.energyBudget.exerciseAdditionalKcal, 0);
assert.equal(targets.energyBudget.totalDailyExpenditureKcal, targets.tdee);
assert.ok(targets.energyAccounting, 'goal targets must expose structured energyAccounting metadata');
assert.equal(targets.energyAccounting.tdeeRecord.energyKind, 'total_day_estimate');
assert.ok(targets.energyAccounting.macroWeightingRationale.length > 20);

// 6. Legacy resolveDailyEnergyBudget continues rejecting invalid component sums
const directLegacy = resolveDailyEnergyBudget({
  restingMetabolicRateKcal: 1700,
  baseExpenditureKcal: 2400,
  basis: 'total_includes_exercise',
  exerciseNetKcal: 350,
  goalAdjustmentKcal: 0,
});
assert.equal(directLegacy.totalDailyExpenditureKcal, 2400);

// 7. Activity energy flags anaerobic/resistance MET limitations + 19-59 scope
const resistanceEst = estimateActivityEnergy({
  met: 6,
  weightKg: 80,
  durationMinutes: 60,
  activityCategory: 'resistance_training',
  age: 64,
});
assert.ok(
  resistanceEst.warnings.some((w) => /19–59|19-59/.test(w)),
  'must warn explicitly when outside 19-59 Adult Compendium range',
);
assert.ok(
  resistanceEst.warnings.some((w) => /resistido|musculação|anaerób/i.test(w)),
  'must warn explicitly about anaerobic/resistance MET uncertainty',
);

// 8. OpenMetabolics bridge explicitly reports provider_required native parity requirement
const omEst = integrateOpenMetabolicsPower({
  modelId: 'openmetabolics_xgboost',
  modelVersion: '1.0',
  modelArtifactSha256: 'a'.repeat(64),
  placement: 'front_pocket',
  sensorSamplingHz: 50,
  sensorCoveragePercent: 98,
  durationSeconds: 60,
  modelBaselinePowerW: 90,
  samples: Array.from({ length: 13 }, (_, idx) => ({
    timestampMs: idx * 5_000,
    estimatedPowerW: 320,
  })),
});
assert.equal(omEst.nativeRuntimeStatus, 'provider_required');

console.log('energy-accounting.test.mjs PASS');
