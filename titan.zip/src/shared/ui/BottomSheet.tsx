import { useCallback, useEffect, useId, useLayoutEffect, useRef, useState, type PointerEvent as ReactPointerEvent, type ReactNode } from 'react';
import { Drawer } from 'vaul';
import { X } from 'lucide-react';
import { useEscapeKey } from '../hooks/use-escape-key';
import {
  getSharedFluidEngine,
  interpolateRatio,
  prefersReducedMotion,
  type FluidDrawJob,
} from '../graphics/fluid-shader-engine';
import {
  extractCoalescedSamples,
  KalmanTouchPredictor,
} from '../motion/titan-motion';

const MAX_SHEET_RIPPLES = 4;

function LiquidGlassSheetOverlay({
  hostRef,
  open,
  tiltRef,
  targetTiltRef,
  pointerRef,
  ripplesRef,
  solitonRef,
}: {
  hostRef: { current: HTMLDivElement | null };
  open: boolean;
  tiltRef: { current: [number, number] };
  targetTiltRef: { current: [number, number] };
  pointerRef: { current: [number, number, number, number] };
  ripplesRef: { current: Float32Array };
  solitonRef: { current: [number, number, number, number] };
}) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const sizeRef = useRef({ w: 360, h: 420 });
  const lastStepAtRef = useRef(0);
  const providerRef = useRef<(() => FluidDrawJob | null) | null>(null);

  useEffect(() => {
    if (!open) return;
    const host = hostRef.current;
    const canvas = canvasRef.current;
    if (!host || !canvas) return;
    const engine = getSharedFluidEngine();

    sizeRef.current = {
      w: Math.max(200, host.clientWidth),
      h: Math.max(160, host.clientHeight),
    };

    const clearOnFallback = () => {
      const ctx = canvas.getContext('2d');
      if (ctx) ctx.clearRect(0, 0, canvas.width, canvas.height);
    };
    window.addEventListener('fluid-engine-fallback', clearOnFallback);

    const provider = (): FluidDrawJob | null => {
      if (prefersReducedMotion()) {
        ripplesRef.current.fill(0);
        solitonRef.current[2] = 0;
        solitonRef.current[3] = 0;
        lastStepAtRef.current = 0;
        return {
          kind: 'liquid-glass',
          targetCanvas: canvas,
          width: sizeRef.current.w,
          height: sizeRef.current.h,
          fill: 0,
          isAnimating: false,
          cardPointer: [0.5, 0.5, 0, 0],
          cardRipples: ripplesRef.current,
          soliton: solitonRef.current,
          tilt: [0, 0],
          isVisible: open,
        };
      }
      const now = performance.now();
      const dt = lastStepAtRef.current
        ? Math.min(0.033, Math.max(0.002, (now - lastStepAtRef.current) / 1000))
        : 1 / 60;
      lastStepAtRef.current = now;

      const tx = interpolateRatio(tiltRef.current[0], targetTiltRef.current[0], dt, 0.11);
      const ty = interpolateRatio(tiltRef.current[1], targetTiltRef.current[1], dt, 0.11);
      tiltRef.current[0] = tx;
      tiltRef.current[1] = ty;
      const isTilting =
        Math.abs(targetTiltRef.current[0] - tx) > 0.001 ||
        Math.abs(targetTiltRef.current[1] - ty) > 0.001;

      let hasActiveRipple = false;
      const ripples = ripplesRef.current;
      for (let i = 0; i < MAX_SHEET_RIPPLES; i++) {
        const ageIdx = i * 4 + 2;
        const strIdx = i * 4 + 3;
        const str = ripples[strIdx] ?? 0;
        const age = ripples[ageIdx] ?? 0;
        if (str > 0.001) {
          const nextAge = age + dt;
          if (nextAge > 1.75) {
            ripples[strIdx] = 0;
            ripples[ageIdx] = 0;
          } else {
            ripples[ageIdx] = nextAge;
            hasActiveRipple = true;
          }
        }
      }

      let hasActiveSoliton = false;
      const sol = solitonRef.current;
      if (sol[3] > 0.001) {
        const nextAge = sol[2] + dt;
        if (nextAge > 1.85) {
          sol[2] = 0;
          sol[3] = 0;
        } else {
          sol[2] = nextAge;
          hasActiveSoliton = true;
        }
      }

      return {
        kind: 'liquid-glass',
        targetCanvas: canvas,
        width: sizeRef.current.w,
        height: sizeRef.current.h,
        fill: 0,
        isAnimating: open && (hasActiveRipple || hasActiveSoliton || isTilting || pointerRef.current[2] > 0.5),
        cardPointer: pointerRef.current,
        cardRipples: ripples,
        soliton: sol,
        tilt: tiltRef.current,
        isVisible: open,
      };
    };
    providerRef.current = provider;

    const ro =
      typeof ResizeObserver !== 'undefined'
        ? new ResizeObserver(() => {
            sizeRef.current = {
              w: Math.max(200, host.clientWidth),
              h: Math.max(160, host.clientHeight),
            };
            engine.renderSinglePass(provider);
          })
        : null;
    ro?.observe(host);

    engine.renderSinglePass(provider);
    const unsubscribe = engine.subscribe(provider, true);
    if (!prefersReducedMotion() && solitonRef.current[3] > 0.001) {
      engine.wake();
    }
    return () => {
      providerRef.current = null;
      unsubscribe();
      ro?.disconnect();
      window.removeEventListener('fluid-engine-fallback', clearOnFallback);
    };
  }, [hostRef, open, tiltRef, targetTiltRef, pointerRef, ripplesRef, solitonRef]);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className="pointer-events-none absolute inset-0 z-[1] block w-full h-full rounded-[inherit]"
    />
  );
}

export interface SheetOriginRect {
  left: number;
  top: number;
  width: number;
  height: number;
}

interface BottomSheetProps {
  open: boolean;
  onClose: () => void;
  title: string;
  eyebrow?: string;
  subtitle?: string;
  animateOpen?: boolean;
  variant?: 'default' | 'liquid-glass';
  originRect?: SheetOriginRect | null;
  footer?: ReactNode;
  children: ReactNode;
}

const FOCUSABLE_SELECTOR = [
  'a[href]',
  'area[href]',
  'button:not([disabled])',
  'input:not([disabled]):not([type="hidden"])',
  'select:not([disabled])',
  'textarea:not([disabled])',
  '[tabindex]:not([tabindex="-1"])',
].join(',');

let activeModalCount = 0;
let previousBodyOverflow = '';

function lockBodyScroll(): () => void {
  if (activeModalCount === 0) {
    previousBodyOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
  }
  activeModalCount += 1;
  return () => {
    activeModalCount = Math.max(0, activeModalCount - 1);
    if (activeModalCount === 0) {
      document.body.style.overflow = previousBodyOverflow;
      previousBodyOverflow = '';
    }
  };
}

export function BottomSheet({
  open,
  onClose,
  title,
  eyebrow,
  subtitle,
  animateOpen = true,
  variant = 'default',
  originRect = null,
  footer,
  children,
}: BottomSheetProps) {
  const titleId = useId();
  const subtitleId = useId();
  const panelRef = useRef<HTMLDivElement | null>(null);
  const innerMorphRef = useRef<HTMLDivElement | null>(null);
  const backdropRef = useRef<HTMLDivElement | null>(null);
  const morphVesselRef = useRef<HTMLDivElement | null>(null);
  const [panelEl, setPanelEl] = useState<HTMLDivElement | null>(null);
  const glassTiltRef = useRef<[number, number]>([0, 0]);
  const glassTargetTiltRef = useRef<[number, number]>([0, 0]);
  const glassPointerRef = useRef<[number, number, number, number]>([0.5, 0.25, 0, 0]);
  const glassKalmanRef = useRef(new KalmanTouchPredictor());
  const glassRipplesRef = useRef<Float32Array>(new Float32Array(MAX_SHEET_RIPPLES * 4));
  const glassSolitonRef = useRef<[number, number, number, number]>([0.5, 0.96, 0, 0]);
  const nextRippleIdxRef = useRef(0);
  useEscapeKey(open, onClose);
  const isLiquidGlass = variant === 'liquid-glass';
  const hasSharedOrigin = Boolean(originRect) && isLiquidGlass && animateOpen;

  useLayoutEffect(() => {
    if (!open || !isLiquidGlass) {
      if (!open) glassKalmanRef.current.reset();
      return;
    }
    const reduced = prefersReducedMotion();
    const panel = panelEl ?? panelRef.current;
    const inner = innerMorphRef.current;
    const backdrop = backdropRef.current;
    const vessel = morphVesselRef.current;

    if (reduced) {
      if (vessel) vessel.style.display = 'none';
      return;
    }

    const animations: Animation[] = [];

    if (
      hasSharedOrigin &&
      originRect &&
      panel &&
      panel.clientWidth > 0 &&
      panel.clientHeight > 0 &&
      typeof panel.animate === 'function'
    ) {
      const panelRect = panel.getBoundingClientRect();
      const originCx = originRect.left + originRect.width * 0.5;
      const originCy = originRect.top + originRect.height * 0.5;
      const panelCx = panelRect.left + panelRect.width * 0.5;
      const panelCy = panelRect.top + panelRect.height * 0.5;

      const dx = originCx - panelCx;
      const dy = originCy - panelCy;
      const targetScaleX = Math.max(1.2, panelRect.width / Math.max(1, originRect.width));
      const targetScaleY = Math.max(1.2, panelRect.height / Math.max(1, originRect.height));

      const normX = Math.max(0.08, Math.min(0.92, (originCx - panelRect.left) / Math.max(1, panelRect.width)));
      const normY = Math.max(0.08, Math.min(0.92, (originCy - panelRect.top) / Math.max(1, panelRect.height)));
      glassTiltRef.current = [(normX - 0.5) * 0.24, (normY - 0.5) * 0.16];
      glassTargetTiltRef.current = [0, 0];
      glassSolitonRef.current = [normX, normY, 0.015, 1.98];

      const primarySlot = nextRippleIdxRef.current % MAX_SHEET_RIPPLES;
      nextRippleIdxRef.current += 1;
      const pOff = primarySlot * 4;
      glassRipplesRef.current[pOff] = normX;
      glassRipplesRef.current[pOff + 1] = normY;
      glassRipplesRef.current[pOff + 2] = 0.015;
      glassRipplesRef.current[pOff + 3] = 1.50;

      const secondarySlot = nextRippleIdxRef.current % MAX_SHEET_RIPPLES;
      nextRippleIdxRef.current += 1;
      const sOff = secondarySlot * 4;
      glassRipplesRef.current[sOff] = 0.5;
      glassRipplesRef.current[sOff + 1] = 0.90;
      glassRipplesRef.current[sOff + 2] = 0.015;
      glassRipplesRef.current[sOff + 3] = 0.92;

      panel.style.setProperty('--glass-px', `${(normX * 100).toFixed(1)}%`);
      panel.style.setProperty('--glass-py', `${(normY * 100).toFixed(1)}%`);

      if (backdrop && typeof backdrop.animate === 'function') {
        animations.push(
          backdrop.animate(
            [
              { opacity: 0, offset: 0 },
              { opacity: 0.22, offset: 0.18 },
              { opacity: 1, offset: 1 },
            ],
            {
              duration: 320,
              easing: 'cubic-bezier(0.22, 1, 0.36, 1)',
              fill: 'none',
            },
          ),
        );
      }

      if (vessel && typeof vessel.animate === 'function') {
        vessel.style.display = 'flex';
        vessel.style.left = `${originRect.left}px`;
        vessel.style.top = `${originRect.top}px`;
        vessel.style.width = `${originRect.width}px`;
        vessel.style.height = `${originRect.height}px`;
        vessel.style.opacity = '1';

        const vesselAnim = vessel.animate(
          [
            {
              opacity: 0.98,
              transform: 'translate3d(0px, 0px, 0) scale3d(1, 1, 1)',
              filter: 'brightness(1.22) saturate(1.25)',
              offset: 0,
            },
            {
              opacity: 0.96,
              transform: `translate3d(${(-dx * 0.44).toFixed(1)}px, ${(-dy * 0.46 - 8).toFixed(1)}px, 0) scale3d(${(1 + (targetScaleX - 1) * 0.38).toFixed(3)}, ${(1 + (targetScaleY - 1) * 0.28).toFixed(3)}, 1)`,
              filter: 'brightness(1.12) saturate(1.14)',
              offset: 0.34,
            },
            {
              opacity: 0.64,
              transform: `translate3d(${(-dx).toFixed(1)}px, ${(-dy).toFixed(1)}px, 0) scale3d(${targetScaleX.toFixed(3)}, ${targetScaleY.toFixed(3)}, 1)`,
              filter: 'brightness(1.04) saturate(1.05)',
              offset: 0.72,
            },
            {
              opacity: 0,
              transform: `translate3d(${(-dx).toFixed(1)}px, ${(-dy).toFixed(1)}px, 0) scale3d(${(targetScaleX * 1.016).toFixed(3)}, ${(targetScaleY * 1.016).toFixed(3)}, 1)`,
              filter: 'brightness(1) saturate(1)',
              offset: 1,
            },
          ],
          {
            duration: 460,
            easing: 'cubic-bezier(0.16, 1, 0.3, 1)',
            fill: 'forwards',
          },
        );
        vesselAnim.onfinish = () => {
          vessel.style.display = 'none';
        };
        animations.push(vesselAnim);
      }

      // Only opacity on Vaul's outer Drawer.Content so we never fight Vaul's drag transforms
      animations.push(
        panel.animate(
          [
            { opacity: 0.04, offset: 0 },
            { opacity: 0.88, offset: 0.48 },
            { opacity: 1, offset: 1 },
          ],
          {
            duration: 440,
            easing: 'cubic-bezier(0.16, 1, 0.3, 1)',
            fill: 'none',
          },
        ),
      );

      if (inner && typeof inner.animate === 'function') {
        animations.push(
          inner.animate(
            [
              {
                opacity: 0,
                transform: `translate3d(${(dx * 0.16).toFixed(1)}px, ${(dy * 0.16).toFixed(1)}px, 0) scale3d(0.92, 0.92, 1)`,
                offset: 0,
              },
              {
                opacity: 0.98,
                transform: 'translate3d(0px, -2px, 0) scale3d(1.006, 1.004, 1)',
                offset: 0.68,
              },
              {
                opacity: 1,
                transform: 'translate3d(0px, 0px, 0) scale3d(1, 1, 1)',
                offset: 1,
              },
            ],
            {
              duration: 460,
              easing: 'cubic-bezier(0.16, 1, 0.3, 1)',
              fill: 'none',
            },
          ),
        );
      }
    } else {
      if (vessel) vessel.style.display = 'none';
      glassSolitonRef.current = [0.5, 0.92, 0.015, 1.35];
    }

    getSharedFluidEngine().wake();
    return () => {
      for (const anim of animations) {
        anim.cancel();
      }
      if (vessel) vessel.style.display = 'none';
    };
  }, [open, isLiquidGlass, hasSharedOrigin, originRect, panelEl]);

  const handleGlassPointer = (event: ReactPointerEvent<HTMLDivElement>, isDown: boolean) => {
    if (!isLiquidGlass) return;
    const panel = panelEl ?? panelRef.current;
    if (!panel) return;
    const rect = panel.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return;

    const samples = extractCoalescedSamples(
      event.nativeEvent,
      event.clientX,
      event.clientY,
      rect,
    );
    let pred = glassKalmanRef.current.update(
      samples[0]?.x ?? 0.5,
      samples[0]?.y ?? 0.5,
      samples[0]?.t ?? performance.now(),
    );
    for (let i = 1; i < samples.length; i++) {
      const s = samples[i];
      if (!s) continue;
      pred = glassKalmanRef.current.update(s.x, s.y, s.t);
    }

    panel.style.setProperty('--glass-px', `${(pred.x * 100).toFixed(1)}%`);
    panel.style.setProperty('--glass-py', `${(pred.y * 100).toFixed(1)}%`);

    glassPointerRef.current = [pred.x, pred.y, 1, Math.min(1, pred.speed)];
    if (!prefersReducedMotion()) {
      glassTargetTiltRef.current = [(pred.x - 0.5) * 0.18, (pred.y - 0.5) * 0.12];
      if (isDown) {
        const slot = nextRippleIdxRef.current % MAX_SHEET_RIPPLES;
        nextRippleIdxRef.current += 1;
        const o = slot * 4;
        glassRipplesRef.current[o] = pred.x;
        glassRipplesRef.current[o + 1] = pred.y;
        glassRipplesRef.current[o + 2] = 0.015;
        glassRipplesRef.current[o + 3] = 0.95;
      }
      getSharedFluidEngine().wake();
    }
  };

  useEffect(() => {
    if (!open) return;
    const panel = panelEl ?? panelRef.current;
    if (!panel) return;

    const previouslyFocused = document.activeElement instanceof HTMLElement
      ? document.activeElement
      : null;
    const releaseScrollLock = lockBodyScroll();
    const focusableElements = () => Array.from(
      panel.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR),
    ).filter((element) => element.getAttribute('aria-hidden') !== 'true' && element.getClientRects().length > 0);

    const firstFocusable = focusableElements()[0];
    (firstFocusable ?? panel).focus();

    const containFocus = (event: KeyboardEvent) => {
      if (event.key !== 'Tab') return;
      const focusable = focusableElements();
      if (focusable.length === 0) {
        event.preventDefault();
        panel.focus();
        return;
      }
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      const active = document.activeElement;
      if (event.shiftKey && (active === first || !panel.contains(active))) {
        event.preventDefault();
        last?.focus();
      } else if (!event.shiftKey && (active === last || !panel.contains(active))) {
        event.preventDefault();
        first?.focus();
      }
    };

    document.addEventListener('keydown', containFocus, true);
    return () => {
      document.removeEventListener('keydown', containFocus, true);
      releaseScrollLock();
      if (previouslyFocused?.isConnected) previouslyFocused.focus();
    };
  }, [open, panelEl]);

  const handlePanelRef = useCallback((node: HTMLDivElement | null) => {
    panelRef.current = node;
    setPanelEl(node);
  }, []);

  return (
    <Drawer.Root
      open={open}
      onOpenChange={(nextOpen) => {
        if (!nextOpen) onClose();
      }}
      modal={false}
      shouldScaleBackground={false}
      repositionInputs={false}
    >
      <Drawer.Portal>
        {hasSharedOrigin && (
          <div
            ref={morphVesselRef}
            aria-hidden="true"
            style={{ display: 'none' }}
            className="titan-liquid-glass-morph-vessel items-center justify-center overflow-hidden"
          >
            <span className="h-3/4 w-3/4 rounded-full bg-[radial-gradient(circle,rgba(232,253,255,0.52),rgba(116,216,248,0.18)_58%,transparent_78%)]" />
          </div>
        )}
        <div
          ref={backdropRef}
          className={`fixed inset-0 z-50 flex items-end sm:items-center justify-center ${
            isLiquidGlass ? 'bg-[#040B0F]/72 backdrop-blur-[10px]' : 'bg-[#060908]/82 backdrop-blur-[6px]'
          } ${animateOpen && !hasSharedOrigin ? 'animate-sheet-backdrop' : ''}`}
          onClick={onClose}
        >
          <Drawer.Content
            ref={handlePanelRef}
            role="dialog"
            aria-modal="true"
            aria-labelledby={titleId}
            aria-describedby={subtitle ? subtitleId : undefined}
            data-titan-shared-origin={hasSharedOrigin ? 'true' : undefined}
            tabIndex={-1}
            onClick={(event) => event.stopPropagation()}
            onPointerDown={(e) => handleGlassPointer(e, true)}
            onPointerMove={(e) => handleGlassPointer(e, false)}
            onPointerUp={() => {
              if (!isLiquidGlass) return;
              glassTargetTiltRef.current = [0, 0];
              if (!prefersReducedMotion()) getSharedFluidEngine().wake();
            }}
            onPointerCancel={() => {
              if (!isLiquidGlass) return;
              glassKalmanRef.current.reset();
              glassTargetTiltRef.current = [0, 0];
              if (!prefersReducedMotion()) getSharedFluidEngine().wake();
            }}
            onPointerLeave={() => {
              if (!isLiquidGlass) return;
              glassKalmanRef.current.reset();
              glassPointerRef.current = [0.5, 0.25, 0, 0];
              glassTargetTiltRef.current = [0, 0];
              if (!prefersReducedMotion()) getSharedFluidEngine().wake();
            }}
            className={`${
              isLiquidGlass
                ? 'titan-liquid-glass-sheet border-t sm:border border-[rgba(214,244,255,0.28)]'
                : 'titan-luxury-sheet border-t sm:border border-[rgba(200,173,122,0.18)]'
            } relative w-full sm:max-w-lg rounded-t-[28px] sm:rounded-[24px] max-h-[90dvh] flex flex-col overflow-hidden focus:outline-none ${
              animateOpen && !hasSharedOrigin
                ? (isLiquidGlass ? 'animate-liquid-glass-sheet' : 'animate-sheet-panel')
                : ''
            }`}
          >
            {isLiquidGlass && (
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 rounded-[inherit] overflow-hidden opacity-95"
              >
                <div className="absolute -top-12 -left-10 h-44 w-56 rounded-full bg-[radial-gradient(circle,rgba(128,224,252,0.32),transparent_68%)] blur-xl" />
                <div className="absolute top-1/3 -right-12 h-36 w-48 rounded-full bg-[radial-gradient(circle,rgba(92,202,238,0.18),transparent_72%)] blur-xl" />
                <div className="absolute -bottom-12 right-0 h-44 w-60 rounded-full bg-[radial-gradient(circle,rgba(56,162,196,0.26),transparent_70%)] blur-xl" />
                <div className="absolute inset-0 rounded-[inherit] shadow-[inset_0_1px_1px_rgba(255,255,255,0.22),inset_0_-1px_1px_rgba(104,210,242,0.14)]" />
              </div>
            )}

            {isLiquidGlass && (
              <LiquidGlassSheetOverlay
                hostRef={panelRef}
                open={open}
                tiltRef={glassTiltRef}
                targetTiltRef={glassTargetTiltRef}
                pointerRef={glassPointerRef}
                ripplesRef={glassRipplesRef}
                solitonRef={glassSolitonRef}
              />
            )}

            <div ref={innerMorphRef} className="relative z-[2] flex flex-col flex-1 min-h-0">
              <div className="sm:hidden pt-3 pb-1 flex justify-center shrink-0" aria-hidden="true">
                <div
                  className={`w-11 h-1 rounded-full ${
                    isLiquidGlass ? 'bg-[#C4ECFA]/45' : 'bg-[var(--titan-champagne)]/35'
                  }`}
                />
              </div>

              <div
                className={`flex items-start justify-between gap-4 px-5 pt-3.5 sm:pt-5 pb-4 border-b shrink-0 ${
                  isLiquidGlass ? 'border-[rgba(208,240,252,0.14)]' : 'border-[rgba(193,204,196,0.10)]'
                }`}
              >
                <div className="min-w-0">
                  {eyebrow && (
                    <p className="titan-eyebrow mb-1">{eyebrow}</p>
                  )}
                  <Drawer.Title asChild>
                    <h2
                      id={titleId}
                      className={`text-lg font-semibold tracking-tight truncate ${
                        isLiquidGlass ? 'text-[#ECF8FD]' : 'text-[var(--titan-text-primary)]'
                      }`}
                    >
                      {title}
                    </h2>
                  </Drawer.Title>
                  {subtitle && (
                    <Drawer.Description asChild>
                      <p
                        id={subtitleId}
                        className={`text-xs mt-0.5 leading-relaxed ${
                          isLiquidGlass ? 'text-[#A2CAD9]' : 'text-[var(--titan-text-secondary)]'
                        }`}
                      >
                        {subtitle}
                      </p>
                    </Drawer.Description>
                  )}
                </div>
                <button
                  type="button"
                  onClick={onClose}
                  aria-label="Fechar painel"
                  className={`min-h-[44px] min-w-[44px] -mr-2 -mt-1 flex items-center justify-center rounded-2xl border border-transparent shrink-0 transition-colors focus-visible:outline-none focus-visible:ring-2 ${
                    isLiquidGlass
                      ? 'hover:border-[rgba(212,244,255,0.34)] hover:bg-[rgba(140,214,242,0.14)] text-[#A2CAD9] hover:text-[#F4FCFF] focus-visible:ring-[var(--titan-info)]/70'
                      : 'hover:border-[var(--titan-border)]/70 hover:bg-[var(--titan-surface-raised)]/60 text-[var(--titan-text-secondary)] hover:text-[var(--titan-text-primary)] focus-visible:ring-[var(--titan-focus)]'
                  }`}
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div
                data-vaul-no-drag=""
                className={`px-5 pt-4 overflow-y-auto flex-1 overscroll-contain ${
                  isLiquidGlass && animateOpen ? 'titan-liquid-glass-cascade' : ''
                } ${footer ? 'pb-5' : 'pb-6 pb-safe'}`}
              >
                {children}
              </div>

              {footer && (
                <div
                  className={`shrink-0 px-5 pt-3 pb-4 pb-safe border-t ${
                    isLiquidGlass
                      ? 'border-[rgba(208,240,252,0.14)] bg-[#08151C]/92'
                      : 'border-[rgba(193,204,196,0.10)] bg-[#0E1412]/95'
                  }`}
                >
                  {footer}
                </div>
              )}
            </div>
          </Drawer.Content>
        </div>
      </Drawer.Portal>
    </Drawer.Root>
  );
}
