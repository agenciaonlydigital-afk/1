import { prefersReducedMotion } from '@/src/shared/graphics/fluid-shader-engine';

let sharedAudioCtx: AudioContext | null = null;
let noiseBufferCache: AudioBuffer | null = null;
let lastGlassTapAt = 0;
let lastDropletPlopAt = 0;
let lastSheetSweepAt = 0;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined' || prefersReducedMotion()) return null;
  const Ctor =
    window.AudioContext ??
    (window as Window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctor) return null;

  try {
    if (!sharedAudioCtx) {
      sharedAudioCtx = new Ctor();
    }
    if (sharedAudioCtx.state === 'suspended') {
      void sharedAudioCtx.resume().catch(() => {});
    }
    return sharedAudioCtx;
  } catch {
    return null;
  }
}

function getTransientNoiseBuffer(ctx: AudioContext): AudioBuffer | null {
  try {
    if (noiseBufferCache && noiseBufferCache.sampleRate === ctx.sampleRate) {
      return noiseBufferCache;
    }
    const length = Math.max(256, Math.round(ctx.sampleRate * 0.045));
    const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
    const channel = buffer.getChannelData(0);
    for (let i = 0; i < length; i++) {
      const env = Math.exp(-i / Math.max(1, length * 0.24));
      channel[i] = (Math.random() * 2 - 1) * env;
    }
    noiseBufferCache = buffer;
    return buffer;
  } catch {
    return null;
  }
}

/**
 * Physical Minnaert bubble cavity plop + micro-transient splash burst.
 * Resonant base pitch subtly deepens as the water vessel fills.
 */
export function playDropletPlop(fillRatio = 0.5, intensity = 1): void {
  const nowMs = typeof performance !== 'undefined' ? performance.now() : Date.now();
  if (nowMs - lastDropletPlopAt < 70) return;
  const ctx = getAudioContext();
  if (!ctx || ctx.state === 'closed') return;
  lastDropletPlopAt = nowMs;

  try {
    const t0 = ctx.currentTime + 0.002;
    const clampedFill = Math.max(0, Math.min(1, Number.isFinite(fillRatio) ? fillRatio : 0.5));
    const gainScale = Math.max(0.25, Math.min(1.2, Number.isFinite(intensity) ? intensity : 1)) * 0.055;
    const fStart = 590 - clampedFill * 165;
    const fEnd = fStart * 2.24;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(fStart * 1.45, t0);
    filter.frequency.exponentialRampToValueAtTime(fEnd * 1.1, t0 + 0.062);
    filter.Q.setValueAtTime(6.5, t0);

    const master = ctx.createGain();
    master.gain.setValueAtTime(0.0001, t0);
    master.gain.linearRampToValueAtTime(gainScale, t0 + 0.005);
    master.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.088);

    filter.connect(master);
    master.connect(ctx.destination);

    // Primary + secondary Minnaert bubble harmonic pair [1.0, 2.3]
    const modes: ReadonlyArray<readonly [number, number]> = [
      [1.0, 1.0],
      [2.3, 0.26],
    ];
    for (const [ratio, weight] of modes) {
      const osc = ctx.createOscillator();
      const modeGain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(fStart * ratio, t0);
      osc.frequency.exponentialRampToValueAtTime(fEnd * ratio, t0 + 0.068);
      modeGain.gain.setValueAtTime(weight, t0);
      osc.connect(modeGain);
      modeGain.connect(filter);
      osc.start(t0);
      osc.stop(t0 + 0.095);
    }

    const noise = getTransientNoiseBuffer(ctx);
    if (noise) {
      const src = ctx.createBufferSource();
      src.buffer = noise;
      const noiseGain = ctx.createGain();
      noiseGain.gain.setValueAtTime(0.22, t0);
      noiseGain.gain.exponentialRampToValueAtTime(0.001, t0 + 0.022);
      src.connect(noiseGain);
      noiseGain.connect(filter);
      src.start(t0);
      src.stop(t0 + 0.03);
    }
  } catch {
    // Audio playback is strictly progressive enhancement.
  }
}

/**
 * Physical borosilicate crystal glass tap via modal synthesis
 * using inharmonic partial ratios [1.0, 2.76, 5.4, 8.9].
 */
export function playCrystalGlassTap(normX = 0.5, intensity = 1): void {
  const nowMs = typeof performance !== 'undefined' ? performance.now() : Date.now();
  if (nowMs - lastGlassTapAt < 48) return;
  const ctx = getAudioContext();
  if (!ctx || ctx.state === 'closed') return;
  lastGlassTapAt = nowMs;

  try {
    const t0 = ctx.currentTime + 0.002;
    const clampedX = Math.max(0, Math.min(1, Number.isFinite(normX) ? normX : 0.5));
    const gainScale = Math.max(0.25, Math.min(1.2, Number.isFinite(intensity) ? intensity : 1)) * 0.038;
    const baseFreq = 1360 + (1 - clampedX) * 260;

    const master = ctx.createGain();
    master.gain.setValueAtTime(0.0001, t0);
    master.gain.linearRampToValueAtTime(gainScale, t0 + 0.0025);
    master.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.11);
    master.connect(ctx.destination);

    const glassModes: ReadonlyArray<readonly [number, number, number]> = [
      [1.0, 1.0, 0.095],
      [2.76, 0.44, 0.068],
      [5.4, 0.20, 0.042],
      [8.9, 0.09, 0.024],
    ];
    for (const [ratio, amp, decaySec] of glassModes) {
      const freq = baseFreq * ratio;
      if (freq > ctx.sampleRate * 0.42) continue;
      const osc = ctx.createOscillator();
      const modeGain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t0);
      modeGain.gain.setValueAtTime(amp, t0);
      modeGain.gain.exponentialRampToValueAtTime(0.0001, t0 + decaySec);
      osc.connect(modeGain);
      modeGain.connect(master);
      osc.start(t0);
      osc.stop(t0 + decaySec + 0.01);
    }
  } catch {
    // Audio playback is strictly progressive enhancement.
  }
}

/**
 * Subtle resonant crystal opening shimmer for Liquid Glass sheet transitions.
 */
export function playLiquidGlassOpenCue(intensity = 1): void {
  const nowMs = typeof performance !== 'undefined' ? performance.now() : Date.now();
  if (nowMs - lastSheetSweepAt < 140) return;
  const ctx = getAudioContext();
  if (!ctx || ctx.state === 'closed') return;
  lastSheetSweepAt = nowMs;

  try {
    const t0 = ctx.currentTime + 0.003;
    const gainScale = Math.max(0.2, Math.min(1.1, Number.isFinite(intensity) ? intensity : 1)) * 0.032;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(640, t0);
    filter.frequency.exponentialRampToValueAtTime(1920, t0 + 0.14);
    filter.Q.setValueAtTime(4.2, t0);

    const master = ctx.createGain();
    master.gain.setValueAtTime(0.0001, t0);
    master.gain.linearRampToValueAtTime(gainScale, t0 + 0.016);
    master.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.17);
    filter.connect(master);
    master.connect(ctx.destination);

    const noise = getTransientNoiseBuffer(ctx);
    if (noise) {
      const src = ctx.createBufferSource();
      src.buffer = noise;
      src.connect(filter);
      src.start(t0);
      src.stop(t0 + 0.05);
    }

    const osc = ctx.createOscillator();
    const oscGain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(980, t0);
    osc.frequency.exponentialRampToValueAtTime(1480, t0 + 0.12);
    oscGain.gain.setValueAtTime(0.55, t0);
    oscGain.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.14);
    osc.connect(oscGain);
    oscGain.connect(master);
    osc.start(t0);
    osc.stop(t0 + 0.15);
  } catch {
    // Audio playback is strictly progressive enhancement.
  }
}
