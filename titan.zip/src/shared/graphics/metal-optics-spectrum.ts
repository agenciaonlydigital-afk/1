export type MetalOpticsPreset = 'silver' | 'chromium' | 'gold';

export interface MeasuredMetalOpticsSample {
  wavelengthNm: number;
  n: number;
  k: number;
}

// Johnson & Christy (1972, Au/Ag) and Johnson, Christy (1974, Cr), digitized
// anchors from refractiveindex.info. Data source is CC0 1.0; units are nm.
export const METAL_SPECTRAL_SAMPLES: Readonly<Record<MetalOpticsPreset, readonly MeasuredMetalOpticsSample[]>> = Object.freeze({
  silver: Object.freeze([
    { wavelengthNm: 430.5, n: 0.04, k: 2.462 }, { wavelengthNm: 450.9, n: 0.04, k: 2.657 },
    { wavelengthNm: 471.4, n: 0.05, k: 2.869 }, { wavelengthNm: 495.9, n: 0.05, k: 3.093 },
    { wavelengthNm: 520.9, n: 0.05, k: 3.324 }, { wavelengthNm: 548.6, n: 0.06, k: 3.586 },
    { wavelengthNm: 582.1, n: 0.05, k: 3.858 }, { wavelengthNm: 616.8, n: 0.06, k: 4.152 },
    { wavelengthNm: 659.5, n: 0.05, k: 4.483 },
  ]),
  chromium: Object.freeze([
    { wavelengthNm: 430.5, n: 2.19, k: 3.04 }, { wavelengthNm: 450.9, n: 2.33, k: 3.14 },
    { wavelengthNm: 471.4, n: 2.51, k: 3.24 }, { wavelengthNm: 495.9, n: 2.75, k: 3.30 },
    { wavelengthNm: 520.9, n: 2.94, k: 3.33 }, { wavelengthNm: 548.6, n: 3.18, k: 3.33 },
    { wavelengthNm: 582.1, n: 3.22, k: 3.30 }, { wavelengthNm: 616.8, n: 3.17, k: 3.30 },
    { wavelengthNm: 659.5, n: 3.09, k: 3.34 },
  ]),
  gold: Object.freeze([
    { wavelengthNm: 430.5, n: 1.45, k: 1.948 }, { wavelengthNm: 450.9, n: 1.38, k: 1.914 },
    { wavelengthNm: 471.4, n: 1.31, k: 1.849 }, { wavelengthNm: 495.9, n: 1.04, k: 1.833 },
    { wavelengthNm: 520.9, n: 0.62, k: 2.081 }, { wavelengthNm: 548.6, n: 0.43, k: 2.455 },
    { wavelengthNm: 582.1, n: 0.29, k: 2.863 }, { wavelengthNm: 616.8, n: 0.21, k: 3.272 },
    { wavelengthNm: 659.5, n: 0.14, k: 3.697 },
  ]),
});

export function sampleMetalOptics(preset: MetalOpticsPreset, wavelengthNm: number): { n: number; k: number } {
  if (!Number.isFinite(wavelengthNm)) throw new RangeError('Wavelength must be finite');
  const samples = METAL_SPECTRAL_SAMPLES[preset];
  if (!samples) throw new RangeError(`Unknown conductor preset: ${String(preset)}`);
  if (wavelengthNm <= samples[0]!.wavelengthNm) return { n: samples[0]!.n, k: samples[0]!.k };
  const last = samples[samples.length - 1]!;
  if (wavelengthNm >= last.wavelengthNm) return { n: last.n, k: last.k };
  let lo = 0;
  let hi = samples.length - 1;
  while (hi - lo > 1) {
    const mid = (lo + hi) >> 1;
    if (samples[mid]!.wavelengthNm <= wavelengthNm) lo = mid;
    else hi = mid;
  }
  const a = samples[lo]!;
  const b = samples[hi]!;
  const t = (wavelengthNm - a.wavelengthNm) / (b.wavelengthNm - a.wavelengthNm);
  return { n: a.n + (b.n - a.n) * t, k: a.k + (b.k - a.k) * t };
}

/** Exact normal-incidence Fresnel for a complex conductor index n + i*k. */
export function spectralConductorFresnel(cosTheta: number, n: number, k: number): number {
  if (![cosTheta, n, k].every(Number.isFinite) || n < 0 || k < 0) throw new RangeError('Conductor Fresnel inputs must be finite and n/k non-negative');
  const c = Math.min(1, Math.max(0, cosTheta));
  const c2 = c * c;
  const sin2 = 1 - c2;
  const sin4 = sin2 * sin2;
  const n2 = n * n;
  const k2 = k * k;
  const t0 = n2 - k2 - sin2;
  const a2PlusB2 = Math.sqrt(Math.max(t0 * t0 + 4 * n2 * k2, 1e-12));
  const a = Math.sqrt(Math.max(0.5 * (a2PlusB2 + t0), 1e-12));
  const twoAC = 2 * a * c;
  const rs = (a2PlusB2 + c2 - twoAC) / Math.max(a2PlusB2 + c2 + twoAC, 1e-12);
  const t3 = c2 * a2PlusB2 + sin4;
  const t4 = twoAC * sin2;
  const rp = rs * (t3 - t4) / Math.max(t3 + t4, 1e-12);
  return Math.min(1, Math.max(0, 0.5 * (rs + rp)));
}

// Three spectral quadrature samples per output RGB band. This is not a full
// CIE spectral renderer, but it captures measured dispersion across visible bands.
export const METAL_SPECTRAL_FRESNEL_GLSL = `
vec3 measuredMetalFresnelSpectral(int preset, float cosTheta) {
  vec3 nA; vec3 kA; vec3 nB; vec3 kB; vec3 nC; vec3 kC;
  if (preset == 0) { // Ag, Johnson & Christy 1972
    nA = vec3(0.05, 0.05, 0.04); kA = vec3(3.858, 3.093, 2.462);
    nB = vec3(0.06, 0.05, 0.04); kB = vec3(4.152, 3.324, 2.657);
    nC = vec3(0.05, 0.06, 0.05); kC = vec3(4.483, 3.586, 2.869);
  } else if (preset == 1) { // Cr, Johnson & Christy 1974
    nA = vec3(3.22, 2.75, 2.19); kA = vec3(3.30, 3.30, 3.04);
    nB = vec3(3.17, 2.94, 2.33); kB = vec3(3.30, 3.33, 3.14);
    nC = vec3(3.09, 3.18, 2.51); kC = vec3(3.34, 3.33, 3.24);
  } else { // Au, Johnson & Christy 1972
    nA = vec3(0.29, 1.04, 1.45); kA = vec3(2.863, 1.833, 1.948);
    nB = vec3(0.21, 0.62, 1.38); kB = vec3(3.272, 2.081, 1.914);
    nC = vec3(0.14, 0.43, 1.31); kC = vec3(3.697, 2.455, 1.849);
  }
  vec3 fa = evalConductorFresnelExact(nA, kA, cosTheta);
  vec3 fb = evalConductorFresnelExact(nB, kB, cosTheta);
  vec3 fc = evalConductorFresnelExact(nC, kC, cosTheta);
  return (fa + fb + fc) / 3.0;
}
`;
