export type DropletMassChangeKind = 'external' | 'transfer' | 'internal';

export interface DropletMassBalanceSnapshot {
  initialMass: number;
  currentMass: number;
  sourceMass: number;
  sinkMass: number;
  transferredMass: number;
  coalescedMass: number;
  expectedMass: number;
  residual: number;
}

function finiteNonNegative(value: number, label: string): number {
  if (!Number.isFinite(value) || value < 0) throw new RangeError(`${label} must be finite and non-negative`);
  return value;
}

/** Tracks the water represented by the UI droplet pool without pretending the visual solver is a CFD solver. */
export class DropletMassLedger {
  private initialMass = 0;
  private sourceMass = 0;
  private sinkMass = 0;
  private transferredMass = 0;
  private coalescedMass = 0;

  resetBaseline(currentMass: number): void {
    this.initialMass = finiteNonNegative(currentMass, 'Initial mass');
    this.sourceMass = 0;
    this.sinkMass = 0;
    this.transferredMass = 0;
    this.coalescedMass = 0;
  }

  recordChange(before: number, after: number, kind: DropletMassChangeKind = 'external'): void {
    const oldMass = finiteNonNegative(before, 'Previous mass');
    const newMass = finiteNonNegative(after, 'New mass');
    if (kind === 'internal') return;
    const delta = newMass - oldMass;
    if (delta > 0) this.sourceMass += delta;
    else if (delta < 0) {
      this.sinkMass -= delta;
      if (kind === 'transfer') this.transferredMass -= delta;
    }
  }

  recordCoalescence(transferredInternally: number): void {
    this.coalescedMass += finiteNonNegative(transferredInternally, 'Coalesced mass');
  }

  snapshot(currentMass: number): DropletMassBalanceSnapshot {
    const current = finiteNonNegative(currentMass, 'Current mass');
    const expected = this.initialMass + this.sourceMass - this.sinkMass;
    return {
      initialMass: this.initialMass,
      currentMass: current,
      sourceMass: this.sourceMass,
      sinkMass: this.sinkMass,
      transferredMass: this.transferredMass,
      coalescedMass: this.coalescedMass,
      expectedMass: expected,
      residual: current - expected,
    };
  }
}

/** Merging two represented drops is an internal transfer: no mass may be discarded. */
export function mergeDropletMassConservatively(survivorMass: number, donorMass: number): number {
  return finiteNonNegative(survivorMass, 'Survivor mass') + finiteNonNegative(donorMass, 'Donor mass');
}
