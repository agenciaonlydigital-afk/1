import assert from 'node:assert/strict';
import { capillaryMeniscusHeightNonlinear } from '../capillary-meniscus.ts';

function integrateReference(theta, normalizedDistance, steps = 1024) {
  const sinTheta = Math.sin(theta);
  const cosTheta = Math.cos(theta);
  const q = Math.sqrt(Math.max(0, 2 * (1 - sinTheta)));
  const sign = cosTheta < 0 ? -1 : 1;
  let y = sign * q;
  let slope = -cosTheta / Math.max(Math.abs(sinTheta), 1e-8);
  const dx = normalizedDistance / steps;
  const derivative = (height, gradient) => [gradient, height * (1 + gradient * gradient) ** 1.5];

  for (let i = 0; i < steps; i += 1) {
    const k1 = derivative(y, slope);
    const k2 = derivative(y + dx * k1[0] / 2, slope + dx * k1[1] / 2);
    const k3 = derivative(y + dx * k2[0] / 2, slope + dx * k2[1] / 2);
    const k4 = derivative(y + dx * k3[0], slope + dx * k3[1]);
    y += dx * (k1[0] + 2 * k2[0] + 2 * k3[0] + k4[0]) / 6;
    slope += dx * (k1[1] + 2 * k2[1] + 2 * k3[1] + k4[1]) / 6;
  }
  return y;
}

const capillaryLength = 0.03;
const anglesDeg = [22.5, 30, 45, 60, 75, 105, 120, 135, 150, 157.5];
const distances = [0, 0.25, 0.5, 1, 2, 3, 4];

for (const angleDeg of anglesDeg) {
  const angle = angleDeg * Math.PI / 180;
  for (const normalizedDistance of distances) {
    const expected = integrateReference(angle, normalizedDistance);
    const actual = capillaryMeniscusHeightNonlinear(
      normalizedDistance * capillaryLength,
      capillaryLength,
      angle,
    ) / capillaryLength;
    const relativeError = Math.abs(actual - expected) / Math.max(Math.abs(expected), 1e-5);
    assert.ok(Number.isFinite(actual), `finite nonlinear profile at ${angleDeg}°, ${normalizedDistance} λ`);
    assert.ok(relativeError <= 0.08, `profile error <=8% at ${angleDeg}°, ${normalizedDistance} λ (got ${(relativeError * 100).toFixed(2)}%)`);
  }
}

for (const angle of [0.05, Math.PI / 2, Math.PI - 0.05]) {
  assert.ok(Number.isFinite(capillaryMeniscusHeightNonlinear(0.015, capillaryLength, angle)));
}
assert.equal(capillaryMeniscusHeightNonlinear(0, capillaryLength, Math.PI / 2), 0);
assert.throws(() => capillaryMeniscusHeightNonlinear(0, 0, Math.PI / 4), /length/i);
console.log('PASS: nonlinear Young–Laplace meniscus approximation matches RK4 reference within 8%');
