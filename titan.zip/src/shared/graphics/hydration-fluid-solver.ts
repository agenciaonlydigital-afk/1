// SOTA 2D Vorticity-Confinement Fluid Solver, Analytic Teardrop Volume Integral,
// and Component-Aware Interfacial Card Droplet Simulation
// (Contact Angle Hysteresis, Stick-Slip Pinning, Lubrication Theory, Landau-Levich Trails,
//  Plateau-Rayleigh Breakup, explicit droplet mass ledger, Real Container Geometry Colliders,
//  and 6-Stage Reservoir Absorption).

import { DropletMassLedger, mergeDropletMassConservatively, type DropletMassBalanceSnapshot, type DropletMassChangeKind } from './droplet-mass-balance.ts';
import { projectIncompressibleVelocity2D, type PressureProjectionDiagnostics } from './fluid-pressure-projection.ts';
import { contactAnglePinningMultiplier, updateContactAngleHysteresis } from './capillary-meniscus.ts';

// ============================================================================
// 1. Analytic Volume Conservation for Teardrop Silhouette (Area Integral Inversion)
// ============================================================================
// Matches inner cavity of sdTeardropOuter3D(p) with tapered wall thickness in DROPLET_FRAGMENT_300.
const DROPLET_Y_MIN = -0.440;
const DROPLET_Y_MAX = 0.436;
const AREA_LUT_SIZE = 129;

function smoothstepJS(edge0: number, edge1: number, x: number): number {
  const t = Math.max(0, Math.min(1, (x - edge0) / (edge1 - edge0)));
  return t * t * (3 - 2 * t);
}

function dropletInnerRadiusAtY(y: number): number {
  const yBot = -0.155;
  const yTop = 0.435;
  const wallThickness = 0.020 - (0.020 - 0.0045) * smoothstepJS(0.05, 0.43, y);

  if (y <= yBot) {
    const rBot = 0.305 - wallThickness;
    const dy = y - yBot;
    return Math.sqrt(Math.max(0.0001, rBot * rBot - dy * dy));
  }
  if (y >= yTop) {
    const rTop = 0.015 - wallThickness;
    const dy = y - yTop;
    return Math.sqrt(Math.max(0.0001, rTop * rTop - dy * dy));
  }
  const t = Math.max(0, Math.min(1, (y - yBot) / (yTop - yBot)));
  const omt2 = Math.max(0, 1 - t * t);
  const outerProfileR = 0.015 + (0.305 - 0.015) * Math.pow(omt2, 1.65);
  const slope = -0.4915 * 3.30 * t * Math.pow(Math.max(omt2, 1e-4), 0.65);
  const radialWall = wallThickness * Math.sqrt(1 + slope * slope);
  return Math.max(0.0025, outerProfileR - radialWall);
}

const DROPLET_AREA_LUT = (() => {
  const lut = new Float32Array(AREA_LUT_SIZE);
  let accum = 0;
  const step = (DROPLET_Y_MAX - DROPLET_Y_MIN) / (AREA_LUT_SIZE - 1);
  const r0 = dropletInnerRadiusAtY(DROPLET_Y_MIN);
  let prevSection = Math.PI * r0 * r0;
  lut[0] = 0;
  for (let i = 1; i < AREA_LUT_SIZE; i++) {
    const y = DROPLET_Y_MIN + i * step;
    const r = dropletInnerRadiusAtY(y);
    // 3D revolution slice cross-section pi * r^2
    const section = Math.PI * r * r;
    accum += 0.5 * (prevSection + section) * step;
    lut[i] = accum;
    prevSection = section;
  }
  const total = accum > 0 ? accum : 1;
  for (let i = 0; i < AREA_LUT_SIZE; i++) {
    lut[i] = (lut[i] ?? 0) / total;
  }
  return lut;
})();

export function volumeToDropletFillY(volumeRatio: number): number {
  const v = Math.min(1, Math.max(0, Number.isFinite(volumeRatio) ? volumeRatio : 0));
  if (v <= 0) return DROPLET_Y_MIN;
  if (v >= 1) return DROPLET_Y_MAX;

  let lo = 0;
  let hi = AREA_LUT_SIZE - 1;
  while (hi - lo > 1) {
    const mid = (lo + hi) >> 1;
    if ((DROPLET_AREA_LUT[mid] ?? 0) <= v) lo = mid;
    else hi = mid;
  }
  const a0 = DROPLET_AREA_LUT[lo] ?? 0;
  const a1 = DROPLET_AREA_LUT[hi] ?? 1;
  const frac = a1 > a0 ? (v - a0) / (a1 - a0) : 0;
  const t = (lo + frac) / (AREA_LUT_SIZE - 1);
  return DROPLET_Y_MIN + t * (DROPLET_Y_MAX - DROPLET_Y_MIN);
}

// ============================================================================
// 2. 2D Incompressible Navier-Stokes + Vorticity Confinement + CSF Curvature
// ============================================================================

export class FluidVorticityGrid {
  readonly width: number;
  readonly height: number;
  private readonly size: number;
  private u: Float32Array;
  private v: Float32Array;
  private uPrev: Float32Array;
  private vPrev: Float32Array;
  private curl: Float32Array;
  private absCurl: Float32Array;
  private p: Float32Array;
  private pressureResidual: Float32Array;
  private pressurePreconditioned: Float32Array;
  private pressureDirection: Float32Array;
  private pressureProduct: Float32Array;
  private pressurePreconditionerDiagonal: Float32Array;
  private pressurePreconditionerForward: Float32Array;
  private pressurePreconditionerRootDiagonal: Float32Array;
  private div: Float32Array;
  private projectionDiagnostics: PressureProjectionDiagnostics | null = null;
  private aeration: Float32Array;
  private aerationPrev: Float32Array;
  readonly packedRgba: Uint8Array;
  private energy = 0;
  private _version = 0;

  get version(): number {
    return this._version;
  }

  getProjectionDiagnostics(): PressureProjectionDiagnostics | null {
    return this.projectionDiagnostics ? { ...this.projectionDiagnostics } : null;
  }

  constructor(width = 48, height = 24) {
    this.width = width;
    this.height = height;
    this.size = width * height;
    this.u = new Float32Array(this.size);
    this.v = new Float32Array(this.size);
    this.uPrev = new Float32Array(this.size);
    this.vPrev = new Float32Array(this.size);
    this.curl = new Float32Array(this.size);
    this.absCurl = new Float32Array(this.size);
    this.p = new Float32Array(this.size);
    this.pressureResidual = new Float32Array(this.size);
    this.pressurePreconditioned = new Float32Array(this.size);
    this.pressureDirection = new Float32Array(this.size);
    this.pressureProduct = new Float32Array(this.size);
    this.pressurePreconditionerDiagonal = new Float32Array(this.size);
    this.pressurePreconditionerForward = new Float32Array(this.size);
    this.pressurePreconditionerRootDiagonal = new Float32Array(this.size);
    this.div = new Float32Array(this.size);
    this.aeration = new Float32Array(this.size);
    this.aerationPrev = new Float32Array(this.size);
    this.packedRgba = new Uint8Array(this.size * 4);
    this.packToTexture();
  }

  private idx(x: number, y: number): number {
    const cx = x < 0 ? 0 : x >= this.width ? this.width - 1 : x;
    const cy = y < 0 ? 0 : y >= this.height ? this.height - 1 : y;
    return cy * this.width + cx;
  }

  isActive(): boolean {
    return this.energy > 0.002;
  }

  injectImpulse(normX: number, normY: number, vx: number, vy: number, aerationAmount = 0.75): void {
    const cx = Math.round(Math.min(1, Math.max(0, normX)) * (this.width - 1));
    const cy = Math.round(Math.min(1, Math.max(0, normY)) * (this.height - 1));
    const radius = 3;
    for (let dy = -radius; dy <= radius; dy++) {
      for (let dx = -radius; dx <= radius; dx++) {
        const d2 = dx * dx + dy * dy;
        if (d2 > radius * radius) continue;
        const w = Math.exp(-d2 * 0.45);
        const i = this.idx(cx + dx, cy + dy);
        const swirlU = -dy * 0.38 * (vx >= 0 ? 1 : -1);
        const swirlV = dx * 0.38 * (vx >= 0 ? 1 : -1);
        this.u[i] = Math.max(-4, Math.min(4, (this.u[i] ?? 0) + (vx + swirlU) * w));
        this.v[i] = Math.max(-4, Math.min(4, (this.v[i] ?? 0) + (vy + swirlV) * w));
        this.aeration[i] = Math.min(1, (this.aeration[i] ?? 0) + aerationAmount * w);
      }
    }
    this.energy = Math.min(1.5, this.energy + 0.65);
    this.packToTexture();
  }

  step(dt: number, tiltX = 0, tiltY = 0): void {
    const clampedDt = Math.min(0.033, Math.max(0.004, dt));
    const w = this.width;
    const h = this.height;

    if (Math.abs(tiltX) > 0.01 || Math.abs(tiltY) > 0.01) {
      this.energy = Math.min(1.5, this.energy + (Math.abs(tiltX) + Math.abs(tiltY)) * 0.08);
    }

    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const i = y * w + x;
        const aeL = this.aeration[i - 1] ?? 0;
        const aeR = this.aeration[i + 1] ?? 0;
        const aeD = this.aeration[i - w] ?? 0;
        const aeU = this.aeration[i + w] ?? 0;
        const aeC = this.aeration[i] ?? 0;
        const curvature = aeL + aeR + aeD + aeU - 4 * aeC;
        const gradX = 0.5 * (aeR - aeL);
        const gradY = 0.5 * (aeU - aeD);
        const csfScale = 0.0728 * 3.5;

        const buoyY = aeC * 0.42;
        this.u[i] = (this.u[i] ?? 0) + (tiltX * 0.85 + curvature * gradX * csfScale) * clampedDt;
        this.v[i] = (this.v[i] ?? 0) + (tiltY * 0.45 + buoyY + curvature * gradY * csfScale) * clampedDt;
      }
    }

    // Vorticity Confinement (Fedkiw et al.)
    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const i = y * w + x;
        const dvdx = 0.5 * ((this.v[i + 1] ?? 0) - (this.v[i - 1] ?? 0));
        const dudy = 0.5 * ((this.u[i + w] ?? 0) - (this.u[i - w] ?? 0));
        const c = dvdx - dudy;
        this.curl[i] = c;
        this.absCurl[i] = Math.abs(c);
      }
    }

    const vorticityStrength = 2.6;
    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const i = y * w + x;
        const nx = 0.5 * ((this.absCurl[i + 1] ?? 0) - (this.absCurl[i - 1] ?? 0));
        const ny = 0.5 * ((this.absCurl[i + w] ?? 0) - (this.absCurl[i - w] ?? 0));
        const len = Math.hypot(nx, ny) + 1e-5;
        const dx = nx / len;
        const dy = ny / len;
        const c = this.curl[i] ?? 0;
        this.u[i] = (this.u[i] ?? 0) + dy * c * vorticityStrength * clampedDt;
        this.v[i] = (this.v[i] ?? 0) - dx * c * vorticityStrength * clampedDt;
      }
    }

    this.projectionDiagnostics = projectIncompressibleVelocity2D(
      this.u,
      this.v,
      w,
      h,
      {
        divergence: this.div,
        pressure: this.p,
        pressureResidual: this.pressureResidual,
        pressurePreconditioned: this.pressurePreconditioned,
        pressureDirection: this.pressureDirection,
        pressureProduct: this.pressureProduct,
        preconditionerInverseDiagonal: this.pressurePreconditionerDiagonal,
        preconditionerForward: this.pressurePreconditionerForward,
        preconditionerRootDiagonal: this.pressurePreconditionerRootDiagonal,
      },
      { minIterations: 4, maxIterations: 12, relativeTolerance: 0.05 },
    );

    // Semi-Lagrangian Advection
    this.uPrev.set(this.u);
    this.vPrev.set(this.v);
    this.aerationPrev.set(this.aeration);

    const velDamp = Math.exp(-clampedDt * 1.15);
    const aerDamp = Math.exp(-clampedDt * 0.65);

    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const i = y * w + x;
        const sx = Math.max(0.5, Math.min(w - 1.5, x - (this.uPrev[i] ?? 0) * clampedDt * 14));
        const sy = Math.max(0.5, Math.min(h - 1.5, y - (this.vPrev[i] ?? 0) * clampedDt * 14));
        const x0 = Math.floor(sx);
        const y0 = Math.floor(sy);
        const tx = sx - x0;
        const ty = sy - y0;

        const i00 = y0 * w + x0;
        const i10 = i00 + 1;
        const i01 = i00 + w;
        const i11 = i01 + 1;

        const uSample =
          (1 - tx) * (1 - ty) * (this.uPrev[i00] ?? 0) +
          tx * (1 - ty) * (this.uPrev[i10] ?? 0) +
          (1 - tx) * ty * (this.uPrev[i01] ?? 0) +
          tx * ty * (this.uPrev[i11] ?? 0);
        const vSample =
          (1 - tx) * (1 - ty) * (this.vPrev[i00] ?? 0) +
          tx * (1 - ty) * (this.vPrev[i10] ?? 0) +
          (1 - tx) * ty * (this.vPrev[i01] ?? 0) +
          tx * ty * (this.vPrev[i11] ?? 0);
        const aSample =
          (1 - tx) * (1 - ty) * (this.aerationPrev[i00] ?? 0) +
          tx * (1 - ty) * (this.aerationPrev[i10] ?? 0) +
          (1 - tx) * ty * (this.aerationPrev[i01] ?? 0) +
          tx * ty * (this.aerationPrev[i11] ?? 0);

        this.u[i] = uSample * velDamp;
        this.v[i] = vSample * velDamp;
        this.aeration[i] = aSample * aerDamp;
      }
    }

    for (let x = 0; x < w; x++) {
      this.u[x] = 0;
      this.v[x] = 0;
      this.u[(h - 1) * w + x] = 0;
      this.v[(h - 1) * w + x] = 0;
    }
    for (let y = 0; y < h; y++) {
      this.u[y * w] = 0;
      this.v[y * w] = 0;
      this.u[y * w + (w - 1)] = 0;
      this.v[y * w + (w - 1)] = 0;
    }

    this.energy *= Math.exp(-clampedDt * 0.85);
    this.packToTexture();
  }

  private packToTexture(): void {
    const out = this.packedRgba;
    for (let i = 0; i < this.size; i++) {
      const o = i * 4;
      const uVal = Math.max(-1, Math.min(1, (this.u[i] ?? 0) * 0.5));
      const vVal = Math.max(-1, Math.min(1, (this.v[i] ?? 0) * 0.5));
      const cVal = Math.max(-1, Math.min(1, (this.curl[i] ?? 0) * 0.4));
      const aVal = Math.max(0, Math.min(1, this.aeration[i] ?? 0));
      out[o] = Math.round((uVal * 0.5 + 0.5) * 255);
      out[o + 1] = Math.round((vVal * 0.5 + 0.5) * 255);
      out[o + 2] = Math.round((cVal * 0.5 + 0.5) * 255);
      out[o + 3] = Math.round(aVal * 255);
    }
    this._version += 1;
  }
}

// ============================================================================
// 3. Component-Aware Interfacial Card Droplet Simulation
//    - Real DOM + Geometric Silhouette Colliders (External Buttons, Droplet, Tank, Labels)
//    - Contact Angle Hysteresis (CAH) + Stick-Slip + Lubrication Theory
//    - Curved Landau-Levich Wet Trails + Plateau-Rayleigh Breakup
//    - 6-Stage Physical Reservoir Absorption (Contact -> Bridge -> Merge -> Wave)
//    - Smooth-Min Coalescence with Area Conservation (A_total = A1 + A2)
// ============================================================================

export const MAX_CARD_DROPLETS = 12;
export const MAX_CARD_OBSTACLES = 6;

export type CardColliderKind = 'ledge' | 'droplet-pool' | 'tank-pool' | 'label';

export interface CardColliderRect {
  id: string;
  kind: CardColliderKind;
  xMin: number;
  yMin: number;
  xMax: number;
  yMax: number;
}

export interface CardDropletVesselState {
  dropletFillRatio?: number;
  tankFillRatio?: number;
}

export interface CardDropletImpactEvent {
  target: 'droplet' | 'tank';
  normX: number;
  strength: number;
  /** Water mass removed from this droplet and handed to the receiving UI reservoir. */
  massTransferred?: number;
  /** 'impact' fires at meniscus contact; 'merge' fires when the capillary bridge completes absorption. */
  stage?: 'impact' | 'merge';
}

export interface CardDropletBody {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  mass: number;
  contactAngleLeadingRadians: number;
  contactAngleTrailingRadians: number;
  pinned: boolean;
  pinThreshold: number;
  dwellTimer: number;
  maxDwell: number;
  creepRate: number;
  trailStartX: number;
  trailStartY: number;
  trailBendX: number;
  trailAlpha: number;
  stretch: number;
  onLedge: boolean;
  splashedTank: boolean;
  splashedDroplet: boolean;
  /** 0 = free/sliding, 1 = contact deformation, 2 = capillary bridge, 3 = meniscus merge */
  absorbStage: 0 | 1 | 2 | 3;
  absorbTarget: 'none' | 'droplet' | 'tank';
  absorbProgress: number;
  absorbAnchorX: number;
  absorbAnchorY: number;
  absorbLocalNormX: number;
  absorbInitialMass: number;
}

export interface CardDropletGpuState {
  // [x, y, radius, stretch] * 12
  drops: Float32Array;
  // [vx, vy] * 12
  velocities: Float32Array;
  // [trailStartX, trailStartY, trailBendX, trailAlpha] * 12
  trails: Float32Array;
  // [anchorX, anchorY, progress, stageCode] * 12
  dropAbsorb: Float32Array;
  // [xMin, yMin, xMax, yMax] * 6
  obstacles: Float32Array;
  // Wetness glow intensity on each obstacle [0..1]
  obstacleWetness: Float32Array;
}

/** Projected 2D half-width of the rendered 3D teardrop within its canvas (normalized to width). */
function dropletProjectedHalfWidth(canvasRelY: number): number {
  const y = Math.max(0.06, Math.min(0.95, canvasRelY));
  if (y < 0.62) {
    const t = (y - 0.08) / (0.62 - 0.08);
    return 0.055 + 0.345 * Math.pow(Math.max(0, Math.min(1, t)), 1.35);
  }
  const t = (y - 0.62) / (0.94 - 0.62);
  return Math.max(0.08, 0.40 * Math.sqrt(Math.max(0, 1 - t * t * 0.92)));
}

/** Projected top-to-bottom half-height of the horizontal capsule at normalized X in [0, 1]. */
function tankCapsuleHalfHeightRatio(relX: number, colW: number, colH: number): number {
  const capRadiusNormX = Math.min(0.22, (colH * 0.5) / Math.max(0.04, colW));
  if (relX < capRadiusNormX) {
    const dx = (capRadiusNormX - relX) / capRadiusNormX;
    return 0.5 * Math.sqrt(Math.max(0, 1 - dx * dx));
  }
  if (relX > 1 - capRadiusNormX) {
    const dx = (relX - (1 - capRadiusNormX)) / capRadiusNormX;
    return 0.5 * Math.sqrt(Math.max(0, 1 - dx * dx));
  }
  return 0.5;
}

export class CardDropletSim {
  readonly bodies: CardDropletBody[] = [];
  colliders: CardColliderRect[] = [];
  readonly gpu: CardDropletGpuState = {
    drops: new Float32Array(MAX_CARD_DROPLETS * 4),
    velocities: new Float32Array(MAX_CARD_DROPLETS * 2),
    trails: new Float32Array(MAX_CARD_DROPLETS * 4),
    dropAbsorb: new Float32Array(MAX_CARD_DROPLETS * 4),
    obstacles: new Float32Array(MAX_CARD_OBSTACLES * 4),
    obstacleWetness: new Float32Array(MAX_CARD_OBSTACLES),
  };
  private seed = 1337;
  private activityEnergy = 0;
  private ambientEnabled = false;
  private ambientAccumulator = 0;
  private readonly massLedger = new DropletMassLedger();

  getMassBalance(): DropletMassBalanceSnapshot {
    let currentMass = 0;
    for (const body of this.bodies) currentMass += body.mass;
    return this.massLedger.snapshot(currentMass);
  }

  private setBodyMass(body: CardDropletBody, nextMass: number, kind: DropletMassChangeKind = 'external'): void {
    const safeMass = Number.isFinite(nextMass) ? Math.max(0, nextMass) : 0;
    this.massLedger.recordChange(body.mass, safeMass, kind);
    body.mass = safeMass;
  }

  constructor() {
    this.resetCalmDew();
  }

  private nextRand(): number {
    this.seed = (this.seed * 1664525 + 1013904223) >>> 0;
    return this.seed / 4294967296;
  }

  setColliders(nextColliders: CardColliderRect[]): void {
    this.colliders = nextColliders.slice(0, MAX_CARD_OBSTACLES);
    this.gpu.obstacles.fill(-2);
    for (let i = 0; i < this.colliders.length; i++) {
      const c = this.colliders[i];
      if (!c) continue;
      const o4 = i * 4;
      this.gpu.obstacles[o4] = c.xMin;
      this.gpu.obstacles[o4 + 1] = c.yMin;
      this.gpu.obstacles[o4 + 2] = c.xMax;
      this.gpu.obstacles[o4 + 3] = c.yMax;
    }
  }

  private resetAbsorbState(b: CardDropletBody): void {
    b.absorbStage = 0;
    b.absorbTarget = 'none';
    b.absorbProgress = 0;
    b.absorbAnchorX = b.x;
    b.absorbAnchorY = b.y;
    b.absorbLocalNormX = 0.5;
    b.absorbInitialMass = b.mass;
  }

  setAmbientCondensation(enabled: boolean): void {
    const wasEnabled = this.ambientEnabled;
    this.ambientEnabled = enabled;
    if (enabled && !wasEnabled) {
      this.activityEnergy = Math.max(this.activityEnergy, 0.56);
      // Balanced mobile ambient motion: 4 staggered sliding droplets + resting micro-beads
      for (let i = 0; i < this.bodies.length; i++) {
        const b = this.bodies[i];
        if (!b || b.absorbStage > 0) continue;
        const isImmediateSlide = i < 4;
        b.x = 0.08 + ((i + 0.35 + this.nextRand() * 0.50) / this.bodies.length) * 0.84;
        b.y = isImmediateSlide ? 0.03 + (i / 4) * 0.34 : 0.08 + this.nextRand() * 0.58;
        const targetRadius = isImmediateSlide
          ? 0.0044 + this.nextRand() * 0.0022
          : 0.0033 + this.nextRand() * 0.0016;
        b.radius = targetRadius;
        this.setBodyMass(b, b.radius * b.radius);
        b.pinned = !isImmediateSlide;
        b.pinThreshold = b.mass * (isImmediateSlide ? 0.80 : 1.08 + this.nextRand() * 0.16);
        b.dwellTimer = this.nextRand() * 0.55;
        b.maxDwell = 0.75 + this.nextRand() * 1.45;
        b.creepRate = 0.004 + this.nextRand() * 0.005;
        b.vx = (this.nextRand() - 0.5) * 0.015;
        b.vy = isImmediateSlide ? 0.048 + this.nextRand() * 0.045 : b.creepRate;
        b.trailStartX = b.x;
        b.trailStartY = b.y;
        b.trailBendX = 0;
        b.trailAlpha = isImmediateSlide ? 0.68 : 0.08;
        b.stretch = isImmediateSlide ? 0.24 : 0.04;
        b.onLedge = false;
        b.splashedTank = false;
        b.splashedDroplet = false;
        this.resetAbsorbState(b);
      }
      this.syncGpuBuffers();
    }
  }

  resetCalmDew(): void {
    this.ambientEnabled = false;
    this.bodies.length = 0;
    const anchors: ReadonlyArray<[number, number, number]> = [
      [0.10, 0.14, 0.0042],
      [0.24, 0.10, 0.0036],
      [0.39, 0.20, 0.0045],
      [0.54, 0.12, 0.0038],
      [0.69, 0.18, 0.0046],
      [0.86, 0.14, 0.0040],
      [0.17, 0.40, 0.0034],
      [0.34, 0.49, 0.0037],
      [0.52, 0.37, 0.0036],
      [0.68, 0.46, 0.0042],
      [0.84, 0.68, 0.0039],
      [0.22, 0.79, 0.0034],
    ];
    for (let i = 0; i < MAX_CARD_DROPLETS; i++) {
      const [x, y, r] = anchors[i] ?? [0.5, 0.3, 0.005];
      const mass = r * r;
      this.bodies.push({
        x,
        y,
        vx: 0,
        vy: 0,
        radius: r,
        mass,
        contactAngleLeadingRadians: 50 * Math.PI / 180,
        contactAngleTrailingRadians: 50 * Math.PI / 180,
        pinned: true,
        pinThreshold: mass * (1.10 + this.nextRand() * 0.22),
        dwellTimer: 0,
        maxDwell: 0.45 + this.nextRand() * 0.95,
        creepRate: 0.005 + this.nextRand() * 0.006,
        trailStartX: x,
        trailStartY: y,
        trailBendX: 0,
        trailAlpha: 0,
        stretch: 0,
        onLedge: false,
        splashedTank: false,
        splashedDroplet: false,
        absorbStage: 0,
        absorbTarget: 'none',
        absorbProgress: 0,
        absorbAnchorX: x,
        absorbAnchorY: y,
        absorbLocalNormX: 0.5,
        absorbInitialMass: mass,
      });
    }
    this.activityEnergy = 0;
    let initialMass = 0;
    for (const body of this.bodies) initialMass += body.mass;
    this.massLedger.resetBaseline(initialMass);
    this.gpu.obstacleWetness.fill(0);
    this.syncGpuBuffers();
  }

  /** Spawns active condensation and stick-slip sliding droplets when water is added or card is touched. */
  triggerCondensationBurst(intensity = 1.0): void {
    const count = Math.min(MAX_CARD_DROPLETS, 7 + Math.round(intensity * 5));
    for (let i = 0; i < count; i++) {
      const body = this.bodies[i];
      if (!body || body.absorbStage > 0) continue;
      body.x = 0.07 + this.nextRand() * 0.86;
      body.y = 0.02 + this.nextRand() * 0.18;
      body.radius = 0.0044 + this.nextRand() * 0.0026;
      this.setBodyMass(body, body.radius * body.radius);
      body.pinned = i % 5 === 4;
      body.pinThreshold = body.mass * (body.pinned ? 1.05 : 0.78);
      body.dwellTimer = 0;
      body.maxDwell = 0.22 + this.nextRand() * 0.65;
      body.creepRate = 0.006 + this.nextRand() * 0.007;
      body.vx = (this.nextRand() - 0.5) * 0.022;
      body.vy = body.pinned ? body.creepRate : 0.075 + this.nextRand() * 0.085;
      body.trailStartX = body.x;
      body.trailStartY = body.y;
      body.trailBendX = 0;
      body.trailAlpha = body.pinned ? 0.22 : 0.84;
      body.stretch = body.pinned ? 0.10 : 0.34;
      body.onLedge = false;
      body.splashedTank = false;
      body.splashedDroplet = false;
      this.resetAbsorbState(body);
    }
    this.activityEnergy = Math.max(this.activityEnergy, 1.0);
    this.syncGpuBuffers();
  }

  /** Direct tactile pointer/touch interaction: sweeps droplets aside, breaks pinning, or spawns a bead at tap. */
  applyPointerSweep(normX: number, normY: number, vx: number, vy: number, isTap: boolean): void {
    const cx = Math.min(0.96, Math.max(0.04, normX));
    const cy = Math.min(0.94, Math.max(0.02, normY));
    const brushR = isTap ? 0.18 : 0.13;
    let touchedAny = false;

    for (let i = 0; i < this.bodies.length; i++) {
      const b = this.bodies[i];
      if (!b || b.absorbStage > 0) continue;
      const dx = b.x - cx;
      const dy = b.y - cy;
      const dist = Math.hypot(dx, dy);
      if (dist < brushR) {
        touchedAny = true;
        const falloff = 1 - dist / brushR;
        const pushAngleX = dist > 0.004 ? dx / dist : (i % 2 === 0 ? 1 : -1);
        b.pinned = false;
        b.dwellTimer = 0;
        b.onLedge = false;
        b.vx = Math.max(-0.45, Math.min(0.45, b.vx + (vx * 0.55 + pushAngleX * 0.14) * falloff));
        b.vy = Math.max(0.045, Math.min(0.48, b.vy + (Math.max(0, vy) * 0.45 + 0.11) * falloff));
        b.stretch = Math.min(1, b.stretch + 0.35 * falloff);
        b.trailAlpha = Math.max(b.trailAlpha, 0.80);
      }
    }

    if (isTap || !touchedAny) {
      let target: CardDropletBody | undefined;
      let minPriority = Infinity;
      for (let i = 0; i < this.bodies.length; i++) {
        const b = this.bodies[i];
        if (!b || b.absorbStage > 0) continue;
        const score = (b.pinned ? 0 : 10) + b.radius * 100;
        if (score < minPriority) {
          minPriority = score;
          target = b;
        }
      }
      if (target) {
        target.x = cx;
        target.y = cy;
        target.radius = isTap ? 0.0056 + this.nextRand() * 0.0018 : 0.0044 + this.nextRand() * 0.0016;
        this.setBodyMass(target, target.radius * target.radius);
        target.pinned = false;
        target.dwellTimer = 0;
        target.pinThreshold = target.mass * 0.8;
        target.vx = Math.max(-0.22, Math.min(0.22, vx * 0.35 + (this.nextRand() - 0.5) * 0.035));
        target.vy = Math.max(0.08, Math.min(0.28, 0.10 + Math.max(0, vy) * 0.22));
        target.trailStartX = target.x;
        target.trailStartY = target.y;
        target.trailBendX = 0;
        target.trailAlpha = 0.84;
        target.stretch = 0.36;
        target.onLedge = false;
        target.splashedTank = false;
        target.splashedDroplet = false;
        this.resetAbsorbState(target);
      }
    }

    this.activityEnergy = Math.max(this.activityEnergy, isTap ? 0.95 : 0.76);
    this.syncGpuBuffers();
  }

  /** Shakes droplets off a clicked/hovered button ledge so they cascade onto the card & vessels below. */
  shakeCollider(colliderId: string): void {
    const colIndex = this.colliders.findIndex((c) => c.id === colliderId);
    const col = colIndex >= 0 ? this.colliders[colIndex] : undefined;
    if (!col) return;
    this.gpu.obstacleWetness[colIndex] = 1.0;

    for (let i = 0; i < this.bodies.length; i++) {
      const b = this.bodies[i];
      if (!b || b.absorbStage > 0) continue;
      if (
        b.x >= col.xMin - 0.08 &&
        b.x <= col.xMax + 0.08 &&
        b.y >= col.yMin - 0.08 &&
        b.y <= col.yMax + 0.10
      ) {
        b.pinned = false;
        b.dwellTimer = 0;
        b.onLedge = false;
        const center = (col.xMin + col.xMax) * 0.5;
        b.vx += (b.x >= center ? 1 : -1) * 0.13;
        b.vy = Math.max(b.vy, 0.18);
        b.stretch = 0.62;
        b.trailAlpha = 0.88;
      }
    }
    this.activityEnergy = Math.max(this.activityEnergy, 0.85);
    this.syncGpuBuffers();
  }

  isActive(): boolean {
    if (this.ambientEnabled) return true;
    if (this.activityEnergy > 0.01) return true;
    for (let i = 0; i < this.bodies.length; i++) {
      const b = this.bodies[i];
      if (b && (!b.pinned || b.absorbStage > 0 || b.vy > 0.002 || b.trailAlpha > 0.02 || b.stretch > 0.02)) {
        return true;
      }
    }
    return false;
  }

  private respawnBodyAtTop(b: CardDropletBody, slideNow: boolean): void {
    b.x = 0.06 + this.nextRand() * 0.88;
    b.y = 0.015 + this.nextRand() * 0.065;
    this.setBodyMass(b, 0);
    b.radius = 0.0040 + this.nextRand() * 0.0024;
    this.setBodyMass(b, b.radius * b.radius);
    b.pinned = !slideNow;
    b.dwellTimer = 0;
    b.maxDwell = 0.55 + this.nextRand() * 1.15;
    b.creepRate = 0.005 + this.nextRand() * 0.006;
    b.pinThreshold = b.mass * (1.03 + this.nextRand() * 0.14);
    b.vx = (this.nextRand() - 0.5) * 0.014;
    b.vy = b.pinned ? b.creepRate : 0.055 + this.nextRand() * 0.05;
    b.trailStartX = b.x;
    b.trailStartY = b.y;
    b.trailBendX = 0;
    b.trailAlpha = b.pinned ? 0.12 : 0.72;
    b.stretch = b.pinned ? 0.05 : 0.24;
    b.onLedge = false;
    b.splashedTank = false;
    b.splashedDroplet = false;
    this.resetAbsorbState(b);
  }

  private beginAbsorption(
    b: CardDropletBody,
    target: 'droplet' | 'tank',
    anchorX: number,
    anchorY: number,
    localNormX: number,
    cIdx: number,
    onDropletImpact?: (event: CardDropletImpactEvent) => void,
  ): void {
    if (b.absorbStage > 0) return;
    b.absorbStage = 1;
    b.absorbTarget = target;
    b.absorbProgress = 0.01;
    b.absorbAnchorX = anchorX;
    b.absorbAnchorY = anchorY;
    b.absorbLocalNormX = localNormX;
    b.absorbInitialMass = b.mass;
    b.pinned = false;
    b.onLedge = false;
    if (cIdx >= 0) {
      this.gpu.obstacleWetness[cIdx] = 1.0;
    }

    const transferredMass = b.mass * (target === 'droplet' ? 0.38 : 0.42);
    const impactStrength = Math.min(3.4, Math.max(1.15, b.mass * 12500 + b.vy * 4.4));
    if (target === 'droplet') b.splashedDroplet = true;
    else b.splashedTank = true;

    onDropletImpact?.({
      target,
      normX: localNormX,
      strength: impactStrength,
      massTransferred: transferredMass,
      stage: 'impact',
    });

    this.setBodyMass(b, Math.max(0.000004, b.mass - transferredMass), 'transfer');
    b.radius = Math.max(0.0022, Math.sqrt(b.mass));
  }

  private advanceAbsorption(
    b: CardDropletBody,
    clampedDt: number,
    onDropletImpact?: (event: CardDropletImpactEvent) => void,
  ): void {
    // 6-stage physical progression (~0.48s total from contact deformation -> liquid bridge -> fusion)
    b.absorbProgress += clampedDt * 2.15;

    if (b.absorbProgress < 0.28) {
      // Stage 2: Contact & impact flattening onto meniscus
      b.absorbStage = 1;
      const pull = Math.min(1, clampedDt * 12);
      b.x += (b.absorbAnchorX - b.x) * pull * 0.45;
      b.y += (b.absorbAnchorY - b.radius * 0.9 - b.y) * pull;
      b.vx *= Math.exp(-clampedDt * 8);
      b.vy *= Math.exp(-clampedDt * 6);
      b.stretch = -0.34 * (b.absorbProgress / 0.28);
      b.trailAlpha = Math.max(0, b.trailAlpha - clampedDt * 1.6);
      return;
    }

    if (b.absorbProgress < 0.68) {
      // Stage 3: Capillary liquid bridge neck connecting microdroplet to reservoir surface
      b.absorbStage = 2;
      const bridgeT = (b.absorbProgress - 0.28) / 0.40;
      const targetMass = Math.max(0.000002, b.absorbInitialMass * (1 - 0.50 - 0.34 * bridgeT));
      if (b.mass > targetMass) {
        this.setBodyMass(b, targetMass, 'transfer');
        b.radius = Math.max(0.0016, Math.sqrt(b.mass));
      }
      b.x += (b.absorbAnchorX - b.x) * Math.min(1, clampedDt * 10);
      b.y += (b.absorbAnchorY - b.radius * 0.45 - b.y) * Math.min(1, clampedDt * 10);
      b.vx = 0;
      b.vy = 0.015;
      b.stretch = -0.20 + 0.45 * bridgeT;
      b.trailAlpha = Math.max(0, b.trailAlpha - clampedDt * 2.4);
      return;
    }

    if (b.absorbProgress < 1.0) {
      // Stage 4-5: Fusion & surface incorporation
      b.absorbStage = 3;
      const mergeT = (b.absorbProgress - 0.68) / 0.32;
      const targetMass = Math.max(0.0000005, b.absorbInitialMass * 0.16 * (1 - mergeT));
      if (b.mass > targetMass) {
        this.setBodyMass(b, targetMass, 'transfer');
        b.radius = Math.max(0.0008, Math.sqrt(b.mass));
      }
      b.x += (b.absorbAnchorX - b.x) * Math.min(1, clampedDt * 16);
      b.y += (b.absorbAnchorY - b.y) * Math.min(1, clampedDt * 16);
      b.stretch = 0.28 * (1 - mergeT);
      b.trailAlpha = 0;
      return;
    }

    // Stage 6: Finalize remaining mass transfer & recycle particle cleanly
    const finalMass = b.mass;
    if (finalMass > 0) {
      this.setBodyMass(b, 0, 'transfer');
      if (b.absorbTarget === 'droplet' || b.absorbTarget === 'tank') {
        onDropletImpact?.({
          target: b.absorbTarget,
          normX: b.absorbLocalNormX,
          strength: 0.78,
          massTransferred: finalMass,
          stage: 'merge',
        });
      }
    }

    if (this.activityEnergy > 0.12 || this.ambientEnabled) {
      this.respawnBodyAtTop(b, this.nextRand() > 0.45);
    } else {
      b.y = 0.14 + this.nextRand() * 0.64;
      b.radius = 0.0036 + this.nextRand() * 0.0014;
      this.setBodyMass(b, b.radius * b.radius);
      b.pinned = true;
      b.dwellTimer = 0;
      b.pinThreshold = b.mass * 1.25;
      b.vx = 0;
      b.vy = 0;
      b.trailStartX = b.x;
      b.trailStartY = b.y;
      b.trailBendX = 0;
      b.trailAlpha = 0;
      b.stretch = 0;
      b.onLedge = false;
      b.splashedTank = false;
      b.splashedDroplet = false;
      this.resetAbsorbState(b);
    }
  }

  step(
    dt: number,
    tiltX = 0,
    onDropletImpact?: (event: CardDropletImpactEvent) => void,
    vessels?: CardDropletVesselState,
  ): void {
    const clampedDt = Math.min(0.033, Math.max(0.002, dt));
    const dropletFill = Math.min(1, Math.max(0, vessels?.dropletFillRatio ?? 0.52));
    const tankFill = Math.min(1, Math.max(0, vessels?.tankFillRatio ?? 0.52));

    for (let k = 0; k < MAX_CARD_OBSTACLES; k++) {
      const w = this.gpu.obstacleWetness[k] ?? 0;
      if (w > 0) this.gpu.obstacleWetness[k] = Math.max(0, w - clampedDt * 0.55);
    }

    // Balanced mobile ambient cycle: keep 3-4 droplets actively moving without turning into a storm
    if (this.ambientEnabled) {
      this.ambientAccumulator += clampedDt;
      this.activityEnergy = Math.max(this.activityEnergy, 0.34);
      if (this.ambientAccumulator > 0.65) {
        this.ambientAccumulator = 0;
        let movingCount = 0;
        for (let i = 0; i < this.bodies.length; i++) {
          const b = this.bodies[i];
          if (b && (!b.pinned || b.absorbStage > 0)) movingCount++;
        }
        if (movingCount < 4) {
          for (let i = 0; i < this.bodies.length; i++) {
            const b = this.bodies[i];
            if (!b || !b.pinned || b.absorbStage > 0) continue;
            b.pinned = false;
            b.dwellTimer = 0;
            b.vx = (this.nextRand() - 0.5) * 0.018;
            b.vy = 0.050 + this.nextRand() * 0.042;
            b.trailStartX = b.x;
            b.trailStartY = b.y;
            b.trailBendX = 0;
            b.trailAlpha = Math.max(b.trailAlpha, 0.70);
            b.stretch = 0.24;
            break;
          }
        }
      }
    }

    for (let i = 0; i < this.bodies.length; i++) {
      const b = this.bodies[i];
      if (!b) continue;

      if (b.absorbStage > 0) {
        this.advanceAbsorption(b, clampedDt, onDropletImpact);
        continue;
      }

      const dynamicAngles = updateContactAngleHysteresis(
        { leadingRadians: b.contactAngleLeadingRadians, trailingRadians: b.contactAngleTrailingRadians },
        b.vy,
        clampedDt,
        30 * Math.PI / 180,
        70 * Math.PI / 180,
      );
      b.contactAngleLeadingRadians = dynamicAngles.leadingRadians;
      b.contactAngleTrailingRadians = dynamicAngles.trailingRadians;
      b.pinThreshold = b.mass * contactAnglePinningMultiplier(dynamicAngles.leadingRadians, dynamicAngles.trailingRadians);

      if (this.activityEnergy > 0.05 || this.ambientEnabled) {
        this.setBodyMass(b, b.mass + 0.000038 * clampedDt * (0.50 + this.activityEnergy));
        b.radius = Math.min(0.0102, Math.sqrt(b.mass));
      }

      if (b.pinned) {
        b.dwellTimer += clampedDt;
        if (this.ambientEnabled || this.activityEnergy > 0.06) {
          b.y += b.creepRate * clampedDt;
          b.x = Math.max(0.035, Math.min(0.965, b.x + tiltX * 0.014 * clampedDt));
        }

        const readyToSlide =
          (b.dwellTimer >= b.maxDwell || b.mass >= b.pinThreshold) &&
          (this.activityEnergy > 0.05 || this.ambientEnabled);

        if (readyToSlide || b.y > 0.96) {
          b.pinned = false;
          b.dwellTimer = 0;
          b.vy = 0.052 + this.nextRand() * 0.042;
          b.trailStartX = b.x;
          b.trailStartY = b.y;
          b.trailBendX = 0;
          b.trailAlpha = Math.max(b.trailAlpha, 0.74);
        } else {
          b.vx *= Math.exp(-clampedDt * 6);
          b.vy = b.creepRate;
          b.stretch = 0.07 + 0.05 * Math.sin(b.dwellTimer * 6.0 + i);
          b.trailAlpha = Math.max(0, b.trailAlpha - clampedDt * 0.18);
          continue;
        }
      }

      // Stick-Slip lubrication velocity with organic hesitation pulses
      const roughnessPin = 0.5 + 0.5 * Math.sin(b.y * 46.0 + i * 2.1);
      const gravityDrive = (0.38 + b.mass * 3000.0) * (0.58 + 0.54 * roughnessPin);
      const viscousDrag = 2.85;
      b.vy += (gravityDrive - b.vy * viscousDrag) * clampedDt;
      b.vy = Math.max(0.018, Math.min(0.35, b.vy));
      b.vx += (tiltX * 0.28 - b.vx * 4.2) * clampedDt;

      // Real Geometric Collider Interaction
      b.onLedge = false;
      for (let cIdx = 0; cIdx < this.colliders.length; cIdx++) {
        const col = this.colliders[cIdx];
        if (!col) continue;
        const colW = Math.max(0.02, col.xMax - col.xMin);
        const colH = Math.max(0.02, col.yMax - col.yMin);
        const margin = Math.max(0.010, b.radius * 1.15);
        const inX = b.x >= col.xMin - margin && b.x <= col.xMax + margin;

        if (col.kind === 'ledge') {
          if (inX && b.y >= col.yMin - b.radius * 0.4 && b.y <= col.yMin + 0.045) {
            b.onLedge = true;
            b.y = Math.min(b.y, col.yMin + 0.010);
            b.vy = 0.016;
            const colCenter = (col.xMin + col.xMax) * 0.5;
            const sideDir = b.x >= colCenter ? 1 : -1;
            b.vx += (sideDir * 0.42 + tiltX * 0.25) * clampedDt * 3.8;
            b.trailBendX = (b.x - b.trailStartX) * 0.45;
            this.gpu.obstacleWetness[cIdx] = Math.min(1, (this.gpu.obstacleWetness[cIdx] ?? 0) + clampedDt * 2.5);
          } else if (
            b.x >= col.xMin &&
            b.x <= col.xMax &&
            b.y > col.yMin + 0.045 &&
            b.y <= col.yMax + b.radius * 0.35
          ) {
            const colCenter = (col.xMin + col.xMax) * 0.5;
            const sideDir = b.x >= colCenter ? 1 : -1;
            b.vx += sideDir * 0.48 * clampedDt * 4.2;
            b.vy = Math.max(0.032, b.vy * 0.90);
            this.gpu.obstacleWetness[cIdx] = Math.min(1, (this.gpu.obstacleWetness[cIdx] ?? 0) + clampedDt * 1.8);
          }
        } else if (col.kind === 'droplet-pool') {
          // Droplet canvas covers top ~85% of dropletBox (below is % badge)
          const canvasBottomY = col.yMin + colH * 0.85;
          const canvasH = Math.max(0.02, canvasBottomY - col.yMin);
          if (inX && b.y >= col.yMin && b.y <= canvasBottomY + b.radius) {
            const relX = (b.x - col.xMin) / colW;
            const canvasRelY = Math.max(0, Math.min(1, (b.y - col.yMin) / canvasH));
            const halfWidthRatio = dropletProjectedHalfWidth(canvasRelY);
            const distFromCenter = Math.abs(relX - 0.5);

            // Dynamic liquid fill surface inside the 3D teardrop
            const fillY3D = volumeToDropletFillY(dropletFill);
            const surfaceCanvasY = Math.max(
              0.12,
              Math.min(0.90, 0.90 - ((fillY3D - DROPLET_Y_MIN) / (DROPLET_Y_MAX - DROPLET_Y_MIN)) * 0.78),
            ) + tiltX * (relX - 0.5) * 0.12;
            const surfaceGlobalY = col.yMin + surfaceCanvasY * canvasH;

            if (distFromCenter <= halfWidthRatio + 0.045) {
              const insideLiquidCore =
                dropletFill > 0.025 &&
                distFromCenter <= halfWidthRatio + 0.015 &&
                canvasRelY >= surfaceCanvasY - 0.085 &&
                canvasRelY <= 0.94;

              if (insideLiquidCore && !b.splashedDroplet) {
                const localNormX = Math.min(1, Math.max(0, relX));
                const anchorX = Math.max(
                  col.xMin + (0.5 - halfWidthRatio * 0.78) * colW,
                  Math.min(col.xMin + (0.5 + halfWidthRatio * 0.78) * colW, b.x),
                );
                this.beginAbsorption(b, 'droplet', anchorX, surfaceGlobalY, localNormX, cIdx, onDropletImpact);
                break;
              } else if (distFromCenter > halfWidthRatio * 0.84) {
                // Outer dry glass shell rim: trace gently along the curved silhouette
                const sideDir = relX >= 0.5 ? 1 : -1;
                b.onLedge = true;
                b.vx += (sideDir * 0.12 + tiltX * 0.14) * clampedDt * 2.4;
                b.vy = Math.max(0.032, b.vy * 0.95);
                this.gpu.obstacleWetness[cIdx] = Math.min(0.8, (this.gpu.obstacleWetness[cIdx] ?? 0) + clampedDt * 1.4);
              } else {
                // Upper front glass cone above water line: slide down glass face directly toward liquid surface
                b.vx = (b.vx + tiltX * 0.12 * clampedDt) * Math.exp(-clampedDt * 3.5);
                b.vy = Math.max(0.042, b.vy * 0.96);
                this.gpu.obstacleWetness[cIdx] = Math.min(0.8, (this.gpu.obstacleWetness[cIdx] ?? 0) + clampedDt * 1.2);
              }
            }
          }
        } else if (col.kind === 'tank-pool') {
          if (inX && b.y >= col.yMin - b.radius * 0.7 && b.y <= col.yMax + b.radius * 0.4) {
            const relX = Math.max(0, Math.min(1, (b.x - col.xMin) / colW));
            const relY = (b.y - col.yMin) / colH;
            const halfH = tankCapsuleHalfHeightRatio(relX, colW, colH);
            const topRimRelY = 0.5 - halfH;
            const bottomRimRelY = 0.5 + halfH;
            const liquidEndX = Math.max(0.04, Math.min(1.0, tankFill + tiltX * 0.04));

            if (relY >= topRimRelY - 0.18 && relY <= bottomRimRelY + 0.10) {
              const hitsFilledWater = tankFill > 0.02 && relX <= liquidEndX + 0.045;
              if (hitsFilledWater && !b.splashedTank) {
                // Liquid entry & 6-stage absorption into the tank water surface or meniscus
                const meniscusFrontX = col.xMin + Math.min(relX, liquidEndX) * colW;
                const waterSurfaceY = col.yMin + (topRimRelY + halfH * 0.36) * colH;
                this.beginAbsorption(b, 'tank', meniscusFrontX, waterSurfaceY, relX, cIdx, onDropletImpact);
                break;
              } else {
                // Dry right capsule end or outer quartz wall: deflect along capsule curvature
                b.onLedge = true;
                b.y = Math.min(b.y, col.yMin + topRimRelY * colH + 0.008);
                b.vy = Math.max(0.022, b.vy * 0.80);
                const pushDir = relX > 0.85 ? 1 : relX < 0.15 ? -1 : (relX > liquidEndX ? 1 : 0);
                b.vx += (pushDir * 0.18 + tiltX * 0.22) * clampedDt * 2.5;
                this.gpu.obstacleWetness[cIdx] = Math.min(0.8, (this.gpu.obstacleWetness[cIdx] ?? 0) + clampedDt * 1.2);
              }
            }
          }
        } else if (col.kind === 'label') {
          if (inX && b.y >= col.yMin && b.y <= col.yMax) {
            const colCenter = (col.xMin + col.xMax) * 0.5;
            b.vx += (b.x >= colCenter ? 0.09 : -0.09) * clampedDt * 2.2;
            b.vy = Math.max(0.028, b.vy * 0.94);
          }
        }
      }

      if (b.absorbStage > 0) continue;

      b.x = Math.max(0.035, Math.min(0.965, b.x + b.vx * clampedDt));
      b.y += b.vy * clampedDt;

      // Contact Angle Hysteresis (CAH) elongation
      const targetStretch = b.onLedge ? 0.08 : Math.min(0.68, b.vy * 2.2);
      b.stretch += (targetStretch - b.stretch) * Math.min(1, clampedDt * 12);
      b.trailAlpha = Math.min(1.0, b.trailAlpha + clampedDt * 0.45);
      b.trailBendX = (b.x - b.trailStartX) * 0.38;

      if (this.colliders.length === 0 && b.y >= 0.58 && b.y <= 0.64 && b.vy > 0.03 && !b.splashedTank) {
        b.splashedTank = true;
        const transferredMass = b.mass * 0.40;
        onDropletImpact?.({
          target: b.x < 0.25 ? 'droplet' : 'tank',
          normX: b.x < 0.25 ? b.x * 4 : (b.x - 0.25) / 0.75,
          strength: Math.min(2.6, Math.max(1.0, b.mass * 10000 + b.vy * 4.0)),
          massTransferred: transferredMass,
          stage: 'impact',
        });
        this.setBodyMass(b, Math.max(0.00002, b.mass - transferredMass), 'transfer');
        b.radius = Math.sqrt(b.mass);
      }

      // Landau-Levich trail mass deposition
      this.setBodyMass(b, Math.max(0.000032, b.mass - b.vy * 0.000034 * clampedDt));
      b.radius = Math.sqrt(b.mass);

      // Brief stick-slip micro-pause on microscopic glass roughness
      if (roughnessPin < 0.04 && b.vy < 0.085 && !b.onLedge && this.nextRand() > 0.58) {
        b.pinned = true;
        b.dwellTimer = 0;
        b.maxDwell = 0.24 + this.nextRand() * 0.60;
        b.pinThreshold = b.mass * 1.05;
      }

      // Recycle droplet smoothly at top emission band once it exits the bottom edge
      if (b.y > 1.05) {
        if (this.activityEnergy > 0.14 || this.ambientEnabled) {
          this.respawnBodyAtTop(b, this.nextRand() > 0.55);
        } else {
          b.y = 0.16 + this.nextRand() * 0.68;
          this.setBodyMass(b, 0);
          b.radius = 0.0036 + this.nextRand() * 0.0014;
          this.setBodyMass(b, b.radius * b.radius);
          b.pinned = true;
          b.dwellTimer = 0;
          b.pinThreshold = b.mass * 1.25;
          b.vx = 0;
          b.vy = 0;
          b.trailStartX = b.x;
          b.trailStartY = b.y;
          b.trailBendX = 0;
          b.trailAlpha = 0;
          b.stretch = 0;
          b.onLedge = false;
          b.splashedTank = false;
          b.splashedDroplet = false;
          this.resetAbsorbState(b);
        }
      }
    }

    // Conservative coalescence between free-moving beads (never swallow absorbing beads)
    for (let i = 0; i < this.bodies.length; i++) {
      const a = this.bodies[i];
      if (!a || a.pinned || a.absorbStage > 0) continue;
      for (let j = 0; j < this.bodies.length; j++) {
        if (i === j) continue;
        const other = this.bodies[j];
        if (!other || other.absorbStage > 0) continue;
        const dist = Math.hypot(a.x - other.x, a.y - other.y);
        if (dist < (a.radius + other.radius) * 0.95 && a.mass >= other.mass) {
          const donorMass = other.mass;
          this.setBodyMass(a, mergeDropletMassConservatively(a.mass, donorMass), 'internal');
          this.setBodyMass(other, 0, 'internal');
          this.massLedger.recordCoalescence(donorMass);
          a.radius = Math.min(0.0108, Math.sqrt(a.mass));
          a.vy = Math.min(0.38, a.vy + 0.042);
          this.respawnBodyAtTop(other, false);
        }
      }
    }

    this.activityEnergy = Math.max(0, this.activityEnergy - clampedDt * 0.14);
    this.syncGpuBuffers();
  }

  private syncGpuBuffers(): void {
    for (let i = 0; i < MAX_CARD_DROPLETS; i++) {
      const b = this.bodies[i];
      const d4 = i * 4;
      const v2 = i * 2;
      if (!b) {
        this.gpu.drops[d4] = -2;
        this.gpu.drops[d4 + 1] = -2;
        this.gpu.drops[d4 + 2] = 0;
        this.gpu.drops[d4 + 3] = 0;
        this.gpu.velocities[v2] = 0;
        this.gpu.velocities[v2 + 1] = 0;
        this.gpu.trails[d4] = -2;
        this.gpu.trails[d4 + 1] = 0;
        this.gpu.trails[d4 + 2] = 0;
        this.gpu.trails[d4 + 3] = 0;
        this.gpu.dropAbsorb[d4] = -2;
        this.gpu.dropAbsorb[d4 + 1] = -2;
        this.gpu.dropAbsorb[d4 + 2] = 0;
        this.gpu.dropAbsorb[d4 + 3] = 0;
        continue;
      }
      this.gpu.drops[d4] = b.x;
      this.gpu.drops[d4 + 1] = b.y;
      this.gpu.drops[d4 + 2] = b.radius;
      this.gpu.drops[d4 + 3] = b.stretch;
      this.gpu.velocities[v2] = b.vx;
      this.gpu.velocities[v2 + 1] = b.vy;
      this.gpu.trails[d4] = b.trailStartX;
      this.gpu.trails[d4 + 1] = b.trailStartY;
      this.gpu.trails[d4 + 2] = b.trailBendX;
      this.gpu.trails[d4 + 3] = b.trailAlpha;
      this.gpu.dropAbsorb[d4] = b.absorbAnchorX;
      this.gpu.dropAbsorb[d4 + 1] = b.absorbAnchorY;
      this.gpu.dropAbsorb[d4 + 2] = b.absorbProgress;
      this.gpu.dropAbsorb[d4 + 3] = b.absorbStage;
    }
  }
}
