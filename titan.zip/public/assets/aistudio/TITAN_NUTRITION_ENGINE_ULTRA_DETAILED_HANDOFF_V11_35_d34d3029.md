# TITAN Nutrition Engine — Auditoria integral e plano de conclusão

**Relatório de handoff técnico para outra IA / engenharia sênior**  
**Data:** 26-11-2026  
**Escopo:** motor nutricional, composição dos alimentos, receitas, metas energéticas, referências DRI/UL, otimização, ingestão diária, preparo, DIAAS, dados, proveniência, testes e release.  
**Objetivo do documento:** permitir que uma IA diferente retome a implementação sem perder decisões, sem repetir trabalho concluído e sem declarar como validado aquilo que ainda depende de dados reais, licença ou execução de ambiente.

---

## 0. AVISO DE BASELINE E CONFIABILIDADE DESTE HANDOFF

Esta seção é obrigatória. Não a ignore.

### 0.1 O que foi efetivamente inspecionado nesta sessão

O arquivo binário mais recente que pôde ser recuperado da Biblioteca/arquivos da conversa foi:

- `TITAN_V11_28_NUTRITION_ENGINE.zip`
- `package.json` dentro do ZIP: `11.28.0`
- SHA-256 do ZIP recuperado: `3d18bfc3505c46bc871f2bcca693e81358995c2539aeffd932a444fd424d7fca`
- SHA-256 do catálogo compacto TBCA: `10a83ac4d079a37fdfa5ee43ba3eeac8ee37716c2aaa416b272869051d5ced3e`
- Hash do arquivo-fonte informado no manifest: `d0da42d674e4288881a73331175f57543ab518c32777a6b135855114dfe23e36`
- `unzip -t` do V11.28: sem erros.

A árvore V11.28 foi extraída e inspecionada diretamente. Foram consultados `AGENTS.md`, `README.md`, `package.json`, arquivos nutricionais, adaptadores, cobertura, regras, solver, DRI, testes, pesquisa e changelogs.

### 0.2 O que consta no histórico recente da conversa, mas NÃO foi reaberto como ZIP nesta sessão

A conversa anterior registrou uma evolução posterior:

| Versão registrada no histórico | Mudança declarada | Estado da evidência neste handoff |
|---|---|---|
| V11.33 | Pipeline seguro de ingestão USDA FDC, ZIP reader, downloader fixado, auditoria/importação e catálogo multi-release | Histórico da conversa; precisa confirmar no código recebido |
| V11.34 | Regra para não usar TBCA `PREPARACAO_COMPOSTA` como ingrediente; aliases TBCA corrigidos; refeições legadas reclassificadas; 6/8 templates de receita bloqueados | Histórico da conversa; precisa confirmar no código recebido |
| V11.35 | Derivação rastreável de B3/NE a partir de FDC 409, 406+407 ou 406+501; cobertura TBCA dividida em `ALIMENTO`, `PREPARACAO_COMPOSTA`, `UNKNOWN`; relatório e pesquisa atualizados | Histórico da conversa; precisa confirmar no código recebido |

A resposta anterior informou para V11.35 o ZIP `TITAN_V11_35_NUTRITION_ENGINE.zip`, commit `cc8572b172085f4c23dd5d3230cc3cb83de6ee6b` e SHA-256 `554102ac736b50b96263164046bb426c911f265a25ce3b1568aa0c49e1b7d395`. O arquivo não apareceu como item persistido na Biblioteca quando este relatório foi preparado. **Não trate esses metadados do histórico como verificação do binário que será entregue à outra IA.**

### 0.3 Instrução obrigatória para a IA que receber este relatório

1. Abra o ZIP/código que o usuário efetivamente fornecer.
2. Leia o `package.json`, `README.md`, `AGENTS.md`, o changelog, os relatórios `NUTRITION_ENGINE_V11_*` e o manifest TBCA.
3. Calcule SHA-256 do ZIP e do catálogo compacto.
4. Determine se a versão do código recebido é 11.28, 11.33, 11.34, 11.35 ou posterior.
5. Confirme por busca de código e testes se os itens marcados como V11.34/V11.35 abaixo estão presentes. **Não suponha que o histórico foi incorporado ao ZIP.**
6. Se o usuário fornecer apenas V11.28, classifique os patches descritos como V11.34/V11.35 como trabalho pendente, e não como funcionalidades existentes.
7. Se o usuário fornecer V11.35, mantenha o que estiver comprovado no source e concentre-se nas lacunas restantes deste documento.
8. Não sobrescreva o código recebido por um baseline antigo. Faça worktree/branch isolada e preserve o original.

### 0.4 Legenda de status usada no documento

- **CONFIRMADO NO V11.28:** visto diretamente nos arquivos do ZIP V11.28.
- **REGISTRADO NA CONVERSA V11.34/V11.35:** mudança descrita nas mensagens anteriores, aguardando confirmação no ZIP que a próxima IA receber.
- **PARCIAL:** existe contrato, motor, UI ou teste, mas não existe dado real ou validação operacional suficiente.
- **PENDENTE:** funcionalidade, dado, integração ou validação ainda não demonstrada.
- **BLOQUEADO:** depende de licença, download, credencial, ambiente ou validação humana/científica.

---

# 1. Conclusão executiva

O motor nutricional do TITAN não é uma calculadora simples. No baseline V11.28 já existem componentes avançados: catalogação TBCA compacta com hash, adaptador Open Food Facts com dois produtos, qualidade de macros, agregação com estados de dados, perfis DRI adultos, otimização QP/MIP, fallback matemático em TypeScript, orçamento de gasto energético, equações de RMR, simulação dinâmica Hall, TDEE adaptativo com tendência robusta/Kalman, primitivas para DIAAS e conversão cru/preparado com evidência explícita.

**A principal deficiência deixou de ser “falta de fórmulas”. É falta de dados rastreáveis, domínio de validade, cobertura real, validação científica e operacionalização das funcionalidades que já existem.**

A conclusão deve ser organizada em cinco eixos que não podem ser confundidos:

1. **Código implementado:** existe função, contrato, UI, integração ou worker.
2. **Dados disponíveis:** há medições/valores completos e compatíveis para os alimentos e populações suportados.
3. **Aplicabilidade científica:** a fonte e a equação são adequadas à população, estado do alimento, finalidade e unidade.
4. **Execução operacional:** build, worker, WASM, importação real, persistência, recuperação e navegador foram executados.
5. **Validação externa:** resultados comparados com medição independente, laboratório, nutricionista ou conjunto publicado.

Um recurso só pode ser chamado de concluído quando os cinco estados aplicáveis estiverem registrados. Ter uma função DIAAS, por exemplo, não significa ter DIAAS disponível para os alimentos do catálogo. Ter downloader USDA não significa que a base USDA foi realmente importada. Ter uma simulação sintética de TDEE não significa validação clínica.

## 1.1 Bloqueadores mais importantes

| Prioridade | Bloqueador | Por que impede a conclusão |
|---|---|---|
| **P0** | Baseline real V11.35 precisa ser verificado | O binário V11.35 não foi reaberto nesta sessão; é necessário confirmar que as correções V11.34/V11.35 existem no código entregue |
| **P0** | USDA FDC sem corpus real importado | Adaptador e pipeline podem existir, mas cobertura USDA é zero até importar arquivos oficiais e medir a saída |
| **P0** | TBCA 7.2 e autorização para TBCA 7.3 | Atualização de dados exige direito de uso/reprodução compatível com o aplicativo e sua distribuição |
| **P0** | Build/lint/teste integral e HiGHS WASM em navegador | O histórico V11.28/V11.35 indica bloqueio por ausência de `node_modules`, `vite`, `vite/client`, `tsx` e/ou Bun |
| **P0** | Ingredientes simples versus preparações compostas | V11.28 possui 3.113 preparações compostas no catálogo TBCA; V11.34 registra a correção para não usar compostos como ingredientes; precisa confirmar no source entregue |
| **P1** | Cobertura de micronutrientes | K, B5, B7, B3/NE, colina, iodo, cloreto, Mo, Cr e fluoreto têm lacunas relevantes |
| **P1** | DRI/UL por fonte e forma química | O escopo de UL nem sempre é ingestão total; o app ainda não fecha a exposição de suplementos, fortificados, água, medicamentos e formas químicas |
| **P1** | DIAAS com datasets reais | Há motor/evidência, mas não perfis completos por alimento + digestibilidade ileal por aminoácido/processamento |
| **P1** | Fatores de preparo/rendimento | Existe transformador explícito, mas não há crosswalk amplo e validado alimento × método × rendimento × retenção |
| **P1** | Validação do TDEE/RMR | Equações, Hall e Kalman existem; faltam validação externa, população brasileira, qualidade da ingestão/peso e intervalos calibrados |
| **P1** | Receitas completas | Catálogo pequeno; V11.34 declarou 6/8 modelos bloqueados por preparações compostas legadas sem ficha verificada |
| **P2** | Planejamento 7/14/28 dias | Otimização predominante é diária; falta frequência/variedade/estoque/custo/repetição em horizonte multidiário |
| **P2** | Persistência/portabilidade | Zustand local está implementado; backup/importação, recuperação entre dispositivos e conflitos exigem prova de ponta a ponta |

---

# 2. Inventário arquitetural do motor

## 2.1 Módulos existentes no V11.28

| Área | Arquivos/entradas | O que já existe | Principal lacuna |
|---|---|---|---|
| Entidades e contratos | `src/domains/nutrition/domain/entities/nutrient.ts` | `NutrientId` com 29 nutrientes; estados `quantified`, `trace`, `not_analyzed`, `unit_mismatch`, `invalid_value`, `missing`; fonte TBCA/OFF; unidades e conversões | `food_type` é string livre; `FoodSourceId` não inclui USDA no V11.28; faltam schemas ricos de proveniência/amostra/método/forma química |
| TBCA | `data/sources/tbca-adapter.ts`, `tbca-catalog.compact.json`, `tbca-catalog.manifest.json` | 5.830 registros, 100g, 20 nutrientes da planilha, IDs namespaced `tbca:<code>`, nulidade preservada | Catálogo ainda é TBCA 7.2; licença/uso; 10%? dos nutrientes não publicados/sem dados; qualidade analítica não detalhada no runtime |
| Open Food Facts | `data/sources/open-food-facts-adapter.ts` | Dois produtos curados, valores de rótulo parciais, dados normalizados | Não é ingestão/atualização live; falta ciclo de versão/recall/validade/porção/rótulo completo |
| Busca alimentar | `data/sources/food-search-index.ts`, `domain/rules/food-search.ts` | Normalização, busca por texto/tokens e ranking local; limite de resultados; filtro simples/composite descrito depois em V11.34 | Sinônimos e tolerância a typo; classificação de identidade não deve usar fuzzy isolado; crosswalk entre fontes inexistente |
| Qualidade de macros | `domain/rules/food-data-quality.ts` | Finito/não negativo, base positiva, sanity checks de massa de macros, gordura saturada ≤ gordura total, alerta de diferença Atwater | Revisar energia Atwater específica, fibra/polióis/álcool/ácidos orgânicos e energia direta da fonte; não recalcular fonte automaticamente |
| Cálculo por porção | `domain/rules/nutrition-calculator.ts` | Precisão fracionária, cobertura de massa, IDs não resolvidos, qualidade baixa, macro total e micronutriente com estado completo | Revisar todos os consumidores/visuais para que totais incompletos não pareçam completos; unidade e base precisam sobreviver a todos os fluxos |
| Diário alimentar | `domain/rules/food-diary.ts`, `state/nutrition.store.ts` | Planejado/consumido/parcial/substituído/pulado, massas planejadas e consumidas | Adicionar ingestão de suplementos, bebidas, fortificados, água e fontes não pertencentes a receitas; reconciliar todos os itens que entram no total diário |
| Receitas | `data/recipes/recipe-catalog.ts`, `domain/rules/recipe-engine.ts`, `recipe-search.ts` | Modelo ingrediente + gramas, cálculo por receita e busca | Poucas receitas canônicas; fichas incompletas; V11.34 bloqueou templates compostos históricos, mas precisa confirmar no ZIP atual |
| Composer | `domain/rules/cardapio-composer-engine.ts` (~2.738 linhas), componentes `cardapio-composer/*` | Alocações de refeições, escala proporcional, cobertura, metas macro/micro, QP, substituições | Arquivo central muito grande; ainda solver por dia; preferências/estoque/custo/alergia e múltiplas semanas não cobertos |
| Solver HiGHS | `application/highs-lp-builder.ts`, `highs-nutrition-solver.ts`, `composer-optimizer.worker.ts`, client | QP/LP, MIP para trocas, worker, timeout 2s, fallback TypeScript | Runtime WASM real, performance em mobile, timeout/cancelamento, estado observável e equivalência solver/fallback precisam ser validados |
| Fallback TypeScript | `cardapio-composer-engine.ts` | FISTA projetado + coordinate polish; checagem de limites UL e KKT aproximada | Testar optimalidade, tolerância, infeasibilidade, monotonicidade, reprodutibilidade e comportamento sob dados extremos |
| DRI | `data/references/dri-profiles.ts` | Perfis adultos com RDA/AI/CDRR/UL; metas diárias, CDRR distinto de UL | Poucas fases de vida; referência global NASEM sem registro granular por nutriente/jurisdição; exposição UL por forma/fonte incompleta |
| DIAAS | `domain/rules/protein-quality.ts` | Motor com aminoácidos indispensáveis, digestibilidade ileal por aminoácido, espécie, estado e proveniência; rejeita ratos como base DIAAS | Sem datasets completos reais; sem pontuação real em alimentos do catálogo; precisa validar AA, padrões de referência, lisina reativa e fallback animal |
| Preparo | `domain/rules/food-preparation-transform.ts` | Exige ID/estado exatos, rendimento explícito, evidência separada macro e micronutrientes, fatores true/apparent retention | Falta tabela de fatores; crosswalk TBCA/USDA inexistente; sem interface de processo completa para receitas |
| Cobertura | `domain/rules/nutrition-data-coverage.ts`, `scripts/audit-nutrition-data-coverage.mjs` | Mede unidade correta, valor finito, base positiva e estado de dados por fonte | Em V11.28 apenas TBCA/OFF; a V11.35 histórica acrescenta divisão TBCA por `ALIMENTO`/`PREPARACAO_COMPOSTA`/`UNKNOWN`; confirmar no source |
| RMR/EER/TDEE | `profile/domain/rules/resting-metabolic-rate.ts`, `goal-calculator.ts`, `adaptive-energy.ts`, `hall-body-weight.ts`, `energy-budget.ts` | Mifflin, Pavlidou, Cunningham, Katch-McArdle, Ten Haaf, calorimetria, NASEM EER, Hall, Kalman e prevenção de dupla contagem | Equação não troca automaticamente só porque novos dados foram preenchidos, exceto medição direta; falta validação em brasileiros e ingestão/peso de longo prazo |
| Persistência | `state/nutrition-persistence.ts`, `nutrition.store.ts`, `nutrition.schema.ts` | Zustand persist local, filtros/validação, chaves versionadas; Zod para partes dos inputs | Backup/export/import, restauração, conflito, resolução de IDs alimentares após upgrades, migração de recipes antigos e teste browser |
| Public API do domínio | `application/nutrition-public.ts` | Exposição de cálculo, transformação, DIAAS, busca e cobertura | Garantir que consumidores usem contratos públicos e não acessem internos; revisar novas funções V11.34/35 |

## 2.2 Arquivos mais sensíveis a regressões

| Arquivo | Por que é sensível | Diretriz |
|---|---|---|
| `cardapio-composer-engine.ts` | Contém cálculo, preparação de modelo, solver TS, escala, UL, substituição e propostas; ~2.7 mil linhas | Não refatorar inteiro. Extrair módulos pequenos por função apenas com testes de contrato antes/depois |
| `nutrition.store.ts` | Persiste estado, ações de ingrediente/receita, diário, confirmações de ingestão; ~1.5 mil linhas | Gate na camada de comando; UI sozinha não é segurança |
| `nutrition-calculator.ts` | Constrói todos os totais e cobertura | Não mudar sem goldens de unidades, estados missing/trace e bases por 100g |
| `dri-profiles.ts` | Fonte de recomendações e UL; erros afetam segurança | Cada entrada exige fonte, edição, data, jurisdição, população e forma química |
| `usda-fdc-adapter.ts` (esperado em V11.33+) | Boundary de importação externa | Validar IDs/números/unidades/nomes/base, duplicatas, não finitos, CRC, hash, origem e versão |

---

# 3. Dados: cobertura, qualidade e limitações

## 3.1 Catálogo TBCA V11.28 — verificado diretamente

O manifest da V11.28 identifica:

- Fonte: `Planejamento_Nutricional_Final.xlsx`
- Aba: `TBCA`
- Versão: TBCA 7.2
- Regra de inclusão: `Elegivel_Calculo == 'SIM'` e `Status_Dados == 'OK'`
- 5.830 registros, cada um baseado em 100g
- 5.830 IDs únicos, 9 campos compactos por linha
- Macro vetor com 9 valores: energia, proteína, carboidrato, gordura, base, fibra, gordura saturada, colesterol, sódio
- 20 nutrientes publicados pela planilha
- ausência numérica preservada como `null`/`not_analyzed`; zero numérico continua medido zero

Distribuição por tipo na planilha compacta:

| Tipo da fonte | Registros | Participação |
|---|---:|---:|
| `ALIMENTO` | 2.717 | 46,6% |
| `PREPARACAO_COMPOSTA` | 3.113 | 53,4% |
| **Total** | **5.830** | **100%** |

Esta distribuição foi calculada diretamente do JSON compacto V11.28. A V11.34 histórica relatou o gate que permite apenas `ALIMENTO` como ingrediente, mantendo compostos disponíveis para lançamento direto no diário. A próxima IA deve validar o gate no ZIP que receber.

### Regra semântica obrigatória

- `ALIMENTO` não é sinônimo de “cru”. Um alimento simples pode estar cozido, grelhado, assado ou refogado.
- `PREPARACAO_COMPOSTA` não é ingrediente simples mesmo que o nome pareça curto.
- A classificação oficial `food_type` deve ser um enum fechado e controlado por fonte/versão.
- Nome, busca fuzzy, embedding ou LLM não podem transformar composto em ingrediente.
- Registro sem classificação ou com tipo desconhecido falha fechado para seleção de ingredientes.
- Diário geral pode registrar uma preparação composta como unidade de alimento/refeição completa.

### Limitações da proveniência

O runtime compacto mantém código, nome, grupo, tipo, estado, preparo, URL e valores de nutrientes. Não há, no registro compacto, evidência granular de:

- tamanho da amostra `n`, número de laboratórios;
- média/desvio-padrão/mínimo/máximo e distribuição da análise;
- método analítico por nutriente;
- data de coleta/análise e lote;
- incerteza/erro analítico;
- qualidade de amostra e tratamento pré-analítico;
- componentes completos da receita padronizada para todos os compostos;
- licença/documento de permissão incorporado no pacote.

**Próximo trabalho:** manter catálogo bruto imutável/versionado e manifest estendido com fonte, licença, data, arquivo, aba/linha, URL, método, qualidade, grupo, tipo, estado e hash. Não afirmar que todos os valores do workbook são “laboratório” sem evidência por linha/nutriente.

## 3.2 Cobertura de micronutrientes — snapshot V11.27 e leitura V11.35

O snapshot V11.27 foi gerado para 5.838 entradas (5.836 TBCA + 2 OFF). Ele exigia `data_status=quantified`, unidade normalizada exatamente igual à unidade canônica, valor finito e base positiva. Principais resultados históricos:

| Nutriente | Cobertura agregada V11.27 | Problema |
|---|---:|---|
| Vitamina A | 94,9% | Confirmar RAE e fontes de caroteno/retinol |
| Vitamina C | 98,5–98,6% | Alta cobertura, validar estado e perdas de preparo |
| Vitamina D | 89,9% | Confirmar D2/D3 e base |
| Vitamina E | 93,0–93,1% | Confirmar alfa-tocoferol vs formas totais |
| Vitamina K | 0,1% | K1 não equivale automaticamente a K total |
| B3 (mg NE) | 0% | 5.785 registros em unidade/semântica incompatível; niacina pré-formada não é automaticamente NE |
| B5 | 0,1% | Quase sem dado |
| B7 | abaixo de 0,1% | Quase sem dado |
| B9 DFE | 94,9% | Manter DFE distinto de folato µg e ácido fólico |
| B12 | 97,4% | Cobertura alta agregada |
| Selênio | 82,7% | 1.009 não analisados no snapshot |
| Colina, iodo, cloreto, molibdênio, cromo, fluoreto | 0% | Dados ausentes na base local |

A conversa V11.35 registrou a segmentação dos 2.717 `ALIMENTO`: A 91,4%; C 97,4%; D 86,9%; E 87,6%; K 0%; B1 99,2%; B2 99,1%; B3/NE 0%; B5 0%; B6 98,2%; B7 0%; B9/DFE 91,0%; B12 95,6%; Ca 99,7%; Cu 95,3%; Fe 99,7%; Mg 99,6%; Mn 93,0%; K 99,7%; Se 70,7%; Na 99,4%; Zn 99,6%; colina/iodo/cloreto/Mo/Cr/fluoreto 0%. Estes números são **histórico declarado na conversa**, não reextraídos do ZIP V11.35 nesta sessão.

A IA deve regenerar todos os snapshots do código/fonte atual. Não combinar denominadores de V11.27, V11.28 e V11.35 sem explicar deduplicação, aliases `TITAN_LEGACY`, registros OFF/USDA e tipo alimentar.

## 3.3 Open Food Facts

V11.28 contém somente dois itens curados no adaptador. Isso não é cobertura de branded foods e não é ingestão live. A próxima etapa deve decidir:

1. consulta sob demanda API oficial;
2. cache local com TTL, ETag/Last-Modified e versão;
3. fallback offline;
4. política de correção de rótulo, produto descontinuado e recall;
5. deduplicação por código de barras + país + variante;
6. unidades por porção vs 100g, preparo e produto drenado;
7. licenças/atribuição ODbL/AGPL aplicáveis, examinadas separadamente para software e dados.

Não usar valores de rótulo para completar lacunas analíticas sem marcar a qualidade `label_*` e fonte exata.

## 3.4 USDA FoodData Central

O histórico V11.33 informa que existe um pipeline downloader/parser/importer seguro, mas o catálogo real permanece com zero registros USDA. Os testes sintéticos verificam parser, CRC e persistência; isso não demonstra cobertura real.

Datasets e semântica devem ser mantidos separados:

| Dataset | Fonte/versão citada no portal em 26-11-2026 | Uso adequado |
|---|---|---|
| Foundation Foods | Outubro 2026 | Alimentos pouco processados, amostras analíticas e componentes medidos; manter estatísticas/amostras quando presentes |
| SR Legacy | Abril 2018 | Base histórica consolidada; não tratá-la como release analítico atual |
| FNDDS | Pesquisa alimentar NHANES 2021–2023, release outubro 2024 | Alimentos e bebidas consumidos reportados em recordatórios; inclui composições/receitas e descrições de consumo |
| Branded Foods | Outubro 2026 | Produtos de marca e valores de rótulo; não misturar qualidade com dados analíticos de Foundation |

Tamanhos reportados pelo USDA: Foundation JSON ~681KB zip/9MB extraído; SR Legacy JSON ~12,3MB/205MB; FNDDS JSON ~3,7MB/64MB; Branded Foods muito maior (~187MB/3GB). Medir memory e tempo real antes de optar por importar tudo. Fonte oficial: https://fdc.nal.usda.gov/download-datasets/ e documentação: https://fdc.nal.usda.gov/data-documentation/.

### Especificação do ingest real

- Pin por release, type, URL e SHA-256.
- Downloader com allowlist, redirects controlados, streaming, Content-Length, limites por chunk, Content-Type, HTTPS e host/rota exatos.
- ZIP reader: central directory, CRC32, local header, data descriptors, zip bomb ratio, caminho seguro, file count, uncompressed bytes, duplicate path, symlink, arquivo criptografado, ZIP64 policy e truncated entries.
- Importador: exatamente um JSON de dados esperado por tipo, schema validation por release, tamanho de entrada limitado, parsing stream/NDJSON se aplicável, nenhum `JSON.parse` de vários GB em memória.
- Proveniência: FDC id, dataType, release, food category, modified date, source nutrients exact IDs, number, name, unit, amount, derivation, sample info, publication/source URL.
- Idempotência: reimportar mesma release e hash não reescreve; release diferente gera novo snapshot e delta.
- Quarentena: unidade, ID, número, nome, duplicata, valor inválido, base não igual, ausência e semântica incompatível.
- Não sobrescrever TBCA/OFF nem unir namespaces apenas por nome.
- Rebuild canônico após validation completa; gerar contagem por fonte e food_type e cobertura por nutriente.

### B3/NE — mudança declarada V11.35

O histórico diz que a V11.35 passou a normalizar B3 em mg NE por três caminhos:

1. FDC 409 direto (Niacin equivalent N406+N407), com evidência de origem;
2. FDC 406 + 407 (niacina pré-formada em mg + fração já determinada do triptofano em mg);
3. FDC 406 + 501 (niacina em mg + triptofano em g convertido para mg e dividido por 60).

Fórmula: `mg NE = mg niacina + mg triptofano/60`. Não somar 407 e 501, pois são caminhos alternativos para contribuição do triptofano. Sem 406 e fração suficiente, B3 fica não quantificada; não presumir ausência como zero. Testes V11.35 declarados com fixtures sintéticas, ID/name/unit mismatch, duplicates, overflow, runtime evidence validation.

**Próxima IA deve confirmar** no código que as identidades FDC 406/407/409/501, unidade, nome, base 100g e aritmética são validados no parser e na fronteira de registro runtime. Também deve conferir o nome/URL exatos do nutriente 409 do dicionário FDC que estiver importando. Não confiar somente em número histórico se o permanent ID/name mudou na release.

---

# 4. Revisão científica e cálculos

## 4.1 RMR, BMR, EER, TDEE e troca automática de modelo

### Implementado V11.28

`src/domains/profile/domain/rules/resting-metabolic-rate.ts` contém:

- calorimetria indireta quando `measuredRmrKcal` é fornecido;
- Mifflin–St Jeor (1990) como equação geral padrão;
- Pavlidou et al. (2023);
- Cunningham (1980);
- Katch–McArdle;
- Ten Haaf & Weijs (2014).

O código valida faixa de idade/peso/altura, FFM, % gordura, origem de composição e RMR medido. A função `resolveAutomaticRmrMethod()` retorna calorimetria quando medição existe; sem medição, retorna Mifflin. Equações com FFM e Ten Haaf permanecem escolhas explícitas porque atividade ou FFM isoladamente não provam que o usuário pertence à população de desenvolvimento. Isso é uma decisão conservadora consciente, não bug a ser alterado sem evidência.

### Problemas a fechar

- Distinguir terminologicamente RMR/REE de BMR: equação de repouso não é medida basal clínica.
- A fonte, faixa e população de cada equação precisam acompanhar resultado salvo, junto de versão do método e dados utilizados.
- O seletor automático do método ainda é simples: medição direta > Mifflin. Uma futura seleção automática de equação específica pode ser proposta apenas quando a população de validação, método de composição e nível de evidência forem compatíveis.
- Perfil biológico atualmente usa sexo `male`/`female`; reportar limites de aplicabilidade e não inferir automaticamente variáveis fisiológicas de gênero. Desenvolver fluxo inclusivo com escolha/limite explícito e não inventar coeficiente.
- Falta demonstrar validação externa das equações em brasileiros e nos grupos representados pelo app.
- Medição DXA/BodPod/isótopo e bioimpedância validada não são equivalentes. Guardar método, aparelho, data, preparação e erro; não assumir FFM de uma balança doméstica como DXA.

### EER/TDEE

`goal-calculator.ts` possui equações NASEM 2023 para adultos e categorias de atividade; o `energy-budget.ts` implementa explicitamente:

`TDEE_total = base_expenditure + exercício_NET (somente se base_excludes_exercise)`  
`meta_ingestão = TDEE_total + ajuste_do_objetivo`

Quando a base é NASEM EER ou TDEE que já inclui atividade, exercício não é somado novamente. Essa regra atende o requisito do usuário de considerar metabolismo de repouso + atividade/exercício + ajuste do objetivo sem contar gasto duas vezes. Não confundir calorias ingeridas com calorias de repouso: o RMR é componente do gasto, não uma parcela da ingestão que se adiciona separadamente.

### Gaps prioritários

1. Criar ledger de atividade por sessão: tipo, duração, intensidade, modalidade, gross kcal, net kcal, método, origem (wearable, MET, calorimetria), confiança e duplicação.
2. Reconciliar sessões com nível de atividade/EER: se o gasto médio já está embutido, exibir `already_included`; só adicionar net kcal quando a base é expressamente sem exercício.
3. Não estimar musculação como energia medida. MET de campo é aproximação; distinguir energia bruta/líquida e fontes de erro glicolítico.
4. Criar calibração N-of-1 com intake completo, peso, água/glicogênio, ciclo menstrual quando a pessoa optar, mudanças de treino e doença/medicação que alterem peso; qualquer feature sensível exige consentimento e explicação.
5. Validar contra calorimetria indireta / estudos independentes; medir bias, MAE/RMSE e coverage de intervalos por subgrupo.
6. Intervalo de TDEE Kalman atual é model-based e ainda não calibrado externamente; não chamá-lo de confiança clínica de 95%.
7. Não atualizar automaticamente a meta sem uma regra de aprovação explícita, limites de alteração e janela mínima de dados.

### Hall e adaptação

`hall-body-weight.ts` implementa uma aproximação adulta do modelo Hall 2011: composição corporal inicial, adaptação de gasto, TEF, glicogênio/água e simulação diária, com solver de intake para alvo. `adaptive-energy.ts` usa ingestão confirmada e tendência de peso, mediana de duplicatas, Theil–Sen e Kalman, rejeita outliers >4σ, e marca quando não há cobertura suficiente. É mais sofisticado que regra fixa 7.700kcal/kg, mas não é o NIDDK Body Weight Planner inteiro nem medição individual.

Critérios adicionais:
- Comparar trajetórias com implementação de referência e dataset publicado.
- Cobrir regressões de sub-registro alimentar, semanas incompletas, pesos duplicados, retenção hídrica, mudanças bruscas de carboidrato/sódio e treino.
- Manter medição e estimativa separadas; não treinar/calibrar em dados de usuário sem consentimento e política de privacidade.
- Manter janela adaptativa com cobertura e número mínimo de dias como gate; exibir razões de exclusão e não interpretar dias sem registro como jejum.

## 4.2 Energia diária e metas por objetivo

A fórmula de domínio é adequada estruturalmente, mas a IA seguinte deve conferir no código que todas as entradas de UI e persistidas usam `basis` correto:

- `total_includes_exercise`: EER/TDEE já inclui atividade e exercício; `exerciseAdditionalKcal=0`.
- `base_excludes_exercise`: somente aqui `exerciseNetKcal` obrigatório é somado uma vez.
- `targetIntakeKcal = totalDailyExpenditureKcal + goalAdjustmentKcal`.
- Para emagrecimento, ajuste negativo; manutenção, próximo de zero; ganho, positivo; recomposição depende de uma política explicitamente definida.
- O valor do ajuste não deve exceder regras de segurança ou limites de velocidade sem advertir que são limites de produto, não leis fisiológicas universais.
- Calcular meta final antes de alocar refeições e macros.

### Metas de proteína/gordura/carboidrato

O código de objetivo usa fatores de proteína por goal, peso e piso de gordura (~0,6g/kg) e carboidrato como residual energético. Isso precisa ser revisto por população, idade, tipo de treino, déficit, doença renal/hepática, gestação, lactação e qualidade da proteína. Não tornar o maior número de proteína possível em regra universal. Deve existir:

- faixa sugerida com referência e população;
- unidade (g/d e g/kg/d);
- peso usado (atual, alvo, peso ajustado, FFM) e motivo;
- fonte da equação;
- modo “estimativa geral” e aviso de populações excluídas;
- piso de gordura/macro com justificativa científica;
- reconciliação calórica pós-arredondamento e relatório de infeasibilidade.

## 4.3 Meta diária e alocação de refeições

V11.24+ adiciona meta kcal por refeição a partir da meta diária e porcentagem do slot. V11.28 usa alocações defaults [22, 33, 18, 27] por quatro refeições. Ajuste proporcional aplica um único fator aos ingredientes livres da refeição; ingredientes travados permanecem fixos. Isso preserva a proporção dos alimentos conforme solicitado anteriormente.

Pendências:
- validação soma de shares exatamente 100% (tolerância explícita) e tratamento de refeição adicionada/removida;
- separar “porção proposta”, “quantidade consumida”, “receita base” e “rendimento final”;
- após porções arredondadas, recalcular kcal/macros/micros no valor efetivamente gravado; não reportar só o valor pré-arredondamento;
- se locked ingredients fazem target impossível, explicar item e quantidade que restringem a meta;
- não relaxar alérgenos/limites UL/estado simples só para acertar calorias;
- o otimizador não deve mudar composição sem usuário aceitar a proposta;
- comparar o resultado com alvo diário de calorias e macros após todas as refeições.

## 4.4 DRI, RDA, AI, CDRR e UL

V11.28 contém 29 `NutrientId`s e perfis adultos NASEM, com sexo/idade em algumas faixas. O otimizador:

- RDA/AI como alvo mínimo/penalidade suave;
- CDRR como teto preferencial, não UL;
- UL aplicável como restrição dura;
- metas de micronutriente só entram quando todos ingredientes positivos possuem dado completo na mesma unidade;
- nenhuma ausência/traço/unidade incompatível vira zero.

### Gaps críticos

1. A fonte DRI é rotulada genericamente `DRI NASEM`, versão `1997–2023 · edições por nutriente`; cada entrada precisa ter referência bibliográfica, edição/ano, URL, jurisdição, idade/sexo/população, unidade, forma química, RDA/AI/UL, escopo e status de revisão.
2. Atualmente perfis são adultos saudáveis. Faltam crianças, adolescentes, gestação, lactação e idosos com faixas completas e diferenças comprovadas. Não adicionar até ter fonte por nutriente/população.
3. O perfil amplo `adult_51_plus` guarda algumas referências como `null` quando sexo/idade não permite escolha; isto é preferível a inventar valores, mas a UI deve explicar e guiar o usuário para perfil exato quando houver dados.
4. A regra de UL precisa ser source-specific. UL de niacina e folato, por exemplo, pode se aplicar às formas sintéticas/fortificadas/suplementares, não automaticamente ao total alimentar; UL de magnésio costuma ser específico de suplementos/fármacos. A regra deve ser a da autoridade e forma química, não uma enum simples genérica.
5. Se falta registro de suplemento, fortificação, medicamento ou água relevante, status não pode ser “dentro do UL”; usar `indeterminate/scope_incomplete`.
6. CDRR não é UL e AI não é alvo mínimo com a mesma semântica de RDA; UI e solver precisam rotular corretamente.
7. DRI NASEM dos EUA não deve ser apresentado como recomendação brasileira oficial. Manter perfis por autoridade/jurisdição e dizer qual referência ativa.
8. Valores AI/RDA/UL mudam por atualização da autoridade; exigir data e fonte, e teste contra tabela de referência primária.

## 4.5 B3 / niacina equivalente

A meta DRI é mg NE. A planilha TBCA atual fornece niacina em mg sem triptofano; não é correto simplesmente atribuir mg de niacina pré-formada à meta NE. O histórico V11.35 implementou caminhos USDA 409 direto, 406+407, 406+501. A próxima IA deve auditar:

- nome e ID permanente do nutriente no release FDC;
- número nutricional histórico, nome, unidade e base;
- se FDC 407 já representa contribuição derivada de triptofano;
- se FDC 501 está em g/100g, converter para mg e dividir por 60;
- nunca somar FDC 407 e 501;
- preferência 409 > 406+407 > 406+501;
- se método preferido tem overflow/contradição, não fazer fallback que esconda o erro;
- guardar `derivation/source_evidence`, fórmula, IDs, unidades, valor de cada componente, base, source URL/version;
- revalidar a aritmética na entrada do catálogo runtime;
- zero só se fonte reportou zero medido; falta de componente significa não quantificado.

Aceite: fixtures e dados reais separados; pelo menos 50 alimentos verificados manualmente contra dados FDC; cobertura `mg NE` por `ALIMENTO` publicada; unidade mismatches em quarentena.

## 4.6 DIAAS e qualidade proteica

A primitiva V11.27/V11.28 exige dados apropriados; sem tais dados, não há DIAAS real de catálogo. O cálculo precisa:

- perfil de 9 aminoácidos indispensáveis (11 agrupados com Met+Cys, Phe+Tyr, e histidina, isoleucina, leucina, lisina, treonina, triptofano, valina) em mg/g proteína;
- digestibilidade ileal específica por aminoácido, não digestibilidade genérica da proteína;
- espécie, método (true/standardized ileal), fase/idade, alimento, estado/processo, amostra e fonte;
- padrão de referência FAO por fase da vida e sua versão;
- identificar aminoácido limitante;
- lisina reativa para alimentos/processos onde reação de Maillard pode reduzir biodisponibilidade;
- resultado de alimento único pode exceder 100; dieta mista pode ter teto de 100 na apresentação e preservar bruto;
- fallback para suínos só com indicação explícita de evidência animal e hierarquia aceita; não igualar dado humano e animal.

Pendência: adquirir dataset de perfil de aminoácidos/digestibilidade com licença e identidade compatíveis, e validar exemplos publicados; até lá, DIAAS permanece unavailable/insufficient_data.

## 4.7 Cozimento, rendimento e retenção

O motor V11.28 possui transformador evidence-gated `derivePreparedFoodComposition()`. Exige ID/state exatos, prepared state, method, weight yield factor, proveniência e fatores separados de macros e micronutrientes.

Não confundir:
- `EP` (edible portion): parte efetivamente comestível após refugo;
- `YF` (yield factor): peso cozido final / peso inicial, conforme convenção documentada;
- `TRF` (true retention factor): fração do nutriente retida em peso e concentração; pode ser >1 em bases aparentes/água perdida, mas precisa método e definição;
- `apparent retention`: fórmula pode parecer concentrar por perda de água, diferente de retenção total;
- `water/fat gain/loss`: água absorvida/perdida e gordura adicionada/perdida alteram denominador/densidade;
- fator por nutriente não deve ser aplicado ao outro nutriente nem a macros quando fonte é tabela de micronutrientes.

Próximas entregas:
1. Dataset versionado de yield por alimento, corte, parte, método, equipamento, tempo, temperatura, lote e condição.
2. Dataset de true retention por nutriente, alimento, método e fonte.
3. Crosswalk da matéria-prima exata TBCA/FDC; cru não é automaticamente igual a cozido em mesmo nome.
4. Receita composta: ingredient weights raw/EP, água/óleo/sal adicionados, yield final, rendimento por porção, peso final medido.
5. Balanceamento de massa, validação de limites e propagação de incerteza.
6. Comparar composição calculada com alimentos/receitas analisados laboratorialmente.

Nenhum cálculo cru→cozido deve ocorrer com fator universal ou ausência de evidência.

---

# 5. Otimização, solver e planejador

## 5.1 Daily QP / MIP

V11.28 possui `highs-lp-builder.ts`, `highs-nutrition-solver.ts`, worker e fallback TS:

- HiGHS carrega WASM de `/wasm/highs.wasm`;
- QP e MIP são limitados a 2 segundos por solve;
- relaxa faixas macro externas somente quando corridor é inviável, mantendo hard UL e outras regras;
- status diferente de `Optimal` retorna fallback TS;
- fallback: Projected FISTA + coordinate polish, projeções de box bounds e UL, residual KKT aproximado;
- swap por slot e combinação discreta MIP.

Gaps:
- HiGHS WASM não teve execução real comprovada na sessão V11.28; a conversa V11.35 também deixou runtime WASM não verificado.
- O solver Worker client não declara, no código V11.28 consultado, um timeout por request, cancelamento/AbortSignal e política explícita para request stale. `pendingRequests` precisa sempre limpar no sucesso, erro, `messageerror`, `onerror`, timeout, desmontagem e erro ao postar.
- O worker captura falhas e faz fallback; é bom para resiliência, mas pode ocultar a falha do backend sem telemetry. A resposta precisa trazer engine/status/fallback reason/duration/constraint warnings.
- Candidatos MIP devem passar pelo mesmo gate de ingrediente/receita da busca e store (V11.34 histórico); confirme que os 6 templates legacy não entram no set de candidatos.
- A saída deve mostrar `Optimal`, `Feasible`, `TimeLimit`, `Infeasible`, `Fallback` como estados distintos; não rotular qualquer proposta como ótima.
- Validar tolerância numérica, escala/unidades, limites mínimos/máximos, integralidade, arredondamento de 0,5g, lock status, UL e consistência final recalculada.
- O resultado final após arredondamento precisa reavaliar UL; se exceder, bloquear a aplicação (V11.28 e V11.34/35 histórico dizem haver gate).

## 5.2 Planejamento multidiário

Atual: otimizador principal por dia e troca por slots. Ainda não há demonstração de um solver integrado 7/14/28 dias.

Especificação proposta:
- Variáveis binárias `x[d,meal,recipe]`, contínuas `q[d,meal,ingredient]`;
- variáveis de compra `buy[f]`, estoque `stock[d,f]`, consumo `use[d,f]`, preparação em lote e desperdício, se houver dados de custo/estoque confiáveis;
- hard constraints: alergia, intolerância, segurança, disponibilidade, receita elegível, UL aplicável e massa por porção;
- macro/energia como target bands/soft deviations, não constraints absolutas se fisiologicamente possível variar;
- restrições semanais de repetição/frequência e limite de servings por food group;
- preferência, custo, variedade, tempo de preparo, reaproveitamento de ingrediente e desperdício como objetivos lexicográficos;
- `CP-SAT` para combinação discreta/agenda; `HiGHS MIP/LP/QP` para quantidades contínuas; estudar decomposição mestre/subproblema se instância crescer;
- `Pareto frontier`, penalidades e pesos precisam ser explicáveis;
- infeasibilidade com unsat core/IIS ou relaxação sequencial em objetivos soft apenas; nunca relaxar alergia/UL para obter solução.

Repositório candidato: Google OR-Tools (Apache-2.0, 14,459 stars snapshot 26-11-2026). HiGHS permanece opção atual (MIT, 1,953 stars). Não integrar ambos sem benchmark com cardápios reais e execução WASM/runtime.

## 5.3 Otimização com incerteza

Próxima etapa científica (não P0): composição de alimento tem erro/intervalo. Hoje o solver trata cada coeficiente como exato. Para alimento com baixa confiança, um plano pode parecer ótimo mas ser nutricionalmente não ótimo.

Avaliar:
- robust optimization com intervalos por nutriente/alimento;
- chance constraints somente se distribuição/variância tiver suporte real;
- interval sensitivity para resultados que mudam muito com fonte;
- penalidade por baixa evidência versus penalidade por distância macro;
- não inventar variância quando a tabela não publica desvio-padrão.

---

# 6. Receita, alimento composto e associação

## 6.1 Regra de elegibilidade

V11.28 compact TBCA inclui 2.717 `ALIMENTO` e 3.113 `PREPARACAO_COMPOSTA`. O histórico V11.34 informa que foi criada uma política `food-ingredient-policy.ts` para aceitar TBCA `ALIMENTO`, bloquear `PREPARACAO_COMPOSTA` e tipo desconhecido; busca geral/diário ainda mostra composto. Store deve validar a mesma condição, e não confiar na UI.

No V11.34 histórico, os aliases foram corrigidos:
- `tbca-ovo-mexido` -> `BRC0065J`;
- `tbca-pao-integral` -> `BRC0149A`;
- `tbca-banana-prata` -> `BRC0011C`.

Três meals locais passaram a `TITAN_LEGACY`, `unverified`, `PREPARACAO_COMPOSTA`:
- `tbca-mamao-aveia`;
- `tbca-frango-arroz-legumes`;
- `tbca-salmao-batata-doce`.

Seis modelos de receita (de 8) com refeição composta em linha foram bloqueados para novas seleções/substituições; 2 permanecem selecionáveis. Conferir no source recebido. Nunca reconstruir gramas por conjectura.

## 6.2 Crosswalk de alimentos

O problema de identidade não se resolve com fuzzy search apenas. A associação TBCA ↔ USDA ↔ OFF precisa considerar:
- taxonomia/espécie;
- parte (polpa, folha, peito, coxa, corte etc.);
- estado (cru/cozido/assado/grelhado/desidratado);
- método, tempo, temperatura, gordura/água/sal adicionados;
- porção comestível e refugo;
- categoria simples/composta;
- base e unidade;
- nutrientes comparáveis (com incerteza e sem forçar match quando há divergência);
- nome original, sinônimos, idioma, termos regionais, rótulo e fabricante.

Stack metodológica:
1. Normalização ortográfica (Unicode NFKD, diacríticos, caixa, pontuação) preservando original.
2. Facets LanguaL / FoodOn URI para descritores semânticos.
3. Hard blocking por `food_type`, grupo/taxonomia, parte, estado e método antes de qualquer ranking.
4. Candidate generation por nome/sinônimo e taxonomia.
5. Matching probabilístico Fellegi–Sunter (Splink) com m/u probabilities, term frequency adjustment, prior probability e comparação multissinal.
6. Calibração em pares rotulados: precisão/recall, limiar de autoaceite, revisão humana, rejeição.
7. Decision provenance: modelo/versão, atributos, scores, fonte, reviewer, decisão, timestamp e razões.
8. IDs das fontes nunca são fundidos; criar canonical concept ID separado e arestas `sameAs/relatedTo/derivedFrom`.

Fuse.js serve como fuzzy search de UX, depois dos hard gates. Não usar embeddings/LLM para aprovar associação automaticamente.

---

# 7. Persistência, ingestão e segurança

## Persistência do usuário

- `nutrition.store.ts` usa Zustand persist local; V11.5 já declara local browser persistence, sem backup cloud/sync.
- Confirmar storage quota/rehydrate/migration com navegador real.
- Implementar export/import versionado (JSON assinado/hash, schemaVersion, manifest, cópia dos IDs de fonte e data), validação Zod strict e preview antes de confirmar.
- Restaurar em outro browser/perfil e fazer diff antes de mesclar.
- Snapshot atômico e backup; não misturar estado vivo com artefatos imutáveis.
- Alimentos removidos/renomeados: manter snapshot histórico imutável ou migrar com relatório; nunca apontar para food_id diferente silenciosamente.
- Chaves antigas e planos históricos compostos permanecem visíveis; new-entry policy separada de history display.

## Ingestão/atualização de fontes

- Dataset acquisition plane separado do runtime de nutrição.
- Manifest por release, fonte, licença, data, URL, hash, schema version, data type, contagens, rejected/quarantine, runtime catalog hash.
- Pipeline raw immutable -> parse -> validate -> canonicalize -> coverage -> human review -> promote; promoção com hash, atomic write and rollback.
- Reimport idempotente, no-op identical hash, new immutable version on data change.
- `source_id` namespace; no overwrite entre TBCA/OFF/FDC.
- Dados comerciais, rótulos e open data precisam de política de licença/atribuição específica.

---

# 8. Top repositories by function — stars/licences snapshot 26-11-2026

**Observação:** estrelas são apenas descoberta/popularidade; não são prova científica, de qualidade de código, segurança ou adequação. Licença do código e licença do dataset são independentes. Não copiar código sem revisão de licença; alguns projetos são AGPL/GPL, e alguns repositórios retornaram `NOASSERTION`.

## 8.1 TypeScript, schemas, testing, code quality

| Repositório | Stars | Licença | Funcionalidade | Decisão para TITAN |
|---|---:|---|---|---|
| [Microsoft TypeScript](https://github.com/microsoft/TypeScript) | 111,908 | Apache-2.0 | Checker/compilador/tipos | Manter strict TS; reforçar tipos discriminados para alimento/fonte/estado |
| [Zod](https://github.com/colinhacks/zod) | 44,423 | MIT | Runtime schema validation | Já está no projeto; usar strict parsing para ingestões, storage, APIs e importações |
| [Biome](https://github.com/biomejs/biome) | 26,216 | Apache-2.0 | Lint/formatter | Candidato para CI global; não migrar o repo todo sem baseline |
| [Vitest](https://github.com/vitest-dev/vitest) | 17,459 | MIT | Unit/integration tests | Já compatível com Vite; se for adotado no lock, organizar suite TSX e mocks de worker |
| [ast-grep](https://github.com/ast-grep/ast-grep) | 16,708 | MIT | AST search/rewrite/rules | Regras para impedir imports cross-domain e busca geral em seleção de ingredientes |
| [Semgrep](https://github.com/semgrep/semgrep) | 17,959 | LGPL-2.1 | Variant analysis/static security | CLI externa pode ser avaliada; revisar licença antes de integração/cópia |
| [fast-check](https://github.com/dubzzz/fast-check) | 5,322 | MIT | Property-based testing | Adicionar invariantes para units, overflow, duplicates, states, order permutations |

## 8.2 Nutritional food data / recipes / inventory

| Repositório | Stars | Licença | Área de interesse | Decisão |
|---|---:|---|---|---|
| [Mealie](https://github.com/mealie-recipes/mealie) | 13,995 | AGPL-3.0 | Recipe manager/meal planner | Referência de UX, receitas, yield, planejamento; não copiar código AGPL |
| [Grocy](https://github.com/grocy/grocy) | 9,710 | MIT | Estoque, unidades, pantry, expiração | Referência para inventory/portion/unit conversion; sem runtime PHP |
| [wger](https://github.com/wger-project/wger) | 7,326 | AGPL-3.0 | Fitness/workout/nutrition logs | Referência de modelo de domínio; sem cópia AGPL |
| [OpenNutriTracker](https://github.com/simonoppowa/OpenNutriTracker) | 3,035 | GPL-3.0 | Food diary/nutrient tracking | Referência UX; sem código GPL |
| [Open Food Facts server](https://github.com/openfoodfacts/openfoodfacts-server) | 1,219 | AGPL-3.0 | Branded database/API | Provider/data reference; license/data terms separate |

## 8.3 Optimization, LP/MIP/CP-SAT/QP

| Repositório | Stars | Licença | Área de interesse | Decisão |
|---|---:|---|---|---|
| [Google OR-Tools](https://github.com/google/or-tools) | 14,459 | Apache-2.0 | CP-SAT, routing, scheduling, integer optimization | Melhor candidato para 7/14/28-day combinatorial planning se benchmark justificar |
| [CVXPY](https://github.com/cvxpy/cvxpy) | 6,402 | Apache-2.0 | Declarative convex optimization | Referência de modelagem, Python não é substituto direto do browser TypeScript |
| [Pyomo](https://github.com/Pyomo/pyomo) | 2,566 | NOASSERTION | Algebraic optimization modelling | Sem adicionar até licença e deployment estarem claros |
| [HiGHS](https://github.com/ERGO-Code/HiGHS) | 1,953 | MIT | LP/QP/MIP solver | Já está integrado; validar WASM real antes de trocar |

## 8.4 Matching, ontology, fuzzy UX

| Repositório | Stars | Licença | Área de interesse | Decisão |
|---|---:|---|---|---|
| [Fuse.js](https://github.com/krisk/Fuse) | 20,538 | Apache-2.0 | Fuzzy text search | UX typo-tolerance após hard gates; não decide food identity |
| [RapidFuzz](https://github.com/rapidfuzz/RapidFuzz) | 4,220 | MIT | String distances (Python) | Offline candidate scoring/benchmark, não runtime TS |
| [Splink](https://github.com/moj-analytical-services/splink) | 2,604 | MIT | Probabilistic record linkage/Fellegi-Sunter | Crosswalk TBCA↔USDA; offline with labels and calibrated thresholds |
| [FoodOn](https://github.com/FoodOntology/foodon) | 250 | CC-BY-4.0 | Food ontology, raw/processed concepts | Semantic URI reference, not replace TBCA `food_type`; verify version and attribution |

## 8.5 Data quality / monitoring / prompts

| Repositório | Stars | Licença | Aplicação | Decisão |
|---|---:|---|---|---|
| [Evidently](https://github.com/evidentlyai/evidently) | 8,083 | Apache-2.0 | Data/drift quality monitoring | Reference for dataset-vintage drift after real data baselines; avoid Python runtime in browser |
| [whylogs](https://github.com/whylabs/whylogs) | 2,838 | Apache-2.0 | Data profiling | Reference only; inspected repo had low recent activity (last push Jan 2025) |
| [Soda Core](https://github.com/sodadata/soda-core) | 2,463 | NOASSERTION | Declarative data contracts/checks | Do not reuse until license resolved; current audit scripts are enough |
| [Dair AI Prompt Engineering Guide](https://github.com/dair-ai/Prompt-Engineering-Guide) | 80,379 | MIT | Prompt/context engineering, RAG and AI agents | Use for task framing only; handoff prompt in this report is domain-specific and must require evidence per claim |

### Stack decision summary

Do **not** install all of these. Keep the existing React/TypeScript/Zustand/Zod/HiGHS architecture. Candidate additions should be gated:
- `fast-check`: small devDependency for high-value invariants if lockfile/CI can install cleanly;
- `ast-grep`: CI-only rules for architecture and ingredient eligibility;
- `Vitest`: retain existing runner unless moving TS tests justifies it;
- `OR-Tools`: only after a benchmark shows current HiGHS/TS approach fails multiday planning constraints;
- `Fuse.js`: only UI search typo tolerance after semantic eligibility and source filtering;
- `Splink`: offline crosswalk model, not app runtime;
- `Evidently`: offline/reporting only after real data vintage.
No new search/embedding/LLM package should govern nutritional identity or nutrient calculations.

---

# 9. Deep technical glossary by subsystem

## Food identity and provenance
- **Entity resolution:** determine whether two source records refer to same food concept; preserve source-specific facts.
- **Blocking:** reduce candidate comparisons using taxonomy/type/part/state, before textual matching.
- **Fellegi–Sunter:** probabilistic record linkage using m/u probabilities; calibrate thresholds using labeled true/false pairs.
- **Term-frequency adjustment:** common terms (e.g. “rice”) carry less discriminative information than rare descriptors.
- **LanguaL facets:** structured descriptors for product type, source, part, physical state, process, preservation, container/medium and use.
- **FoodOn CURIE/URI:** normalized ontology concepts; keep ontology version and do not replace source IDs.
- **Source assertion vs canonical concept:** TBCA code and USDA FDC ID remain immutable; canonical ID is a separate graph node.
- **Evidence lineage:** source file, hash, release, date, dataset, raw row, transformations, reviewer and promoted snapshot.

## Nutrient chemistry / units
- **Analyte identity:** exact form of nutrient (retinol, RAE, folate, DFE, folic acid, alpha-tocopherol, K1, total K, preformed niacin, niacin equivalent).
- **Canonical unit:** exact unit + denominator (mg/100g, µg DFE/100g, mg NE/100g); number alone is meaningless.
- **Chemical species normalization:** retain form-specific data; combine only when authority and stoichiometry permit.
- **Reported vs derived vs imputed:** distinct conversion provenance states; imputed must never masquerade as measured.
- **Censoring/trace:** value below quantification limit is not zero; retain detection limit and status if source supplies it.
- **Basis conversion:** 100g edible portion, dry matter, per serving, per protein gram, cooked weight—must be transformed only with known denominator.
- **Uncertainty propagation:** carry analytical variability or interval only when the source supplies it; never invent a standard deviation.

## Recipe and food preparation
- **EP:** edible portion after waste/refuse.
- **YF:** cooked yield factor; final prepared mass / raw edible mass under explicit convention.
- **TRF:** true nutrient retention (total nutrient amount after process / before process), not the same as concentration.
- **Apparent retention:** may exceed 100% due concentration/water loss; label method.
- **Mass balance:** raw ingredients, refuse, water/fat/salt additions/losses reconcile to final batch weight.
- **Recipe composition graph:** ingredient identity, quantity, source, unit, edible portion, processing, subrecipe and final yield.
- **Process-aware transform:** separate transformations for nutrients, weight and chemical changes.

## Protein quality
- **IAA:** indispensable amino acids.
- **DIAA:** digestible indispensable amino acid amount per gram protein (amino acid-specific ileal digestibility × amino acid amount).
- **DIAAS:** 100 × minimum ratio of DIAA to the life-stage reference pattern; preserve limiting IAA and pattern version.
- **True ileal vs standardized ileal:** distinct coefficients/methods; do not mix without declared methodology.
- **Reactive lysine:** critical when processing can damage lysine; total lysine may overestimate bioavailable lysine.
- **Matrix-specific digestibility:** raw, cooked, extruded, isolated protein and fermented food are not necessarily comparable.

## DRI/UL and safety
- **EAR/RDA/AI:** distinct intake reference meanings; AI is not an RDA and below AI is not automatically deficiency.
- **UL:** tolerable upper intake; source scope/form chemistry must follow authority.
- **CDRR:** chronic disease risk reduction level, not UL; keep separate.
- **Usual intake:** long-term exposure distribution, not a single meal/day snapshot.
- **Scope-complete exposure:** food, fortified food, water/beverages, supplements/medication as the UL requires; else status `indeterminate`.
- **Authority/jurisdiction/age-stage:** part of each reference, not global constants.

## Energy and optimization
- **RMR/REE vs BMR:** resting estimation vs stricter basal measurement protocol.
- **EER/TDEE:** total daily expenditure; NASEM EER already includes activity.
- **Net vs gross exercise energy:** gross includes resting energy during exercise; avoid double count.
- **Adaptive TDEE:** observational inference from complete intake + aligned weight trend; not measured calorimetry.
- **State-space/Kalman:** latent TDEE state, measurement/observation variance, process noise, robust residual/outlier policy.
- **N-of-1 calibration:** within-person time-series calibration with explicit uncertainty and confounders.
- **QP:** continuous convex optimization for ingredient grams.
- **MIP:** binary/integer selection of recipes/slots.
- **CP-SAT:** constraint programming for discrete, multi-period meal assignment.
- **Lexicographic objectives:** satisfy safety/hard constraints first, then macro, variety, cost, convenience in ordered levels.
- **IIS/unsat core:** explain conflicting constraints instead of silently relaxing them.
- **KKT residual/gap:** diagnostics for numerical optimizer quality; do not call a solution optimal from status alone if post-processed portions violate constraints.
- **Robust optimization:** optimize with known coefficient intervals; only if uncertainty intervals are actually supported by data.

---

# 10. Implementation roadmap for the next AI

The next AI must make small, testable commits. Do not execute everything in one rewrite.

## Phase 0 — Establish current truth (P0, no code modifications until complete)

**Tasks**
1. Inspect user-provided current ZIP/source. Record version, Git SHA, ZIP SHA, working tree, Node/Bun, lockfile, `AGENTS.md`.
2. Compare with V11.28 baseline and identify changes after V11.28. If V11.35, verify the B3, TBCA eligibility and coverage split from source.
3. Read all `CHANGELOG_V11_*`, `docs/superpowers/specs`, `plans`, `research`, `quality`, generated coverage JSON.
4. Build a file-level feature inventory: implemented, tests, data, execution, external validation.
5. Run baseline tests before modifying code; keep raw output.

**Acceptance**
- A commit/file/line trace for every item the AI claims already exists.
- No feature status inferred from an earlier assistant message.
- No modifications until source version and baseline are established.

## Phase 1 — P0 safety, data eligibility, and source ingestion

### WP-1: enforce simple-vs-composite food eligibility everywhere

**Likely files**
- `src/domains/nutrition/domain/entities/nutrient.ts`
- `src/domains/nutrition/data/sources/tbca-adapter.ts`
- `src/domains/nutrition/domain/rules/food-ingredient-policy.ts` (expected V11.34+)
- `src/domains/nutrition/domain/rules/food-search.ts`
- `src/domains/nutrition/domain/rules/recipe-engine.ts`
- `src/domains/nutrition/domain/rules/cardapio-composer-engine.ts`
- `src/domains/nutrition/state/nutrition.store.ts`
- composer UI, catalog browser, recipe search, substitution paths

**Required behavior**
- closed enum `ALIMENTO | PREPARACAO_COMPOSTA | UNKNOWN` at TBCA parser boundary;
- fail-closed `UNKNOWN` for recipe ingredients;
- filter before search ranking and limit;
- guard store/application commands and direct ID actions;
- guard new recipe templates, substitutions, MIP candidate list and automatic proposals;
- diary/general catalog may continue to use composed items as complete foods;
- keep persisted historical records but hide/disable invalid ones in new composition flows;
- aliases preserve historic food_id while mapping to exact canonical source code with provenance;
- no regex on name as source of truth.

**Tests**
- all TBCA ALIMENTO can be candidate; every PREPARACAO_COMPOSTA blocked for ingredient paths;
- missing/unknown type blocked;
- general search and diary still allow prepared dishes;
- direct store calls blocked;
- MIP candidate generation and automatic substitutions blocked;
- all 8 templates and all recipe lines audited; preserve 6 historical blocked templates if V11.34 is verified.

### WP-2: USDA FDC real ingestion

**Files expected**
- `scripts/download-usda-fdc.mjs`
- `scripts/import-usda-fdc.mjs`
- `scripts/lib/usda-fdc-archive.mjs`
- `scripts/lib/usda-fdc-download.mjs`
- `src/domains/nutrition/data/sources/usda-fdc-adapter.ts`
- generated source catalogs, manifests, coverage reports

**Release order**
1. Foundation Foods Oct 2026 (small first vertical slice).
2. SR Legacy Apr 2018.
3. FNDDS 2021–2023.
4. Branded Foods only after scale/memory/duplicate/label license decision; not a prerequisite for first reliable dataset.

**Acceptance**
- download exact official release and hash;
- archive parser/security gates pass on both real file and fixtures;
- count rows and compare expected manifest/data type, duplicates, quarantined rows;
- import exact source data types separately;
- benchmark peak RSS, duration, temp space, throughput;
- register actual foods in catalog with no cross-source overwrite;
- coverage by nutrient, source, category, and simple/composite food type;
- reimport idempotently; new version produces immutable delta;
- test final ZIP clean extraction and rebuild.

### WP-3: License and TBCA source strategy

1. Keep current user workbook / TBCA 7.2 until 7.3 use is legally clarified.
2. Contact TBCA/FoRC coordinator to obtain written authorization for the use and distribution intended by TITAN.
3. Verify whether local/private processing, commercial app computation, output values, redistribution and derivative catalog are each allowed.
4. Preserve license and attribution per release in manifest.
5. Do not distribute TBCA 7.3 JSON or derived catalog if terms don't permit it.
6. If licensed, acquire via official route, hash original, record release version, inspect data and schema differences.

### WP-4: full CI/build/solver runtime

1. Use the exact lockfile/runtime (V11.28 is Bun-based; later package must be checked).
2. Install in clean environment; do not make a second npm/pnpm lockfile to bypass Bun.
3. Run `npm/bun run lint`, full build, full test and browser E2E.
4. Load actual `highs.wasm` in browser worker.
5. Test solver status, fallback, timeout, post-rounding, UL hard limits, cancellation and stale request handling.
6. Benchmark mid-tier mobile INP and worker latency with realistic recipes.

## Phase 2 — P1 nutrient data and scientific semantics

### WP-5: reference registry redesign

Replace broad labels with versioned reference records:
- authority (NASEM, NIH ODS, EFSA, ANVISA, FAO, etc.);
- jurisdiction;
- publication/review year and source URL;
- age band, sex/reference grouping, pregnancy/lactation, life-stage;
- nutrient identity, form, unit, denominator;
- RDA/AI/EAR/UL/CDRR semantics;
- UL scope/source restriction;
- whether guidance is established, not set, not applicable or out of scope;
- exact evidence/version and reviewer.

Do not set pediatric/pregnancy profiles until values for each nutrient/phase are sourced and reviewed. A value is not valid because another profile exists.

### WP-6: UL total-exposure ledger

Add separate source events/records for:
- foods and recipe ingredients;
- fortified products;
- beverages/water/fluoridated water;
- supplements (dose, chemical form, frequency, label and source);
- medications/therapeutic use when user chooses to enter it;
- other source scopes defined by the nutrient authority.

Compute total/limited exposure according to specific UL scope. If missing supplements, medicine or water input is material, report `indeterminate` rather than “safe/below UL”. Hard UL constraints enter optimizer only when scope-complete and chemical-form-compatible. CDRR remains preference soft, not UL.

### WP-7: nutrient coverage expansion

Target currently uncovered/near-zero nutrients: K, B3/NE, B5, B7, choline, iodine, chloride, molybdenum, chromium, fluoride; improve selenium and other gaps.

For each source candidate:
- dataset license/use;
- country and food system representation;
- food identity, simple/composite type, state, preparation;
- analyte identity/form, unit, basis, method, sample count, date, lab source;
- source quality / label vs analytic vs derived;
- API/files version, update cadence and hash;
- coverage by `ALIMENTO` not only total catalog;
- avoid creating a false total if source measures only partial forms (e.g. K1 vs total K).

### WP-8: niacin equivalent and other chemically derived nutrients

Reconfirm V11.35 B3 FDC map and runtime evidence. Then extend chemistry mapping only where authoritative formulas are exact.

Do not normalize different analytes just because names are similar. For each conversion define:
- canonical nutrient/form;
- exact input nutrient IDs/names/units and denominator;
- formula/coefficients;
- valid component combinations and precedence;
- which components are alternative representations;
- rounding/precision;
- evidence in output and runtime revalidation;
- quarantine reasons and data coverage status.

### WP-9: food crosswalk (TBCA ↔ FDC ↔ OFF)

- Build offline matching dataset, not production auto-merge at first.
- Use FoodOn/LanguaL facets and taxonomy.
- Blocking: type, species/group, part, state, method.
- Pair comparison: canonical name, synonyms, descriptors, macros and nutrients on comparable units/bases.
- Train/calibrate Fellegi–Sunter/Splink on manually labeled pairs.
- High precision accept band, human review band, reject band.
- Keep source IDs immutable and canonical concepts separate.
- Evaluate precision/recall and false positives for each group.

### WP-10: preparation yield/true retention dataset

- Acquire official yield data and USDA retention tables.
- Do not treat Food Buying Guide yield as nutrient retention.
- Use distinct tables for edible portion, yield, macro retention, micronutrient retention.
- Crosswalk exact food/source/state/method.
- Process details: raw weight, refuse/EP, added ingredients, water/oil loss, cooked/final weight, method/time/temp.
- Keep direct measured cooked-food entry when available; do not overwrite with derived raw conversion.
- Include uncertainty and quality level.

### WP-11: DIAAS

- Acquire AA profile per food in mg/g protein.
- Acquire per-AA ileal digestibility with food, matrix, preparation, species, age, test method, sample, reference.
- Add life-stage-specific FAO/NASEM/authority reference pattern.
- Add reactive lysine data for thermal/processed foods where needed.
- Calculate digestible IAA, limiting AA, DIAAS with untruncated value and display cap only for mixed-diet convention.
- Missing AA/digestibility => `insufficient_data`; no partial score.
- Reproduce published examples and independent calculations.

## Phase 3 — P1 energy, personalization and meal integrity

### WP-12: energy-model selection and adaptation

- Keep measured indirect calorimetry highest priority.
- Default equation should be population-valid; current Mifflin default is conservative but not personalized.
- Only switch to FFM equations when FFM method, population, age and equation scope are compatible.
- Do not automatically use Ten Haaf just because “high activity”; its development population is recreationally active 18–35, ~9h/week.
- Add equation evidence and warning to stored goal calculation.
- Validate EER PAL categories vs user's actual activity data; current UI level is self-report, not measured PAL.
- Keep `TDEE = RMR + non-resting residual` as reconciliation output, but don't compute from mixed sources without a declared accounting basis.
- Maintain exercise net/gross ledger and no-double-count guard.
- Adaptive TDEE: require complete intake, coverage, daily weights aligned with dates; robust outlier handling; add confounders (water/glycogen, cycle when user consents, illness, training changes) and explicit unknown status.
- Calibrate intervals with external N-of-1 datasets; don't call model-based 95% interval clinical confidence.
- No automatic goal shifts without confirmation and bounded rate.

### WP-13: macro targets and medical/personal constraints

- Protein g/kg basis must be explicit: actual weight, target weight, adjusted weight, FFM; choose by population/evidence.
- Validate protein/fat floors and carb residual under goal and body size.
- Pregnancy/lactation, renal disease, diabetes, eating disorder, adolescent, older frailty, drug interactions and medical diets are out of the general algorithm unless reviewed by specialists.
- Allergen/intolerance/religious/ethical/medical constraints as hard constraints, not weighted preferences.
- Cross contamination/trace and ingredient-list completeness required for packaged products.
- Show why constraints change feasibility and never silently relax hard safety restrictions.

### WP-14: recipes and user recipes

- Rebuild blocked sample recipes only with verifiable source and quantities.
- Model recipe as graph with subrecipes, ingredient amounts, units, EP/refuse, optional ingredient/taste, preparation steps, cooked weight and servings.
- Link ingredient records to source and exact `FoodSourceId/food_type`.
- Show source quality and coverage per nutrient/recipe.
- Food composed prepared dish may be used as a diary item but not silently unpacked into ingredients without a recipe specification.
- Provide date/serving conversions and user-entered cooked yield.

## Phase 4 — P2 planning and system maturity

### WP-15: multiday menu planning

- Add 7/14/28-day discrete scheduling with CP-SAT or MIP.
- Candidate meals are only eligible verified recipes.
- Hard constraints: allergies, safety, UL complete, availability, nutrition coverage, portion bounds.
- Soft goals: macro ranges, cost, time, variety, frequency, inventory, batch cooking, repeated meals.
- Multiobjective lexicographic priorities; hard constraints never relaxed.
- Infeasible plan should produce clear reason/unsat core/IIS if solver supports; suggest which soft preferences to change.
- Benchmark OR-Tools vs current HiGHS with real workloads before adopting second solver.

### WP-16: search and discovery

- Keep deterministic food_type/source/identity filters before ranking.
- Add search synonyms and typo tolerance only as UX assistance; user confirms source record.
- Track search telemetry (query, zero results, user correction) without sensitive personal details where possible.
- No semantic search is allowed to match composite dish as ingredient.

### WP-17: persistence, backup, and synchronization

- Versioned export/import package with source refs and integrity checks.
- Schema migrations and stale-ID resolution with audit log.
- Backup/restore across browser/device; test storage quota and corrupted storage.
- If remote sync is later built, specify conflict resolution/merge semantics and use a real backend; don't add TanStack Query until there is remote server state.

### WP-18: observability / explainability

Every proposed value should explain:
- which source rows are involved;
- source quality and data status;
- exact calculation formula and units;
- data missing/ignored/quarantined;
- optimizer constraints applied, ignored, relaxed and infeasible;
- solver name/status/time/fallback;
- goal/RMR/TDEE method and reason for method selection;
- warnings and external validity limits.

### WP-19: automated engineering gates

- Strict TypeScript, `noUncheckedIndexedAccess`, no unsafe any, discriminated unions.
- Zod strict external schemas.
- fast-check property tests for nutrient units, negative/NaN/Infinity, duplicate order, overflow, missingness, and recipe eligibility invariants.
- ast-grep/ESLint architecture rules: no bypass of food eligibility, no source cross-import, no raw search in ingredient flow, no missing provenance in source adapters.
- Mutation testing for hard gates (UL, composite exclusion, zero/missing, units, aliases, source identity).
- Golden fixtures with versioned FDC/TBCA rows.
- Differential calculation tests against hand calculation / reference implementations.
- Full browser tests, worker error and timeout tests, performance profiling on mid-tier mobile.
- SBOM/lockfile scan, dependency/license audit, code signing/hash release artifact.

### WP-20: clinical/scientific validation

- Independent nutrition scientist/nutritionist review of algorithms, DRI values, formulas, reference populations and UI.
- Validation protocol for RMR/TDEE, food portion estimates, recipe composition and nutrient totals.
- Compare against indirect calorimetry, lab data or official data as appropriate.
- Pre-register success metrics and subgroups; measure bias/MAE/RMSE, interval coverage, false safe/unsafe UL flags and missingness.
- Clearly distinguish analytical, calculated, estimated and user-entered values.
- No “clinically validated” badge until independently documented evidence exists.

---

# 11. Recommended execution order and dependencies

| Order | Work package | Blocks/depends on | Exit gate |
|---:|---|---|---|
| 0 | Current ZIP baseline verification | User provides actual current binary | Version/SHA/source tree established |
| 1 | V11.34/V11.35 composite + NE code audit | WP-0 | Every claimed feature confirmed by code/test or marked pending |
| 2 | Full CI/build/HiGHS runtime environment | WP-0 | Build/lint/full tests/WASM clean run |
| 3 | License/authority decision for TBCA data | WP-0 | Permitted data acquisition/use path |
| 4 | Actual USDA Foundation import | WP-2 | Real data, hash, manifest, coverage report |
| 5 | SR Legacy + FNDDS import | WP-4 | Distinct catalogs, dedup, food_type and coverage |
| 6 | Rebuild TBCA/USDA coverage by ALIMENTO | WP-1, WP-3, WP-4 | Coverage and eligibility report from real source |
| 7 | DRI reference registry + UL scope | WP-6 | per-nutrient authority/form/source rules and exposure completeness |
| 8 | recipe graph and canonical food crosswalk | WP-1, WP-4, WP-6 | verified food identities and real recipes |
| 9 | preparation/yield/retention datasets | WP-8 | exact food/process factors and benchmarks |
| 10 | DIAAS datasets and scoring | WP-4, WP-8 | complete AA/digestibility data and reference pattern |
| 11 | energy calibration validation | WP-12 | external validation report |
| 12 | medical constraints + supplement/water ledger | WP-6, WP-7 | complete source scope and hard safety guards |
| 13 | 7/14/28-day optimizer | WP-8, WP-12, WP-13 | benchmarked viable plans and infeasibility explanations |
| 14 | persistence, observability, data contracts | WP-0 through WP-13 | backup/restore, audit trail, migration tests |
| 15 | external scientific review and release qualification | all P0/P1 | signed report, clean CI/build, reproducible ZIP |

**Do not skip ahead to multi-day AI meal plan generation before food identities, composition, allergens and source coverage are reliable.**

---

# 12. Definition of Done for a future V.MAX nutrition release

A release is not complete until the following are true:

## Data correctness
- Source data have hashes, license, release, method, basis and provenance.
- All simple-food recipe ingredients have verified type and identity.
- Composite foods never enter ingredient search/slot/MIP/store.
- Missing/trace/unmeasured/incompatible remain separate and never become zero.
- Nutrients have exact analyte form/unit/base.
- Coverage is reported by source, food_type and ingredient eligibility.
- USDA real release imported and validated; synthetic fixtures not counted.
- TBCA license/redistribution decision documented.

## Calculation correctness
- RMR/EER/TDEE accounting has one declared basis and no duplicate exercise energy.
- Goal adjustment sign/direction validated for gain/loss/maintain/recomposition.
- Calorie target and macros reconcile after actual grams rounding.
- UL only applied within source/form scope and complete exposure; otherwise indeterminate.
- DIAAS only when all inputs supported; no placeholder output.
- Food preparation uses explicit edible portion, yield and nutrient-specific retention.
- Every derived value has formula, source data and method.

## Optimization correctness
- Solver QP/MIP statuses are explicit.
- HiGHS WASM tested in browser worker with timeout/cancel/error path.
- Fallback matches constraints and is independently verified.
- UL and food eligibility survive post-rounding and apply/store paths.
- Hard constraints never relaxed silently.
- Multiday plan uses verified recipe ingredients only and explains infeasibility.

## Software quality
- lockfile installation clean from supported toolchain;
- full typecheck/lint/build/full tests/browser E2E pass;
- property/mutation tests cover hard gates;
- no unreviewed dependency/license changes;
- persist export/import/restore tests pass;
- package ZIP integrity and clean extraction tests pass.

## Scientific review
- independent reviewer signs RMR/TDEE/DRI/UL/DIAAS/preparation formulas and population applicability;
- validation dataset and results documented;
- no clinical safety/validation claim outside validated scope;
- uncertainty, missingness and source quality shown to user.

---

# 13. Anti-goals — o que NÃO fazer

1. Não reescrever todo `cardapio-composer-engine.ts` como uma grande arquitetura nova antes de baseline, testes e benchmarks.
2. Não instalar cinco motores de busca/otimização concorrentes porque têm muitas estrelas.
3. Não copiar código AGPL/GPL/NOASSERTION sem licença e revisão de compatibilidade comercial.
4. Não usar LLM/embeddings/fuzzy para decidir se alimento composto é simples ou para fundir dados nutricionais.
5. Não tratar TBCA 7.3 como open data sem confirmar os termos; não distribuir planilha/dataset derivado sem permissão.
6. Não inferir nutrientes faltantes com valores de outro alimento, grupo, receita ou porcentagem de proteína sem declarar um modelo de estimativa validado.
7. Não usar a mesma retenção para proteína, energia, gordura e micronutrientes sem evidência separada.
8. Não mostrar DIAAS, UL “seguro”, TDEE “medido” ou cobertura nutricional completa sem todas as entradas necessárias.
9. Não somar exercício a EER/TDEE que já inclui atividade.
10. Não deixar o solver substituir composição alimentar sem aceite explícito do usuário.
11. Não liberar receita com prato composto como ingrediente apenas para aumentar quantidade de receitas.
12. Não inventar pesos, rendimento, amostras, desvios-padrão, fontes ou referências.
13. Não trocar o lockfile/runtime do projeto para contornar um ambiente de execução incompleto.
14. Não declarar build, lint, teste, WASM ou validação clínica aprovados sem saída de comando/artefato recente.

---

# 14. Prompt de transferência para a próxima IA

O arquivo separado `PROMPT_PARA_IA_FINALIZAR_TITAN_NUTRITION.txt` contém o prompt completo para copiar. As instruções essenciais são:

- primeiro verificar o ZIP que o usuário entregar e o commit/versão real;
- comparar com os itens V11.34/V11.35 deste relatório;
- continuar do source mais recente sem regressão;
- usar Superpowers (brainstorm/design/plano/TDD/debug/review/verification/finish branch);
- executar work packages em ordem de prioridade;
- usar GitHub top repositories por capability, licença e compatibilidade, e fonte oficial de dados científicas;
- não fazer code copy de AGPL/GPL;
- separar bug de código de gap de dataset/licença/validação;
- atualizar relatórios/checklists com comandos de teste e saídas reais;
- criar release ZIP final e prompt/report atualizado.

---

# 15. Fontes metodológicas e científicas

Fontes primárias e guias:

1. USDA FoodData Central — datasets e releases: https://fdc.nal.usda.gov/download-datasets/.
2. USDA FDC — tipos, metadados e documentação: https://fdc.nal.usda.gov/data-documentation/.
3. TBCA oficial — versões, citações e termos: https://www.tbca.net.br/.
4. NIH ODS — niacina profissional: https://ods.od.nih.gov/factsheets/Niacin-HealthProfessional/.
5. FDA — conversão de unidade de folato/niacina/vitaminas: https://www.fda.gov/media/129863/download?attachment=.
6. FAO/INFOODS — Food Matching Guidelines v1.2: https://www.fao.org/fileadmin/templates/food_composition/documents/upload/INFOODSGuidelinesforFoodMatching_version_1_2.pdf.
7. FAO — avaliação de qualidade proteica/DIAAS: https://www.fao.org/3/i3124e/i3124e.pdf.
8. Health Canada — método DIAAS (publicado 22-10-2026): https://www.canada.ca/en/health-canada/services/food-nutrition/legislation-guidelines/acts-regulations/notices-proposal-notices-modification/table-chemical-physical-nutritional-characteristics-food-pcpn-2607/determination-protein-rating-diaas.html.
9. USDA — Table of Nutrient Retention Factors, Release 6: https://www.ars.usda.gov/ARSUserFiles/80400525/Data/retn/retn06.pdf.
10. USDA Food Buying Guide — yields e edible portion: https://foodbuyingguide.fns.usda.gov/appendix/downloadfbg.
11. NASEM — Dietary Reference Intakes portal: https://www.nationalacademies.org/our-work/dietary-reference-intakes.
12. EFSA — UL guidance 2024: https://doi.org/10.2903/j.efsa.2024.9052.
13. NIDDK — Body Weight Planner (modelo dinâmico): https://www.niddk.nih.gov/health-information/weight-management/body-weight-planner.
14. Hall et al. (2011), body weight energy imbalance model: https://doi.org/10.1016/S0140-6736(11)60812-X.
15. 2024 scoping review on energy expenditure during resistance exercise (166 studies): https://doi.org/10.1007/s40279-024-02047-8.
16. LanguaL food description: https://www.langual.org/.
17. FoodOn ontology: https://obofoundry.org/ontology/foodon.

**Regra de citação:** próxima IA deve confirmar a versão/data de qualquer norma ou fonte mutável, citar a fonte primária na documentação e registrar data de consulta. Não copiar dados de um dataset apenas porque um repositório GitHub os espelha.

---

# 16. Resultado que o usuário deve receber da próxima IA

O trabalho final não é apenas um ZIP. O output esperado é:

1. código atualizado baseado no ZIP/source real mais recente;
2. ZIP versionado com SHA-256;
3. relatório de auditoria atualizado com cada finding em `P0/P1/P2`, gravidade, arquivos, evidência, causa raiz, solução, dependências e testes;
4. tabela `implemented / tested / data-backed / runtime-verified / independently-reviewed` por recurso;
5. lista clara de bloqueios de acesso/licença/ambiente e tarefas externas;
6. relatório de cobertura nutricional por fonte e por `ALIMENTO` (não apenas total do catálogo);
7. auditoria de receitas sem preparados compostos como ingredientes;
8. logs de execução do full test/build/lint/WASM na extração limpa;
9. avaliação de código independente ou declaração explícita de que foi self-review;
10. prompt/handoff atualizado apenas para o que ainda faltar.

**Critério final:** não usar média geral para esconder um domínio crítico não validado. Dados corretos, elegibilidade de ingredientes, UL, balanço energético e proveniência devem cada um ser aprovados separadamente.
