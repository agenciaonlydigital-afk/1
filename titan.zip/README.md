# TITAN HYDRATION V.MAX V11.35

Aplicativo de treino com biblioteca de 32 exercícios, anatomia 3D interativa focada em superfície corporal e musculatura, nutrição, hidratação e evolução corporal. A V11.35 evolui sobre a V11.34, preserva o bloqueio de preparações compostas como ingrediente, deriva vitamina B3 em mg NE apenas com evidência FDC completa (409 direto, 406+407 ou 406+501 com conversão rastreável) e separa cobertura TBCA por ALIMENTO/PREPARACAO_COMPOSTA/UNKNOWN. A V11.34 fecha a integridade de ingredientes TBCA no compositor: apenas registros `ALIMENTO` entram em receitas, `PREPARACAO_COMPOSTA` continua disponível para o diário e é bloqueada como ingrediente; aliases antigos são resolvidos para códigos canônicos e refeições locais legadas deixam de alegar proveniência TBCA. Dos oito modelos de receita, apenas dois com ingredientes elegíveis entram em novas montagens; seis que incluem pratos compostos sem ficha de ingredientes ficam preservados para históricos, mas fora da busca/substituição. A V11.33 reforça integridade do solver HiGHS, escopos UL, ledger de micronutrientes suplementares, importação estrita de USDA FDC e ponte estimada de gasto energético de treino. A matriz de validação V11.35 está em `docs/quality/NUTRITION_ENGINE_V11_35_VERIFICATION.md`; o backlog está em `docs/quality/NUTRITION_ENGINE_V11_35_REMAINING_GAPS.md`. A pesquisa técnica está em `docs/research/NUTRITION_ENGINE_GITHUB_RESEARCH_V11_35.md`, a auditoria TBCA de elegibilidade em `docs/research/TBCA_INGREDIENT_ELIGIBILITY_AUDIT_V11_35.json`, a proveniência legada em `docs/research/TBCA_LEGACY_PROVENANCE_AUDIT_V11_34.md` e a auditoria executável dos modelos em `npm run audit:recipe-catalog-eligibility`. A V11.27 fecha lacunas de qualidade da agregação de fibra/gordura saturada/colesterol e adiciona motores de evidência para DIAAS e transformação cru/cozido, sem fabricar dados ausentes. A V11.26 amplia o modelo DRI adulto para 29 referências nutricionais e passa esses alvos ao otimizador diário, desde que a cobertura dos alimentos e as unidades sejam completas; limites UL reais são restrições duras, enquanto RDA/AI e CDRR são preferências suaves. Os seis campos recém-adicionados (colina, iodo, cloreto, molibdênio, cromo e flúor) permanecem não analisados no catálogo TBCA atual, sem preenchimento artificial com zero. O relatório de otimização explicita restrições aplicadas e ignoradas, conflitos com UL e limites de cobertura. A V11.25 adiciona um orçamento energético explícito e source-aware: RMR + residual não repouso = TDEE; TDEE + ajuste do objetivo = meta de ingestão. NASEM EER e TDEE adaptativo já incluem atividade/treino e não recebem soma duplicada de calorias de exercício. O ajuste efetivo reconcilia com a meta final mesmo quando há piso de viabilidade dos macros. A V11.24 adicionou cálculo proporcional de porções por meta energética de cada refeição, cobertura dos 23 micronutrientes originais com estados de dado, agregação de fibra/gordura saturada/colesterol, seleção RMR automática mais conservadora e gates de qualidade para otimização. A V11.23 adicionou um perfil 2D de menisco Young–Laplace não linear com referência RK4 e remove infraestrutura remota sem consumidor: aplicação Express/API sem consumidores, cliente HTTP genérico, fila de sync, analytics, SDK Gemini e helper de URL remoto sem uso. Também remove a geometria esquelética oculta que era construída e imediatamente ocultada pelo renderer. O corpo mantém apenas corpo-base, musculatura superficial e camada profunda; nenhum osso ou tendão é necessário ou gerado. As melhorias prévias de óptica medida, plasma, raios, difusão da pele, morfologia muscular e iluminação de estúdio são preservadas. O halo único difuso atrás do corpo e a ausência de iluminação no chão continuam sendo contratos visuais obrigatórios.

## Herança funcional V11.32 — integridade nutricional e fontes adicionais

A V11.35 parte do ZIP V11.34 disponível nesta sessão. A V11.34 parte do ZIP V11.33 disponível nesta sessão. A V11.33 parte do ZIP V11.32 disponível nesta sessão. O importador USDA agora aceita JSON ou ZIP oficial, o downloader baixa apenas três releases fixadas, e a cobertura agrega TBCA, Open Food Facts e USDA sem misturar IDs entre fontes.

- A saída primal do HiGHS agora precisa conter todos os valores contínuos `xN` dentro dos limites, e toda seleção binária deve ser integral e one-hot por refeição. Respostas incompletas ou inválidas não viram gramas atuais nem zeros presumidos.
- O painel de micronutrientes de alimentos não avalia UL de escopo suplementar, de formas pré-formadas ou de formas sintéticas. Um total alimentar de vitamina A em RAE não é tratado como retinol pré-formado.
- Existe um ledger de micronutrientes de suplementos separado do diário alimentar, com data/hora, produto, nutriente, quantidade, unidade, forma química e proveniência. A persistência passa à versão 3 e migra estados antigos sem registros de suplemento.
- A ingestão suplementar não cria calorias/macros e não confirma automaticamente um dia alimentar. Unidades químicas/biológicas como IU, RAE, DFE e NE não são convertidas por regras genéricas.
- Um importador offline estrito USDA FoodData Central foi adicionado para Foundation, SR Legacy, FNDDS e Experimental. O contrato valida simultaneamente o ID permanente `nutrient.id`, o código histórico `nutrient.number`, o nome e `unitName`; não confunde, por exemplo, proteína (`id=1003`, `number=203`) com código `203` usado como ID. Além dos nutrientes principais, lê fibra, gordura saturada, colesterol e sódio quando ID/número/nome/unidade são exatos. IDs duplicados, nutrientes conflitantes ou unidades divergentes são rejeitados ou colocados em quarentena; a saída preserva SHA-256 e auditoria por alimento. A integração de fonte/busca está pronta, com 26 dos 29 micronutrientes canônicos mapeáveis pelo contrato atual; niacina em NE, vitamina K total e cloreto permanecem sem mapeamento semântico seguro. Nenhum arquivo real do FDC foi importado nesta sessão: o download do arquivo oficial falhou no ambiente e o catálogo permanece vazio.
- Sessões de treino concluídas podem gerar, sob ação explícita, um registro estimado de energia ativa baseado em MET com fonte/licença e intervalo da sessão. O resultado ainda não é persistido nem automaticamente somado ao TDEE.
- Pesquisa comparativa de repositórios e stack avançada: `docs/research/NUTRITION_ENGINE_GITHUB_RESEARCH_V11_33.md`. Alterações: `CHANGELOG_V11_33.md`. Plano Superpowers: `docs/superpowers/plans/2026-11-26-usda-ingestion-v11-33.md`. Lacunas abertas: `docs/quality/NUTRITION_ENGINE_V11_33_REMAINING_GAPS.md`.
- A V11.33 não declara o motor completo ou clinicamente validado; os gaps em importação real de FDC, crosswalk TBCA, dados DIAAS, retenção por preparo, otimização multidiária e validação científica continuam documentados.

### Baixar e importar um dataset USDA FoodData Central (opcional)

O downloader aceita somente os seguintes arquivos JSON oficiais, com URLs e versões fixadas no código:

| Tipo | Release fixada | ZIP comprimido / descompactado (aprox.) |
|---|---|---:|
| Foundation Foods | 2026-10-29 / FDC 16.0 | 681 KB / 9 MB |
| SR Legacy | 2018-04 | 12,3 MB / 205 MB |
| Survey (FNDDS) | 2024-10-31 | 3,7 MB / 64 MB |

O Branded Foods (3 GB descompactado) não faz parte do fluxo padrão; tem outro perfil de origem (declarações de rótulo/fornecedor) e exige política própria de atualização e deduplicação.

1. Baixe uma única release oficial:

```bash
bun run download:usda-fdc -- --type Foundation
```

2. Importe diretamente o ZIP validado, sem extração manual:

```bash
bun run import:usda-fdc -- --input data/external/usda-fdc/FoodData_Central_foundation_food_json_2026-10-29.zip --type Foundation --release 2026-10-29-v16.0 --source-url https://fdc.nal.usda.gov/fdc-datasets/FoodData_Central_foundation_food_json_2026-10-29.zip
```

Repita o passo de importação para `SR Legacy` (`--type "SR Legacy" --release 2018-04`) e `Survey (FNDDS)` (`--type "Survey (FNDDS)" --release 2024-10-31`), usando os respectivos ZIPs listados pelo downloader; cada tipo grava seu próprio catálogo gerado e todos são agregados automaticamente sem apagar os demais. Também é possível apontar um JSON previamente extraído. O downloader só usa URLs exatas em `fdc.nal.usda.gov`, bloqueia redirects, valida HTTP/content-type/Content-Length/stream size e salva o ZIP por promoção imutável com SHA-256. O parser ZIP não escreve nomes de entrada em disco; rejeita path traversal, ZIP64, multidisk, criptografia, métodos desconhecidos, razão/tamanho de descompressão fora do limite, múltiplos JSON e CRC incorreto. O importador registra o hash do ZIP original, o nome da entrada JSON e o hash da auditoria. A cobertura `npm run audit:nutrition-coverage` passa a contar TBCA, Open Food Facts e o catálogo USDA com fonte separada.

O ZIP oficial não foi obtido nesta sessão; portanto o catálogo USDA do artefato continua vazio e os testes do importador usam fixtures sintéticas. Esse fluxo prepara a ingestão real, mas não afirma que a cobertura alimentar aumentou. Consulte `docs/quality/NUTRITION_ENGINE_V11_33_VERIFICATION.md` para os comandos e limites efetivamente verificados.

## Status verificável V11.28 — bloqueio de UL e evidência DIAAS

- Propostas de otimização que ultrapassem um limite superior (UL) aplicável agora são bloqueadas no domínio, na store e na interface; não podem ser aplicadas ao dia nem salvas como variante. Uma proposta dentro dos ULs continua aplicável.
- O cálculo DIAAS aceita digestibilidade ileal humana ou de suínos; evidência de rato é rejeitada como base DIAAS. Cada perfil de aminoácidos e cada digestibilidade devem identificar exatamente alimento, estado, fonte, versão, referência e URL; valores em base diferente de mg/g de proteína não são pontuados.
- Testes RED→GREEN cobrem o UL bloqueado e as falhas de identidade/proveniência DIAAS. A função de bloqueio fica centralizada no domínio e também é aplicada no caminho da store, não apenas no botão.

## Histórico de validação e arquitetura

- `npm run test:rendering-realism` executa os novos contratos de ótica, materiais medidos, morphs regionais e SSS; `npm run test:gpu-shaders` tenta compilar os shaders em Chromium/WebGL quando o host oferece contexto GPU.
- `npm run test:review`: inclui testes novos do modelo Hall, solver, densidade adaptativa, reconciliação Health Connect/HealthKit e importação de catálogo MET.
- `npm run typecheck:calculations`: typecheck estrito dos módulos de cálculo, incluindo o solver dinâmico e o serviço de integração de atividade.
- `npm run test:adaptive-simulation`: simulação sintética de 200 perfis; RMSE 91,6 kcal estável e 74,6 kcal após adaptação. Não é validação clínica.
- Neste ambiente, a instalação das dependências expirou e Chromium headless não conseguiu inicializar WebGL/SwiftShader; portanto o build integral, typecheck com dependências e compilação GPU não foram aprovados nesta sessão.
- `npm run lint` não pôde concluir porque `vite/client` não está instalado; `npm run build` não pôde concluir porque o executável `vite` está ausente. O typecheck estrito dedicado (`typecheck:calculations`) passou.
- Na revisão V11.23, a sintaxe TypeScript/TSX de 162 arquivos foi transpilada sem diagnósticos; na V11.24, os 8 arquivos TS/TSX alterados também passaram pela verificação de sintaxe. Os scaffolds nativos não foram compilados com Android SDK/Xcode ou testados em aparelhos. OpenMetabolics ainda exige port científico e validação de direitos de pesos/dados.

## Status verificável V11.27 — qualidade, proteína e preparo

- Fibra, gordura saturada e colesterol agora usam cobertura explícita por ingrediente e por refeição. Se uma fonte não tem o valor analisado, a soma completa vira `null` em vez de mostrar uma soma parcial; a UI exibe `quantificados/fontes`.
- O motor DIAAS foi adicionado à API pública de nutrição. Exige aminoácidos indispensáveis por grama de proteína, digestibilidade ileal específica por aminoácido, estado/preparo correspondente, método, espécie e referências. Um alimento individual pode apresentar resultado acima de 100; para uma dieta mista, o resultado DIAAS é limitado a 100 conforme a orientação FAO. O valor bruto continua em `untruncatedDiaas` para auditoria.
- O catálogo atual não contém perfis completos de aminoácidos indispensáveis nem digestibilidade ileal por alimento/preparo. Portanto, o motor está implementado, mas nenhum DIAAS de alimento real é declarado ou preenchido artificialmente.
- O conversor cru/cozido foi adicionado à API pública. Exige correspondência exata de ID/estado de origem, estado preparado, método, rendimento de massa e evidência independente vinculada ao mesmo ID/estado/preparo para retenção de macronutrientes e de cada micronutriente. Não aplica fatores universais.
- USDA Table of Nutrient Retention Factors fornece fatores específicos de retenção de vitaminas/minerais por alimento/método; não é fonte para retenção de kcal/proteína/carboidratos/gordura. Esses fatores de macro exigem evidência separada. Ainda não há tabela de junção TBCA→USDA com identidade, corte e preparo validados; por isso nenhuma conversão automática é aplicada ao catálogo.
- API pública: `calculateDietaryDIAAS`, `derivePreparedFoodComposition`, `buildNutritionDataCoverage` e seus contratos estão exportados por `src/domains/nutrition/application/nutrition-public.ts`.
- Pesquisa atualizada, critérios de licenças e limites de cobertura: `docs/research/NUTRITION_ENGINE_GITHUB_RESEARCH_V11_27.md`. Registro de alterações: `CHANGELOG_V11_27.md`.
- O novo auditor `buildNutritionDataCoverage` e `npm run audit:nutrition-coverage` medem cobertura real por nutriente/fonte, exigindo unidade canônica, número finito e base positiva. O snapshot V11.33 em `docs/research/NUTRIENT_COVERAGE_ALL_SOURCES_V11_33.json` informa as contagens por fonte e não inclui USDA enquanto o catálogo gerado estiver vazio; o snapshot histórico V11.27 permanece preservado. Entre os gaps críticos: niacina equivalente (mg NE) tem 0% compatível por 5.785 registros em unidade incompatível; vitamina K 0,1%; B5 0,1%; B7 abaixo de 0,1%; selênio 82,7%; seis nutrientes recém-adicionados continuam sem quantificação. A cobertura do catálogo não é igual à cobertura de cada plano: qualquer ingrediente sem dado/unidade compatível bloqueia o cálculo daquele nutriente.

## Verificação V11.28

- `npm run test:review`: PASS (suite de revisão definida no projeto).
- `tsc -p tsconfig.calc-review.json --pretty false`: PASS.
- Verificação de sintaxe por transpilation TypeScript/TSX: 18/18 módulos passaram após V11.28.
- `npm run audit:nutrition-coverage`: PASS; snapshot atual de 5.838 registros gerado.
- `git diff --check`: PASS.
- ZIP final `TITAN_V11_28_NUTRITION_ENGINE.zip`: `unzip -t` PASS; extração limpa confirmou versão 11.28.0 e executou `npm run test:review` com exit 0.
- Build, lint completo, `npm test` e HiGHS WASM permanecem bloqueados pela ausência de `node_modules` (`vite`, `vite/client`, `tsx` não instalados); não são marcados como aprovados.

## Verificação V11.27

- `npm run test:review`: PASS (suite de revisão definida no projeto; não substitui o `npm test` integral).
- Testes diretos do otimizador de micronutrientes, DIAAS/preparo e cobertura do composer: PASS.
- `tsc -p tsconfig.calc-review.json --pretty false`: PASS.
- `git diff --check`: PASS.
- `npm run build` bloqueado (`vite: not found`, exit 127); `npm run lint` bloqueado pela ausência de `vite/client` (exit 2); `npm test` bloqueado (`tsx: not found`, exit 127). `npm install --no-package-lock --ignore-scripts --no-audit --no-fund` excedeu o limite, então `node_modules` não ficou disponível. A execução real do HiGHS WASM também não pôde ser verificada. Testes dos contratos LP gerados e do solver TypeScript passaram; o runtime WASM permanece não verificado nesta sessão.
- Simulações adaptativas são sintéticas e não constituem validação clínica. Não houve estudo externo de calibração Hall/RMR/TDEE nem validação em navegador/dispositivo nesta sessão.

## Histórico V11.26 — micronutrientes e otimização diária

- O catálogo de referências adultas tem 29 entradas DRI por perfil. A ampliação inclui colina, iodo, cloreto, molibdênio, cromo e flúor. Os valores variam por sexo/idade quando a referência oficial assim determina; o perfil legado 51+ sem sexo deixa metas ambíguas como `null`, em vez de copiar valores masculinos.
- O sódio usa AI NASEM 2019 de 1.500 mg/d para adultos 19+, e mantém CDRR 2.300 mg/d separado. Os valores antigos 1.300/1.200 mg (DRI 2005) não são usados como AI atual.
- O solver de dia aplica RDA/AI como meta suave, CDRR como teto preferencial suave e UL verdadeiro como restrição dura. A restrição só entra quando todos os ingredientes em quantidade positiva são quantificados na mesma unidade e dentro do escopo do nutriente; metas diárias não são aplicadas a uma refeição isolada.
- O solver TypeScript projeta porções contra ULs viáveis, mantém ingredientes travados e sinaliza conflitos quando as quantidades fixas/mínimas já excedem o limite. A formulação LP do HiGHS expressa as mesmas restrições, mas sua execução WASM integral depende da instalação da dependência `highs`.
- Valores de unidades incompatíveis não são somados (por exemplo, folato em µg e µg DFE; niacina pré-formada e mg NE). Quando qualquer ingrediente não possui dado completo, o total diário fica indisponível para aquele nutriente, e o painel não mostra um falso “faltam X”.
- Os seis nutrientes adicionados ainda têm **zero alimentos quantificados** tanto no adaptador TBCA (5.836 entradas) quanto no adaptador OFF atual (2 produtos). Por isso, permanecem `not_analyzed` e não participam da otimização; isso é uma lacuna de dados explicitamente reportada, não uma função completa.
- Os perfis `adult_51_plus` sem idade exata ou sexo não inventam AI/RDA quando a referência depende dessas dimensões. Nutrientes sem qualquer referência aplicável recebem `no_reference`, não “dados insuficientes”.
- Registros TBCA crus e preparados permanecem itens distintos selecionados por ID/estado. Não há multiplicador cru→cozido genérico. Uma conversão futura precisa combinar identidade do alimento, rendimento por preparo e fator específico de retenção por nutriente/método.
- Referências de estudo e decisões estão em `docs/research/NUTRITION_ENGINE_GITHUB_RESEARCH_V11_26.md`; mudanças em `CHANGELOG_V11_26.md`.

## Histórico V11.25 — orçamento energético
- Pesquisa GitHub por finalidade e inspeção de código: `docs/research/NUTRITION_ENGINE_GITHUB_RESEARCH_V11_25.md`. Foram comparados Mealie, OR-Tools, SciPy, Grocy, Tandoor, wger, OpenNutriTracker, CVXPY, OSQP, HiGHS, Open Food Facts, Calories-In e o protótipo de otimização multi-período. Nenhum código foi copiado nem dependência adicionada.

- O cálculo distingue RMR, TDEE total e meta de ingestão; o RMR não é somado novamente ao TDEE.
- A equação usada para a ingestão é `meta = TDEE + ajuste do objetivo`: déficit para perda, zero para manutenção/recomposição nesta versão e superávit para ganho.
- O TDEE NASEM 2023 já usa categoria de atividade; o TDEE adaptativo é inferido de ingestão + tendência de peso. Ambos já representam o gasto diário total. Calorias líquidas de treino podem ser apresentadas como informação, mas não são somadas novamente.
- Um futuro baseline que exclua exercício só poderá adicionar calorias líquidas (NET) com registro explícito. Calorias brutas (GROSS) não entram como acréscimo.
- A decomposição `TDEE - RMR` é rotulada como demais componentes estimados; não é apresentada como medição individual de NEAT, treino ou efeito térmico.
- `calorieAdjustmentKcal` agora representa a diferença efetiva entre a meta final e o TDEE; o ajuste limitado antes do piso de macros fica em `boundedCalorieAdjustmentKcal`.
- O histórico de treino não fornece ainda um total diário persistido e reconciliado ao motor de metas; nenhum valor de exercício é inventado nem inferido por séries/repetições.

## Histórico V11.24

- A ação explícita de ajuste proporcional calcula a meta de kcal de cada refeição a partir da meta diária e das frações configuradas. Todos os ingredientes quantificados e desbloqueados da refeição usam o mesmo fator; ingredientes travados permanecem fixos. A operação atualiza o rendimento e as quantidades sem trocar a composição alimentar.
- O resultado informa limites de porção/rendimento, alimentos sem composição, ingredientes de baixa confiança e cobertura nutricional. A otimização HiGHS não recebe certificado `optimal` quando a composição alimentar está incompleta ou com baixa confiança.
- O composer da V11.24 agregava os 23 micronutrientes originais e preservava `quantified`, `trace`, `not_analyzed` e `missing`; os totais parciais não eram tratados como cobertura completa.
- A distribuição de macros por refeição só entra como meta do solver quando cada macro soma 100%; alocações parciais não criam objetivos contraditórios.
- O RMR automático agora é recalculado no motor quando não há escolha manual persistida; Mifflin é o padrão conservador e equações específicas (Katch–McArdle, Cunningham, Ten Haaf e Pavlidou) permanecem explícitas, pois atividade e FFM, isoladamente, não comprovam compatibilidade com a população de desenvolvimento.
- O cálculo adaptativo de TDEE não depende mais de abrir o modal de metas; o histórico de ingestão continua exigindo fechamento explícito e dados quantificados, sem inferir jejum de dias sem registro.
- A validação estrutural de macros bloqueia valores não finitos/negativos, massa de proteína+carboidrato+gordura acima de 105 g/100 g e gordura saturada maior que gordura total. O comparativo simples de Atwater é apenas alerta, nunca correção automática. O registro TBCA `BRC1144B` (219 g de carboidrato/100 g) foi colocado em quarentena: não se adivinha o valor correto. A busca e novas entradas não o disponibilizam; registros antigos ficam sem cálculo e com cobertura incompleta.
- A varredura de domínio `npm run test:energy-budget-boundaries` conferiu 1.071.840 combinações de sexo, idade, altura, peso e categoria de atividade; em todas, o EER NASEM ficou acima do RMR, com margem mínima de 167 kcal.
- O orçamento energético e o gate de dados alimentares foram testados com cenários adversariais; `npm run test:nutrition-data-quality` verifica os 5.836 itens do adaptador TBCA (incluindo entradas legadas), incluindo a quarentena explícita de um registro inconsistente. Quando os mínimos de proteína e gordura não cabem no alvo, o motor reduz primeiro a proteína até seu mínimo de referência; só relaxa o déficit se nem os mínimos couberem. O ajuste efetivo mostra essa diferença.
- A referência de sódio separa AI de 1.500 mg e CDRR de 2.300 mg; CDRR não é codificado como UL, e ficar abaixo da AI não é apresentado como deficiência.
- Não foram adicionadas dependências nem copiado código de repositórios externos. O ZIP V11.23 de origem permanece preservado.

A verificação de produção ainda depende de dependências instaladas: o pacote recebido não contém `node_modules` e não tem `package-lock.json`; os testes diretos com Node 22 e o loader local são registrados no ledger V11.24. Build, lint integral, HiGHS WASM e UI em navegador não são declarados aprovados sem execução real.

### Como usar o cálculo proporcional por refeição (V11.24)

1. Defina a meta diária de kcal no plano nutricional.
2. Confira os percentuais de energia de cada refeição e feche a distribuição em 100%.
3. No painel de balanço, use **Aplicar metas de kcal mantendo as proporções dos alimentos**.
4. O TITAN calcula a meta de kcal de cada refeição e escala os ingredientes quantificados/desbloqueados com um fator comum. Os itens travados permanecem fixos; os escalados passam ao modo proporcional e estabelecem a composição atual como nova base.
5. Confira kcal reais versus alvo, cobertura e alertas de dados incompletos. Se os limites de rendimento/massa impedirem o alvo, o desvio permanece visível; use desfazer se necessário.

Esse modo preserva a composição relativa. Ele não força proteína, carboidratos e gordura a baterem simultaneamente em metas independentes por refeição. Para mudar ingredientes individualmente, use o otimizador QP/MILP e respeite os avisos de cobertura.

## Status verificável V11.23

Executado na revisão V11.23 em Node.js 22.16.0, sem `node_modules`:

- Passaram: `npm run test:rendering-v11-23`, `npm run test:rendering-realism`, `npm run test:review`, `npm run typecheck:calculations` e contratos estáticos de anatomia, lifecycle, limites de domínio, hardening e poda de runtime.
- `npm run test:anatomy` e `npm test` não iniciaram: o executável `tsx` não está instalado; o teste de anatomia que depende de Three.js também não iniciou porque o pacote `three` não está instalado.
- `npm run lint` não concluiu: tipos `vite/client` ausentes. `npm run build` não concluiu: executável `vite` ausente.
- `npm run test:gpu-shaders` foi ignorado pelo próprio gate: Chromium não criou contexto WebGL/SwiftShader (`ETIMEDOUT`). Nenhum shader é declarado compilado em GPU nesta sessão.
- Portanto, a V11.23 não tem aprovação de build integral, compilação WebGL2, screenshots 360° nem profiling de GPU/dispositivos.

## Referências de cálculos e realismo visual

- `docs/CALCULATION_ENGINE_V11_16.md`: modelo dinâmico, equações, pressupostos, reconciliação de fontes e limites.
- `docs/REPOSITORY_RESEARCH_V11_16.md`: pesquisa de repositórios, estrelas observadas, licenças e decisões de não incorporação.
- `docs/IMPLEMENTATION_PRIORITY_V11_16.md`: o que foi adicionado e o que permanece pendente.
- `CHANGELOG_V11_16.md`: histórico da revisão anterior.
- `CHANGELOG_V11_17.md`: mudanças de realismo visual desta revisão.
- `docs/research/ULTRA_REALISM_DEEP_RESEARCH_V11_17.md`: pesquisa GitHub por especialidade, decisões de renderização, melhorias entregues e pendências de validação.

## Executar localmente

**Requisitos:** Node.js 22.12+ e Bun (o `bun.lock` é o lockfile canônico). Os comandos de teste que invocam arquivos TypeScript usam `tsx`, instalado pelo lockfile. Para instalar de forma reproduzível, use `bun install --frozen-lockfile`.

```bash
bun install --frozen-lockfile
cp .env.example .env
bun run dev
```

O app não requer chave de API de IA nem configuração de `APP_URL`. Não existe backend de produto ou cliente HTTP genérico. Dados locais com proveniência permanecem no catálogo; fontes remotas só podem ser adicionadas quando houver fluxo de produto explícito e consumidor testado. `PORT` e `DISABLE_HMR` são opcionais.

## Comandos de qualidade

```bash
bun run lint
bun run test
bun run test:anatomy
bun run test:exercise-library
bun run test:review
bun run test:rendering-realism
bun run perf:food-search
bun run build
```

O comando `build` gera a aplicação estática em `dist/`. `bun run start` ou `npm start` executa `vite preview` para conferência local, não como servidor de produção. Em produção, publique `dist/` em hospedagem estática/CDN; a V11.23 não possui backend HTTP próprio nem endpoints de produto.

O build depende das dependências instaladas. Verificações estáticas dedicadas:

```bash
node scripts/check-fluid-shaders.mjs
node scripts/check-cockpit-visual-semantics.mjs
node scripts/check-rendering-realism-v11-17.mjs
node scripts/check-titan-design-system.mjs
node scripts/check-anatomy-v9.mjs
node scripts/check-materials-v10.mjs
node scripts/check-anatomy-vmax-v11.mjs
node scripts/check-anatomy-group-contract.mjs
node --experimental-strip-types scripts/check-exercise-muscle-contract.mjs
```

## Direção visual e engenharia V9

- `DESIGN.md`: contrato visual e regras do sistema de design.
- `docs/PRODUCT_VISUAL_DIRECTION_VMAX_V7.md`: direção visual, semântica de cor, intenção dos componentes e metas de qualidade.
- `docs/REPOSITORY_RESEARCH.md`: pesquisa GitHub e decisões por repositório, incluindo deep research anatômica V9.
- `docs/COMPONENT_REALISM_PERFORMANCE_AUDIT.md`: auditoria de realismo/desempenho e histórico de validação.
- `docs/anatomy/ANATOMY_3D.md`: arquitetura 3D, referências, performance, contratos e limitações.
- `docs/anatomy/ANATOMY_VMAX_V11_2_VALIDATION.md`: validação da base V11.2.
- `docs/anatomy/ANATOMY_VMAX_V11_2_1_VALIDATION.md`: correção do catálogo exercício→músculo e Top 3 de evolução.

## Corpo 3D V.MAX V11.4

O viewer mantém três lotes de geometria (corpo-base, músculos de treino e camada profunda), seleção por atributos compactos e bitmasks inteiras no vertex shader, PBR com PMREM procedural em hardware identificado, orçamento de pixels e renderização sob demanda. O pipeline de geometria não constrói lote esquelético oculto. A figura completa inclui cabeça, pescoço, tronco, braços, mãos, pernas e pés; a camada de seleção e os dados de treino continuam restritos aos mesmos 14 grupos musculares. UVs são preservados apenas no lote muscular para suportar o normal map procedural de fibras, enquanto os outros lotes continuam descartando UVs sem uso. O modo holográfico é single-pass no material PBR existente, com toggle Natural/Holograma, sem bloom ou render target adicional. O WebGL2 só é criado próximo da viewport, os shaders são preparados com `compileAsync` e os recursos são descartados antes de `renderer.dispose()`, seguido de `forceContextLoss()` no unmount. A geometria muscular segue procedural: não é um atlas médico nem uma medição do corpo.

Não foi adicionado ativo anatômico externo: Human Atlas possui uma coleção de aproximadamente 33 MB comprimidos e uma referência masculina adulta; Z-Anatomy contém referências com licenças NC. A substituição exige auditoria de licença, cobertura e lateralidade, download/memória e avaliação física antes de ser segura.

## Limites de validação históricos da V11.7

Na revisão histórica V11.7, o build integral e testes E2E permaneceram pendentes porque as dependências e o navegador não estavam disponíveis naquele ambiente. O status atual e verificável da V11.23 está registrado na seção “Status verificável V11.23” no início deste README; nenhum FPS, temperatura ou benchmark mobile é declarado sem medição real.


### Anatomy 3D V.MAX V11.2

The anatomy viewer defers WebGL2 context and body construction until it is near the viewport, precompiles PBR programs with `compileAsync`, uses compact typed GPU attributes (8-bit muscle IDs/sides, normalized 16-bit normals and safe 16-bit indices), preserves UVs only for the muscle batch that consumes the procedural fiber normal map, and resolves muscle state in the shader rather than rewriting vertex colors on the CPU. V11.2 also fixes all nine GLSL chunk-injection stage contracts, makes the fiber normal texture periodic across both UV axes, and centralizes disposal after shader/renderer failure. The complete figure remains visible while workout mapping stays at 14 stable muscle IDs. The model remains procedural; it is not a medical atlas or a validated human scan. See `docs/anatomy/ANATOMY_3D.md` for repository research, design constraints and remaining device/GPU gates.


## Patch V.MAX V11.2.1 — consistência do catálogo de treino

Naquele patch, os quatro slugs ausentes (`supino-reto`, `crucifixo`, `desenvolvimento`, `triceps-corda`) foram adicionados para cobrir os exercícios usados nos treinos iniciais. A revisão também corrigiu a divergência de panturrilhas como grupo secundário do agachamento. `EXERCISE_MUSCLE_MAP` passou a ser derivado de `EXERCISE_CATALOG`, para manter uma única fonte de verdade. Os 14 IDs musculares e o renderer não mudaram. A contagem atual, após as ampliações seguintes, é de 32 exercícios na V11.6.

O `scripts/check-exercise-muscle-contract.mjs` verifica slugs únicos, resolução de todos os exercícios dos planos, igualdade dos mapas de músculos entre treino e biblioteca e validade dos 14 IDs. Ele é executado pelos comandos de teste de anatomia e da biblioteca de exercícios.

**Evolução anatômica ainda pendente:** substituir patches musculares procedurais por malhas anatômicas selecionadas e licenciadas; isso continua como P1 e exige validação de correspondência, proporção, lateralidade e picking antes de trocar os ativos.


## Escopo anatômico V11.23

O corpo 3D prioriza superfície corporal e musculatura visível. Não são construídos ossos, esqueleto, tendões ou fáscia; essas estruturas não fazem parte da experiência solicitada. O renderer mantém apenas corpo-base, camada muscular superficial e camada profunda de tecido mole.

## V10 — Material & Texture Finish

The V10 visual pass is limited to textures, materials, optical effects, and their rendering cost. See `docs/MATERIAL_TEXTURE_EFFECT_CATALOG_VMAX_V10.md` for the complete component-by-component inventory, GitHub research, applied changes, avoided effects, and validation boundaries. No runtime dependency was added.



## Biblioteca de exercícios V.MAX V11.6

A biblioteca foi ampliada de 17 para **32 exercícios**, com guias de execução em português, dicas técnicas, erros comuns, respiração, níveis, categorias, mecânica, aliases e relações entre regressões, progressões e alternativas. A busca cobre os textos dos guias e os filtros incluem músculo, equipamento, nível, categoria e mecânica. A página mostra a origem/licença dos registros e mantém o botão de inspeção muscular no 3D.

O catálogo é uma fonte canônica exposta por `ExerciseRegistry`; o mapa para a anatomia continua sendo derivado e preserva os 14 IDs musculares. Foram importados apenas registros textuais selecionados de Yuhonas, sem imagens ou GIFs. wger, hasaneyldrm, Kinetic, exercemus, RepDB e wrkout foram comparados, com suas diferenças de licença descritas em `docs/EXERCISE_LIBRARY_RESEARCH_V11_6.md` e `THIRD_PARTY_NOTICES.md`. A importação integral dos grandes datasets permanece sujeita a deduplicação, mapeamento anatômico e auditoria de licença individual.

## V11.4 — integridade de seleção e contratos de domínio

- O picking agora verifica a distância da superfície externa visível antes de aceitar um músculo. Isso impede selecionar patches posteriores através do tronco, sem impedir a seleção de relevos musculares intencionalmente elevados. A tolerância geométrica é isolada e testada.
- A pesquisa de exercícios aceita sinônimos e termos usuais em português para os mesmos 14 grupos. Os aliases não criam IDs novos nem alteram o mapeamento dos exercícios.
- O domínio de treino consulta o catálogo por um contrato público do domínio de exercícios; a biblioteca consulta o catálogo muscular por um contrato público da anatomia.
- `npm test` não executa novamente o conjunto de anatomia no final; os checks são chamados uma vez. CI reproduz instalação, typecheck, testes e build via Bun e lockfile existente.
- Nenhuma malha anatômica de terceiros foi copiada: os candidatos encontrados têm obrigações de atribuição/share-alike ou proveniência/licença de ativos que não foram aprovadas para redistribuição. A geometria do corpo e a cabeça permanecem; o mapeamento de treino continua limitado aos 14 grupos existentes.

**Limite:** a seleção por oclusão é validada por testes determinísticos da regra de distância e pelos contratos do renderer; a compilação GLSL, renderização e interação devem continuar sendo verificadas em browsers e dispositivos físicos. Não há alegação de FPS medido ou de anatomia clínica.


## Motor de nutrição e evolução

A aba Nutrição reúne Cardápios, Receitas e Alimentos em um único espaço. O catálogo inclui 5.830 registros TBCA 7.2 elegíveis do arquivo final de nutrição, preservando dados ausentes como não analisados. A aba Evolução aceita pesagens diárias independentes e medidas corporais opcionais. Metas e tendências são estimativas, não medições clínicas; veja `docs/NUTRITION_EVOLUTION_ENGINE_VMAX_V11_5.md` para métodos, limites, licenças e validação.

## Revisão de integridade e persistência V11.12

- `CHANGELOG_V11_12.md`: endurecimento de hidratação de fichas e refeições personalizadas.
- `docs/REPOSITORY_RESEARCH_V11_12.md`: comparação de repositórios de teste, acessibilidade e qualidade com snapshot de estrelas e decisão de integração.
- `docs/IMPLEMENTATION_PRIORITY_V11_12.md`: critérios de aceite e limitações ambientais.

## Revisão sênior e engenharia React V11.11

- `CHANGELOG_V11_11.md`: editores de treino/nutrição, rastreabilidade, limites de persistência e gates ainda bloqueados.
- `docs/REPOSITORY_RESEARCH_V11_11.md`: líderes GitHub por finalidade, estrelas aproximadas, licenças e decisão de adoção.
- `docs/IMPLEMENTATION_PRIORITY_V11_11.md`: critérios de aceite e gates restantes.
- `scripts/benchmark-food-search.mjs`: benchmark repetível do índice de alimentos.
- `docs/REPOSITORY_RESEARCH_V11_9.md`: Top 5 de repositórios por função (estado, API/cache, forms, editores, workflows, rotas, auth, testes, code review e performance), licenças, decisões de adoção e não adoção.
- `docs/IMPLEMENTATION_PRIORITY_V11_9.md`: ordem de implementação V12 e critérios objetivos de aceite.
- `docs/REPOSITORY_REVIEW_V11_7.md`: revisão anterior da arquitetura e código.

## Limites de validação da V11.11

Os testes de domínio/persistência e proveniência, checks estáticos e transpilação sintática de 151 arquivos TS/TSX passaram. O benchmark local de busca (5.838 registros, 180 consultas) mediu mediana de 0,96 ms e p95 de 2,54 ms nesta execução. Não foi possível executar build, typecheck semântico oficial nem E2E: o ambiente não possui `node_modules` nem Bun e o registry npm expirou. A migração para React Router e a suíte Playwright/Vitest/RTL/MSW/axe-core exigem instalação reproduzível e regeneração do lockfile. Autenticação e sincronização multi-dispositivo permanecem bloqueadas pela ausência de backend e política de autorização. Consulte `CHANGELOG_V11_11.md` e `docs/IMPLEMENTATION_PRIORITY_V11_11.md` antes de considerar a versão homologada.


## Limites de validação da V11.12

Os testes de persistência de treino/nutrição e a suíte `test:review` passaram no Node.js 22.16.0. Checks estáticos de domínio, semântica visual, design system, contrato anatômico e catálogo TBCA também passaram. O ambiente não possui Bun nem `node_modules`, e `npm ping` falhou por indisponibilidade de DNS do registry; por isso não foi possível regenerar o lockfile, instalar Playwright/React Router/Vitest/RTL/MSW/axe-core, executar build oficial, typecheck semântico ou E2E. Nenhuma dependência foi adicionada nem lockfile alterado.


## V11.19 — realismo e verificação

- Pesquisa técnica: `docs/research/ULTRA_REALISM_DEEP_RESEARCH_V11_19.md`.
- Mudanças: `CHANGELOG_V11_19.md`.
- Testes focados: `npm run test:rendering-realism`; tentativa GPU: `npm run test:gpu-shaders`.
- Build, typecheck completo e compilação GPU precisam ser executados em ambiente com dependências e WebGL2; um teste GPU marcado SKIPPED não conta como aprovado.


## TITAN V11.19 — Realismo óptico, pele e anatomia

- Água: menisco capilar planar com perfil linearizado de Young–Laplace e ângulo de contato explícito, mantendo o solver Euleriano 2D compacto para interações de UI.
- Pele: mapa de refletância UV periódico com pré-filtro multi-Gaussian em luz linear e difusão screen-space RGB dependente de profundidade. É uma aproximação de SSS em tempo real, não transporte de luz completo.
- Iluminação: direção única compartilhada entre key light e shader anatômico; preserva somente o halo difuso atrás do corpo, sem chão/plinto/projetor.
- Anatomia: os três deltoides recebem morphs esparsos independentes por IDs canônicos 2/3/4, preservando fallback dos perfis antigos e os 14 IDs estáveis de treino.
- Pesquisa: `docs/research/ULTRA_REALISM_DEEP_RESEARCH_V11_19.md` registra Top 5 GitHub por especialidade, inspeção de código, técnicas, licenças e limites.
- Plano e critérios Superpowers: `docs/superpowers/specs/2026-11-25-v11-19-realism-design.md` e `docs/superpowers/plans/2026-11-25-v11-19-realism.md`.
- Testes focados: `npm run test:rendering-realism` e `npm run test:review`. O build completo e a compilação GPU precisam de ambiente com dependências instaladas e WebGL2 disponível; ver `CHANGELOG_V11_19.md`.

## V11.20 — Adaptive plasma integration

The energy-volume shader now selects 8–16 ray-march samples based on the traversed cavity segment, preserving a statically bounded GLSL ES 3.00 loop. See `CHANGELOG_V11_20.md` and `docs/research/ULTRA_REALISM_DEEP_RESEARCH_V11_20.md` for implementation details, repository research, limitations, and remaining validation gates.


## V11.35 — Nutrição auditável

- USDA FDC: a vitamina B3 é normalizada em mg NE apenas por total direto 409 ou por componentes medidos e identificados 406+407 / 406+501; evidência é revalidada na entrada do catálogo e overflow é bloqueado.
- Cobertura: auditoria por nutriente e por fonte, com TBCA estratificada em `ALIMENTO`, `PREPARACAO_COMPOSTA` e `UNKNOWN`.
- Elegibilidade de receitas: somente TBCA `ALIMENTO` é ingrediente; compostos/desconhecidos continuam bloqueados nos seletores e no store. Seis modelos de receita sem composição de ingredientes verificada permanecem indisponíveis para novas montagens.
- Pesquisa e pendências: `docs/research/NUTRITION_ENGINE_GITHUB_RESEARCH_V11_35.md` e `docs/quality/NUTRITION_ENGINE_V11_35_REMAINING_GAPS.md`.
- Limite desta release: TBCA local 7.2, USDA real ainda não importado; não declarar o motor clinicamente validado.
