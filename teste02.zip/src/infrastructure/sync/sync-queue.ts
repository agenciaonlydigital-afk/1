export interface SyncOperation {
  id: string;
  domain: string;
  action: string;
  createdAtMs: number;
}

const PENDING_OPERATIONS: SyncOperation[] = [];

export function enqueueSyncOperation(domain: string, action: string): SyncOperation {
  const op: SyncOperation = {
    id: `${domain}-${Date.now()}-${PENDING_OPERATIONS.length + 1}`,
    domain,
    action,
    createdAtMs: Date.now(),
  };
  PENDING_OPERATIONS.push(op);
  return op;
}

export function getPendingSyncCount(): number {
  return PENDING_OPERATIONS.length;
}
