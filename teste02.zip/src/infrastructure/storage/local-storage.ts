export interface StorageAdapter {
  getItem: (key: string) => string | null;
  setItem: (key: string, value: string) => void;
  removeItem: (key: string) => void;
}

const MEMORY_FALLBACK = new Map<string, string | null>();

export const safeStorageAdapter: StorageAdapter = {
  getItem(key) {
    if (MEMORY_FALLBACK.has(key)) return MEMORY_FALLBACK.get(key) ?? null;
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        const stored = window.localStorage.getItem(key);
        if (stored !== null) return stored;
      }
    } catch {
      // Fallback to in-memory store when storage is restricted
    }
    return MEMORY_FALLBACK.get(key) ?? null;
  },
  setItem(key, value) {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.setItem(key, value);
        MEMORY_FALLBACK.delete(key);
        return;
      }
    } catch {
      // Fallback to in-memory store when storage is restricted
    }
    MEMORY_FALLBACK.set(key, value);
  },
  removeItem(key) {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.removeItem(key);
        MEMORY_FALLBACK.delete(key);
        return;
      }
    } catch {
      // A tombstone prevents a stale readable localStorage value from reappearing.
    }
    MEMORY_FALLBACK.set(key, null);
  },
};
