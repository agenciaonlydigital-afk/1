export interface ErrorReportContext {
  source: 'error-boundary' | 'bootstrap' | 'runtime' | 'webgl';
  componentStack?: string;
  metadata?: Record<string, string | number | boolean>;
}

export interface ErrorReportEntry {
  message: string;
  timestampIso: string;
  context: ErrorReportContext;
}

const SESSION_ERROR_BUFFER: ErrorReportEntry[] = [];
const MAX_BUFFER_ENTRIES = 50;

export function reportError(error: unknown, context: ErrorReportContext): void {
  const message =
    error instanceof Error ? error.message : typeof error === 'string' ? error : 'Unknown error';

  SESSION_ERROR_BUFFER.push({
    message,
    timestampIso: new Date().toISOString(),
    context,
  });

  if (SESSION_ERROR_BUFFER.length > MAX_BUFFER_ENTRIES) {
    SESSION_ERROR_BUFFER.shift();
  }
}

export function getRecordedErrorCount(): number {
  return SESSION_ERROR_BUFFER.length;
}
