export interface AnalyticsEvent {
  name: string;
  properties?: Record<string, string | number | boolean>;
  timestampIso: string;
}

const EVENT_BUFFER: AnalyticsEvent[] = [];

export function trackDomainEvent(
  name: string,
  properties?: Record<string, string | number | boolean>,
): void {
  EVENT_BUFFER.push({
    name,
    properties,
    timestampIso: new Date().toISOString(),
  });
  if (EVENT_BUFFER.length > 100) {
    EVENT_BUFFER.shift();
  }
}
