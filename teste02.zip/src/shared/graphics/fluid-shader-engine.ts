// Shared single-context WebGL2 liquid renderer.
// Research references adapted in this implementation:
// - mrdoob/three.js physical shader chunks: anisotropic GGX visibility/distribution for satin metal.
// - evanw/webgl-water and HowdyKeith/swek-webgl2-water: Fresnel, refraction,
//   height-field ripples and differential-area caustics.
// - Aureliengmz/clearwater: compact WebGL2 optics, absorption and clean highlights.
// - pmndrs/drei MeshTransmissionMaterial: IOR, thickness and Beer-Lambert attenuation.
// - StarKnightt/liquid-glass and smirki/glasswork: SDF silhouettes, refraction normals
//   and bounded edge/rim optics.
// This is a small UI liquid volume, not an ocean/SPH simulation. Static water is
// rendered once; the shared RAF wakes only for a fill transition or a single impulse.

export interface SpringNode {
  height: number;
  velocity: number;
}

export interface WaterOpticalConfig {
  ior: number;
  fresnelR0: number;
  attenuationColor: [number, number, number];
  attenuationDistance: number;
  esrIntensity: number;
  causticIntensity: number;
  footprintFilter: boolean;
}

export const DEFAULT_WATER_OPTICAL_CONFIG: WaterOpticalConfig = {
  ior: 1.333,
  fresnelR0: 0.022,
  attenuationColor: [0.94, 0.985, 1.0],
  attenuationDistance: 2.15,
  esrIntensity: 0.92,
  causticIntensity: 0.42,
  footprintFilter: true,
};


let reducedMotionQueryCache: MediaQueryList | null = null;

export function prefersReducedMotion(): boolean {
  if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') return false;
  reducedMotionQueryCache ??= window.matchMedia('(prefers-reduced-motion: reduce)');
  return reducedMotionQueryCache.matches;
}

export function createSpringArray(count: number): SpringNode[] {
  return Array.from({ length: count }, () => ({ height: 0, velocity: 0 }));
}

/** Exponential interpolation keeps progress transitions consistent at 30/60/120Hz. */
export function interpolateRatio(
  current: number,
  target: number,
  elapsedSeconds: number,
  timeConstantSeconds = 0.14,
): number {
  const delta = target - current;
  if (!Number.isFinite(delta) || Math.abs(delta) <= 0.0005) return target;
  const dt = Math.min(0.05, Math.max(0, Number.isFinite(elapsedSeconds) ? elapsedSeconds : 0));
  const timeConstant = Math.max(
    0.001,
    Number.isFinite(timeConstantSeconds) ? timeConstantSeconds : 0.14,
  );
  const next = current + delta * (1 - Math.exp(-dt / timeConstant));
  // Snap on the same frame that crosses the threshold so the final target is actually painted.
  return Math.abs(target - next) <= 0.0005 ? target : next;
}

const springScratch = new WeakMap<SpringNode[], { left: Float32Array; right: Float32Array }>();

export function stepSpringNodes(
  nodes: SpringNode[],
  tension: number,
  damping: number,
  spread: number,
): void {
  const n = nodes.length;
  for (let i = 0; i < n; i++) {
    const node = nodes[i];
    if (!node) continue;
    const force = -tension * node.height - node.velocity * damping;
    node.velocity += force;
    node.height += node.velocity;
  }

  let scratch = springScratch.get(nodes);
  if (!scratch || scratch.left.length !== n) {
    scratch = { left: new Float32Array(n), right: new Float32Array(n) };
    springScratch.set(nodes, scratch);
  }
  const { left: leftDeltas, right: rightDeltas } = scratch;

  for (let pass = 0; pass < 2; pass++) {
    for (let i = 0; i < n; i++) {
      const curr = nodes[i];
      if (!curr) continue;
      const prev = i > 0 ? nodes[i - 1] : undefined;
      const next = i < n - 1 ? nodes[i + 1] : undefined;

      if (prev) {
        const d = spread * (curr.height - prev.height);
        leftDeltas[i] = d;
        prev.velocity += d;
      }
      if (next) {
        const d = spread * (curr.height - next.height);
        rightDeltas[i] = d;
        next.velocity += d;
      }
    }

    for (let i = 0; i < n; i++) {
      const prev = i > 0 ? nodes[i - 1] : undefined;
      const next = i < n - 1 ? nodes[i + 1] : undefined;
      if (prev) prev.height += leftDeltas[i] ?? 0;
      if (next) next.height += rightDeltas[i] ?? 0;
    }
  }
}

export type FluidProgramKind = 'droplet' | 'tank' | 'energy' | 'metal';

const MIN_FLUID_FRAME_INTERVAL_MS = 1000 / 60;

export interface FluidDrawJob {
  kind: FluidProgramKind;
  targetCanvas: HTMLCanvasElement;
  width: number;
  height: number;
  fill: number;
  active?: boolean;
  isAnimating?: boolean;
  wave?: SpringNode[];
  opticalConfig?: Partial<WaterOpticalConfig>;
  metalColor?: [number, number, number];
  metalHighlight?: [number, number, number];
  isVisible: boolean;
}

const VERTEX_SHADER_300 = `#version 300 es
in vec2 a_position;
out vec2 v_uv;
void main() {
  v_uv = a_position * 0.5 + 0.5;
  gl_Position = vec4(a_position, 0.0, 1.0);
}
`;

// Utilitários ópticos em espaço linear HDR + ACES Filmic + derivadas hardware para projeção de cáusticas
const SHARED_OPTICS_GLSL = `
float invSmooth(float lo, float hi, float x) {
  return 1.0 - smoothstep(lo, hi, x);
}

vec3 acesFilmic(vec3 x) {
  float a = 2.51;
  float b = 0.03;
  float c = 2.43;
  float d = 0.59;
  float e = 0.14;
  return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);
}

vec3 linearToSrgb(vec3 c) {
  vec3 linear = max(c, vec3(0.0));
  vec3 low = linear * 12.92;
  vec3 high = 1.055 * pow(linear, vec3(1.0 / 2.4)) - 0.055;
  return mix(high, low, lessThanEqual(linear, vec3(0.0031308)));
}

float distributionGGX(float nDotH, float roughness) {
  float a = max(roughness * roughness, 0.0025);
  float a2 = a * a;
  float n2 = nDotH * nDotH;
  float denom = n2 * (a2 - 1.0) + 1.0;
  return a2 / max(3.14159265 * denom * denom, 1e-5);
}

float geometrySchlickGGX(float nDotV, float roughness) {
  float r = roughness + 1.0;
  float k = (r * r) * 0.125;
  return nDotV / max(nDotV * (1.0 - k) + k, 1e-5);
}

vec3 fresnelSchlick(float cosTheta, vec3 f0) {
  float f = pow(clamp(1.0 - cosTheta, 0.0, 1.0), 5.0);
  return f0 + (1.0 - f0) * f;
}

vec3 evaluateGGXSpecular(vec3 normal, vec3 viewDir, vec3 lightDir, vec3 f0, float roughness) {
  vec3 n = normalize(normal);
  vec3 v = normalize(viewDir);
  vec3 l = normalize(lightDir);
  vec3 h = normalize(v + l);
  float nDotV = max(dot(n, v), 1e-4);
  float nDotL = max(dot(n, l), 0.0);
  float nDotH = max(dot(n, h), 0.0);
  float vDotH = max(dot(v, h), 0.0);
  float d = distributionGGX(nDotH, roughness);
  float g = geometrySchlickGGX(nDotV, roughness) * geometrySchlickGGX(nDotL, roughness);
  vec3 f = fresnelSchlick(vDotH, f0);
  return (d * g * f * nDotL) / max(4.0 * nDotV * nDotL, 1e-4);
}

float softboxRect(vec3 direction, vec3 centerDirection, vec2 halfSize, float softness) {
  vec3 center = normalize(centerDirection);
  vec3 referenceUp = abs(center.y) > 0.94 ? vec3(0.0, 0.0, 1.0) : vec3(0.0, 1.0, 0.0);
  vec3 axisU = normalize(cross(referenceUp, center));
  vec3 axisV = normalize(cross(center, axisU));
  float forward = max(dot(direction, center), 1e-3);
  vec2 panelUv = vec2(dot(direction, axisU), dot(direction, axisV)) / forward;
  float edge = max(abs(panelUv.x) / max(halfSize.x, 1e-3), abs(panelUv.y) / max(halfSize.y, 1e-3));
  return 1.0 - smoothstep(1.0 - softness, 1.0 + softness, edge);
}

// Anisotropic GGX keeps the macro reflections stretched along the liquid-metal flow.
// The tangent follows the arc; the bitangent closes a stable local shading frame.
float visibilityGGXSmithAnisotropic(
  float alphaT,
  float alphaB,
  float dotTV,
  float dotBV,
  float dotTL,
  float dotBL,
  float dotNV,
  float dotNL
) {
  float gv = dotNL * length(vec3(alphaT * dotTV, alphaB * dotBV, dotNV));
  float gl = dotNV * length(vec3(alphaT * dotTL, alphaB * dotBL, dotNL));
  return 0.5 / max(gv + gl, 1e-5);
}

float distributionGGXAnisotropic(
  float alphaT,
  float alphaB,
  float nDotH,
  float tDotH,
  float bDotH
) {
  float a2 = alphaT * alphaB;
  vec3 v = vec3(alphaB * tDotH, alphaT * bDotH, a2 * nDotH);
  float v2 = max(dot(v, v), 1e-6);
  float w2 = a2 / v2;
  return (a2 * w2 * w2) / 3.14159265;
}

vec3 evaluateGGXAnisotropicSpecular(
  vec3 normal,
  vec3 tangent,
  vec3 viewDir,
  vec3 lightDir,
  vec3 f0,
  float roughness,
  float anisotropy
) {
  vec3 n = normalize(normal);
  vec3 t = normalize(tangent - n * dot(n, tangent));
  vec3 b = normalize(cross(n, t));
  vec3 v = normalize(viewDir);
  vec3 l = normalize(lightDir);
  vec3 h = normalize(v + l);

  float nDotV = max(dot(n, v), 1e-4);
  float nDotL = max(dot(n, l), 0.0);
  float nDotH = max(dot(n, h), 0.0);
  float vDotH = max(dot(v, h), 0.0);
  float alpha = max(roughness * roughness, 0.0025);
  float alphaT = max(alpha * (1.0 - clamp(anisotropy, 0.0, 0.7)), 0.0025);
  float alphaB = max(alpha * (1.0 + clamp(anisotropy, 0.0, 0.7)), 0.0025);

  float visibility = visibilityGGXSmithAnisotropic(
    alphaT, alphaB,
    dot(t, v), dot(b, v),
    dot(t, l), dot(b, l),
    nDotV, nDotL
  );
  float distribution = distributionGGXAnisotropic(
    alphaT, alphaB, nDotH, dot(t, h), dot(b, h)
  );
  vec3 fresnel = fresnelSchlick(vDotH, f0);
  return fresnel * (visibility * distribution) * nDotL;
}

float hash21(vec2 p) {
  p = fract(p * vec2(123.34, 456.21));
  p += dot(p, p + 45.32);
  return fract(p.x * p.y);
}


float valueNoise(vec2 st) {
  vec2 i = floor(st);
  vec2 f = fract(st);
  float a = hash21(i);
  float b = hash21(i + vec2(1.0, 0.0));
  float c = hash21(i + vec2(0.0, 1.0));
  float d = hash21(i + vec2(1.0, 1.0));
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}

float fbm3(vec2 st) {
  float val = 0.0;
  float amp = 0.5;
  mat2 rot = mat2(0.8, 0.6, -0.6, 0.8);
  for (int i = 0; i < 3; i++) {
    val += amp * valueNoise(st);
    st = rot * st * 2.02 + vec2(1.7, 3.1);
    amp *= 0.5;
  }
  return val;
}

// Cascata Gerstner com derivadas analíticas + micro-ondulação capilar
void evalGerstnerCascade(
  vec2 pos,
  float t,
  float footprintScale,
  out float heightOut,
  out vec2 gradOut,
  out float causticFocusOut
) {
  heightOut = 0.0;
  gradOut = vec2(0.0);
  float laplacian = 0.0;

  vec4 waves[4];
  waves[0] = vec4(1.25, 0.018, 0.89, 0.45);
  waves[1] = vec4(0.70, 0.011, -0.74, 0.67);
  waves[2] = vec4(0.36, 0.007, 0.48, -0.88);
  waves[3] = vec4(0.19, 0.0035, -0.92, -0.38);

  for (int i = 0; i < 4; i++) {
    float L = waves[i].x;
    float A = waves[i].y;
    vec2 dir = normalize(waves[i].zw);
    float fade = mix(1.0, smoothstep(0.04, 0.30, L), footprintScale);
    float k = 6.283185 / L;
    float c = sqrt(9.81 / k) * 0.48;
    float phase = k * dot(dir, pos) - c * t * 1.35;
    float amp = A * fade;
    float s = sin(phase);
    heightOut += amp * s;
    gradOut += dir * (amp * k * cos(phase));
    laplacian += amp * k * k * s;
  }

  causticFocusOut = clamp(0.5 + laplacian * 0.34, 0.0, 1.5);
}

// Ambiente analítico procedural de estúdio em espaço linear (não é uma textura HDRI).
vec3 sampleStudioEnvironment(vec3 dir, vec3 skyTint) {
  vec3 d = normalize(dir);
  float elev = d.y;
  float az = atan(d.x, d.z);

  // Chão escuro obsidiana + horizonte neutro frio + cúpula celeste clara
  vec3 floorCol = vec3(0.012, 0.022, 0.028);
  vec3 wallCol = vec3(0.045, 0.078, 0.095);
  vec3 horizonCol = mix(wallCol, skyTint * 0.24, 0.45);
  vec3 skyCol = mix(horizonCol, vec3(0.76, 0.90, 0.98), smoothstep(0.0, 0.88, elev));

  vec3 env = elev < 0.0
    ? mix(floorCol, horizonCol * 0.65, smoothstep(-0.65, 0.0, elev))
    : skyCol;

  // Painéis retangulares de estúdio: highlights alongados, não pontos circulares artificiais.
  float stripLeft = softboxRect(d, vec3(-0.56, 0.66, 0.50), vec2(0.13, 0.48), 0.10);
  float stripRight = softboxRect(d, vec3(0.62, 0.38, 0.68), vec2(0.11, 0.40), 0.12);
  float overhead = softboxRect(d, vec3(-0.15, 0.95, 0.27), vec2(0.34, 0.12), 0.12);
  float rimArc = exp(-pow((elev - 0.14) * 11.0, 2.0)) * (0.4 + 0.6 * cos(az * 2.0));

  env += vec3(2.40, 2.50, 2.60) * stripLeft;
  env += skyTint * 1.15 * stripRight;
  env += vec3(3.10, 3.20, 3.30) * overhead;
  env += vec3(0.90, 1.05, 1.15) * rimArc * 0.55;
  return env;
}

// Cáustica por área diferencial projetada (evanw/webgl-water: dFdx / dFdy)
float computeDifferentialCaustic(vec2 basePos, vec2 refrPos) {
  float detBase = abs(dFdx(basePos.x) * dFdy(basePos.y) - dFdx(basePos.y) * dFdy(basePos.x));
  float detRefr = abs(dFdx(refrPos.x) * dFdy(refrPos.y) - dFdx(refrPos.y) * dFdy(refrPos.x));
  float ratio = detBase / max(detRefr, max(detBase * 0.14, 1e-6));
  return clamp(pow(ratio, 1.55) - 0.65, 0.0, 3.8);
}

// Atenuação volumétrica exponencial Beer-Lambert (linear)
vec3 applyBeerLambert(vec3 bgLinear, vec3 attenColor, float attenDist, float opticalDepth) {
  vec3 sigma = -log(max(attenColor, vec3(0.005))) / max(attenDist, 0.05);
  return bgLinear * exp(-sigma * max(opticalDepth, 0.0));
}
`;

// 1. Gota 3D de cristal com refração dupla, TIR real, cáusticas dFdx/dFdy, dispersão RGB e ACES Filmic
const DROPLET_FRAGMENT_300 = `#version 300 es
precision highp float;

in vec2 v_uv;
out vec4 fragColor;

uniform vec2 u_resolution;
uniform float u_time;
uniform float u_fill;
uniform float u_active;
uniform float u_ior;
uniform float u_fresnelR0;
uniform vec3 u_attenColor;
uniform float u_attenDist;
uniform float u_esrIntensity;
uniform float u_causticIntensity;
uniform float u_footprint;
uniform float u_wave[24];

${SHARED_OPTICS_GLSL}

float sdRoundedCone(vec2 p, vec2 a, vec2 b, float r1, float r2) {
  vec2 ba = b - a;
  float l2 = dot(ba, ba);
  float rr = r1 - r2;
  float a2 = l2 - rr * rr;
  float il2 = 1.0 / l2;

  vec2 pa = p - a;
  float y = dot(pa, ba);
  float z = y - l2;
  vec2 proj = pa * l2 - ba * y;
  float x2 = dot(proj, proj);
  float y2 = y * y * l2;
  float z2 = z * z * l2;

  float k = sign(rr) * rr * rr * x2;
  if (sign(z) * a2 * z2 > k) return sqrt(x2 + z2) * il2 - r2;
  if (sign(y) * a2 * y2 < k) return sqrt(x2 + y2) * il2 - r1;
  return (sqrt(x2 * a2 * il2) + y * rr) * il2 - r1;
}

float sdDroplet(vec2 p) {
  return sdRoundedCone(p, vec2(0.0, -0.155), vec2(0.0, 0.435), 0.305, 0.015);
}

float sampleWaveSpring(float u) {
  float idx = clamp(u, 0.0, 1.0) * 23.0;
  int i0 = clamp(int(floor(idx)), 0, 23);
  int i1 = min(23, i0 + 1);
  return mix(u_wave[i0], u_wave[i1], fract(idx));
}

// Refração dupla através do volume 3D + parede traseira curva com ambiente procedural e cáusticas focadas
vec3 traceDropletRay(
  vec2 p,
  vec3 enterN,
  vec3 backN,
  vec3 viewDir,
  float etaIn,
  float etaOut,
  float travelDepth,
  float inWater,
  float causticTerm
) {
  vec3 ray1 = refract(-viewDir, enterN, etaIn);
  if (dot(ray1, ray1) < 0.001) {
    // Total Internal Reflection (TIR) na interface frontal
    return sampleStudioEnvironment(reflect(-viewDir, enterN), vec3(0.75, 0.92, 1.0));
  }

  vec3 ray2 = refract(ray1, -backN, etaOut);
  if (dot(ray2, ray2) < 0.001) {
    // TIR na parede interna traseira: concentra luz cáustica e reflexo celeste brilhante
    vec3 tirDir = reflect(ray1, -backN);
    vec3 tirEnv = sampleStudioEnvironment(tirDir, vec3(0.72, 0.92, 1.0));
    return tirEnv * 0.72 + vec3(0.75, 0.95, 1.0) * causticTerm * inWater * 0.55;
  }

  vec3 envCol = sampleStudioEnvironment(ray2, vec3(0.66, 0.88, 0.98));
  vec3 reflectedBack = sampleStudioEnvironment(reflect(ray1, -backN), vec3(0.78, 0.92, 1.0));
  float exitCos = clamp(abs(dot(ray1, -backN)), 0.0, 1.0);
  float exitR0 = pow((etaOut - 1.0) / max(etaOut + 1.0, 1e-3), 2.0);
  float exitFresnel = exitR0 + (1.0 - exitR0) * pow(1.0 - exitCos, 5.0);
  // A interface traseira também reflete: omiti-la deixa o volume com aspecto de vidro fino.
  vec3 backInterface = mix(envCol, reflectedBack, clamp(exitFresnel * 0.82, 0.0, 0.78));
  // Fundo interno escuro do estúdio para alto contraste transparente + foco cáustico no fundo da gota.
  vec3 backdrop = mix(vec3(0.022, 0.036, 0.045), backInterface * 0.62, smoothstep(-0.35, 0.65, ray2.y));
  backdrop += vec3(0.88, 0.98, 1.0) * causticTerm * inWater * clamp(0.35 + travelDepth * 1.4, 0.0, 1.25);
  return backdrop;
}

void main() {
  float aspect = u_resolution.x / max(u_resolution.y, 1.0);
  vec2 p = vec2((v_uv.x - 0.5) * aspect, v_uv.y - 0.5);

  float d = sdDroplet(p);
  float aa = 1.4 / max(min(u_resolution.x, u_resolution.y), 1.0);
  if (d > 0.04) {
    fragColor = vec4(0.0);
    return;
  }

  // Normal 3D C1-contínua verdadeira ao longo da superfície de revolução da gota
  vec2 eps = vec2(0.0035, 0.0);
  vec2 grad = vec2(sdDroplet(p + eps.xy) - sdDroplet(p - eps.xy),
                   sdDroplet(p + eps.yx) - sdDroplet(p - eps.yx)) / (2.0 * eps.x);
  float localR = mix(0.018, 0.305, (1.0 - smoothstep(-0.155, 0.435, p.y)));
  float zNorm = sqrt(max(0.0, (-d) * (2.0 * localR + d))) / max(localR, 0.02);
  vec3 glassN = normalize(vec3(grad * (1.0 - zNorm * 0.35), max(0.04, zNorm)));
  vec3 backN = normalize(vec3(grad * 0.85, -max(0.08, zNorm)));

  float fillY = mix(-0.43, 0.37, clamp(u_fill, 0.0, 1.0));
  float uX = clamp((p.x + 0.31) / 0.62, 0.0, 1.0);
  float springH = sampleWaveSpring(uX) * 0.018;
  float gerstH = 0.0;
  vec2 gerstGrad = vec2(0.0);
  float causticFocus = 0.0;
  if (u_fill > 0.004) {
    evalGerstnerCascade(vec2(p.x * 2.6, p.y * 1.9), u_time, u_footprint, gerstH, gerstGrad, causticFocus);
  }

  // Menisco capilar real encostando nas paredes do cristal
  float wallProximity = smoothstep(-0.11, -0.002, d);
  float meniscusLift = wallProximity * 0.026 * step(0.02, u_fill) * step(u_fill, 0.98);
  float frontY = fillY + springH + gerstH * 0.65 + meniscusLift;

  // Plano elíptico 2.5D da superfície superior da água
  float ellipseH = 0.042 * step(0.03, u_fill) * step(u_fill, 0.97) * invSmooth(0.16, 0.32, abs(p.x));
  float backY = frontY + ellipseH;
  float inTopPlane = smoothstep(frontY - 0.0045, frontY + 0.0045, p.y) *
                     invSmooth(backY - 0.0045, backY + 0.0045, p.y) *
                     step(0.02, u_fill);

  float depthBelow = backY - p.y;
  float inWater = smoothstep(-0.005, 0.005, depthBelow) * step(0.004, u_fill);

  vec3 planeN = normalize(vec3(-gerstGrad.x * 1.75, 0.74 - gerstGrad.y * 0.95, 0.56));
  vec3 waveBodyN = normalize(vec3(glassN.x - gerstGrad.x * 0.22, glassN.y - gerstGrad.y * 0.14, glassN.z));
  vec3 waterN = normalize(mix(waveBodyN, planeN, inTopPlane * 0.88));
  vec3 activeN = mix(glassN, waterN, inWater);

  // Foco de cáustica aproximado: área diferencial dFdx/dFdy + detalhe procedural
  vec3 keyLight = normalize(vec3(-0.36, 0.86, 0.35));
  float causticTerm = 0.0;
  if (u_fill > 0.004) {
    vec3 refrLight = refract(-keyLight, waterN, 1.0 / max(u_ior, 1.01));
    float throwDist = clamp(depthBelow * 0.8 + zNorm * 0.22, 0.02, 0.65);
    vec2 floorHit = p + refrLight.xy * throwDist;
    float jacCaustic = computeDifferentialCaustic(p, floorHit);
    float waveFocus = clamp(0.72 + causticFocus * 0.22, 0.55, 1.08);
    float bottomLens = (1.0 - smoothstep(-0.44, -0.18, p.y)) * 0.55 + 0.45;
    // Differential-area concentration is the physical signal; curvature only modulates its contrast.
    causticTerm = jacCaustic * waveFocus * u_causticIntensity * bottomLens;
  }

  vec3 viewDir = normalize(vec3(0.0, -0.22, 0.975));

  // Dispersão cromática RGB real (IOR separado por canal R, G, B)
  float curIor = mix(1.48, u_ior, inWater);
  float disp = mix(0.0012, 0.0024, inWater);
  float etaInR = 1.0 / max(curIor - disp, 1.02);
  float etaInG = 1.0 / max(curIor, 1.02);
  float etaInB = 1.0 / max(curIor + disp, 1.02);

  vec3 tracedCol;
  if (u_fill > 0.004) {
    tracedCol = vec3(
      traceDropletRay(p, activeN, backN, viewDir, etaInR, curIor - disp, zNorm, inWater, causticTerm).r,
      traceDropletRay(p, activeN, backN, viewDir, etaInG, curIor, zNorm, inWater, causticTerm).g,
      traceDropletRay(p, activeN, backN, viewDir, etaInB, curIor + disp, zNorm, inWater, causticTerm).b
    );
  } else {
    vec3 glassRay = traceDropletRay(p, activeN, backN, viewDir, 1.0 / 1.48, 1.48, zNorm, 0.0, 0.0);
    tracedCol = glassRay;
  }

  // A gota permanece limpa: sem bolhas decorativas ou movimento contínuo.
  // O volume é definido pela refração, pelo menisco e pelas cáusticas discretas.

  // Atenuação Beer-Lambert cristalina (água pura quase incolor no centro, leve ciano só no caminho longo)
  float opticalPath = clamp(depthBelow * 0.65 + zNorm * 0.18, 0.0, 1.0);
  vec3 beerCol = applyBeerLambert(tracedCol, u_attenColor, u_attenDist, opticalPath);
  vec3 waterBody = mix(tracedCol, beerCol, inWater);

  // Fresnel físico Schlick na interface frontal + reflexão do ambiente procedural de estúdio
  float cosTheta = clamp(dot(activeN, viewDir), 0.0, 1.0);
  float r0 = mix(0.038, u_fresnelR0, inWater);
  float fresnel = r0 + (1.0 - r0) * pow(1.0 - cosTheta, 5.0);
  vec3 envRefl = sampleStudioEnvironment(reflect(-viewDir, activeN), vec3(0.75, 0.92, 1.0));
  vec3 col = mix(waterBody, envRefl, clamp(fresnel * u_esrIntensity * mix(0.68, 0.98, u_active), 0.0, 0.94));

  // Brilho especular GGX na superfície superior ondulante + linha brilhante fina do menisco frontal
  if (inTopPlane > 0.05) {
    vec3 waterSpecular = evaluateGGXSpecular(planeN, viewDir, keyLight,
      vec3(u_fresnelR0), 0.035);
    col += waterSpecular * vec3(3.0, 3.15, 3.25) * inTopPlane;
  }

  float frontLip = invSmooth(0.0, 0.011, abs(p.y - frontY)) * step(0.02, u_fill);
  col += vec3(1.55, 1.75, 1.85) * frontLip * 0.72;

  // Reflexo vítreo sutil de softbox na cápsula + borda prismática nítida
  float glassStreak = invSmooth(0.006, 0.072, length(p - vec2(-0.105, 0.105)));
  float longSoftbox = exp(-pow((p.x + 0.205) * 19.0, 2.0)) *
                      smoothstep(-0.26, -0.12, p.y) *
                      invSmooth(0.17, 0.39, p.y);
  float lowerSoftbox = exp(-pow((p.x - 0.205) * 22.0, 2.0)) *
                       smoothstep(-0.28, -0.12, p.y) *
                       invSmooth(0.10, 0.30, p.y);
  col += vec3(1.6, 1.75, 1.86) * glassStreak * 0.20;
  col += vec3(1.42, 1.62, 1.72) * longSoftbox * 0.19;
  col += vec3(0.72, 1.06, 1.20) * lowerSoftbox * 0.10;

  // Contorno refrativo natural (Fresnel no limite da gota)
  float rimGlow = invSmooth(0.001, 0.014, abs(d));
  vec3 rimTint = mix(vec3(0.32, 0.52, 0.62), vec3(1.35, 1.55, 1.68), clamp(0.55 - p.x + p.y * 0.4, 0.0, 1.0));
  col = mix(col, rimTint, rimGlow * mix(0.55, 0.88, u_active));

  col = linearToSrgb(acesFilmic(col));

  // Transparência óptica real: centro quase translúcido, bordas Fresnel opacas
  float shapeMask = invSmooth(-aa, aa, d);
  float glassAlpha = clamp(mix(0.36, 0.80, inWater) + fresnel * 0.58 + rimGlow * 0.48 + glassStreak * 0.16, 0.0, 1.0);
  float alpha = shapeMask * glassAlpha;
  fragColor = vec4(col * alpha, alpha);
}
`;

// 2. Tubo capilar de cristal 3D preenchido com água transparente contínua, menisco côncavo e lente cilíndrica
const TANK_FRAGMENT_300 = `#version 300 es
precision highp float;

in vec2 v_uv;
out vec4 fragColor;

uniform vec2 u_resolution;
uniform float u_time;
uniform float u_fill;
uniform float u_ior;
uniform float u_fresnelR0;
uniform vec3 u_attenColor;
uniform float u_attenDist;
uniform float u_esrIntensity;
uniform float u_causticIntensity;
uniform float u_footprint;
uniform float u_wave[24];

${SHARED_OPTICS_GLSL}

float sampleTankWave(float u) {
  float idx = clamp(u, 0.0, 1.0) * 23.0;
  int i0 = clamp(int(floor(idx)), 0, 23);
  int i1 = min(23, i0 + 1);
  return mix(u_wave[i0], u_wave[i1], fract(idx));
}

void main() {
  float aspect = u_resolution.x / max(u_resolution.y, 1.0);
  vec2 uv = v_uv;
  vec2 p = vec2(uv.x * aspect, uv.y);
  float t = u_time;

  float fill = clamp(u_fill, 0.0, 1.0);
  float cylY = clamp((uv.y - 0.5) * 1.92, -0.96, 0.96);
  float cylZ = sqrt(max(0.06, 1.0 - cylY * cylY));

  // Cascata de ondas Gerstner + respingo da mola ao longo da superfície interna
  float gerstH = 0.0;
  vec2 gerstGrad = vec2(0.0);
  float causticFocus = 0.0;
  if (fill > 0.004) {
    evalGerstnerCascade(vec2(p.x * 1.35, p.y * 1.8), t, u_footprint, gerstH, gerstGrad, causticFocus);
  }

  // Menisco aderido à parede do tubo. A ondulação vem somente do impulso de interação.
  float wallWetCurve = 0.014 * pow(cylY, 2.0);
  float meniscusSlosh = sampleTankWave(clamp(fill, 0.0, 1.0)) * 0.018 + gerstH * 0.12;
  float waterEnd = fill + (wallWetCurve + meniscusSlosh) * step(0.015, fill) * step(fill, 0.985);

  float inWater = invSmooth(waterEnd - 0.006, waterEnd + 0.006, uv.x) * step(0.004, fill);

  // Normal do tubo de vidro + normal das ondas capilares na água
  vec3 cylN = normalize(vec3(0.0, cylY * 0.88, cylZ));
  vec3 meniscusLipN = normalize(vec3(-invSmooth(0.0, 0.036, abs(uv.x - waterEnd)) * 0.65 * step(fill, 0.985), cylY * 0.72, cylZ));
  vec3 waterWaveN = normalize(vec3(
    -gerstGrad.x * 0.42 - invSmooth(0.0, 0.032, abs(uv.x - waterEnd)) * 0.45 * step(fill, 0.985),
    cylY * 0.80 - gerstGrad.y * 0.34,
    cylZ
  ));
  vec3 activeN = mix(cylN, waterWaveN, inWater);
  activeN = normalize(mix(activeN, meniscusLipN, 0.35 * inWater));

  vec3 viewDir = normalize(vec3(0.0, -0.14, 0.99));
  vec3 keyLight = normalize(vec3(-0.32, 0.88, 0.35));

  // Foco de luz aproximado por área diferencial + lente cilíndrica no fundo do tubo
  float causticTerm = 0.0;
  float cylLensRibbon = exp(-pow((uv.y - 0.24) * 5.2, 2.0));
  if (fill > 0.004) {
    vec3 refrLight = refract(-keyLight, waterWaveN, 1.0 / max(u_ior, 1.01));
    vec2 floorHit = p + refrLight.xy * clamp((1.0 - uv.y) * 0.35 + cylZ * 0.14, 0.02, 0.45);
    float jacCaustic = computeDifferentialCaustic(p, floorHit);
    float waveFocus = clamp(0.68 + causticFocus * 0.24, 0.52, 1.08);
    // Lente cilíndrica concentra luz no terço inferior do tubo (y ~ 0.14..0.38).
    causticTerm = jacCaustic * waveFocus * u_causticIntensity * (0.18 + 0.42 * cylLensRibbon);
  }

  // Refração RGB com dispersão cromática aproximada através da coluna cilíndrica de água
  float etaBase = mix(1.48, u_ior, inWater);
  float disp = mix(0.0010, 0.0022, inWater);

  vec3 refrR;
  vec3 refrG;
  vec3 refrB;
  if (fill > 0.004) {
    refrR = refract(-viewDir, activeN, 1.0 / max(etaBase - disp, 1.02));
    refrG = refract(-viewDir, activeN, 1.0 / max(etaBase, 1.02));
    refrB = refract(-viewDir, activeN, 1.0 / max(etaBase + disp, 1.02));
  } else {
    refrG = refract(-viewDir, activeN, 1.0 / max(etaBase, 1.02));
    refrR = refrG;
    refrB = refrG;
  }

  vec3 backN = normalize(vec3(0.0, cylY * 0.85, -cylZ));
  vec3 exitR;
  vec3 exitG;
  vec3 exitB;
  if (fill > 0.004) {
    exitR = refract(refrR, -backN, etaBase - disp);
    exitG = refract(refrG, -backN, etaBase);
    exitB = refract(refrB, -backN, etaBase + disp);
  } else {
    exitG = refract(refrG, -backN, etaBase);
    exitR = exitG;
    exitB = exitG;
  }

  vec3 glassEnv;
  if (fill > 0.004) {
    vec3 hdrBackR = dot(exitR, exitR) < 0.001
      ? sampleStudioEnvironment(reflect(refrR, -backN), vec3(0.80, 0.95, 1.0))
      : sampleStudioEnvironment(exitR, vec3(0.66, 0.88, 0.98));
    vec3 hdrBackG = dot(exitG, exitG) < 0.001
      ? sampleStudioEnvironment(reflect(refrG, -backN), vec3(0.80, 0.95, 1.0))
      : sampleStudioEnvironment(exitG, vec3(0.66, 0.88, 0.98));
    vec3 hdrBackB = dot(exitB, exitB) < 0.001
      ? sampleStudioEnvironment(reflect(refrB, -backN), vec3(0.80, 0.95, 1.0))
      : sampleStudioEnvironment(exitB, vec3(0.66, 0.88, 0.98));
    glassEnv = vec3(hdrBackR.r, hdrBackG.g, hdrBackB.b);
  } else {
    glassEnv = dot(exitG, exitG) < 0.001
      ? sampleStudioEnvironment(reflect(refrG, -backN), vec3(0.80, 0.95, 1.0))
      : sampleStudioEnvironment(exitG, vec3(0.66, 0.88, 0.98));
  }
  // Tubo vazio à direita = cavidade de vidro escura e limpa; água = lente cristalina translúcida
  vec3 emptyCavity = mix(vec3(0.010, 0.020, 0.026), glassEnv * 0.20, cylZ * 0.72);
  if (fill > 0.004) {
    float exitCos = clamp(abs(dot(refrG, -backN)), 0.0, 1.0);
    float exitR0 = pow((etaBase - 1.0) / max(etaBase + 1.0, 1e-3), 2.0);
    float exitFresnel = exitR0 + (1.0 - exitR0) * pow(1.0 - exitCos, 5.0);
    vec3 reflectedBack = sampleStudioEnvironment(reflect(refrG, -backN), vec3(0.78, 0.92, 1.0));
    glassEnv = mix(glassEnv, reflectedBack, clamp(exitFresnel * 0.78, 0.0, 0.72));
  }
  vec3 waterTint = vec3(0.54, 0.76, 0.86);
  vec3 wetCavity = mix(waterTint * 0.10, glassEnv * 0.72, 0.56 + 0.22 * cylLensRibbon);
  wetCavity = mix(wetCavity, waterTint * 0.42, 0.14);
  wetCavity += vec3(0.66, 0.88, 0.96) * causticTerm * 0.34;

  vec3 beerWater = applyBeerLambert(wetCavity, u_attenColor, u_attenDist, clamp(cylZ * 0.45, 0.04, 0.75));
  vec3 col = mix(emptyCavity, beerWater, inWater);

  // Água cristalina sem bolhas decorativas; o movimento é provocado somente
  // quando o volume muda ou quando o usuário interage com o reservatório.

  // Fresnel cilíndrico + reflexo ESR da cúpula de estúdio
  float cosTheta = clamp(dot(activeN, viewDir), 0.0, 1.0);
  float r0 = mix(0.036, u_fresnelR0, inWater);
  float fresnel = r0 + (1.0 - r0) * pow(1.0 - cosTheta, 5.0);
  vec3 esrCol = sampleStudioEnvironment(reflect(-viewDir, activeN), vec3(0.72, 0.90, 0.98));
  col = mix(col, esrCol, clamp(fresnel * u_esrIntensity * mix(0.32, 0.82, inWater), 0.0, 0.88));

  // Brilho especular contínuo de tubo cilíndrico + menisco frontal luminoso (TIR na interface ar/água)
  vec3 glassSpecular = evaluateGGXSpecular(activeN, viewDir, keyLight,
    vec3(0.036), 0.075);
  float topGlassGlare = invSmooth(0.0, 0.065, abs(uv.y - 0.86)) *
                        smoothstep(0.02, 0.12, uv.x) * invSmooth(0.88, 0.98, uv.x);
  float botLensSheen = invSmooth(0.0, 0.055, abs(uv.y - 0.11)) * inWater;
  col += glassSpecular * vec3(2.4, 2.55, 2.7) + vec3(1.5, 1.65, 1.75) * topGlassGlare * 0.24;
  col += vec3(0.85, 0.98, 1.0) * botLensSheen * 0.28;

  // End-caps refrativos: a cápsula parece uma peça de vidro espesso,
  // não um retângulo azul com uma borda CSS.
  float leftCap = exp(-pow((uv.x - 0.016) * 74.0, 2.0)) *
                  smoothstep(0.08, 0.32, uv.y) * invSmooth(0.68, 0.92, uv.y);
  float rightCap = exp(-pow((uv.x - 0.984) * 74.0, 2.0)) *
                   smoothstep(0.08, 0.32, uv.y) * invSmooth(0.68, 0.92, uv.y);
  float sideRim = leftCap + rightCap;
  col += vec3(1.15, 1.48, 1.62) * sideRim * 0.32;

  // Borda côncava brilhante do menisco no encontro ar/água (x ≈ waterEnd)
  float meniscusRim = invSmooth(0.0, 0.011, abs(uv.x - waterEnd)) * step(0.015, fill) * step(fill, 0.985);
  float meniscusDark = invSmooth(0.0, 0.022, abs(uv.x - (waterEnd + 0.008))) * step(0.015, fill) * step(fill, 0.985);
  col *= 1.0 - meniscusDark * 0.42;
  col += vec3(1.8, 2.0, 2.1) * meniscusRim * 0.82;

  col = linearToSrgb(acesFilmic(col));

  float glassAlpha = clamp(mix(0.30, 0.74, inWater) + topGlassGlare * 0.18 + fresnel * 0.32 + meniscusRim * 0.20, 0.0, 0.92);
  fragColor = vec4(col * glassAlpha, glassAlpha);
}
`;

// Helpers mínimos da barra de energia: não carrega as rotinas ópticas da água/metal.
const ENERGY_NOISE_GLSL = `
float invSmooth(float lo, float hi, float x) {
  return 1.0 - smoothstep(lo, hi, x);
}
float hash21(vec2 p) {
  p = fract(p * vec2(123.34, 456.21));
  p += dot(p, p + 45.32);
  return fract(p.x * p.y);
}
float valueNoise(vec2 st) {
  vec2 i = floor(st);
  vec2 f = fract(st);
  float a = hash21(i);
  float b = hash21(i + vec2(1.0, 0.0));
  float c = hash21(i + vec2(0.0, 1.0));
  float d = hash21(i + vec2(1.0, 1.0));
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}
float fbm3(vec2 st) {
  float val = 0.0;
  float amp = 0.5;
  mat2 rot = mat2(0.8, 0.6, -0.6, 0.8);
  for (int i = 0; i < 3; i++) {
    val += amp * valueNoise(st);
    st = rot * st * 2.02 + vec2(1.7, 3.1);
    amp *= 0.5;
  }
  return val;
}
`;

// 3. Energia nutricional: fluido mineral luminoso, contido e alinhado à paleta Mineral Sage.
// Uma única amostra de ruído de baixa frequência substitui o domínio fractal em cascata;
// o brilho representa energia disponível, não plasma/fogo literal.
const ENERGY_FRAGMENT_300 = `#version 300 es
precision mediump float;

in vec2 v_uv;
out vec4 fragColor;

uniform vec2 u_resolution;
uniform float u_time;
uniform float u_fill;

${ENERGY_NOISE_GLSL}

void main() {
  vec2 uv = v_uv;
  float fill = clamp(u_fill, 0.0, 1.0);
  float t = u_time * 0.18;
  float meniscusX = fill + 0.006 * (1.0 - 4.0 * pow(uv.y - 0.5, 2.0)) * step(0.015, fill) * step(fill, 0.99);
  float inFluid = invSmooth(meniscusX - 0.006, meniscusX + 0.006, uv.x) * step(0.004, fill);

  vec3 cavity = mix(vec3(0.012, 0.022, 0.024), vec3(0.026, 0.043, 0.043), uv.y);
  vec3 color = cavity;

  if (inFluid > 0.01) {
    vec2 flowUv = vec2(uv.x * 2.2 - t * 0.16, uv.y * 1.7);
    float noise = fbm3(flowUv + vec2(0.0, sin(uv.x * 4.0 - t) * 0.035));
    float laminar = sin((uv.y * 1.15 + noise * 0.16 + uv.x * 0.035 - t * 0.11) * 6.28318);
    float body = smoothstep(0.12, 0.88, noise * 0.72 + 0.18);
    float core = exp(-pow((uv.y - (0.48 + laminar * 0.055)) * 3.0, 2.0));

    vec3 deepSage = vec3(0.035, 0.105, 0.080);
    vec3 mineralSage = vec3(0.13, 0.31, 0.235);
    vec3 lightSage = vec3(0.35, 0.58, 0.46);
    vec3 fluid = mix(deepSage, mineralSage, body);
    fluid = mix(fluid, lightSage, core * 0.42);

    // Reflexo largo e suave de softbox: volume acetinado, sem filamentos neon.
    float softbox = invSmooth(0.0, 0.18, abs(uv.y - 0.79)) * smoothstep(0.04, 0.20, uv.x) * invSmooth(0.82, 0.98, uv.x);
    float lowerBounce = invSmooth(0.0, 0.15, abs(uv.y - 0.16));
    fluid += vec3(0.30, 0.43, 0.35) * softbox * 0.20;
    fluid += vec3(0.08, 0.18, 0.14) * lowerBounce * 0.18;

    float meniscus = invSmooth(0.0, 0.010, abs(uv.x - meniscusX)) * step(0.015, fill) * step(fill, 0.99);
    fluid += vec3(0.58, 0.76, 0.65) * meniscus * 0.36;
    color = mix(cavity, fluid, inFluid);
  }

  // Vidro escuro com reflexo superior discreto, coerente com o painel grafite.
  float topReflection = invSmooth(0.0, 0.12, abs(uv.y - 0.86)) * smoothstep(0.03, 0.15, uv.x) * invSmooth(0.84, 0.98, uv.x);
  color += vec3(0.68, 0.78, 0.72) * topReflection * 0.12;
  fragColor = vec4(color, 1.0);
}
`;

// 4. Semicírculo metálico com ambiente procedural de estúdio e microfacet GGX
const METAL_FRAGMENT_300 = `#version 300 es
precision highp float;

in vec2 v_uv;
out vec4 fragColor;

uniform vec2 u_resolution;
uniform float u_time;
uniform float u_fill;
uniform vec3 u_metalColor;
uniform vec3 u_metalHighlight;

${SHARED_OPTICS_GLSL}

void main() {
  vec2 p = vec2(v_uv.x * 96.0, (1.0 - v_uv.y) * 56.0);
  vec2 center = vec2(48.0, 48.0);
  vec2 rel = p - center;
  float dist = length(rel);
  float radius = 38.0;
  float halfThick = 4.9;

  float theta = atan(-rel.y, -rel.x);
  float trackDist;
  if (rel.y <= 0.0) {
    trackDist = abs(dist - radius) - halfThick;
  } else {
    float dLeft = length(p - vec2(48.0 - radius, 48.0)) - halfThick;
    float dRight = length(p - vec2(48.0 + radius, 48.0)) - halfThick;
    trackDist = min(dLeft, dRight);
  }

  float aa = 0.75;
  if (trackDist > aa * 2.5) {
    fragColor = vec4(0.0);
    return;
  }

  float trackProfile = clamp((dist - (radius - halfThick)) / (2.0 * halfThick), 0.0, 1.0);
  vec3 grooveColor = mix(vec3(0.020, 0.032, 0.038), vec3(0.075, 0.105, 0.118), 0.5 + 0.5 * sin(trackProfile * 3.14159));

  float fill = clamp(u_fill, 0.0, 1.0);
  float maxAngle = fill * 3.14159265;
  float inCapStart = length(p - vec2(48.0 - radius, 48.0)) - halfThick;
  vec2 tipPos = vec2(48.0 - radius * cos(maxAngle), 48.0 - radius * sin(maxAngle));
  float inCapTip = length(p - tipPos) - halfThick;

  float bodyAngleOk = step(0.0, theta) * step(theta, maxAngle) * step(0.0, -rel.y + 0.2);
  float bodyDist = bodyAngleOk > 0.5 ? abs(dist - radius) - halfThick : 99.0;
  float liquidDist = fill > 0.002 ? min(inCapStart, min(inCapTip, bodyDist)) : 99.0;

  vec3 col = grooveColor;
  if (liquidDist < aa) {
    float t = u_time * 0.30;
    vec2 mUv = p * 0.095;

    // Uma FBM de três oitavas dá irregularidade microscópica sem o custo
    // do antigo domínio warp com três FBMs completos por fragmento.
    float satinNoise = fbm3(mUv * 0.82 + vec2(t * 0.055, -t * 0.035));

    // Ondulações direcionais analíticas: gradiente estável, sem derivadas GLSL
    // dentro da máscara variável do líquido (onde dFdx/dFdy seriam indefinidas).
    float phaseA = mUv.x * 3.3 + sin(mUv.y * 2.1 + t) * 0.55 + t * 0.42;
    float phaseB = mUv.y * 6.2 - mUv.x * 1.5 - t * 0.25;
    float waveA = sin(phaseA);
    float waveB = sin(phaseB);
    vec2 heightGradient = vec2(
      cos(phaseA) * 0.15 * 3.3 - cos(phaseB) * 0.05 * 1.5,
      cos(phaseA) * 0.15 * cos(mUv.y * 2.1 + t) * 0.55 * 2.1 +
        cos(phaseB) * 0.05 * 6.2
    );
    heightGradient += vec2(waveA, waveB) * (satinNoise - 0.5) * 0.035;

    vec2 radialDir = normalize(rel + vec2(0.0001));
    float crossU = clamp((dist - radius) / halfThick, -0.95, 0.95);
    vec3 tubeN = normalize(vec3(radialDir * crossU, sqrt(max(0.06, 1.0 - crossU * crossU))));
    vec3 rippleN = normalize(vec3(-heightGradient * 0.82, 1.0));
    vec3 normal = normalize(mix(tubeN, rippleN, 0.25));
    vec3 tangent = normalize(vec3(-radialDir.y, radialDir.x, 0.0));

    vec3 viewDir = vec3(0.0, 0.0, 1.0);
    vec3 refl = reflect(-viewDir, normal);
    vec3 esr = sampleStudioEnvironment(refl, u_metalColor) * 0.45;
    float horizonDip = invSmooth(0.0, 0.20, abs(refl.y - 0.02));
    vec3 chromeCol = mix(u_metalColor * 0.48, u_metalHighlight, 0.45) * 0.55 + esr;
    chromeCol = mix(chromeCol, u_metalColor * 0.22, horizonDip * 0.58);
    chromeCol *= mix(0.94, 1.035, satinNoise);

    float fresnel = pow(1.0 - max(dot(normal, viewDir), 0.0), 3.0);
    // Reflexo cromático contido: sem arco-íris decorativo que descaracterize o painel.
    chromeCol += u_metalHighlight * fresnel * 0.035;

    vec3 light1 = normalize(vec3(-0.55, 0.72, 0.72));
    vec3 light2 = normalize(vec3(0.65, 0.45, 0.60));
    float roughness = mix(0.24, 0.32, satinNoise);
    vec3 specular = evaluateGGXAnisotropicSpecular(
      normal, tangent, viewDir, light1, u_metalColor, roughness, 0.28
    ) * 3.2;
    specular += evaluateGGXAnisotropicSpecular(
      normal, tangent, viewDir, light2, u_metalColor, roughness + 0.045, 0.21
    ) * 1.15;
    chromeCol += specular;

    float tipSpot = invSmooth(0.4, 3.4, length(p - (tipPos + vec2(-0.7, -0.8))));
    chromeCol += vec3(1.0) * tipSpot * 0.42;

    float liqMask = invSmooth(-aa, aa, liquidDist);
    col = mix(grooveColor, chromeCol, liqMask);
  }

  float trackAlpha = invSmooth(-aa, aa, trackDist);
  fragColor = vec4(col * trackAlpha, trackAlpha);
}
`;

interface CachedProgram {
  program: WebGLProgram;
  uResolution: WebGLUniformLocation | null;
  uTime: WebGLUniformLocation | null;
  uFill: WebGLUniformLocation | null;
  uActive: WebGLUniformLocation | null;
  uIor: WebGLUniformLocation | null;
  uFresnelR0: WebGLUniformLocation | null;
  uAttenColor: WebGLUniformLocation | null;
  uAttenDist: WebGLUniformLocation | null;
  uEsrIntensity: WebGLUniformLocation | null;
  uCausticIntensity: WebGLUniformLocation | null;
  uFootprint: WebGLUniformLocation | null;
  uWave: WebGLUniformLocation | null;
  uMetalColor: WebGLUniformLocation | null;
  uMetalHighlight: WebGLUniformLocation | null;
}

type TargetBlitHandle = { ctx: CanvasRenderingContext2D };

class SharedFluidShaderEngine {
  private offscreenCanvas: OffscreenCanvas | null = null;
  private fallbackCanvas: HTMLCanvasElement | null = null;
  private gl: WebGL2RenderingContext | null = null;
  private programs = new Map<FluidProgramKind, CachedProgram>();
  private targetCtxCache = new WeakMap<HTMLCanvasElement, TargetBlitHandle>();
  private lastJobRenderAt = new WeakMap<HTMLCanvasElement, number>();
  private quadVao: WebGLVertexArrayObject | null = null;
  private quadBuffer: WebGLBuffer | null = null;
  private activeJobScratch: FluidDrawJob[] = [];
  private webglFailed = false;
  private subscribers = new Set<() => FluidDrawJob | null>();
  private rafId = 0;
  private lastTime = 0;
  private elapsed = 0;
  private springAccumulator = 0;
  private waveUploadBuf = new Float32Array(24);
  private maxDpr = 1.5;
  private visibilityListenerAttached = false;
  private readonly handleVisibilityChange = () => {
    if (typeof document === 'undefined') return;
    if (document.hidden) {
      if (this.rafId) cancelAnimationFrame(this.rafId);
      this.rafId = 0;
      return;
    }
    for (const provider of this.subscribers) {
      this.renderSinglePass(provider);
    }
    this.startLoopIfNeeded();
  };

  private ensureContext(): WebGL2RenderingContext | null {
    if (this.webglFailed || typeof document === 'undefined') return null;
    if (this.gl) return this.gl;

    if (typeof window !== 'undefined' && typeof window.matchMedia === 'function') {
      const isCoarse = window.matchMedia('(pointer: coarse)').matches;
      this.maxDpr = isCoarse ? 1.5 : 2;
    }

    const attrs: WebGLContextAttributes = {
      alpha: true,
      antialias: false,
      depth: false,
      stencil: false,
      premultipliedAlpha: true,
      powerPreference: 'high-performance',
    };

    let gl: WebGL2RenderingContext | null = null;
    if (typeof OffscreenCanvas !== 'undefined') {
      const oc = new OffscreenCanvas(64, 64);
      gl = oc.getContext('webgl2', attrs);
      if (gl) {
        this.offscreenCanvas = oc;
        oc.addEventListener('webglcontextlost', (e) => {
          e.preventDefault();
          if (this.rafId) cancelAnimationFrame(this.rafId);
          this.rafId = 0;
          this.teardownContext();
          this.webglFailed = true;
          if (typeof window !== 'undefined') window.dispatchEvent(new Event('fluid-engine-fallback'));
        });
        oc.addEventListener('webglcontextrestored', () => {
          this.teardownContext();
          this.webglFailed = false;
          if (typeof window !== 'undefined') window.dispatchEvent(new Event('fluid-engine-restored'));
          this.wake();
        });
      }
    }

    if (!gl) {
      const hc = document.createElement('canvas');
      gl = hc.getContext('webgl2', attrs);
      if (gl) {
        this.fallbackCanvas = hc;
        hc.addEventListener('webglcontextlost', (e) => {
          e.preventDefault();
          if (this.rafId) cancelAnimationFrame(this.rafId);
          this.rafId = 0;
          this.teardownContext();
          this.webglFailed = true;
          if (typeof window !== 'undefined') window.dispatchEvent(new Event('fluid-engine-fallback'));
        });
        hc.addEventListener('webglcontextrestored', () => {
          this.teardownContext();
          this.webglFailed = false;
          if (typeof window !== 'undefined') window.dispatchEvent(new Event('fluid-engine-restored'));
          this.wake();
        });
      }
    }

    if (!gl) {
      this.webglFailed = true;
      return null;
    }

    const vao = gl.createVertexArray();
    const buf = gl.createBuffer();
    if (!vao || !buf) {
      if (vao) gl.deleteVertexArray(vao);
      if (buf) gl.deleteBuffer(buf);
      this.webglFailed = true;
      return null;
    }

    gl.bindVertexArray(vao);
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(
      gl.ARRAY_BUFFER,
      new Float32Array([-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1]),
      gl.STATIC_DRAW,
    );
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    gl.bindVertexArray(null);

    this.gl = gl;
    this.quadVao = vao;
    this.quadBuffer = buf;
    return gl;
  }

  private getProgram(gl: WebGL2RenderingContext, kind: FluidProgramKind): CachedProgram | null {
    const existing = this.programs.get(kind);
    if (existing) return existing;

    const fsSource =
      kind === 'droplet'
        ? DROPLET_FRAGMENT_300
        : kind === 'tank'
        ? TANK_FRAGMENT_300
        : kind === 'energy'
        ? ENERGY_FRAGMENT_300
        : METAL_FRAGMENT_300;

    const vs = this.compileShader(gl, gl.VERTEX_SHADER, VERTEX_SHADER_300, `${kind}:vertex`);
    const fs = this.compileShader(gl, gl.FRAGMENT_SHADER, fsSource, `${kind}:fragment`);
    if (!vs || !fs) {
      if (vs) gl.deleteShader(vs);
      if (fs) gl.deleteShader(fs);
      return null;
    }

    const prog = gl.createProgram();
    if (!prog) {
      gl.deleteShader(vs);
      gl.deleteShader(fs);
      return null;
    }
    gl.attachShader(prog, vs);
    gl.attachShader(prog, fs);
    gl.bindAttribLocation(prog, 0, 'a_position');
    gl.linkProgram(prog);

    gl.deleteShader(vs);
    gl.deleteShader(fs);

    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
      const info = gl.getProgramInfoLog(prog);
      console.error(`[FluidEngine] ${kind} program link failed`, info);
      gl.deleteProgram(prog);
      return null;
    }

    const cached: CachedProgram = {
      program: prog,
      uResolution: gl.getUniformLocation(prog, 'u_resolution'),
      uTime: gl.getUniformLocation(prog, 'u_time'),
      uFill: gl.getUniformLocation(prog, 'u_fill'),
      uActive: gl.getUniformLocation(prog, 'u_active'),
      uIor: gl.getUniformLocation(prog, 'u_ior'),
      uFresnelR0: gl.getUniformLocation(prog, 'u_fresnelR0'),
      uAttenColor: gl.getUniformLocation(prog, 'u_attenColor'),
      uAttenDist: gl.getUniformLocation(prog, 'u_attenDist'),
      uEsrIntensity: gl.getUniformLocation(prog, 'u_esrIntensity'),
      uCausticIntensity: gl.getUniformLocation(prog, 'u_causticIntensity'),
      uFootprint: gl.getUniformLocation(prog, 'u_footprint'),
      uWave: gl.getUniformLocation(prog, 'u_wave[0]'),
      uMetalColor: gl.getUniformLocation(prog, 'u_metalColor'),
      uMetalHighlight: gl.getUniformLocation(prog, 'u_metalHighlight'),
    };
    this.programs.set(kind, cached);
    return cached;
  }

  private compileShader(
    gl: WebGL2RenderingContext,
    type: number,
    src: string,
    label: string,
  ): WebGLShader | null {
    const shader = gl.createShader(type);
    if (!shader) return null;
    gl.shaderSource(shader, src);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
      const info = gl.getShaderInfoLog(shader);
      console.error(`[FluidEngine] ${label} shader compilation failed`, info);
      gl.deleteShader(shader);
      return null;
    }
    return shader;
  }

  private getTargetBlitHandle(canvas: HTMLCanvasElement): TargetBlitHandle | null {
    const existing = this.targetCtxCache.get(canvas);
    if (existing) return existing;

    const ctx2d = canvas.getContext('2d');
    if (!ctx2d) return null;
    const handle: TargetBlitHandle = { ctx: ctx2d };
    this.targetCtxCache.set(canvas, handle);
    return handle;
  }

  private renderJobToTarget(job: FluidDrawJob, timeSec: number): boolean {
    const gl = this.ensureContext();
    const offscreen = this.offscreenCanvas;
    const fallback = this.fallbackCanvas;
    if (!gl || !this.quadVao || (!offscreen && !fallback)) return false;

    const dpr = Math.min(window.devicePixelRatio || 1, this.maxDpr);
    const pxW = Math.max(2, Math.round(job.width * dpr));
    const pxH = Math.max(2, Math.round(job.height * dpr));

    if (job.targetCanvas.width !== pxW || job.targetCanvas.height !== pxH) {
      job.targetCanvas.width = pxW;
      job.targetCanvas.height = pxH;
    }

    const cached = this.getProgram(gl, job.kind);
    if (!cached) return false;

    const blit = this.getTargetBlitHandle(job.targetCanvas);
    if (!blit) return false;

    if (fallback) {
      if (fallback.width < pxW || fallback.height < pxH) {
        fallback.width = Math.max(fallback.width, pxW);
        fallback.height = Math.max(fallback.height, pxH);
      }
    } else if (offscreen) {
      if (offscreen.width < pxW || offscreen.height < pxH) {
        offscreen.width = Math.max(offscreen.width, pxW);
        offscreen.height = Math.max(offscreen.height, pxH);
      }
    }

    gl.enable(gl.SCISSOR_TEST);
    gl.scissor(0, 0, pxW, pxH);
    gl.viewport(0, 0, pxW, pxH);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.useProgram(cached.program);
    gl.bindVertexArray(this.quadVao);

    if (cached.uResolution) gl.uniform2f(cached.uResolution, pxW, pxH);
    if (cached.uTime) gl.uniform1f(cached.uTime, timeSec);
    if (cached.uFill) gl.uniform1f(cached.uFill, job.fill);

    if (job.kind === 'droplet' && cached.uActive) {
      gl.uniform1f(cached.uActive, job.active ? 1 : 0);
    }

    if (job.kind === 'droplet' || job.kind === 'tank') {
      const cfg = job.opticalConfig;
      const ior = cfg?.ior ?? DEFAULT_WATER_OPTICAL_CONFIG.ior;
      const r0 = cfg?.fresnelR0 ?? DEFAULT_WATER_OPTICAL_CONFIG.fresnelR0;
      const ac = cfg?.attenuationColor ?? DEFAULT_WATER_OPTICAL_CONFIG.attenuationColor;
      const ad = cfg?.attenuationDistance ?? DEFAULT_WATER_OPTICAL_CONFIG.attenuationDistance;
      const esr = cfg?.esrIntensity ?? DEFAULT_WATER_OPTICAL_CONFIG.esrIntensity;
      const caust = cfg?.causticIntensity ?? DEFAULT_WATER_OPTICAL_CONFIG.causticIntensity;
      const fp = cfg?.footprintFilter ?? DEFAULT_WATER_OPTICAL_CONFIG.footprintFilter;

      if (cached.uIor) gl.uniform1f(cached.uIor, ior);
      if (cached.uFresnelR0) gl.uniform1f(cached.uFresnelR0, r0);
      if (cached.uAttenColor) gl.uniform3f(cached.uAttenColor, ac[0], ac[1], ac[2]);
      if (cached.uAttenDist) gl.uniform1f(cached.uAttenDist, ad);
      if (cached.uEsrIntensity) gl.uniform1f(cached.uEsrIntensity, esr);
      if (cached.uCausticIntensity) gl.uniform1f(cached.uCausticIntensity, caust);
      if (cached.uFootprint) gl.uniform1f(cached.uFootprint, fp ? 1 : 0);

      if (job.wave && cached.uWave) {
        const srcLen = job.wave.length;
        for (let i = 0; i < 24; i++) {
          const mapped = Math.min(srcLen - 1, Math.round((i / 23) * (srcLen - 1)));
          this.waveUploadBuf[i] = job.wave[mapped]?.height ?? 0;
        }
        gl.uniform1fv(cached.uWave, this.waveUploadBuf);
      }
    }

    if (job.kind === 'metal') {
      const mc = job.metalColor ?? [0.56, 0.69, 0.75];
      const mh = job.metalHighlight ?? [0.92, 0.98, 1.0];
      if (cached.uMetalColor) gl.uniform3f(cached.uMetalColor, mc[0], mc[1], mc[2]);
      if (cached.uMetalHighlight) gl.uniform3f(cached.uMetalHighlight, mh[0], mh[1], mh[2]);
    }

    gl.drawArrays(gl.TRIANGLES, 0, 6);
    gl.disable(gl.SCISSOR_TEST);

    const src = fallback ?? offscreen;
    if (!src) return false;
    blit.ctx.clearRect(0, 0, pxW, pxH);
    // OffscreenCanvas is itself a CanvasImageSource. Drawing it directly avoids
    // allocating/transferring/closing a new ImageBitmap for every gauge frame.
    blit.ctx.drawImage(src, 0, src.height - pxH, pxW, pxH, 0, 0, pxW, pxH);
    return true;
  }

  subscribe(
    provider: () => FluidDrawJob | null,
    initialRenderAlreadyDone = false,
  ): () => void {
    this.subscribers.add(provider);
    if (!this.visibilityListenerAttached && typeof document !== 'undefined') {
      document.addEventListener('visibilitychange', this.handleVisibilityChange);
      this.visibilityListenerAttached = true;
    }

    if (!initialRenderAlreadyDone) this.renderSinglePass(provider);
    const initialJob = provider();
    if (
      !this.webglFailed &&
      initialJob &&
      (initialJob.isAnimating || (initialJob.wave && this.hasActiveWave(initialJob.wave)))
    ) {
      this.startLoopIfNeeded();
    }

    return () => {
      this.subscribers.delete(provider);
      if (this.subscribers.size === 0) {
        if (this.rafId) cancelAnimationFrame(this.rafId);
        this.rafId = 0;
        if (this.visibilityListenerAttached && typeof document !== 'undefined') {
          document.removeEventListener('visibilitychange', this.handleVisibilityChange);
          this.visibilityListenerAttached = false;
        }
      }
    };
  }

  /**
   * Starts the shared renderer only after a value transition or a user impulse.
   * Static liquid is rendered once and then remains completely still.
   */
  wake(): void {
    if (this.webglFailed) return;
    if (
      typeof window === 'undefined' ||
      prefersReducedMotion() ||
      (typeof document !== 'undefined' && document.hidden)
    ) {
      return;
    }
    this.startLoopIfNeeded();
  }

  renderSinglePass(provider: () => FluidDrawJob | null): boolean {
    const job = provider();
    if (!job || !job.isVisible) return false;
    const ok = this.renderJobToTarget(job, this.elapsed);
    if (ok) {
      this.lastJobRenderAt.set(job.targetCanvas, performance.now());
    }
    return ok;
  }

  private hasActiveWave(nodes: SpringNode[]): boolean {
    for (let i = 0; i < nodes.length; i++) {
      const node = nodes[i];
      if (node && (Math.abs(node.height) > 0.012 || Math.abs(node.velocity) > 0.012)) {
        return true;
      }
    }
    return false;
  }

  private startLoopIfNeeded(): void {
    if (this.rafId || this.subscribers.size === 0) return;
    if (
      typeof window === 'undefined' ||
      prefersReducedMotion() ||
      (typeof document !== 'undefined' && document.hidden)
    ) {
      return;
    }

    this.lastTime = performance.now();

    const tick = (now: number) => {
      if (typeof document !== 'undefined' && document.hidden) {
        this.rafId = 0;
        return;
      }
      if (typeof window !== 'undefined' && prefersReducedMotion()) {
        for (const provider of this.subscribers) {
          const job = provider();
          if (job?.isVisible) this.renderJobToTarget(job, this.elapsed);
        }
        this.rafId = 0;
        return;
      }

      const dt = Math.min(0.05, Math.max(0, (now - this.lastTime) / 1000));
      this.lastTime = now;
      this.elapsed += dt;

      this.springAccumulator += dt;
      const springSubsteps = Math.min(3, Math.floor(this.springAccumulator * 60));
      if (springSubsteps > 0) this.springAccumulator -= springSubsteps / 60;
      this.activeJobScratch.length = 0;
      for (const provider of this.subscribers) {
        const job = provider();
        if (!job || !job.isVisible) continue;

        const waveActive = job.wave ? this.hasActiveWave(job.wave) : false;
        // Do not redraw static water at 30 fps. Only a fill transition or a
        // physical spring impulse is allowed to keep the GPU loop alive.
        if (!job.isAnimating && !waveActive) continue;

        if (waveActive && job.wave && springSubsteps > 0) {
          for (let step = 0; step < springSubsteps; step++) {
            stepSpringNodes(job.wave, 0.12, 0.20, 0.14);
          }
        }
        this.activeJobScratch.push(job);
      }

      if (this.activeJobScratch.length === 0) {
        this.rafId = 0;
        return;
      }

      for (let i = 0; i < this.activeJobScratch.length; i++) {
        const job = this.activeJobScratch[i];
        if (!job) continue;

        const prevAt = this.lastJobRenderAt.get(job.targetCanvas) ?? 0;
        if (now - prevAt >= MIN_FLUID_FRAME_INTERVAL_MS) {
          this.lastJobRenderAt.set(job.targetCanvas, now);
          this.renderJobToTarget(job, this.elapsed);
        }
      }

      this.rafId = requestAnimationFrame(tick);
    };

    this.rafId = requestAnimationFrame(tick);
  }

  private teardownContext(): void {
    const gl = this.gl;
    if (gl) {
      for (const cached of this.programs.values()) {
        gl.deleteProgram(cached.program);
      }
      this.programs.clear();
      if (this.quadBuffer) gl.deleteBuffer(this.quadBuffer);
      if (this.quadVao) gl.deleteVertexArray(this.quadVao);
    }
    this.quadBuffer = null;
    this.quadVao = null;
    this.gl = null;
    this.offscreenCanvas = null;
    this.fallbackCanvas = null;
  }
}

let sharedEngineSingleton: SharedFluidShaderEngine | null = null;

export function getSharedFluidEngine(): SharedFluidShaderEngine {
  if (!sharedEngineSingleton) {
    sharedEngineSingleton = new SharedFluidShaderEngine();
  }
  return sharedEngineSingleton;
}
