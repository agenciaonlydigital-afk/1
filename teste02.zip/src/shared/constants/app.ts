import { buildRecentLocalDayDescriptors, formatLocalDateLabel, getLocalDateKey } from '../utils/local-date';

export const APP_DAY_KEY = getLocalDateKey();
export const APP_DATE_LABEL = formatLocalDateLabel(APP_DAY_KEY).fullLabel;
export const APP_BRAND_NAME = 'TITAN';

/** Recent date choices are derived from the device's local date, never a release-time literal. */
export const AVAILABLE_DAYS = buildRecentLocalDayDescriptors();
