import type { ReactNode } from 'react';

interface SurfaceProps {
  children: ReactNode;
  className?: string;
  elevation?: 0 | 1 | 2;
}

export function Surface({ children, className = '', elevation = 1 }: SurfaceProps) {
  return (
    <div className={`titan-surface ${className}`} data-elevation={elevation}>
      {children}
    </div>
  );
}
