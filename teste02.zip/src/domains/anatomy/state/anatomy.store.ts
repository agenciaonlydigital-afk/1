import { create } from 'zustand';
import type {
  MuscleGroupId,
  MuscleHighlightPayload,
  MuscleSide,
} from '@/src/shared/types/common';
import type { AnatomicalView } from '../mapping/muscle-registry';

export type FocusRegion = 'full' | 'upper' | 'core' | 'lower';
export type AnatomyLayerMode = 'complete' | 'deep' | 'skeleton';
export type WebglStatus = 'initializing' | 'ready' | 'fallback';

interface AnatomyState {
  selectedMuscleId: MuscleGroupId | null;
  selectedMuscleSide: MuscleSide | null;
  hoveredMuscleId: MuscleGroupId | null;
  hoveredMuscleSide: MuscleSide | null;
  cameraView: AnatomicalView;
  focusRegion: FocusRegion;
  layerMode: AnatomyLayerMode;
  zoomScale: number;
  workoutHighlights: MuscleHighlightPayload;
  hologramMode: boolean;
  webglStatus: WebglStatus;
  showAccessibleList: boolean;
  setSelectedMuscle: (id: MuscleGroupId | null, side?: MuscleSide | null) => void;
  setHoveredMuscle: (id: MuscleGroupId | null, side?: MuscleSide | null) => void;
  setCameraView: (view: AnatomicalView) => void;
  setFocusRegion: (region: FocusRegion) => void;
  setLayerMode: (mode: AnatomyLayerMode) => void;
  setHologramMode: (enabled: boolean) => void;
  adjustZoom: (delta: number) => void;
  setZoomScale: (scale: number) => void;
  setWorkoutHighlights: (payload: MuscleHighlightPayload) => void;
  setWebglStatus: (status: WebglStatus) => void;
  toggleAccessibleList: () => void;
  resetExploration: () => void;
}

export const useAnatomyStore = create<AnatomyState>((set) => ({
  selectedMuscleId: null,
  selectedMuscleSide: null,
  hoveredMuscleId: null,
  hoveredMuscleSide: null,
  cameraView: 'frontal',
  focusRegion: 'full',
  layerMode: 'complete',
  zoomScale: 1,
  workoutHighlights: {
    primary: ['pectoralis', 'anterior_deltoid', 'lateral_deltoid', 'triceps'],
    secondary: [],
  },
  hologramMode: true,
  webglStatus: 'initializing',
  showAccessibleList: false,
  setSelectedMuscle: (id, side = null) =>
    set({
      selectedMuscleId: id,
      selectedMuscleSide: id ? side ?? 'center' : null,
    }),
  setHoveredMuscle: (id, side = null) =>
    set({
      hoveredMuscleId: id,
      hoveredMuscleSide: id ? side ?? 'center' : null,
    }),
  setCameraView: (view) => set({ cameraView: view }),
  setFocusRegion: (region) => set({ focusRegion: region }),
  setLayerMode: (mode) => set({ layerMode: mode }),
  setHologramMode: (enabled) => set({ hologramMode: enabled }),
  adjustZoom: (delta) =>
    set((state) => ({
      zoomScale: Number(
        Math.min(1.65, Math.max(0.75, state.zoomScale + delta)).toFixed(2),
      ),
    })),
  setZoomScale: (scale) =>
    set({
      zoomScale: Number(Math.min(1.65, Math.max(0.75, scale)).toFixed(2)),
    }),
  setWorkoutHighlights: (payload) => set({ workoutHighlights: payload }),
  setWebglStatus: (status) => set({ webglStatus: status }),
  toggleAccessibleList: () =>
    set((state) => ({ showAccessibleList: !state.showAccessibleList })),
  resetExploration: () =>
    set({
      selectedMuscleId: null,
      selectedMuscleSide: null,
      hoveredMuscleId: null,
      hoveredMuscleSide: null,
      cameraView: 'frontal',
      focusRegion: 'full',
      layerMode: 'complete',
      zoomScale: 1,
    }),
}));
