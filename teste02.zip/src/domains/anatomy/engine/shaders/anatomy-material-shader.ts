import type * as THREE from 'three';

export interface AnatomyShaderUniforms {
  uActiveMusclesMask: { value: number };
  uPrimaryMusclesMask: { value: number };
  uSecondaryMusclesMask: { value: number };
  uSelectedMuscleIndex: { value: number };
  uSelectedMuscleSide: { value: number };
  uSelectedSideAny: { value: number };
  uHasSelection: { value: number };
  uMuscleRestingColor: { value: THREE.Color };
  uMuscleDimmedColor: { value: THREE.Color };
  uMusclePrimaryColor: { value: THREE.Color };
  uMuscleSecondaryColor: { value: THREE.Color };
  uMuscleSelectedColor: { value: THREE.Color };
  uSweepY: { value: number };
  uHologramMode: { value: number };
  uHologramTint: { value: THREE.Color };
  uHologramAccent: { value: THREE.Color };
}

type AnatomyMaterialRole = 'body' | 'muscle';

function replaceShaderChunk(source: string, chunkName: string, replacement: string, stage: 'vertex' | 'fragment'): string {
  const token = `#include <${chunkName}>`;
  const occurrences = source.split(token).length - 1;
  if (occurrences !== 1) {
    throw new Error(`TITAN anatomy shader patch expected exactly one ${stage} <${chunkName}> chunk; found ${occurrences}`);
  }
  return source.replace(token, replacement);
}

/**
 * Adds small anatomy-specific behaviours to Three.js' standard PBR shaders.
 * Muscle classification runs in the vertex stage: each patch carries constant
 * ID/side attributes, so state changes never rewrite geometry buffers and the
 * fragment stage receives only its final colour + two tiny effects.
 */
export function applyAnatomyMaterialEnhancements(
  material: THREE.MeshStandardMaterial,
  uniforms: AnatomyShaderUniforms,
  role: AnatomyMaterialRole,
): void {
  material.onBeforeCompile = (shader) => {
    shader.uniforms.uSweepY = uniforms.uSweepY;
    shader.uniforms.uHologramMode = uniforms.uHologramMode;
    shader.uniforms.uHologramTint = uniforms.uHologramTint;
    shader.uniforms.uHologramAccent = uniforms.uHologramAccent;

    shader.vertexShader = replaceShaderChunk(
      shader.vertexShader,
      'common',
      `#include <common>
varying float vAnatomyWorldY;
${role === 'muscle' ? `
attribute float aMuscleId;
attribute float aMuscleSide;
uniform int uActiveMusclesMask;
uniform int uPrimaryMusclesMask;
uniform int uSecondaryMusclesMask;
uniform int uSelectedMuscleIndex;
uniform float uSelectedMuscleSide;
uniform float uSelectedSideAny;
uniform float uHasSelection;
uniform vec3 uMuscleRestingColor;
uniform vec3 uMuscleDimmedColor;
uniform vec3 uMusclePrimaryColor;
uniform vec3 uMuscleSecondaryColor;
uniform vec3 uMuscleSelectedColor;
varying vec3 vMuscleColor;
varying float vMuscleActive;` : ''}`,
      'vertex',
    );

    shader.vertexShader = replaceShaderChunk(
      shader.vertexShader,
      'begin_vertex',
      `#include <begin_vertex>
${role === 'muscle' ? `
int titanMuscleId = int(aMuscleId + 0.5);
float titanIsActive = float((uActiveMusclesMask >> titanMuscleId) & 1);
float titanIsPrimary = float((uPrimaryMusclesMask >> titanMuscleId) & 1);
float titanIsSecondary = float((uSecondaryMusclesMask >> titanMuscleId) & 1);
float titanIsSelected = titanMuscleId == uSelectedMuscleIndex ? 1.0 : 0.0;
float titanSideMatch = 1.0 - step(0.5, abs(aMuscleSide - uSelectedMuscleSide));
titanSideMatch = mix(titanSideMatch, 1.0, uSelectedSideAny);
titanIsSelected *= titanSideMatch * uHasSelection;
vec3 titanWorkoutColor = mix(uMuscleRestingColor, uMuscleSecondaryColor, titanIsSecondary);
titanWorkoutColor = mix(titanWorkoutColor, uMusclePrimaryColor, titanIsPrimary);
vec3 titanSelectionColor = mix(uMuscleDimmedColor, uMuscleSelectedColor, titanIsSelected);
vMuscleColor = mix(titanWorkoutColor, titanSelectionColor, uHasSelection);
vMuscleActive = titanIsActive;` : ''}`,
      'vertex',
    );

    shader.vertexShader = replaceShaderChunk(
      shader.vertexShader,
      'project_vertex',
      `vAnatomyWorldY = (modelMatrix * vec4(transformed, 1.0)).y;
#include <project_vertex>`,
      'vertex',
    );

    if (role === 'muscle') {
      shader.uniforms.uActiveMusclesMask = uniforms.uActiveMusclesMask;
      shader.uniforms.uPrimaryMusclesMask = uniforms.uPrimaryMusclesMask;
      shader.uniforms.uSecondaryMusclesMask = uniforms.uSecondaryMusclesMask;
      shader.uniforms.uSelectedMuscleIndex = uniforms.uSelectedMuscleIndex;
      shader.uniforms.uSelectedMuscleSide = uniforms.uSelectedMuscleSide;
      shader.uniforms.uSelectedSideAny = uniforms.uSelectedSideAny;
      shader.uniforms.uHasSelection = uniforms.uHasSelection;
      shader.uniforms.uMuscleRestingColor = uniforms.uMuscleRestingColor;
      shader.uniforms.uMuscleDimmedColor = uniforms.uMuscleDimmedColor;
      shader.uniforms.uMusclePrimaryColor = uniforms.uMusclePrimaryColor;
      shader.uniforms.uMuscleSecondaryColor = uniforms.uMuscleSecondaryColor;
      shader.uniforms.uMuscleSelectedColor = uniforms.uMuscleSelectedColor;

      shader.fragmentShader = replaceShaderChunk(
        shader.fragmentShader,
        'common',
        `#include <common>
uniform float uSweepY;
uniform float uHologramMode;
uniform vec3 uHologramTint;
uniform vec3 uHologramAccent;
varying vec3 vMuscleColor;
varying float vMuscleActive;
varying float vAnatomyWorldY;`,
        'fragment',
      );
      shader.fragmentShader = replaceShaderChunk(
        shader.fragmentShader,
        'color_fragment',
        `#include <color_fragment>
float titanSweepGate = smoothstep(-0.08, 0.02, uSweepY) * (1.0 - smoothstep(1.82, 1.92, uSweepY));
float titanSweep = exp(-pow((vAnatomyWorldY - uSweepY) * 10.0, 2.0)) * titanSweepGate;
diffuseColor.rgb = vMuscleColor * (1.0 + vMuscleActive * 0.004);
diffuseColor.rgb += vec3(0.008, 0.006, 0.004) * titanSweep;
if (uHologramMode > 0.5) {
  float titanMuscleLift = mix(0.14, 0.44, vMuscleActive);
  vec3 titanHoloSurface = diffuseColor.rgb * titanMuscleLift + uHologramTint * 0.055;
  diffuseColor.rgb = titanHoloSurface;
}
`,
        'fragment',
      );

      shader.fragmentShader = replaceShaderChunk(
        shader.fragmentShader,
        'emissivemap_fragment',
        `#include <emissivemap_fragment>
if (uHologramMode > 0.5) {
  float titanHoloFresnel = pow(1.0 - max(dot(normalize(normal), normalize(vViewPosition)), 0.0), 1.85);
  float titanHoloScanSignal = 0.5 + 0.5 * cos(vAnatomyWorldY * 240.0);
  float titanHoloBand = smoothstep(0.56, 0.92, titanHoloScanSignal);
  float titanHoloHarmonic = smoothstep(0.72, 0.98, 0.5 + 0.5 * cos(vAnatomyWorldY * 52.0));
  float titanHoloScan = titanHoloBand * 0.68 + titanHoloHarmonic * 0.32;
  float titanHoloSweep = exp(-pow((vAnatomyWorldY - uSweepY) * 23.0, 2.0));
  vec3 titanHoloBaseEdge = mix(uHologramTint, uHologramAccent, smoothstep(0.58, 0.96, titanHoloFresnel));
  vec3 titanHoloEdge = mix(titanHoloBaseEdge, vMuscleColor, vMuscleActive * 0.78);
  totalEmissiveRadiance += titanHoloEdge * (titanHoloFresnel * (0.94 + vMuscleActive * 0.44) + titanHoloScan * (0.28 + vMuscleActive * 0.16) + titanHoloSweep * 0.46) + vMuscleColor * (vMuscleActive * 0.38);
}`,
        'fragment',
      );
    } else {
      shader.fragmentShader = replaceShaderChunk(
        shader.fragmentShader,
        'common',
        `#include <common>\nuniform float uHologramMode;\nuniform float uSweepY;\nuniform vec3 uHologramTint;\nuniform vec3 uHologramAccent;\nvarying float vAnatomyWorldY;`,
        'fragment',
      );
      shader.fragmentShader = replaceShaderChunk(
        shader.fragmentShader,
        'color_fragment',
        `#include <color_fragment>\nif (uHologramMode > 0.5) {\n  vec3 titanHoloSurface = diffuseColor.rgb * 0.14 + uHologramTint * 0.075;\n  diffuseColor.rgb = titanHoloSurface;\n}`,
        'fragment',
      );
      shader.fragmentShader = replaceShaderChunk(
        shader.fragmentShader,
        'emissivemap_fragment',
        `#include <emissivemap_fragment>\nif (uHologramMode > 0.5) {\n  float titanHoloFresnel = pow(1.0 - max(dot(normalize(normal), normalize(vViewPosition)), 0.0), 1.85);\n  float titanHoloScanSignal = 0.5 + 0.5 * cos(vAnatomyWorldY * 240.0);\n  float titanHoloBand = smoothstep(0.56, 0.92, titanHoloScanSignal);\n  float titanHoloHarmonic = smoothstep(0.72, 0.98, 0.5 + 0.5 * cos(vAnatomyWorldY * 52.0));\n  float titanHoloScan = titanHoloBand * 0.68 + titanHoloHarmonic * 0.32;\n  float titanHoloSweep = exp(-pow((vAnatomyWorldY - uSweepY) * 23.0, 2.0));\n  vec3 titanHoloEdge = mix(uHologramTint, uHologramAccent, smoothstep(0.58, 0.96, titanHoloFresnel));\n  totalEmissiveRadiance += titanHoloEdge * (titanHoloFresnel * 0.94 + titanHoloScan * 0.28 + titanHoloSweep * 0.46) + uHologramTint * 0.05;\n}`,
        'fragment',
      );
    }
  };

  material.customProgramCacheKey = () => `titan-anatomy-${role}-pbr-v11.3-single-pass-worldy`;
}
