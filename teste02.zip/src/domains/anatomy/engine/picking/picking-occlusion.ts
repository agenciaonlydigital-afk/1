/** True when a visible body surface is meaningfully closer than a muscle patch. */
export function isOccludedByBodySurface(
  bodySurfaceDistance: number,
  muscleSurfaceDistance: number,
  tolerance = 0.002,
): boolean {
  if (!Number.isFinite(muscleSurfaceDistance)) return false;
  if (!Number.isFinite(bodySurfaceDistance)) return false;
  if (!Number.isFinite(tolerance) || tolerance < 0) return false;
  return bodySurfaceDistance + tolerance < muscleSurfaceDistance;
}
