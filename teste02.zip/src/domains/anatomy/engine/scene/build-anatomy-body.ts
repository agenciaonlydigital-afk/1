import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import type { MuscleGroupId, MuscleSide } from '@/src/shared/types/common';
import { MUSCLE_ID_TO_SHADER_INDEX } from '../../mapping/anatomy-identifiers';
import { averageClosedLoftSeamNormals, createLoftTopology, writeLoftCapPositions } from './loft-topology';
import {
  attachMuscleIdAttribute,
  type AnatomyMaterialSet,
} from '../materials/anatomy-materials';

export interface MuscleMeshEntry {
  muscleId: MuscleGroupId;
  side: MuscleSide;
}

export interface AnatomyBodyRig {
  root: THREE.Group;
  shellGroup: THREE.Group;
  superficialGroup: THREE.Group;
  deepGroup: THREE.Group;
  skeletonGroup: THREE.Group;
  muscleEntries: MuscleMeshEntry[];
  muscleSurface: THREE.Mesh | null;
  pickableMeshes: THREE.Mesh[];
  occlusionMeshes: THREE.Mesh[];
  dispose: () => void;
}

interface CrossSectionSlice {
  y: number;
  rx: number;
  rz: number;
  cx?: number;
  cz?: number;
  chestCleft?: number;
  spineIndent?: number;
}

function catmullRom(a: number, b: number, c: number, d: number, t: number): number {
  const t2 = t * t;
  const t3 = t2 * t;
  return 0.5 * (
    2 * b +
    (-a + c) * t +
    (2 * a - 5 * b + 4 * c - d) * t2 +
    (-a + 3 * b - 3 * c + d) * t3
  );
}

function smoothCrossSections(
  slices: CrossSectionSlice[],
  subdivisions: number,
): CrossSectionSlice[] {
  if (slices.length < 3 || subdivisions <= 1) return slices;
  const result: CrossSectionSlice[] = [];
  const keys: Array<keyof CrossSectionSlice> = [
    'y', 'rx', 'rz', 'cx', 'cz', 'chestCleft', 'spineIndent',
  ];

  for (let index = 0; index < slices.length - 1; index += 1) {
    const p0 = slices[Math.max(0, index - 1)]!;
    const p1 = slices[index]!;
    const p2 = slices[index + 1]!;
    const p3 = slices[Math.min(slices.length - 1, index + 2)]!;

    for (let step = 0; step < subdivisions; step += 1) {
      const t = step / subdivisions;
      const sample: CrossSectionSlice = {
        y: 0, rx: 0.005, rz: 0.005,
      };
      for (const key of keys) {
        const a = Number(p0[key] ?? 0);
        const b = Number(p1[key] ?? 0);
        const c = Number(p2[key] ?? 0);
        const d = Number(p3[key] ?? 0);
        const value = catmullRom(a, b, c, d, t);
        if (key === 'y' || key === 'rx' || key === 'rz') {
          sample[key] = value;
        } else if (Math.abs(value) > 0.000001) {
          sample[key] = value;
        }
      }
      // Keep interpolation monotonic in height and prevent negative radii from spline overshoot.
      sample.y = Math.max(p1.y, Math.min(p2.y, sample.y));
      sample.rx = Math.max(0.005, sample.rx);
      sample.rz = Math.max(0.005, sample.rz);
      result.push(sample);
    }
  }
  result.push(slices[slices.length - 1]!);
  return result;
}

function buildLoftedGeometry(
  slices: CrossSectionSlice[],
  radialSegments = 36,
  angleStart = 0,
  angleEnd = Math.PI * 2,
  capEnds = true,
  radialOffset = 0,
  smoothSubdivisions = 1,
  bulge = 0,
): THREE.BufferGeometry {
  const geometrySlices = smoothCrossSections(slices, smoothSubdivisions);
  const closed = Math.abs(angleEnd - angleStart - Math.PI * 2) < 0.001;
  // Keep a duplicated seam vertex for closed surfaces so U=0 and U=1 remain
  // distinct in UV space. This is required for stable normal-map sampling.
  const rows = geometrySlices.length;
  const topology = createLoftTopology(rows, radialSegments, closed, capEnds);
  const { columns: cols, vertexCount, uvs, indices } = topology;
  const positions = new Float32Array(vertexCount * 3);
  let positionOffset = 0;

  for (let r = 0; r < rows; r++) {
    const slice = geometrySlices[r];
    if (!slice) continue;
    const v = r / Math.max(1, rows - 1);
    const cx = slice.cx ?? 0;
    const cz = slice.cz ?? 0;

    for (let c = 0; c < cols; c++) {
      const u = c / radialSegments;
      const theta = angleStart + u * (angleEnd - angleStart);
      const cosT = Math.cos(theta);
      const sinT = Math.sin(theta);

      const longitudinalProfile = Math.pow(Math.max(0, Math.sin(Math.PI * v)), 0.85);
      const transverseProfile = closed ? 1 : Math.pow(Math.max(0, Math.sin(Math.PI * u)), 0.62);
      const sculptedOffset = radialOffset + bulge * longitudinalProfile * transverseProfile;
      const rx = Math.max(0.005, slice.rx + sculptedOffset);
      let rz = Math.max(0.005, slice.rz + sculptedOffset);

      const frontFactor = Math.max(0, sinT);
      const backFactor = Math.max(0, -sinT);
      const centerLine = Math.exp(-Math.pow(cosT * 3.6, 2));

      if (slice.chestCleft) rz -= slice.chestCleft * frontFactor * centerLine;
      if (slice.spineIndent) rz -= slice.spineIndent * backFactor * centerLine;

      positions[positionOffset++] = cx + cosT * rx;
      positions[positionOffset++] = slice.y;
      positions[positionOffset++] = cz + sinT * rz;
    }
  }

  // The topology helper owns UV seams and indices; cap-center positions are
  // written separately from the first and last cross-section centers.
  const firstSlice = geometrySlices[0]!;
  const lastSlice = geometrySlices[rows - 1]!;
  positionOffset = writeLoftCapPositions(
    positions,
    positionOffset,
    [firstSlice.cx ?? 0, firstSlice.y, firstSlice.cz ?? 0],
    [lastSlice.cx ?? 0, lastSlice.y, lastSlice.cz ?? 0],
    topology.hasClosedCaps,
  );
  if (positionOffset !== positions.length) {
    throw new Error('Anatomy loft position buffer length mismatch');
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
  geo.setIndex(new THREE.BufferAttribute(indices, 1));
  geo.computeVertexNormals();

  // Duplicate U=0/U=1 vertices are spatially coincident but have separate
  // triangle fans. Average their normals so PBR lighting has no visible seam.
  if (closed) {
    const normals = geo.getAttribute('normal');
    if (!(normals.array instanceof Float32Array)) {
      throw new Error('Anatomy loft normals must use Float32Array before seam averaging');
    }
    averageClosedLoftSeamNormals(normals.array, rows, radialSegments);
    normals.needsUpdate = true;
  }
  return geo;
}

function mergeStaticBatch(
  parts: THREE.BufferGeometry[],
  disposableList: THREE.BufferGeometry[],
  preserveUV = false,
): THREE.BufferGeometry | null {
  if (parts.length === 0) return null;
  // Only the muscle batch needs UVs for the procedural fiber normal map. Keep
  // the previous compact buffers for shell, deep tissue, and skeleton batches.
  if (!preserveUV) {
    for (const part of parts) part.deleteAttribute('uv');
  }
  const merged = mergeGeometries(parts, false);
  for (const part of parts) part.dispose();
  if (!merged) return null;

  // Normal vectors tolerate signed-normalized 16-bit precision. This halves
  // normal-buffer memory without changing positions or simplifying triangles.
  const normals = merged.getAttribute('normal') as THREE.BufferAttribute | undefined;
  if (normals?.array instanceof Float32Array) {
    const source = normals.array;
    const packedNormals = new Int16Array(source.length);
    for (let index = 0; index < source.length; index += 1) {
      const value = source[index] ?? 0;
      packedNormals[index] = Math.round(Math.max(-1, Math.min(1, value)) * 32767);
    }
    merged.setAttribute('normal', new THREE.BufferAttribute(packedNormals, 3, true));
  }

  // Most procedural batches remain below 65,536 vertices. Use 16-bit indices
  // when safe; keep Uint32 for any future higher-detail batch.
  const positions = merged.getAttribute('position');
  const index = merged.getIndex();
  if (index && positions && positions.count <= 65_535 && !(index.array instanceof Uint16Array)) {
    merged.setIndex(new THREE.BufferAttribute(new Uint16Array(index.array), 1));
  }

  merged.computeBoundingBox();
  merged.computeBoundingSphere();
  disposableList.push(merged);
  return merged;
}

export function buildAnatomyBody(materials: AnatomyMaterialSet): AnatomyBodyRig {
  const root = new THREE.Group();
  root.name = 'titan-anatomy-sculpture';

  const shellGroup = new THREE.Group();
  const superficialGroup = new THREE.Group();
  const deepGroup = new THREE.Group();
  const skeletonGroup = new THREE.Group();

  root.add(shellGroup, skeletonGroup, deepGroup, superficialGroup);

  const muscleEntries: MuscleMeshEntry[] = [];
  const pickableMeshes: THREE.Mesh[] = [];
  const occlusionMeshes: THREE.Mesh[] = [];
  const geometries: THREE.BufferGeometry[] = [];

  // One material batch per anatomical layer; muscle picking metadata lives in vertex attributes.
  const shellGeos: THREE.BufferGeometry[] = [];
  const muscleGeos: THREE.BufferGeometry[] = [];
  const deepGeos: THREE.BufferGeometry[] = [];
  const skeletonGeos: THREE.BufferGeometry[] = [];

  const addShellPart = (slices: CrossSectionSlice[], radialSegs = 48) => {
    const shellGeo = buildLoftedGeometry(
      slices,
      radialSegs,
      0,
      Math.PI * 2,
      true,
      0,
      3,
    );
    attachMuscleIdAttribute(shellGeo, 0);
    shellGeos.push(shellGeo);
  };

  const registerMusclePatch = (
    muscleId: MuscleGroupId,
    side: MuscleSide,
    slices: CrossSectionSlice[],
    angleStart: number,
    angleEnd: number,
    radialSegs = 20,
    radialOffset = 0.0018,
    bulge = 0.009,
  ) => {
    // Rounded elliptical relief replaces flat sticker-like patches. Six spline steps
    // smooth the muscle belly and a sine profile blends the edges back into the body.
    const geo = buildLoftedGeometry(
      slices,
      radialSegs,
      angleStart,
      angleEnd,
      false,
      radialOffset,
      6,
      bulge,
    );
    const numericSide = side === 'left' ? 1 : side === 'right' ? -1 : 0;
    attachMuscleIdAttribute(geo, MUSCLE_ID_TO_SHADER_INDEX[muscleId], numericSide);
    muscleGeos.push(geo);
    muscleEntries.push({ muscleId, side });
  };

  const addShellEllipsoid = (
    center: THREE.Vector3,
    scale: THREE.Vector3,
    segments = 18,
  ) => {
    const geo = new THREE.SphereGeometry(1, segments, Math.max(10, Math.floor(segments * 0.65)));
    geo.scale(scale.x, scale.y, scale.z);
    geo.translate(center.x, center.y, center.z);
    geo.computeVertexNormals();
    attachMuscleIdAttribute(geo, 0);
    shellGeos.push(geo);
  };
  const addDeepPlane = (
    slices: CrossSectionSlice[],
    angleStart = 0,
    angleEnd = Math.PI * 2,
    radialOffset = -0.018,
  ) => {
    const geo = buildLoftedGeometry(slices, 32, angleStart, angleEnd, false, radialOffset, 2);
    attachMuscleIdAttribute(geo, 0);
    deepGeos.push(geo);
  };

  const addBoneTube = (points: THREE.Vector3[], radius: number, segs = 14) => {
    const curve = new THREE.CatmullRomCurve3(points);
    const geo = new THREE.TubeGeometry(curve, segs, radius, 8, false);
    attachMuscleIdAttribute(geo, 0);
    skeletonGeos.push(geo);
  };

  // === LAYER 01: CONTINUOUS SCULPTED TORSO + NECK + HEAD ===
  const torsoAndHeadSlices: CrossSectionSlice[] = [
    { y: 0.85, rx: 0.145, rz: 0.105, cz: -0.005 },
    { y: 0.91, rx: 0.155, rz: 0.112, cz: 0 },
    { y: 0.98, rx: 0.142, rz: 0.102, cz: 0.005, spineIndent: 0.012 },
    { y: 1.06, rx: 0.148, rz: 0.106, cz: 0.008, spineIndent: 0.015 },
    { y: 1.15, rx: 0.168, rz: 0.115, cz: 0.008, chestCleft: 0.008, spineIndent: 0.016 },
    { y: 1.24, rx: 0.188, rz: 0.125, cz: 0.006, chestCleft: 0.018, spineIndent: 0.018 },
    { y: 1.33, rx: 0.198, rz: 0.128, cz: 0.004, chestCleft: 0.022, spineIndent: 0.014 },
    { y: 1.40, rx: 0.175, rz: 0.108, cz: -0.002, chestCleft: 0.01, spineIndent: 0.01 },
    { y: 1.45, rx: 0.092, rz: 0.075, cz: -0.008 },
    { y: 1.50, rx: 0.056, rz: 0.058, cz: -0.008 },
    { y: 1.56, rx: 0.054, rz: 0.058, cz: -0.004 },
    { y: 1.60, rx: 0.068, rz: 0.082, cz: 0.012 },
    { y: 1.66, rx: 0.084, rz: 0.098, cz: 0.008 },
    { y: 1.72, rx: 0.088, rz: 0.102, cz: 0.002 },
    { y: 1.77, rx: 0.072, rz: 0.085, cz: -0.004 },
    { y: 1.80, rx: 0.032, rz: 0.038, cz: -0.006 },
  ];
  addShellPart(torsoAndHeadSlices, 56);

  // === LAYER 03: ESTRUTURAS PROFUNDAS (CORE & SUBESCAPULAR PLANES) ===
  addDeepPlane(torsoAndHeadSlices.slice(1, 6), 0, Math.PI * 2, -0.022);
  addDeepPlane(torsoAndHeadSlices.slice(4, 8), 0.15, Math.PI - 0.15, -0.016);
  addDeepPlane(torsoAndHeadSlices.slice(4, 8), Math.PI + 0.15, Math.PI * 2 - 0.15, -0.016);

  // === LAYER 04: ESQUELETO DE REFERÊNCIA DISCRETO ===
  // Spine column
  addBoneTube(
    [
      new THREE.Vector3(0, 0.89, -0.032),
      new THREE.Vector3(0, 1.06, -0.028),
      new THREE.Vector3(0, 1.24, -0.044),
      new THREE.Vector3(0, 1.42, -0.036),
      new THREE.Vector3(0, 1.57, -0.018),
    ],
    0.014,
    20,
  );
  // Sternum & Cranium core reference
  addBoneTube(
    [
      new THREE.Vector3(0, 1.19, 0.076),
      new THREE.Vector3(0, 1.38, 0.068),
    ],
    0.011,
    10,
  );
  const skullGeo = new THREE.SphereGeometry(0.062, 18, 14);
  skullGeo.scale(0.88, 1.08, 1.0);
  skullGeo.translate(0, 1.70, 0.004);
  attachMuscleIdAttribute(skullGeo, 0);
  skeletonGeos.push(skullGeo);

  // Ribcage arches
  [1.18, 1.24, 1.30, 1.35].forEach((ry, idx) => {
    const rx = 0.122 + idx * 0.012;
    const rz = 0.082 + idx * 0.005;
    const ribPts: THREE.Vector3[] = [];
    for (let i = 0; i <= 16; i++) {
      const t = (i / 16) * Math.PI * 2;
      ribPts.push(new THREE.Vector3(Math.cos(t) * rx, ry, Math.sin(t) * rz));
    }
    addBoneTube(ribPts, 0.0055, 24);
  });

  // Pelvic girdle ring
  const pelvisPts: THREE.Vector3[] = [];
  for (let i = 0; i <= 16; i++) {
    const t = (i / 16) * Math.PI * 2;
    pelvisPts.push(new THREE.Vector3(Math.cos(t) * 0.118, 0.90, Math.sin(t) * 0.074));
  }
  addBoneTube(pelvisPts, 0.011, 20);

  const buildArmSlices = (side: -1 | 1): CrossSectionSlice[] => [
    { y: 0.69, rx: 0.024, rz: 0.036, cx: side * 0.305, cz: 0.024 },
    { y: 0.77, rx: 0.028, rz: 0.026, cx: side * 0.296, cz: 0.018 },
    { y: 0.87, rx: 0.036, rz: 0.034, cx: side * 0.285, cz: 0.010 },
    { y: 0.96, rx: 0.044, rz: 0.042, cx: side * 0.274, cz: 0.004 },
    { y: 1.05, rx: 0.039, rz: 0.038, cx: side * 0.264, cz: -0.004 },
    { y: 1.14, rx: 0.047, rz: 0.049, cx: side * 0.252, cz: -0.002 },
    { y: 1.23, rx: 0.052, rz: 0.054, cx: side * 0.242, cz: 0.000 },
    { y: 1.32, rx: 0.056, rz: 0.056, cx: side * 0.232, cz: 0.000 },
    { y: 1.38, rx: 0.062, rz: 0.062, cx: side * 0.215, cz: -0.002 },
    { y: 1.42, rx: 0.044, rz: 0.044, cx: side * 0.188, cz: -0.004 },
  ];

  const buildLegSlices = (side: -1 | 1): CrossSectionSlice[] => [
    { y: 0.00, rx: 0.044, rz: 0.095, cx: side * 0.104, cz: 0.036 },
    { y: 0.04, rx: 0.041, rz: 0.078, cx: side * 0.104, cz: 0.026 },
    { y: 0.10, rx: 0.034, rz: 0.036, cx: side * 0.104, cz: 0.002 },
    { y: 0.22, rx: 0.044, rz: 0.046, cx: side * 0.105, cz: -0.008 },
    { y: 0.34, rx: 0.054, rz: 0.056, cx: side * 0.105, cz: -0.008 },
    { y: 0.45, rx: 0.049, rz: 0.051, cx: side * 0.105, cz: 0.002 },
    { y: 0.56, rx: 0.062, rz: 0.064, cx: side * 0.106, cz: 0.004 },
    { y: 0.69, rx: 0.075, rz: 0.076, cx: side * 0.104, cz: 0.002 },
    { y: 0.81, rx: 0.083, rz: 0.085, cx: side * 0.098, cz: -0.002 },
    { y: 0.89, rx: 0.078, rz: 0.082, cx: side * 0.086, cz: -0.005 },
  ];

  ([-1, 1] as const).forEach((sideNum) => {
    // In anatomical view facing +Z: screen-left (+X when mirrored? Wait: user's anatomical LEFT is +X in +Z facing camera!)
    const sideLabel: MuscleSide = sideNum === 1 ? 'left' : 'right';
    const armSlices = buildArmSlices(sideNum);
    const legSlices = buildLegSlices(sideNum);

    addShellPart(armSlices, 36);
    addShellPart(legSlices, 40);

    // Palm, fingers and feet complete the silhouette while remaining part of the same shell draw call.
    addShellEllipsoid(
      new THREE.Vector3(sideNum * 0.306, 0.618, 0.018),
      new THREE.Vector3(0.034, 0.061, 0.025),
      20,
    );
    const fingerOffsets = [-0.021, -0.007, 0.007, 0.020];
    const fingerLengths = [0.060, 0.069, 0.064, 0.054];
    fingerOffsets.forEach((offset, fingerIndex) => {
      const length = fingerLengths[fingerIndex] ?? 0.058;
      const finger = new THREE.CapsuleGeometry(0.006, length, 3, 7);
      finger.rotateZ(sideNum * (fingerIndex - 1.4) * 0.035);
      finger.translate(sideNum * 0.306 + offset, 0.555 - (fingerIndex === 3 ? 0.004 : 0), 0.023);
      attachMuscleIdAttribute(finger, 0);
      shellGeos.push(finger);
    });
    const thumb = new THREE.CapsuleGeometry(0.0075, 0.045, 3, 8);
    thumb.rotateZ(-sideNum * 0.72);
    thumb.translate(sideNum * 0.345, 0.598, 0.027);
    attachMuscleIdAttribute(thumb, 0);
    shellGeos.push(thumb);

    addShellEllipsoid(
      new THREE.Vector3(sideNum * 0.104, 0.039, 0.078),
      new THREE.Vector3(0.056, 0.036, 0.126),
      24,
    );
    const toeXOffsets = [-0.033, -0.017, 0, 0.016, 0.031];
    const toeLengths = [0.041, 0.046, 0.041, 0.035, 0.029];
    toeXOffsets.forEach((offset, toeIndex) => {
      const length = toeLengths[toeIndex] ?? 0.032;
      addShellEllipsoid(
        new THREE.Vector3(sideNum * 0.104 + offset, 0.027, 0.168 + (toeIndex === 0 ? -0.006 : 0)),
        new THREE.Vector3(0.009, 0.010, length * 0.58),
        12,
      );
    });

    // Deep muscular planes for arms & thighs
    addDeepPlane(armSlices.slice(3, 8), 0, Math.PI * 2, -0.015);
    addDeepPlane(legSlices.slice(4, 9), 0, Math.PI * 2, -0.02);

    // Clavicle, Humerus, Radius/Ulna, Femur, Tibia reference bones
    addBoneTube(
      [
        new THREE.Vector3(sideNum * 0.025, 1.39, 0.052),
        new THREE.Vector3(sideNum * 0.115, 1.40, 0.028),
        new THREE.Vector3(sideNum * 0.195, 1.385, -0.004),
      ],
      0.008,
      10,
    );
    addBoneTube(
      [
        new THREE.Vector3(sideNum * 0.215, 1.37, -0.002),
        new THREE.Vector3(sideNum * 0.258, 1.06, -0.004),
        new THREE.Vector3(sideNum * 0.295, 0.77, 0.018),
      ],
      0.01,
      14,
    );
    addBoneTube(
      [
        new THREE.Vector3(sideNum * 0.095, 0.88, -0.002),
        new THREE.Vector3(sideNum * 0.105, 0.46, 0.002),
        new THREE.Vector3(sideNum * 0.104, 0.09, 0.002),
      ],
      0.014,
      16,
    );

    // === LAYER 02: SUPERFICIAL MUSCLES (LEFT & RIGHT INDEPENDENT) ===
    const chestSlices = torsoAndHeadSlices.slice(4, 8);
    if (sideNum === 1) {
      registerMusclePatch('pectoralis', sideLabel, chestSlices, 0.12, Math.PI * 0.46, 24, 0.0018, 0.013);
    } else {
      registerMusclePatch('pectoralis', sideLabel, chestSlices, Math.PI * 0.54, Math.PI - 0.12, 24, 0.0018, 0.013);
    }

    const latSlices = torsoAndHeadSlices.slice(2, 7);
    if (sideNum === 1) {
      registerMusclePatch('latissimus', sideLabel, latSlices, Math.PI * 1.56, Math.PI * 1.94, 22, 0.0018, 0.011);
    } else {
      registerMusclePatch('latissimus', sideLabel, latSlices, Math.PI * 1.06, Math.PI * 1.44, 22, 0.0018, 0.011);
    }

    const deltSlices = armSlices.slice(6, 10);
    if (sideNum === 1) {
      registerMusclePatch('anterior_deltoid', sideLabel, deltSlices, 0.15, Math.PI * 0.65, 20, 0.0018, 0.013);
      registerMusclePatch('lateral_deltoid', sideLabel, deltSlices, -Math.PI * 0.32, 0.15, 20, 0.0018, 0.014);
      registerMusclePatch('posterior_deltoid', sideLabel, deltSlices, -Math.PI * 0.82, -Math.PI * 0.32, 20, 0.0018, 0.012);
    } else {
      registerMusclePatch('anterior_deltoid', sideLabel, deltSlices, Math.PI * 0.35, Math.PI * 0.85, 20, 0.0018, 0.013);
      registerMusclePatch('lateral_deltoid', sideLabel, deltSlices, Math.PI * 0.85, Math.PI * 1.32, 20, 0.0018, 0.014);
      registerMusclePatch('posterior_deltoid', sideLabel, deltSlices, Math.PI * 1.32, Math.PI * 1.82, 20, 0.0018, 0.012);
    }

    const upperArmSlices = armSlices.slice(4, 8);
    registerMusclePatch('biceps', sideLabel, upperArmSlices, Math.PI * 0.12, Math.PI * 0.88, 22, 0.0018, 0.011);
    registerMusclePatch('triceps', sideLabel, upperArmSlices, Math.PI * 1.12, Math.PI * 1.88, 22, 0.0018, 0.010);

    const forearmSlices = armSlices.slice(1, 5);
    registerMusclePatch('forearms', sideLabel, forearmSlices, 0, Math.PI * 2, 28, 0.0015, 0.008);

    const gluteSlices = legSlices.slice(7, 10);
    registerMusclePatch('glutes', sideLabel, gluteSlices, Math.PI * 1.15, Math.PI * 1.85, 22, 0.0018, 0.013);

    const thighSlices = legSlices.slice(5, 9);
    registerMusclePatch('quadriceps', sideLabel, thighSlices, Math.PI * 0.1, Math.PI * 0.9, 26, 0.0018, 0.013);
    registerMusclePatch('hamstrings', sideLabel, thighSlices, Math.PI * 1.12, Math.PI * 1.88, 26, 0.0018, 0.011);

    const calfSlices = legSlices.slice(2, 5);
    registerMusclePatch('calves', sideLabel, calfSlices, Math.PI * 1.08, Math.PI * 1.92, 22, 0.0018, 0.010);
  });

  // Rectus abdominis is represented as six restrained, tapered bellies rather
  // than one broad plate. They retain one stable domain ID while left/right
  // anatomy remains available to hit-testing.
  const addAbdominalLobe = (side: -1 | 1, y: number, frontZ: number) => {
    const geo = new THREE.SphereGeometry(1, 18, 12);
    geo.scale(0.028, 0.021, 0.008);
    geo.translate(side * 0.032, y, frontZ);
    geo.computeVertexNormals();
    const numericSide = side === 1 ? 1 : -1;
    attachMuscleIdAttribute(geo, MUSCLE_ID_TO_SHADER_INDEX.abdominals, numericSide);
    muscleGeos.push(geo);
    muscleEntries.push({ muscleId: 'abdominals', side: side === 1 ? 'left' : 'right' });
  };
  addAbdominalLobe(-1, 1.065, 0.118);
  addAbdominalLobe(1, 1.065, 0.118);
  addAbdominalLobe(-1, 1.115, 0.126);
  addAbdominalLobe(1, 1.115, 0.126);
  addAbdominalLobe(-1, 1.165, 0.132);
  addAbdominalLobe(1, 1.165, 0.132);

  // Upper trapezius and back of the neck.
  registerMusclePatch(
    'trapezius',
    'center',
    torsoAndHeadSlices.slice(6, 10),
    Math.PI * 1.15,
    Math.PI * 1.85,
    24,
    0.0018,
    0.011,
  );

  // One body batch, one muscle batch, one deep-layer batch and one skeleton batch.
  const mergedShellGeo = mergeStaticBatch(shellGeos, geometries);
  if (mergedShellGeo) {
    const shellMesh = new THREE.Mesh(mergedShellGeo, materials.bodySurface);
    shellMesh.name = 'anatomy-body-surface';
    shellMesh.renderOrder = 1;
    shellGroup.add(shellMesh);
    occlusionMeshes.push(shellMesh);
  }

  let muscleSurface: THREE.Mesh | null = null;
  const mergedMuscleGeo = mergeStaticBatch(muscleGeos, geometries, true);
  if (mergedMuscleGeo) {
    muscleSurface = new THREE.Mesh(mergedMuscleGeo, materials.muscleSurface);
    muscleSurface.name = 'anatomy-muscle-surface-batched';
    muscleSurface.layers.set(1);
    muscleSurface.layers.enable(0);
    muscleSurface.renderOrder = 3;
    muscleSurface.userData.muscleIdAttribute = 'aMuscleId';
    muscleSurface.userData.muscleSideAttribute = 'aMuscleSide';
    superficialGroup.add(muscleSurface);
    pickableMeshes.push(muscleSurface);
  }

  const mergedDeepGeo = mergeStaticBatch(deepGeos, geometries);
  if (mergedDeepGeo) {
    const deepMesh = new THREE.Mesh(mergedDeepGeo, materials.deepPlane);
    deepMesh.name = 'anatomy-deep-layer';
    deepMesh.renderOrder = 2;
    deepGroup.add(deepMesh);
  }

  const mergedSkeletonGeo = mergeStaticBatch(skeletonGeos, geometries);
  if (mergedSkeletonGeo) {
    const skeletonMesh = new THREE.Mesh(mergedSkeletonGeo, materials.skeletonReference);
    skeletonMesh.name = 'anatomy-skeleton-reference';
    skeletonMesh.renderOrder = 1;
    skeletonGroup.add(skeletonMesh);
  }

  return {
    root,
    shellGroup,
    superficialGroup,
    deepGroup,
    skeletonGroup,
    muscleEntries,
    muscleSurface,
    pickableMeshes,
    occlusionMeshes,
    dispose: () => {
      geometries.forEach((g) => g.dispose());
    },
  };
}
