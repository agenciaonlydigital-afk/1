import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import type {
  MuscleGroupId,
  MuscleHighlightPayload,
  MuscleSide,
} from '@/src/shared/types/common';
import type { AnatomicalView } from '../../mapping/muscle-registry';
import {
  computeActiveMusclesMask,
  MUSCLE_ID_TO_SHADER_INDEX,
} from '../../mapping/anatomy-identifiers';
import type { AnatomyLayerMode, FocusRegion } from '../../state/anatomy.store';
import { getAnatomyCameraPreset } from '../camera/anatomy-camera';
import { detectSoftwareWebGL } from '../lifecycle/webgl-guard';
import { createAnatomyMaterials, type AnatomyMaterialSet } from '../materials/anatomy-materials';
import { buildAnatomyBody, type AnatomyBodyRig } from '../scene/build-anatomy-body';
import { MusclePicker } from '../picking/muscle-picking';

export interface AnatomyEngineCallbacks {
  onStatusChange: (status: 'initializing' | 'ready' | 'fallback') => void;
  onMusclePick: (muscleId: MuscleGroupId, side: MuscleSide) => void;
}

export interface AnatomyVisualInput {
  selectedMuscleId: MuscleGroupId | null;
  selectedMuscleSide: MuscleSide | null;
  workoutHighlights: MuscleHighlightPayload;
  cameraView: AnatomicalView;
  focusRegion: FocusRegion;
  layerMode: AnatomyLayerMode;
  zoomScale: number;
  hologramMode: boolean;
}

export interface AnatomyPerformanceSnapshot {
  drawCalls: number;
  triangles: number;
  geometries: number;
  textures: number;
  pixelRatio: number;
}

export class AnatomyRendererController {
  private renderer: THREE.WebGLRenderer | null = null;
  private controls: OrbitControls | null = null;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  // Heavy geometry/material construction is deferred until the actual WebGL2 renderer exists.
  // Unsupported browsers and offscreen viewers never pay the anatomy build cost.
  private materials: AnatomyMaterialSet | null = null;
  private bodyRig: AnatomyBodyRig | null = null;
  private environmentTarget: THREE.WebGLRenderTarget | null = null;
  private readonly musclePicker = new MusclePicker();
  private pointerDown: { x: number; y: number; pointerId: number } | null = null;
  private emitterResources: Array<{ dispose: () => void }> = [];
  private backlightHalo: THREE.Mesh | null = null;
  private resizeObserver: ResizeObserver | null = null;
  private intersectionObserver: IntersectionObserver | null = null;

  private isSoftwareGl = false;
  private isTouchDevice = false;
  private isVisible = true;
  private pageVisible = typeof document === 'undefined' || !document.hidden;
  private contextLost = false;
  private contextGeneration = 0;
  private shaderPreparationPending = false;
  private prefersReducedMotion = false;
  private motionQuery: MediaQueryList | null = null;
  private lastCameraKey = '';
  private lastWidth = 0;
  private lastHeight = 0;
  private lastPixelRatio = 0;
  private lastSelectionKey = '';
  private selectionSweepStartedAt = 0;
  private rafId = 0;
  private renderDirty = false;
  private disposed = false;
  private mountStarted = false;
  private initializationAttempted = false;
  private pendingVisualInput: AnatomyVisualInput | null = null;
  private cameraTransition: {
    startedAt: number;
    durationMs: number;
    fromPos: THREE.Vector3;
    toPos: THREE.Vector3;
    fromTarget: THREE.Vector3;
    toTarget: THREE.Vector3;
  } | null = null;

  constructor(
    private readonly container: HTMLElement,
    private readonly callbacks: AnatomyEngineCallbacks,
  ) {
    this.scene = new THREE.Scene();
    this.scene.background = null;

    const width = Math.max(1, container.clientWidth);
    const height = Math.max(1, container.clientHeight);
    this.camera = new THREE.PerspectiveCamera(35, width / height, 0.1, 40);
    const preset = getAnatomyCameraPreset('frontal', 'full', 1);
    this.camera.position.copy(preset.position);
    this.camera.lookAt(preset.target);
  }

  mount(): boolean {
    if (this.disposed || this.mountStarted) return false;
    this.mountStarted = true;
    this.callbacks.onStatusChange('initializing');
    document.addEventListener('visibilitychange', this.handleDocumentVisibilityChange);
    if (typeof IntersectionObserver === 'undefined') {
      this.isVisible = true;
      this.initializeRenderer();
      return true;
    }

    // The WebGL context and anatomy are both deferred until the viewer is actually seen.
    this.isVisible = false;
    this.intersectionObserver = new IntersectionObserver(
      (entries) => {
        const nextVisible = entries[0]?.isIntersecting ?? false;
        const becameVisible = !this.isVisible && nextVisible;
        this.isVisible = nextVisible;
        if (!nextVisible) {
          cancelAnimationFrame(this.rafId);
          this.rafId = 0;
          return;
        }
        if (this.pageVisible && becameVisible) {
          if (!this.renderer) this.initializeRenderer();
          else this.requestRender();
        }
      },
      // Prepare slightly before the stage enters view so context creation and
      // geometry build are less likely to compete with the first interaction.
      { rootMargin: '120px 0px', threshold: 0.01 },
    );
    this.intersectionObserver.observe(this.container);
    return true;
  }

  private initializeRenderer(): void {
    if (
      this.disposed ||
      this.initializationAttempted ||
      this.renderer ||
      !this.isVisible ||
      !this.pageVisible
    ) return;
    this.initializationAttempted = true;

    this.isTouchDevice = window.matchMedia('(pointer: coarse)').matches;
    this.motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    this.prefersReducedMotion = this.motionQuery.matches;
    this.motionQuery.addEventListener('change', this.handleMotionPreferenceChange);

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !this.isTouchDevice,
        powerPreference: 'high-performance',
        alpha: true,
        depth: true,
        stencil: false,
        preserveDrawingBuffer: false,
      });
    } catch {
      // WebGL constructor failures still release the mount-time observers and page listeners.
      this.releaseViewportObservers();
      this.callbacks.onStatusChange('fallback');
      return;
    }
    // Read the actual renderer string from the context Three.js just created.
    // This avoids a throwaway WebGL context and avoids probing a different GPU path.
    this.isSoftwareGl = detectSoftwareWebGL(renderer.getContext());

    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.04;
    renderer.setClearColor(0x000000, 0);

    this.lastWidth = Math.max(1, this.container.clientWidth);
    this.lastHeight = Math.max(1, this.container.clientHeight);
    this.lastPixelRatio = this.getEffectivePixelRatio(this.lastWidth, this.lastHeight);
    renderer.setPixelRatio(this.lastPixelRatio);
    renderer.setSize(this.lastWidth, this.lastHeight);
    renderer.domElement.style.display = 'block';
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    renderer.domElement.style.touchAction = 'pan-y';
    renderer.domElement.style.pointerEvents = 'auto';
    renderer.domElement.style.cursor = 'grab';
    renderer.domElement.setAttribute(
      'aria-label',
      'Modelo anatômico tridimensional interativo. Arraste para girar e toque em um músculo para selecionar.',
    );

    try {
      const materials = createAnatomyMaterials();
      this.materials = materials;
      this.bodyRig = buildAnatomyBody(materials);
    } catch {
      this.releaseRendererToFallback(renderer);
      this.callbacks.onStatusChange('fallback');
      return;
    }

    const bodyRig = this.bodyRig;
    if (!bodyRig) {
      this.releaseRendererToFallback(renderer);
      this.callbacks.onStatusChange('fallback');
      return;
    }

    this.container.appendChild(renderer.domElement);
    this.renderer = renderer;

    this.buildStudioLighting();
    try {
      this.buildStudioEnvironment(renderer);
    } catch {
      // Studio reflections are an enhancement. Keep the PBR material + direct-light fallback.
      this.scene.environment = null;
      this.environmentTarget?.dispose();
      this.environmentTarget = null;
    }

    // Horizontal orbit only is intentional: it preserves the frontal/posterior/lateral study axes.
    const controls = new OrbitControls(this.camera, renderer.domElement);
    controls.target.set(0, 0.90, 0);
    controls.enableRotate = true;
    controls.enableZoom = false;
    controls.enablePan = false;
    controls.minPolarAngle = Math.PI / 2;
    controls.maxPolarAngle = Math.PI / 2;
    controls.enableDamping = !this.isSoftwareGl && !this.prefersReducedMotion;
    controls.dampingFactor = 0.065;
    controls.rotateSpeed = 0.72;
    controls.update();
    renderer.domElement.style.touchAction = 'pan-y';
    controls.addEventListener('start', this.handleControlsStart);
    controls.addEventListener('change', this.handleControlsChange);
    this.controls = controls;

    this.buildProjectorPlinth();
    this.scene.add(bodyRig.root);

    this.bindEvents(renderer.domElement);

    // React effects may have delivered the initial state while the viewer was still
    // outside the viewport. Apply the latest snapshot exactly once after resources exist.
    const pendingVisualInput = this.pendingVisualInput;
    this.pendingVisualInput = null;
    if (pendingVisualInput) this.syncVisualState(pendingVisualInput);

    // Hold rendering until PBR programs are ready. Three.js recommends
    // compileAsync when KHR_parallel_shader_compile is available; this avoids
    // making the first interaction pay the shader-compilation stall.
    this.shaderPreparationPending = true;
    const compileGeneration = this.contextGeneration;
    void renderer.compileAsync(this.scene, this.camera).then(() => {
      if (this.disposed || this.renderer !== renderer || compileGeneration !== this.contextGeneration) return;
      this.shaderPreparationPending = false;
      if (this.contextLost) return;
      this.callbacks.onStatusChange('ready');
      this.requestRender();
    }).catch(() => {
      if (this.disposed || this.renderer !== renderer || compileGeneration !== this.contextGeneration) return;
      this.releaseRendererToFallback(renderer);
      this.callbacks.onStatusChange('fallback');
    });
  }

  /** Release page/viewport listeners whether or not a WebGL context was created. */
  private releaseViewportObservers(): void {
    window.removeEventListener('resize', this.handleResize);
    document.removeEventListener('visibilitychange', this.handleDocumentVisibilityChange);
    this.motionQuery?.removeEventListener('change', this.handleMotionPreferenceChange);
    this.motionQuery = null;
    this.resizeObserver?.disconnect();
    this.resizeObserver = null;
    this.intersectionObserver?.disconnect();
    this.intersectionObserver = null;
  }

  /** Release every resource after an unrecoverable WebGL or shader failure. */
  private releaseRendererToFallback(renderer: THREE.WebGLRenderer): void {
    cancelAnimationFrame(this.rafId);
    this.rafId = 0;
    this.renderDirty = false;
    this.shaderPreparationPending = false;
    this.contextLost = false;
    this.pointerDown = null;
    this.pendingVisualInput = null;

    if (this.controls) {
      this.controls.removeEventListener('start', this.handleControlsStart);
      this.controls.removeEventListener('change', this.handleControlsChange);
      this.controls.dispose();
      this.controls = null;
    }

    this.releaseViewportObservers();

    const canvas = renderer.domElement;
    canvas.removeEventListener('webglcontextlost', this.handleContextLost);
    canvas.removeEventListener('pointerdown', this.handlePointerDown);
    canvas.removeEventListener('pointerup', this.handlePointerUp);
    canvas.removeEventListener('pointercancel', this.handlePointerCancel);
    canvas.removeEventListener('webglcontextrestored', this.handleContextRestored);
    if (canvas.parentElement === this.container) this.container.removeChild(canvas);

    if (this.bodyRig) this.bodyRig.dispose();
    this.bodyRig = null;
    if (this.materials) this.materials.dispose();
    this.materials = null;
    this.emitterResources.forEach((resource) => resource.dispose());
    this.emitterResources = [];
    this.backlightHalo = null;

    this.scene.environment = null;
    this.environmentTarget?.dispose();
    this.environmentTarget = null;
    this.scene.clear();

    if (this.renderer === renderer) this.renderer = null;
    renderer.dispose();
    renderer.forceContextLoss();
  }

  private getEffectivePixelRatio(width: number, height: number): number {
    const deviceRatio = Math.max(0.1, window.devicePixelRatio || 1);
    const maxRatio = this.isSoftwareGl ? 1 : this.isTouchDevice ? 1.35 : 1.55;
    const pixelBudget = this.isSoftwareGl
      ? 520_000
      : this.isTouchDevice
        ? 1_050_000
        : 1_850_000;
    const budgetRatio = Math.sqrt(pixelBudget / Math.max(1, width * height));
    // There is deliberately no 0.5 DPR floor: an unusually large canvas may
    // need a lower ratio to keep the fragment workload inside the pixel budget.
    return Math.min(deviceRatio, maxRatio, budgetRatio);
  }

  private buildStudioLighting(): void {
    // One hemispheric source and two directional sources provide readable volume
    // without the per-fragment cost of a larger multi-light rig.
    const ambient = new THREE.HemisphereLight('#DDF4F2', '#101B1C', 0.95);
    const key = new THREE.DirectionalLight('#E8FBF9', 1.85);
    key.position.set(-2.6, 3.8, 3.4);
    const rim = new THREE.DirectionalLight('#54D8D2', 1.15);
    rim.position.set(0.2, 2.2, -3.4);
    this.scene.add(ambient, key, rim);
  }

  private buildStudioEnvironment(renderer: THREE.WebGLRenderer): void {
    // A small PMREM studio environment adds physically based soft reflections.
    // Skip its one-time generation on software renderers to protect startup time.
    if (this.isSoftwareGl) return;
    const generator = new THREE.PMREMGenerator(renderer);
    const room = new RoomEnvironment();
    try {
      this.environmentTarget = generator.fromScene(room, 0.04);
      this.scene.environment = this.environmentTarget.texture;
      this.scene.environmentIntensity = 0.34;
    } finally {
      room.dispose();
      generator.dispose();
    }
  }

  private buildProjectorPlinth(): void {
    const discGeo = new THREE.CircleGeometry(0.68, 64);
    discGeo.rotateX(-Math.PI / 2);
    const discMat = new THREE.MeshBasicMaterial({
      color: new THREE.Color('#0E1D1E'),
      transparent: true,
      opacity: 0.52,
    });
    const disc = new THREE.Mesh(discGeo, discMat);
    disc.position.y = 0;
    this.scene.add(disc);
    this.emitterResources.push(discGeo, discMat);

    // Analytic contact shadow avoids a shadow-map pass and its extra render cost.
    const shadowGeo = new THREE.PlaneGeometry(0.88, 0.30, 1, 1);
    const shadowMat = new THREE.ShaderMaterial({
      vertexShader: `
        varying vec2 vUv;
        void main() {
          vUv = uv;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        varying vec2 vUv;
        void main() {
          vec2 p = (vUv - 0.5) * 2.0;
          float r2 = dot(p, p);
          float broad = exp(-r2 * 4.2);
          float contact = exp(-r2 * 19.0);
          float edge = 1.0 - smoothstep(0.72, 1.0, r2);
          float alpha = (broad * 0.105 + contact * 0.12) * edge;
          vec3 shadowColor = vec3(0.006, 0.014, 0.016);
          gl_FragColor = vec4(shadowColor, alpha);
        }
      `,
      transparent: true,
      depthWrite: false,
      side: THREE.DoubleSide,
      blending: THREE.NormalBlending,
    });
    const contactShadow = new THREE.Mesh(shadowGeo, shadowMat);
    contactShadow.rotation.x = -Math.PI / 2;
    contactShadow.position.set(0, 0.001, 0.025);
    contactShadow.renderOrder = 1;
    this.scene.add(contactShadow);
    this.emitterResources.push(shadowGeo, shadowMat);

    const ringGeo = new THREE.RingGeometry(0.615, 0.625, 96);
    ringGeo.rotateX(-Math.PI / 2);
    const ringMat = new THREE.MeshBasicMaterial({
      color: new THREE.Color('#54D8D2'),
      transparent: true,
      opacity: 0.34,
      depthWrite: false,
    });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.position.y = 0.002;
    this.scene.add(ring);
    this.emitterResources.push(ringGeo, ringMat);

    const innerRingGeo = new THREE.RingGeometry(0.455, 0.461, 96);
    innerRingGeo.rotateX(-Math.PI / 2);
    const innerRingMat = new THREE.MeshBasicMaterial({
      color: new THREE.Color('#A0B7A8'),
      transparent: true,
      opacity: 0.22,
      depthWrite: false,
    });
    const innerRing = new THREE.Mesh(innerRingGeo, innerRingMat);
    innerRing.position.y = 0.0025;
    this.scene.add(innerRing);
    this.emitterResources.push(innerRingGeo, innerRingMat);

    // Circular backlight halo rendered behind the 3D hologram across all view angles.
    const haloGeo = new THREE.PlaneGeometry(2.1, 2.1, 1, 1);
    const haloMat = new THREE.ShaderMaterial({
      vertexShader: `
        varying vec2 vUv;
        void main() {
          vUv = uv;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        varying vec2 vUv;
        void main() {
          vec2 p = (vUv - 0.5) * 2.0;
          float r = length(p);
          float coreGlow = exp(-r * r * 3.8) * 0.24;
          float softField = exp(-r * r * 1.55) * 0.14;
          float circleRim = exp(-pow((r - 0.72) * 32.0, 2.0)) * 0.22;
          float innerHalo = exp(-pow((r - 0.48) * 24.0, 2.0)) * 0.08;
          float mask = 1.0 - smoothstep(0.84, 1.0, r);
          float intensity = (coreGlow + softField + circleRim + innerHalo) * mask;
          vec3 glowColor = mix(vec3(0.329, 0.847, 0.824), vec3(0.627, 0.718, 0.659), smoothstep(0.25, 0.78, r));
          gl_FragColor = vec4(glowColor * intensity, intensity);
        }
      `,
      transparent: true,
      depthWrite: false,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
    });
    const backlightHalo = new THREE.Mesh(haloGeo, haloMat);
    backlightHalo.position.set(0, 0.96, -0.45);
    backlightHalo.renderOrder = -1;
    this.scene.add(backlightHalo);
    this.backlightHalo = backlightHalo;
    this.emitterResources.push(haloGeo, haloMat);
  }

  private bindEvents(canvas: HTMLCanvasElement): void {
    canvas.addEventListener('webglcontextlost', this.handleContextLost);
    canvas.addEventListener('pointerdown', this.handlePointerDown);
    canvas.addEventListener('pointerup', this.handlePointerUp);
    canvas.addEventListener('pointercancel', this.handlePointerCancel);
    canvas.addEventListener('webglcontextrestored', this.handleContextRestored);
    window.addEventListener('resize', this.handleResize);
    if (typeof ResizeObserver !== 'undefined') {
      this.resizeObserver = new ResizeObserver(() => this.handleResize());
      this.resizeObserver.observe(this.container);
    }
  }

  private handleDocumentVisibilityChange = (): void => {
    this.pageVisible = !document.hidden;
    if (!this.pageVisible) {
      cancelAnimationFrame(this.rafId);
      this.rafId = 0;
      return;
    }
    if (this.isVisible && !this.renderer) {
      this.initializeRenderer();
      return;
    }
    this.requestRender();
  };

  private handleControlsStart = (): void => {
    this.cameraTransition = null;
  };

  private handleControlsChange = (): void => {
    this.requestRender();
  };

  private handlePointerDown = (event: PointerEvent): void => {
    if (event.button !== 0) return;
    this.pointerDown = { x: event.clientX, y: event.clientY, pointerId: event.pointerId };
  };

  private handlePointerCancel = (): void => {
    this.pointerDown = null;
  };

  private handlePointerUp = (event: PointerEvent): void => {
    const start = this.pointerDown;
    this.pointerDown = null;
    if (!start || start.pointerId !== event.pointerId) return;
    if (Math.hypot(event.clientX - start.x, event.clientY - start.y) > 6) return;
    const renderer = this.renderer;
    const bodyRig = this.bodyRig;
    if (!renderer || !bodyRig || this.disposed || this.contextLost) return;

    const hit = this.musclePicker.pick(
      event.clientX,
      event.clientY,
      renderer.domElement,
      this.camera,
      bodyRig.pickableMeshes,
      bodyRig.occlusionMeshes,
    );
    if (hit) {
      this.callbacks.onMusclePick(hit.muscleId, hit.side);
      this.requestRender();
    }
  };

  private handleContextLost = (event: Event): void => {
    event.preventDefault();
    this.contextLost = true;
    this.contextGeneration += 1;
    cancelAnimationFrame(this.rafId);
    this.rafId = 0;
    this.callbacks.onStatusChange('fallback');
  };

  private handleContextRestored = (): void => {
    const renderer = this.renderer;
    if (!renderer || this.disposed) return;
    try {
      this.contextLost = true;
      this.shaderPreparationPending = true;
      const compileGeneration = ++this.contextGeneration;
      // Render-target contents do not survive a context loss. Rebuild the PMREM
      // before compiling PBR programs; if this optional pass fails, direct lights remain.
      this.environmentTarget?.dispose();
      this.environmentTarget = null;
      this.scene.environment = null;
      try {
        this.buildStudioEnvironment(renderer);
      } catch {
        this.scene.environment = null;
      }
      void renderer.compileAsync(this.scene, this.camera).then(() => {
        if (this.disposed || this.renderer !== renderer || compileGeneration !== this.contextGeneration) return;
        this.shaderPreparationPending = false;
        this.contextLost = false;
        this.callbacks.onStatusChange('ready');
        this.requestRender();
      }).catch(() => {
        if (this.disposed || this.renderer !== renderer || compileGeneration !== this.contextGeneration) return;
        this.releaseRendererToFallback(renderer);
        this.callbacks.onStatusChange('fallback');
      });
    } catch {
      this.releaseRendererToFallback(renderer);
      this.callbacks.onStatusChange('fallback');
    }
  };

  private handleMotionPreferenceChange = (event: MediaQueryListEvent): void => {
    this.prefersReducedMotion = event.matches;
    if (this.controls) this.controls.enableDamping = !this.isSoftwareGl && !event.matches;
    if (event.matches) {
      this.selectionSweepStartedAt = 0;
      if (this.materials) this.materials.uniforms.uSweepY.value = 2.05;
    }
    this.requestRender();
  };

  handleResize = (): void => {
    if (!this.renderer || this.disposed) return;
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    if (width <= 0 || height <= 0) return;

    const nextPixelRatio = this.getEffectivePixelRatio(width, height);
    const sizeChanged = width !== this.lastWidth || height !== this.lastHeight;
    const densityChanged = Math.abs(nextPixelRatio - this.lastPixelRatio) > 0.001;
    if (!sizeChanged && !densityChanged) return;

    this.lastWidth = width;
    this.lastHeight = height;
    if (densityChanged) {
      this.lastPixelRatio = nextPixelRatio;
      this.renderer.setPixelRatio(nextPixelRatio);
    }
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
    this.requestRender();
  };

  private syncMuscleShaderState(next: AnatomyVisualInput): void {
    if (!this.materials) return;
    const uniforms = this.materials.uniforms;
    const primaryMask = computeActiveMusclesMask(next.workoutHighlights.primary);
    const secondaryMask = computeActiveMusclesMask(next.workoutHighlights.secondary);
    const activeIds: MuscleGroupId[] = [
      ...next.workoutHighlights.primary,
      ...next.workoutHighlights.secondary,
      ...(next.selectedMuscleId ? [next.selectedMuscleId] : []),
    ];
    const activeMask = computeActiveMusclesMask(activeIds);
    const selectedIndex = next.selectedMuscleId
      ? MUSCLE_ID_TO_SHADER_INDEX[next.selectedMuscleId]
      : 0;
    const selectedSide = next.selectedMuscleSide === 'left'
      ? 1
      : next.selectedMuscleSide === 'right'
        ? -1
        : 0;
    const selectedSideAny = next.selectedMuscleId && next.selectedMuscleSide && next.selectedMuscleSide !== 'center' ? 0 : 1;
    const hasSelection = next.selectedMuscleId ? 1 : 0;

    if (uniforms.uPrimaryMusclesMask.value !== primaryMask) uniforms.uPrimaryMusclesMask.value = primaryMask;
    if (uniforms.uSecondaryMusclesMask.value !== secondaryMask) uniforms.uSecondaryMusclesMask.value = secondaryMask;
    if (uniforms.uActiveMusclesMask.value !== activeMask) uniforms.uActiveMusclesMask.value = activeMask;
    if (uniforms.uSelectedMuscleIndex.value !== selectedIndex) uniforms.uSelectedMuscleIndex.value = selectedIndex;
    if (uniforms.uSelectedMuscleSide.value !== selectedSide) uniforms.uSelectedMuscleSide.value = selectedSide;
    if (uniforms.uSelectedSideAny.value !== selectedSideAny) uniforms.uSelectedSideAny.value = selectedSideAny;
    if (uniforms.uHasSelection.value !== hasSelection) uniforms.uHasSelection.value = hasSelection;
  }

  syncVisualState(next: AnatomyVisualInput): void {
    if (this.disposed) return;
    // Preserve the latest React state while IntersectionObserver defers WebGL setup.
    // Do not touch uninitialized materials, geometry, controls or GPU resources.
    const renderer = this.renderer;
    const materials = this.materials;
    const bodyRig = this.bodyRig;
    if (!renderer || !materials || !bodyRig) {
      if (!this.initializationAttempted) this.pendingVisualInput = next;
      return;
    }


    this.syncMuscleShaderState(next);
    materials.uniforms.uHologramMode.value = next.hologramMode ? 1 : 0;

    const selectionKey = next.selectedMuscleId
      ? `${next.selectedMuscleId}:${next.selectedMuscleSide ?? 'all'}`
      : '';
    if (selectionKey && selectionKey !== this.lastSelectionKey) {
      this.selectionSweepStartedAt = this.prefersReducedMotion ? 0 : performance.now();
      materials.uniforms.uSweepY.value = this.prefersReducedMotion ? 2.05 : -0.08;
    } else if (!selectionKey) {
      this.selectionSweepStartedAt = 0;
      materials.uniforms.uSweepY.value = 2.05;
    }
    this.lastSelectionKey = selectionKey;

    const isDeep = next.layerMode === 'deep';
    bodyRig.shellGroup.visible = true;
    bodyRig.superficialGroup.visible = !isDeep;
    bodyRig.deepGroup.visible = isDeep;
    bodyRig.skeletonGroup.visible = false;

    // A translucent outer reference lets the deeper planes read without a second post-process pass.
    materials.bodySurface.transparent = isDeep;
    materials.bodySurface.opacity = isDeep ? 0.16 : 1;
    materials.bodySurface.depthWrite = !isDeep;

    const cameraKey = `${next.cameraView}:${next.focusRegion}:${next.zoomScale}`;
    if (cameraKey !== this.lastCameraKey) {
      const hadPreviousCamera = this.lastCameraKey !== '';
      this.lastCameraKey = cameraKey;
      const preset = getAnatomyCameraPreset(
        next.cameraView,
        next.focusRegion,
        next.zoomScale,
      );
      if (!hadPreviousCamera || this.prefersReducedMotion || this.isSoftwareGl) {
        this.cameraTransition = null;
        this.camera.position.copy(preset.position);
        if (this.controls) {
          this.controls.target.copy(preset.target);
          this.controls.update();
        } else {
          this.camera.lookAt(preset.target);
        }
      } else {
        this.cameraTransition = {
          startedAt: performance.now(),
          durationMs: 360,
          fromPos: this.camera.position.clone(),
          toPos: preset.position.clone(),
          fromTarget: (this.controls ? this.controls.target : preset.target).clone(),
          toTarget: preset.target.clone(),
        };
      }
    }

    this.requestRender();
  }

  private updateCameraTransition(now: number): boolean {
    const transition = this.cameraTransition;
    if (!transition || this.prefersReducedMotion) {
      this.cameraTransition = null;
      return false;
    }
    const progress = Math.min(1, Math.max(0, (now - transition.startedAt) / transition.durationMs));
    const eased = 1 - Math.pow(1 - progress, 3);
    this.camera.position.lerpVectors(transition.fromPos, transition.toPos, eased);
    if (this.controls) {
      this.controls.target.lerpVectors(transition.fromTarget, transition.toTarget, eased);
      this.controls.update();
    } else {
      this.camera.lookAt(transition.toTarget);
    }
    if (progress >= 1) {
      this.cameraTransition = null;
      return false;
    }
    return true;
  }

  private updateSelectionSweep(now: number): boolean {
    if (!this.materials || !this.selectionSweepStartedAt || this.prefersReducedMotion) return false;
    const progress = Math.min(1, Math.max(0, (now - this.selectionSweepStartedAt) / 420));
    const eased = 1 - Math.pow(1 - progress, 3);
    this.materials.uniforms.uSweepY.value = -0.08 + eased * 1.95;
    if (progress >= 1) {
      this.materials.uniforms.uSweepY.value = 2.05;
      this.selectionSweepStartedAt = 0;
      return false;
    }
    return true;
  }

  requestRender = (): void => {
    const renderer = this.renderer;
    const bodyRig = this.bodyRig;
    const materials = this.materials;
    if (
      this.disposed ||
      !renderer ||
      !bodyRig ||
      !materials ||
      !this.isVisible ||
      !this.pageVisible ||
      this.contextLost ||
      this.shaderPreparationPending
    ) return;

    this.renderDirty = true;
    if (this.rafId) return;

    this.rafId = requestAnimationFrame(() => {
      this.rafId = 0;
      if (
        this.renderer !== renderer ||
        this.bodyRig !== bodyRig ||
        this.materials !== materials ||
        this.disposed ||
        !this.isVisible ||
        !this.pageVisible ||
        this.contextLost ||
        this.shaderPreparationPending
      ) return;

      this.renderDirty = false;
      const now = performance.now();
      const cameraAnimating = this.updateCameraTransition(now);
      const dampingActive = this.controls?.update() ?? false;
      const sweepActive = this.updateSelectionSweep(now);
      if (this.backlightHalo) {
        const cx = this.camera.position.x;
        const cz = this.camera.position.z;
        const len = Math.hypot(cx, cz) || 1;
        const nx = cx / len;
        const nz = cz / len;
        this.backlightHalo.position.set(-nx * 0.48, 0.96, -nz * 0.48);
        this.backlightHalo.rotation.set(0, Math.atan2(nx, nz), 0);
      }
      renderer.render(this.scene, this.camera);

      if (
        this.renderDirty ||
        cameraAnimating ||
        sweepActive ||
        (dampingActive && !this.isSoftwareGl)
      ) {
        this.requestRender();
      }
    });
  };

  getPerformanceSnapshot(): AnatomyPerformanceSnapshot {
    const info = this.renderer?.info;
    return {
      drawCalls: info?.render.calls ?? 0,
      triangles: info?.render.triangles ?? 0,
      geometries: info?.memory.geometries ?? 0,
      textures: info?.memory.textures ?? 0,
      pixelRatio: this.lastPixelRatio,
    };
  }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    cancelAnimationFrame(this.rafId);
    this.rafId = 0;
    this.cameraTransition = null;

    if (this.controls) {
      this.controls.removeEventListener('start', this.handleControlsStart);
      this.controls.removeEventListener('change', this.handleControlsChange);
      this.controls.dispose();
      this.controls = null;
    }

    this.releaseViewportObservers();

    // Dispose scene-owned resources while the renderer is still listening to
    // their dispose events, so GPU buffers/programs can be released explicitly.
    if (this.bodyRig) this.bodyRig.dispose();
    this.bodyRig = null;
    if (this.materials) this.materials.dispose();
    this.materials = null;
    this.emitterResources.forEach((resource) => resource.dispose());
    this.emitterResources = [];
    this.backlightHalo = null;

    if (this.renderer) {
      const renderer = this.renderer;
      const canvas = renderer.domElement;
      canvas.removeEventListener('webglcontextlost', this.handleContextLost);
      canvas.removeEventListener('pointerdown', this.handlePointerDown);
      canvas.removeEventListener('pointerup', this.handlePointerUp);
      canvas.removeEventListener('pointercancel', this.handlePointerCancel);
      canvas.removeEventListener('webglcontextrestored', this.handleContextRestored);
      if (canvas.parentElement === this.container) this.container.removeChild(canvas);
      this.scene.environment = null;
      this.environmentTarget?.dispose();
      this.environmentTarget = null;
      this.scene.clear();
      renderer.dispose();
      // Free the browser's WebGL context slot on route changes/unmounts; a new
      // viewer instance gets a fresh context only when it approaches the viewport.
      renderer.forceContextLoss();
      this.renderer = null;
    }

    this.pointerDown = null;
    this.pendingVisualInput = null;
    this.shaderPreparationPending = false;
  }
}
