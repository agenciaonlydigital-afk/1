import * as THREE from 'three';
import { createMuscleFiberNormalPixels } from './muscle-fiber-normal';
import {
  applyAnatomyMaterialEnhancements,
  type AnatomyShaderUniforms,
} from '../shaders/anatomy-material-shader';

export type { AnatomyShaderUniforms } from '../shaders/anatomy-material-shader';

export interface AnatomyMaterialSet {
  bodySurface: THREE.MeshStandardMaterial;
  muscleSurface: THREE.MeshStandardMaterial;
  deepPlane: THREE.MeshStandardMaterial;
  skeletonReference: THREE.MeshStandardMaterial;
  uniforms: AnatomyShaderUniforms;
  dispose: () => void;
}

export function attachMuscleIdAttribute(
  geometry: THREE.BufferGeometry,
  muscleNumericId: number,
  muscleSide: -1 | 0 | 1 = 0,
): void {
  const posAttr = geometry.attributes.position;
  if (!posAttr) return;
  const vertexCount = posAttr.count;
  // These are categorical attributes, not continuous measurements. Compact integer
  // buffers are exact for the 14 stable muscle IDs and the -1/0/+1 side values.
  const ids = new Uint8Array(vertexCount);
  const sides = new Int8Array(vertexCount);
  ids.fill(muscleNumericId);
  sides.fill(muscleSide);
  geometry.setAttribute('aMuscleId', new THREE.BufferAttribute(ids, 1));
  geometry.setAttribute('aMuscleSide', new THREE.BufferAttribute(sides, 1));
}


function createMuscleFiberNormalMap(): THREE.DataTexture {
  const size = 256;
  const data = createMuscleFiberNormalPixels(size);
  const texture = new THREE.DataTexture(data, size, size, THREE.RGBAFormat, THREE.UnsignedByteType);
  texture.name = 'titan-procedural-muscle-fiber-normal';
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.magFilter = THREE.LinearFilter;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.generateMipmaps = true;
  texture.colorSpace = THREE.NoColorSpace;
  texture.needsUpdate = true;
  return texture;
}

export function createAnatomyMaterials(): AnatomyMaterialSet {
  const uniforms: AnatomyShaderUniforms = {
    uActiveMusclesMask: { value: 0 },
    uPrimaryMusclesMask: { value: 0 },
    uSecondaryMusclesMask: { value: 0 },
    uSelectedMuscleIndex: { value: 0 },
    uSelectedMuscleSide: { value: 0 },
    uSelectedSideAny: { value: 1 },
    uHasSelection: { value: 0 },
    uMuscleRestingColor: { value: new THREE.Color('#2E4246') },
    uMuscleDimmedColor: { value: new THREE.Color('#213135') },
    uMusclePrimaryColor: { value: new THREE.Color('#6CE8B5') },
    uMuscleSecondaryColor: { value: new THREE.Color('#74C5E8') },
    uMuscleSelectedColor: { value: new THREE.Color('#F2CD7D') },
    uSweepY: { value: 2.05 },
    uHologramMode: { value: 1 },
    uHologramTint: { value: new THREE.Color('#54D8D2') },
    uHologramAccent: { value: new THREE.Color('#D6EFEA') },
  };

  // A quiet, museum-grade anatomical surface: physically lit, matte and non-metallic.
  const bodySurface = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#C8B9A8'),
    roughness: 0.74,
    metalness: 0,
    side: THREE.FrontSide,
  });
  applyAnatomyMaterialEnhancements(bodySurface, uniforms, 'body');

  // Muscle identity and workout state are resolved in the vertex/fragment shader.
  // This avoids a per-vertex color buffer and CPU rewrites when selection changes.
  const muscleSurface = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#FFFFFF'),
    roughness: 0.68,
    metalness: 0,
    side: THREE.FrontSide,
  });
  const muscleFiberNormalMap = createMuscleFiberNormalMap();
  muscleSurface.normalMap = muscleFiberNormalMap;
  muscleSurface.normalScale.set(0.16, 0.055);
  applyAnatomyMaterialEnhancements(muscleSurface, uniforms, 'muscle');

  const deepPlane = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#9D766A'),
    roughness: 0.88,
    metalness: 0,
    transparent: true,
    opacity: 0.72,
    depthWrite: false,
    side: THREE.FrontSide,
    polygonOffset: true,
    polygonOffsetFactor: -1,
  });

  const skeletonReference = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#DED2BE'),
    roughness: 0.86,
    metalness: 0,
    side: THREE.FrontSide,
  });

  return {
    bodySurface,
    muscleSurface,
    deepPlane,
    skeletonReference,
    uniforms,
    dispose: () => {
      bodySurface.dispose();
      muscleSurface.dispose();
      muscleFiberNormalMap.dispose();
      deepPlane.dispose();
      skeletonReference.dispose();
    },
  };
}
