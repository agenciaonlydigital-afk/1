/** Generate a tangent-space, longitudinal muscle-fiber normal map without external assets. */
export function createMuscleFiberNormalPixels(size = 256): Uint8Array {
  if (!Number.isInteger(size) || size < 16 || (size & (size - 1)) !== 0) {
    throw new RangeError(`Normal-map size must be a power of two >= 16; received ${size}`);
  }

  const heights = new Float32Array(size * size);
  const data = new Uint8Array(size * size * 4);
  const tau = Math.PI * 2;
  const heightAt = (u: number, v: number): number => {
    const phase = tau * (u * 36 + 0.055 * Math.sin(tau * v * 3) + 0.012 * Math.sin(tau * (u * 7 + v * 5)));
    return 0.026 * Math.sin(phase) + 0.006 * Math.sin(tau * (u * 13 + v * 3.0));
  };

  for (let y = 0; y < size; y += 1) {
    const v = y / size;
    for (let x = 0; x < size; x += 1) heights[y * size + x] = heightAt(x / size, v);
  }

  const strength = 0.024;
  for (let y = 0; y < size; y += 1) {
    const y0 = (y - 1 + size) % size;
    const y1 = (y + 1) % size;
    for (let x = 0; x < size; x += 1) {
      const x0 = (x - 1 + size) % size;
      const x1 = (x + 1) % size;
      const dx = (heights[y * size + x1]! - heights[y * size + x0]!) * size * 0.5;
      const dy = (heights[y1 * size + x]! - heights[y0 * size + x]!) * size * 0.5;
      let nx = -dx * strength;
      let ny = -dy * strength;
      let nz = 1;
      const length = Math.hypot(nx, ny, nz) || 1;
      nx /= length;
      ny /= length;
      nz /= length;
      const offset = (y * size + x) * 4;
      data[offset] = Math.round((nx * 0.5 + 0.5) * 255);
      data[offset + 1] = Math.round((ny * 0.5 + 0.5) * 255);
      data[offset + 2] = Math.round((nz * 0.5 + 0.5) * 255);
      data[offset + 3] = 255;
    }
  }
  return data;
}
