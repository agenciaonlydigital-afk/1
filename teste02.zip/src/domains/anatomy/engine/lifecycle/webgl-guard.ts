/**
 * Detect software rendering from the renderer's real WebGL2 context.
 *
 * Avoid creating a throwaway canvas/context just to probe capability: a second
 * context adds startup work and can consume scarce mobile WebGL context slots.
 * Three.js r163+ itself requires WebGL2 and throws when it is unavailable. Its
 * published type declaration still exposes a WebGL1/WebGL2 union for getContext().
 */
export function detectSoftwareWebGL(gl: WebGLRenderingContext | WebGL2RenderingContext): boolean {
  try {
    const extension = gl.getExtension('WEBGL_debug_renderer_info');
    const rendererParameter = extension?.UNMASKED_RENDERER_WEBGL ?? gl.RENDERER;
    const rendererName = String(gl.getParameter(rendererParameter) ?? '');
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(rendererName);
  } catch {
    // Unknown GPU: keep the hardware path, but conservative pixel budgets remain.
    return false;
  }
}
