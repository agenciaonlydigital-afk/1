import type { MuscleHighlightPayload } from '@/src/shared/types/common';
import { useAnatomyStore } from '../state/anatomy.store';

export function setWorkoutMuscleHighlights(payload: MuscleHighlightPayload): void {
  useAnatomyStore.getState().setWorkoutHighlights(payload);
}
