import type { MuscleGroupId } from '@/src/shared/types/common';
import { AnatomyViewport } from '../components/AnatomyViewport';
import { MUSCLE_REGISTRY } from './muscle-catalog-public.ts';
import { setWorkoutMuscleHighlights } from './set-muscle-highlights';

export function getMuscleLabel(muscleId: MuscleGroupId): string {
  return MUSCLE_REGISTRY[muscleId].label;
}

export function getMuscleLabels(muscleIds: readonly MuscleGroupId[]): string[] {
  return muscleIds.map((id) => MUSCLE_REGISTRY[id].label);
}

export { AnatomyViewport, setWorkoutMuscleHighlights, MUSCLE_REGISTRY };
