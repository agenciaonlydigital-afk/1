import assert from 'node:assert/strict';
import {
  computeActiveMusclesMask,
  MUSCLE_ID_TO_SHADER_INDEX,
  MUSCLE_SHADER_INDEX_TO_ID,
} from '../mapping/anatomy-identifiers';

const mask = computeActiveMusclesMask(['pectoralis', 'triceps']);
const expected =
  (1 << MUSCLE_ID_TO_SHADER_INDEX.pectoralis) |
  (1 << MUSCLE_ID_TO_SHADER_INDEX.triceps);
assert.equal(mask, expected);

for (const [id, index] of Object.entries(MUSCLE_ID_TO_SHADER_INDEX)) {
  assert.equal(MUSCLE_SHADER_INDEX_TO_ID[index], id, `reverse muscle ID mapping for ${id}`);
  assert.ok(index > 0 && index < 31, `muscle ID ${id} must fit the positive signed 32-bit shader mask`);
}
assert.equal(new Set(Object.values(MUSCLE_ID_TO_SHADER_INDEX)).size, Object.keys(MUSCLE_ID_TO_SHADER_INDEX).length);


const allMuscles = Object.keys(MUSCLE_ID_TO_SHADER_INDEX) as Array<keyof typeof MUSCLE_ID_TO_SHADER_INDEX>;
const allMask = computeActiveMusclesMask(allMuscles);
assert.equal(allMuscles.length, 14, 'the stable exercise registry must contain all 14 muscle groups');
assert.equal(allMask, (1 << 15) - 2, 'all 14 muscle bits must fit in the positive signed 32-bit shader mask');
assert.equal(
  computeActiveMusclesMask([...allMuscles, allMuscles[0]!]),
  allMask,
  'duplicate muscle highlights must not change the mask',
);

for (const id of allMuscles) {
  const index = MUSCLE_ID_TO_SHADER_INDEX[id];
  const maskForMuscle = computeActiveMusclesMask([id]);
  const shaderBit = Math.floor(maskForMuscle / 2 ** index) % 2;
  assert.equal(shaderBit, 1, `shader bit must match the GPU classifier for ${id}`);
}
