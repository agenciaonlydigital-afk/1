import { parseLocaleNumber } from '@/src/shared/utils/formatters';
import { useEvolutionStore } from '../state/evolution.store';

export function submitObservedMeasurement(raw: {
  weightKg: string;
  waistCm: string;
  armCm: string;
  thighCm: string;
  chestCm: string;
  hipCm: string;
  neckCm: string;
  forearmCm: string;
  calfCm: string;
}): { ok: true } | { ok: false; error: string } {
  if (raw.weightKg.trim() === '') {
    return { ok: false, error: 'Informe o peso para registrar a pesagem.' };
  }
  const optionalNumber = (value: string) => value.trim() === '' ? undefined : parseLocaleNumber(value);
  return useEvolutionStore.getState().logMeasurement({
    weightKg: parseLocaleNumber(raw.weightKg),
    waistCm: optionalNumber(raw.waistCm),
    armCm: optionalNumber(raw.armCm),
    thighCm: optionalNumber(raw.thighCm),
    chestCm: optionalNumber(raw.chestCm),
    hipCm: optionalNumber(raw.hipCm),
    neckCm: optionalNumber(raw.neckCm),
    forearmCm: optionalNumber(raw.forearmCm),
    calfCm: optionalNumber(raw.calfCm),
  });
}
