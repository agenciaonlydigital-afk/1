import type { FitnessGoalType } from '@/src/shared/types/fitness-goal';
import type { BodyMeasurementRecord } from '@/src/shared/types/body-measurement';

export interface ObservedMeasurementDeltas {
  weightDelta: string;
  waistDelta: string;
  armDelta: string;
  thighDelta: string;
}


/** Deltas compare the latest two observations of each metric independently. */
export function computeLatestObservedDeltas(records: readonly BodyMeasurementRecord[]): ObservedMeasurementDeltas {
  const chronological = sortMeasurementsChronologically(records);
  const latestWeight = chronological.at(-1);
  const previousWeight = chronological.at(-2);
  const latestFor = (key: 'waistCm' | 'armCm' | 'thighCm') => {
    const measured = chronological.filter((record) => Number.isFinite(record[key]));
    return { latest: measured.at(-1), previous: measured.at(-2) };
  };
  const waist = latestFor('waistCm');
  const arm = latestFor('armCm');
  const thigh = latestFor('thighCm');
  return {
    weightDelta: latestWeight && previousWeight ? (latestWeight.weightKg - previousWeight.weightKg).toFixed(1) : '0.0',
    waistDelta: waist.latest && waist.previous ? (waist.latest.waistCm! - waist.previous.waistCm!).toFixed(1) : '—',
    armDelta: arm.latest && arm.previous ? (arm.latest.armCm! - arm.previous.armCm!).toFixed(1) : '—',
    thighDelta: thigh.latest && thigh.previous ? (thigh.latest.thighCm! - thigh.previous.thighCm!).toFixed(1) : '—',
  };
}

export interface CumulativeEvolutionComparison {
  weightGainKg: number;
  weightGainPercent: number;
  waistDiffCm: number | null;
  armDiffCm: number | null;
  thighDiffCm: number | null;
  remainingToTargetKg: number;
  progressPercent: number;
}

export interface EvolutionCockpitIndicator {
  deltaKg: number;
  formattedDelta: string;
  direction: 'up' | 'down' | 'flat';
  isAlignedWithGoal: boolean;
}

export function computeObservedDeltas(
  latest: BodyMeasurementRecord,
  previous: BodyMeasurementRecord,
): ObservedMeasurementDeltas {
  return {
    weightDelta: (latest.weightKg - previous.weightKg).toFixed(1),
    waistDelta: Number.isFinite(latest.waistCm) && Number.isFinite(previous.waistCm) ? (latest.waistCm! - previous.waistCm!).toFixed(1) : '—',
    armDelta: Number.isFinite(latest.armCm) && Number.isFinite(previous.armCm) ? (latest.armCm! - previous.armCm!).toFixed(1) : '—',
    thighDelta: Number.isFinite(latest.thighCm) && Number.isFinite(previous.thighCm) ? (latest.thighCm! - previous.thighCm!).toFixed(1) : '—',
  };
}

export function computeCumulativeComparison(
  records: readonly BodyMeasurementRecord[],
  targetWeightKg: number,
): CumulativeEvolutionComparison {
  const chronological = sortMeasurementsChronologically(records);
  const baseline = chronological[0];
  const latest = chronological[chronological.length - 1];
  if (!baseline || !latest) {
    return {
      weightGainKg: 0,
      weightGainPercent: 0,
      waistDiffCm: 0,
      armDiffCm: 0,
      thighDiffCm: 0,
      remainingToTargetKg: 0,
      progressPercent: 0,
    };
  }

  const weightGainKg = Number((latest.weightKg - baseline.weightKg).toFixed(1));
  const weightGainPercent =
    baseline.weightKg > 0
      ? Number(((weightGainKg / baseline.weightKg) * 100).toFixed(1))
      : 0;
  const firstMeasured = (key: 'waistCm' | 'armCm' | 'thighCm') => chronological.find((record) => Number.isFinite(record[key]));
  const lastMeasured = (key: 'waistCm' | 'armCm' | 'thighCm') => [...chronological].reverse().find((record) => Number.isFinite(record[key]));
  const measureDelta = (key: 'waistCm' | 'armCm' | 'thighCm') => {
    const first = firstMeasured(key)?.[key];
    const last = lastMeasured(key)?.[key];
    return Number.isFinite(first) && Number.isFinite(last) ? Number((last! - first!).toFixed(1)) : null;
  };
  const waistDiffCm = measureDelta('waistCm');
  const armDiffCm = measureDelta('armCm');
  const thighDiffCm = measureDelta('thighCm');

  const remainingToTargetKg = Number((targetWeightKg - latest.weightKg).toFixed(1));
  const totalGoalSpan = targetWeightKg - baseline.weightKg;
  const progressPercent =
    Math.abs(totalGoalSpan) < 0.1
      ? 100
      : Math.max(
          0,
          Math.min(100, Math.round((weightGainKg / totalGoalSpan) * 100)),
        );

  return {
    weightGainKg,
    weightGainPercent,
    waistDiffCm,
    armDiffCm,
    thighDiffCm,
    remainingToTargetKg,
    progressPercent,
  };
}

export function computeEvolutionCockpitIndicator(
  records: readonly BodyMeasurementRecord[],
  goal: FitnessGoalType,
): EvolutionCockpitIndicator {
  const chronological = sortMeasurementsChronologically(records);
  const baseline = chronological[0];
  const latest = chronological[chronological.length - 1];
  if (!baseline || !latest) {
    return {
      deltaKg: 0,
      formattedDelta: '0.0 kg',
      direction: 'flat',
      isAlignedWithGoal: true,
    };
  }

  const deltaKg = Number((latest.weightKg - baseline.weightKg).toFixed(1));
  const direction: 'up' | 'down' | 'flat' =
    deltaKg > 0.04 ? 'up' : deltaKg < -0.04 ? 'down' : 'flat';

  let isAlignedWithGoal = true;
  if (goal === 'gain_muscle') {
    isAlignedWithGoal = deltaKg >= 0;
  } else if (goal === 'lose_weight') {
    isAlignedWithGoal = deltaKg <= 0;
  } else {
    isAlignedWithGoal = Math.abs(deltaKg) <= 0.5;
  }

  const sign = deltaKg > 0 ? '+' : '';
  return {
    deltaKg,
    formattedDelta: `${sign}${deltaKg.toFixed(1)} kg`,
    direction,
    isAlignedWithGoal,
  };
}


function isValidMeasurementDateKey(dateKey: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateKey)) return false;
  const [year, month, day] = dateKey.split('-').map(Number);
  const date = new Date(Date.UTC(year!, month! - 1, day!));
  return date.getUTCFullYear() === year && date.getUTCMonth() === month! - 1 && date.getUTCDate() === day;
}

export function sortMeasurementsChronologically(
  records: readonly BodyMeasurementRecord[],
): BodyMeasurementRecord[] {
  return [...records].sort((a, b) => {
    const dateA = 'dateKey' in a && typeof a.dateKey === 'string' ? a.dateKey : '';
    const dateB = 'dateKey' in b && typeof b.dateKey === 'string' ? b.dateKey : '';
    const validA = isValidMeasurementDateKey(dateA);
    const validB = isValidMeasurementDateKey(dateB);
    if (validA !== validB) return validA ? -1 : 1;
    return dateA.localeCompare(dateB);
  });
}

export interface WeightTrendEstimate {
  changePerWeekKg: number;
  averageWeightKg: number;
  sampleCount: number;
  uniqueDays: number;
  spanDays: number;
  firstDateKey: string;
  lastDateKey: string;
  direction: 'increasing' | 'decreasing' | 'stable';
  method: 'theil_sen_daily_median';
  confidence: 'low' | 'moderate' | 'higher';
}

function median(values: number[]): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle]! : (sorted[middle - 1]! + sorted[middle]!) / 2;
}

/**
 * Robust trend: same-day weigh-ins are collapsed to their median and the slope
 * is estimated with Theil-Sen (median of pairwise slopes). This reduces the
 * influence of duplicate entries and transient water/gut-content outliers.
 * It is a trend estimator, not a body-composition or fat-loss measurement.
 */
export function calculateWeightTrend(
  records: readonly BodyMeasurementRecord[],
  periodDays = 30,
): WeightTrendEstimate | null {
  if (!Number.isInteger(periodDays) || periodDays < 7 || periodDays > 365) {
    throw new RangeError('A janela da tendência deve ficar entre 7 e 365 dias.');
  }
  const dated = sortMeasurementsChronologically(records).filter((record) => {
    const dateKey = 'dateKey' in record ? record.dateKey : '';
    return isValidMeasurementDateKey(dateKey) && Number.isFinite(record.weightKg) && record.weightKg > 0;
  });
  const latest = dated[dated.length - 1];
  if (!latest) return null;
  const latestTime = Date.parse(`${latest.dateKey}T00:00:00Z`);
  const startTime = latestTime - (periodDays - 1) * 86_400_000;
  const inWindow = dated.filter((record) => Date.parse(`${record.dateKey}T00:00:00Z`) >= startTime);
  const byDay = new Map<string, number[]>();
  for (const record of inWindow) {
    const values = byDay.get(record.dateKey) ?? [];
    values.push(record.weightKg);
    byDay.set(record.dateKey, values);
  }
  const points = [...byDay.entries()]
    .map(([dateKey, weights]) => ({
      dateKey,
      x: Date.parse(`${dateKey}T00:00:00Z`) / 86_400_000,
      y: median(weights),
    }))
    .sort((a, b) => a.x - b.x);
  if (points.length < 2) return null;
  const slopes: number[] = [];
  for (let i = 0; i < points.length; i += 1) {
    for (let j = i + 1; j < points.length; j += 1) {
      const left = points[i]!;
      const right = points[j]!;
      const days = right.x - left.x;
      if (days > 0) slopes.push((right.y - left.y) / days);
    }
  }
  if (slopes.length === 0) return null;
  const changePerWeekKg = Number((median(slopes) * 7).toFixed(3));
  const spanDays = Math.round(points[points.length - 1]!.x - points[0]!.x);
  const averageWeightKg = Number(median(points.map((point) => point.y)).toFixed(2));
  return {
    changePerWeekKg,
    averageWeightKg,
    sampleCount: inWindow.length,
    uniqueDays: points.length,
    spanDays,
    firstDateKey: points[0]!.dateKey,
    lastDateKey: points[points.length - 1]!.dateKey,
    direction: changePerWeekKg > 0.05 ? 'increasing' : changePerWeekKg < -0.05 ? 'decreasing' : 'stable',
    method: 'theil_sen_daily_median',
    confidence: points.length >= 12 && spanDays >= 21 ? 'higher' : points.length >= 5 && spanDays >= 14 ? 'moderate' : 'low',
  };
}

export interface GoalPaceEstimate {
  remainingKg: number;
  requiredKgPerWeek: number | null;
  requiredKgPerDay: number | null;
  requiredPercentBodyWeightPerWeek: number | null;
  projectedTargetDateKey: string | null;
  estimatedWeeksToTarget: number | null;
  trendKgPerWeek: number | null;
  trendKgPerDay: number | null;
  paceStatus: 'on_track' | 'too_slow' | 'too_fast' | 'insufficient_data' | 'target_reached' | 'moving_away' | 'deadline_passed';
}

/** Compares a plan deadline with observed trend; never substitutes estimates for recorded values. */
export function calculateGoalPace(
  currentWeightKg: number,
  targetWeightKg: number,
  deadlineDateKey: string,
  anchorDateKey: string,
  trend: WeightTrendEstimate | null,
): GoalPaceEstimate {
  const remainingKg = Number((targetWeightKg - currentWeightKg).toFixed(2));
  const daysLeft = isValidMeasurementDateKey(deadlineDateKey) && isValidMeasurementDateKey(anchorDateKey)
    ? Math.round((Date.parse(`${deadlineDateKey}T00:00:00Z`) - Date.parse(`${anchorDateKey}T00:00:00Z`)) / 86_400_000)
    : 0;
  const requiredKgPerWeek = daysLeft > 0 ? remainingKg / (daysLeft / 7) : null;
  const requiredKgPerDay = requiredKgPerWeek === null ? null : Number((requiredKgPerWeek / 7).toFixed(4));
  const requiredPercentBodyWeightPerWeek = requiredKgPerWeek !== null && currentWeightKg > 0
    ? (Math.abs(requiredKgPerWeek) / currentWeightKg) * 100
    : null;
  const observed = trend?.changePerWeekKg ?? null;
  const projectedDirection = Math.sign(remainingKg);
  const movingAway = observed !== null && Math.abs(remainingKg) > 0.05 && observed * projectedDirection < -0.03;
  const rateAligned = observed !== null && requiredKgPerWeek !== null && observed * projectedDirection > 0;
  const tolerance = requiredKgPerWeek === null ? 0 : Math.max(0.03, Math.abs(requiredKgPerWeek) * 0.25);
  const paceStatus: GoalPaceEstimate['paceStatus'] = Math.abs(remainingKg) <= 0.05
    ? 'target_reached'
    : daysLeft <= 0 ? 'deadline_passed'
    : !trend || trend.confidence === 'low' || observed === null
      ? 'insufficient_data'
      : movingAway ? 'moving_away'
        : !rateAligned ? 'too_slow'
          : Math.abs(observed) > Math.abs(requiredKgPerWeek ?? 0) + tolerance ? 'too_fast'
            : Math.abs(observed) + tolerance < Math.abs(requiredKgPerWeek ?? 0) ? 'too_slow' : 'on_track';
  const weeks = observed !== null && Math.abs(observed) >= 0.02 && observed * projectedDirection > 0
    ? Math.abs(remainingKg / observed)
    : null;
  let projectedTargetDateKey: string | null = null;
  if (weeks !== null && Number.isFinite(weeks) && weeks < 520) {
    const date = new Date(Date.parse(`${anchorDateKey}T00:00:00Z`) + Math.round(weeks * 7) * 86_400_000);
    projectedTargetDateKey = date.toISOString().slice(0, 10);
  }
  return {
    remainingKg,
    requiredKgPerWeek: requiredKgPerWeek === null ? null : Number(requiredKgPerWeek.toFixed(3)),
    requiredKgPerDay,
    requiredPercentBodyWeightPerWeek: requiredPercentBodyWeightPerWeek === null ? null : Number(requiredPercentBodyWeightPerWeek.toFixed(3)),
    projectedTargetDateKey,
    estimatedWeeksToTarget: weeks === null ? null : Number(weeks.toFixed(1)),
    trendKgPerWeek: observed,
    trendKgPerDay: observed === null ? null : Number((observed / 7).toFixed(4)),
    paceStatus,
  };
}
