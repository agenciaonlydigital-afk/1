import assert from 'node:assert/strict';
import { calculateWeightTrend, calculateGoalPace, computeCumulativeComparison, computeLatestObservedDeltas, sortMeasurementsChronologically } from '../domain/rules/evolution-metrics.ts';
const records = [
  { id: 'late', dateKey: '2026-11-21', dateLabel: '21 NOV', weightKg: 79.1, waistCm: 80, armCm: 38, thighCm: 59 },
  { id: 'bad', dateKey: '2026-02-30', dateLabel: 'BAD', weightKg: 77, waistCm: 80, armCm: 38, thighCm: 59 },
  { id: 'early', dateKey: '2026-11-07', dateLabel: '07 NOV', weightKg: 78.6, waistCm: 80, armCm: 38, thighCm: 59 },
  { id: 'mid', dateKey: '2026-11-14', dateLabel: '14 NOV', weightKg: 78.9, waistCm: 80, armCm: 38, thighCm: 59 },
];
assert.deepEqual(sortMeasurementsChronologically(records).map((record) => record.id), ['early', 'mid', 'late', 'bad']);
const trend = calculateWeightTrend(records, 30);
assert.ok(trend);
assert.equal(trend.sampleCount, 3);
assert.equal(trend.firstDateKey, '2026-11-07');
assert.equal(trend.lastDateKey, '2026-11-21');
assert.ok(trend.changePerWeekKg > 0);
assert.equal(calculateWeightTrend([records[0]], 30), null);
assert.throws(() => calculateWeightTrend(records, 4), /7 e 365/);
console.log('PASS calculation engine evolution: chronological records and date-validated trend');

// Duplicate same-day readings are collapsed to a median; Theil-Sen resists outliers.
const robust = calculateWeightTrend([
  ...records,
  { ...records[0], id: 'same-day-low', weightKg: 70 },
  { ...records[0], id: 'same-day-high', weightKg: 90 },
  { ...records[0], id: 'same-day-center', weightKg: 78.7 },
], 30);
assert.ok(robust);
assert.equal(robust.uniqueDays, 3);
assert.equal(robust.method, 'theil_sen_daily_median');
assert.ok(Math.abs(robust.changePerWeekKg) < 0.5);
const pace = calculateGoalPace(79.1, 82, '2027-02-20', '2026-11-23', trend);
assert.ok(pace.requiredKgPerWeek > 0);
assert.equal(pace.remainingKg, 2.9);
assert.ok(['on_track', 'too_slow', 'too_fast', 'insufficient_data', 'moving_away'].includes(pace.paceStatus));
console.log('PASS robust trend, same-day aggregation and target-pace projection');

// Daily weight-only records are valid; circumference trends remain unavailable until measured.
const weightOnly = [
  { id: 'wo1', dateKey: '2026-10-01', dateLabel: '01 OUT', weightKg: 80 },
  { id: 'wo2', dateKey: '2026-10-08', dateLabel: '08 OUT', weightKg: 79.7 },
  { id: 'wo3', dateKey: '2026-10-15', dateLabel: '15 OUT', weightKg: 79.4 },
];
assert.ok(calculateWeightTrend(weightOnly, 30));
const weightOnlySummary = computeCumulativeComparison(weightOnly, 75);
assert.equal(weightOnlySummary.waistDiffCm, null);
assert.equal(weightOnlySummary.armDiffCm, null);
assert.equal(weightOnlySummary.thighDiffCm, null);
console.log('PASS independent daily weight entries and optional body measurements');

const independentMeasures = computeLatestObservedDeltas([
  { id: 'i1', dateKey: '2026-10-01', dateLabel: '01 OUT', weightKg: 80, waistCm: 80, armCm: 38, thighCm: 59 },
  { id: 'i2', dateKey: '2026-10-08', dateLabel: '08 OUT', weightKg: 79.5, armCm: 38.5 },
  { id: 'i3', dateKey: '2026-10-15', dateLabel: '15 OUT', weightKg: 79, waistCm: 79.5, thighCm: 58.5 },
]);
assert.equal(independentMeasures.weightDelta, '-0.5');
assert.equal(independentMeasures.waistDelta, '-0.5');
assert.equal(independentMeasures.armDelta, '0.5');
assert.equal(independentMeasures.thighDelta, '-0.5');
assert.equal(computeLatestObservedDeltas(weightOnly).waistDelta, '—');
console.log('PASS independent latest-observation deltas for each body measurement');
