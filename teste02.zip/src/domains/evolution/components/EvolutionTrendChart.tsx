import { useMemo, useState } from 'react';
import { Surface } from '@/src/shared/ui/Surface';
import type { BodyMeasurementRecord } from '@/src/shared/types/body-measurement';
import {
  buildEvolutionTrendSeries,
  EVOLUTION_CHART_HEIGHT as HEIGHT,
  EVOLUTION_CHART_PLOT as PLOT,
  EVOLUTION_CHART_WIDTH as WIDTH,
  type EvolutionChartMetric,
} from '../domain/rules/evolution-chart';

type MeasurementKey = EvolutionChartMetric;

const METRICS: Array<{ key: MeasurementKey; label: string; unit: string }> = [
  { key: 'weightKg', label: 'Peso', unit: 'kg' },
  { key: 'waistCm', label: 'Cintura', unit: 'cm' },
  { key: 'armCm', label: 'Braço', unit: 'cm' },
  { key: 'thighCm', label: 'Coxa', unit: 'cm' },
];

function fmt(value: number): string {
  return value.toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 });
}

export function EvolutionTrendChart({ records }: { records: BodyMeasurementRecord[] }) {
  const [metricKey, setMetricKey] = useState<MeasurementKey>('weightKg');
  const metric = METRICS.find((item) => item.key === metricKey) ?? METRICS[0]!;

  const chart = useMemo(
    () => buildEvolutionTrendSeries(records, metricKey),
    [records, metricKey],
  );

  if (records.length === 0 || chart.points.length === 0) {
    return (
      <Surface className="p-5 space-y-2">
        <h2 className="text-lg font-semibold text-[var(--titan-text-primary)]">Evolução observada</h2>
        <p className="text-sm text-[var(--titan-text-muted)]">Registre {metric.label.toLowerCase()} para construir este histórico.</p>
      </Surface>
    );
  }

  const first = chart.points[0];
  const last = chart.points[chart.points.length - 1];
  const delta = first && last ? last.value - first.value : 0;
  const dateLabelIndexes = new Set(
    chart.points.length <= 5
      ? chart.points.map((_, index) => index)
      : [0, Math.floor((chart.points.length - 1) / 2), chart.points.length - 1],
  );

  return (
    <Surface className="p-4 sm:p-5 space-y-3">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="titan-eyebrow">Série histórica</p>
          <h2 className="mt-1 text-lg font-semibold text-[var(--titan-text-primary)]">Evolução observada</h2>
          <p className="mt-0.5 text-xs text-[var(--titan-text-muted)]">Somente medições registradas · sem estimativas ou projeções</p>
        </div>
        <div className="text-right">
          <div className="font-display text-2xl font-semibold tracking-tight text-[var(--titan-text-primary)] tabular-nums">
            {last ? `${fmt(last.value)} ${metric.unit}` : '—'}
          </div>
          <div className="text-xs text-[var(--titan-text-muted)]">
            {chart.points.length > 1 ? `${delta > 0 ? '+' : ''}${fmt(delta)} ${metric.unit} desde o primeiro registro desta métrica` : 'Primeiro registro desta métrica'}
          </div>
        </div>
      </div>

      <div className="titan-segmented w-full sm:w-auto" role="group" aria-label="Métrica exibida no gráfico">
        {METRICS.map((item) => (
          <button
            key={item.key}
            type="button"
            className="titan-segment flex-1 sm:flex-none"
            aria-pressed={metricKey === item.key}
            onClick={() => setMetricKey(item.key)}
          >
            {item.label}
          </button>
        ))}
      </div>

      <div className="titan-chart-wrap">
        <svg
          className="titan-chart-svg"
          viewBox={`0 0 ${WIDTH} ${HEIGHT}`}
          role="img"
          aria-label={`Histórico de ${metric.label.toLowerCase()}: ${chart.points.map((point) => `${point.date}, ${fmt(point.value)} ${metric.unit}`).join('; ')}`}
        >
          <defs>
            <linearGradient id="titan-evolution-area" x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor="var(--titan-accent)" stopOpacity="0.20" />
              <stop offset="100%" stopColor="var(--titan-accent)" stopOpacity="0.01" />
            </linearGradient>
          </defs>
          {[0, 0.5, 1].map((ratio) => {
            const y = PLOT.top + ratio * chart.plotHeight;
            const value = chart.max - ratio * (chart.max - chart.min);
            return (
              <g key={ratio}>
                <line className="titan-chart-gridline" x1={PLOT.left} x2={WIDTH - PLOT.right} y1={y} y2={y} />
                <text className="titan-chart-label" x={PLOT.left - 10} y={y + 4} textAnchor="end">{fmt(value)}</text>
              </g>
            );
          })}
          {chart.area && <path d={chart.area} fill="url(#titan-evolution-area)" />}
          {chart.line && <path d={chart.line} className="titan-chart-line" />}
          {chart.points.map((point, index) => (
            <g key={point.id}>
              <circle className="titan-chart-point" cx={point.x} cy={point.y} r="5" />
              {dateLabelIndexes.has(index) && (
                <text className="titan-chart-label" x={point.x} y={HEIGHT - 13} textAnchor="middle">{point.date}</text>
              )}
            </g>
          ))}
        </svg>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2 border-t border-[var(--titan-border-subtle)] pt-3 text-xs text-[var(--titan-text-muted)]">
        <span>{chart.points.length} {chart.points.length === 1 ? 'medição nesta métrica' : 'medições nesta métrica'}</span>
        <span>Intervalo: {fmt(chart.actualMin)}–{fmt(chart.actualMax)} {metric.unit}</span>
      </div>
      <ul className="sr-only">
        {chart.points.map((point) => <li key={point.id}>{point.date}: {fmt(point.value)} {metric.unit}</li>)}
      </ul>
    </Surface>
  );
}
