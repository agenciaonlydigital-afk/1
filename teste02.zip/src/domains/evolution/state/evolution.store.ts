import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { safeStorageAdapter } from '@/src/infrastructure/storage/local-storage';
import { getLocalDateKey, isValidLocalDateKey } from '@/src/shared/utils/local-date';
import { mergeEvolutionPersistedState, type PersistedEvolutionState } from './evolution-persistence';
import type { BodyMeasurementRecord } from '@/src/shared/types/body-measurement';

export type { BodyMeasurementRecord } from '@/src/shared/types/body-measurement';
import {
  measurementEntrySchema,
  type MeasurementEntryInput,
} from '../schemas/measurement.schema';

function formatDateLabel(dateKey: string): string {
  const [year, month, day] = dateKey.split('-').map(Number);
  return new Intl.DateTimeFormat('pt-BR', { day: '2-digit', month: 'short' })
    .format(new Date(year!, month! - 1, day!, 12))
    .replace('.', '')
    .toUpperCase();
}

interface EvolutionState {
  records: BodyMeasurementRecord[];
  logMeasurement: (
    entry: MeasurementEntryInput,
    dateKey?: string,
  ) => { ok: true } | { ok: false; error: string };
}

export const useEvolutionStore = create<EvolutionState>()(persist<EvolutionState, [], [], PersistedEvolutionState>((set) => ({
  records: [],
  logMeasurement: (entry, dateKey = getLocalDateKey()) => {
    if (!isValidLocalDateKey(dateKey)) return { ok: false, error: 'Data da medição inválida.' };
    const parsed = measurementEntrySchema.safeParse(entry);
    if (!parsed.success) {
      return { ok: false, error: parsed.error.issues[0]?.message ?? 'Medida inválida' };
    }
    set((state) => ({
      records: [
        ...state.records,
        {
          id: `m-${dateKey}-${Date.now()}`,
          dateKey,
          dateLabel: formatDateLabel(dateKey),
          ...parsed.data,
        },
      ],
    }));
    return { ok: true };
  },
}), {
  name: 'titan:evolution:v1',
  version: 1,
  storage: createJSONStorage(() => safeStorageAdapter),
  partialize: (state) => ({ records: state.records }),
  migrate: (persisted) => mergeEvolutionPersistedState(persisted, { records: [] }),
  merge: (persisted, current) => ({
    ...current,
    ...mergeEvolutionPersistedState(persisted, current),
  }),
}));
