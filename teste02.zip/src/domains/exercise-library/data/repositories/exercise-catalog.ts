import type { ExerciseLibraryItem } from '../../domain/entities/exercise-item';
import { EXERCISE_CATALOG_ADDITIONS } from './exercise-catalog-additions.ts';
import { EXERCISE_CATALOG_GUIDES } from './exercise-catalog-guides.ts';

const BASE_EXERCISE_CATALOG: readonly ExerciseLibraryItem[] = [
  {
    slug: 'supino-reto',
    name: 'Supino reto',
    equipment: 'Barra olímpica',
    pattern: 'Empurrar horizontal',
    muscles: { primary: ['pectoralis', 'anterior_deltoid'], secondary: ['triceps'] },
    cue: 'Escápulas estáveis no banco, pés apoiados e descida controlada.',
  },
  {
    slug: 'crucifixo',
    name: 'Crucifixo',
    equipment: 'Polia / Halteres',
    pattern: 'Adução horizontal do ombro',
    muscles: { primary: ['pectoralis'], secondary: ['anterior_deltoid'] },
    cue: 'Mantenha uma flexão leve dos cotovelos e controle a amplitude sem perder a estabilidade dos ombros.',
  },
  {
    slug: 'desenvolvimento',
    name: 'Desenvolvimento',
    equipment: 'Halteres',
    pattern: 'Empurrar vertical',
    muscles: { primary: ['anterior_deltoid', 'lateral_deltoid'], secondary: ['triceps', 'trapezius'] },
    cue: 'Tronco firme, punhos alinhados e subida controlada sem compensar com a lombar.',
  },
  {
    slug: 'triceps-corda',
    name: 'Tríceps corda',
    equipment: 'Polia alta',
    pattern: 'Extensão de cotovelo',
    muscles: { primary: ['triceps'], secondary: ['forearms'] },
    cue: 'Mantenha os cotovelos próximos ao tronco e estenda sem movimentar os ombros.',
  },
  {
    slug: 'supino-inclinado',
    name: 'Supino inclinado',
    equipment: 'Halteres',
    pattern: 'Empurrar horizontal',
    muscles: { primary: ['pectoralis', 'anterior_deltoid'], secondary: ['triceps'] },
    cue: 'Banco a 30°, escápulas estabilizadas e controle na descida.',
  },
  {
    slug: 'remada-curvada',
    name: 'Remada curvada',
    equipment: 'Barra olímpica',
    pattern: 'Puxar horizontal',
    muscles: { primary: ['latissimus', 'trapezius'], secondary: ['posterior_deltoid', 'biceps'] },
    cue: 'Tronco firme, puxe a barra em direção ao umbigo.',
  },
  {
    slug: 'elevacao-lateral',
    name: 'Elevação lateral',
    equipment: 'Halteres',
    pattern: 'Abdução de ombro',
    muscles: { primary: ['lateral_deltoid'], secondary: ['trapezius'] },
    cue: 'Cotovelos levemente flexionados, suba até a linha dos ombros.',
  },
  {
    slug: 'triceps-frances',
    name: 'Tríceps francês',
    equipment: 'Polia',
    pattern: 'Extensão de cotovelo',
    muscles: { primary: ['triceps'], secondary: ['anterior_deltoid'] },
    cue: 'Braços fixos ao lado da cabeça com extensão completa.',
  },
  {
    slug: 'agachamento-livre',
    name: 'Agachamento livre',
    equipment: 'Barra olímpica',
    pattern: 'Dominante de joelho',
    muscles: { primary: ['quadriceps', 'glutes'], secondary: ['hamstrings', 'abdominals', 'calves'] },
    cue: 'Joelhos alinhados à ponta dos pés e coluna neutra.',
  },
  {
    slug: 'stiff-romeno',
    name: 'Stiff romeno',
    equipment: 'Barra olímpica',
    pattern: 'Dominante de quadril',
    muscles: { primary: ['hamstrings', 'glutes'], secondary: ['forearms', 'latissimus'] },
    cue: 'Desloque o quadril para trás mantendo a barra rente às pernas.',
  },

  {
    slug: 'rosca-direta-barra',
    name: 'Rosca direta com barra',
    equipment: 'Barra olímpica',
    pattern: 'Flexão de cotovelo',
    muscles: { primary: ['biceps'], secondary: ['forearms'] },
    cue: 'Mantenha os cotovelos junto ao tronco e mova o antebraço sem embalar o corpo.',
    source: { repository: 'yuhonas/free-exercise-db', recordId: 'Barbell_Curl', license: 'Unlicense', recordUrl: 'https://github.com/yuhonas/free-exercise-db/blob/main/exercises/Barbell_Curl.json', recordBlobSha: '8025c7a821da34bd63c9f887d5e58eff85f0eb66' },
  },
  {
    slug: 'remada-deltoide-posterior',
    name: 'Remada para deltoide posterior',
    equipment: 'Barra olímpica',
    pattern: 'Abdução horizontal do ombro',
    muscles: { primary: ['posterior_deltoid'], secondary: ['biceps', 'latissimus'] },
    cue: 'Incline o tronco com coluna neutra, abra os cotovelos e conduza a barra em direção ao peito alto.',
    source: { repository: 'yuhonas/free-exercise-db', recordId: 'Barbell_Rear_Delt_Row', license: 'Unlicense', recordUrl: 'https://github.com/yuhonas/free-exercise-db/blob/main/exercises/Barbell_Rear_Delt_Row.json', recordBlobSha: 'ef1c6332865b8765073ce335c6769eae409c8712' },
  },
  {
    slug: 'encolhimento-barra',
    name: 'Encolhimento com barra',
    equipment: 'Barra olímpica',
    pattern: 'Elevação escapular',
    muscles: { primary: ['trapezius'], secondary: [] },
    cue: 'Eleve os ombros verticalmente, pause no topo e evite transformar o movimento em uma rotação.',
    source: { repository: 'yuhonas/free-exercise-db', recordId: 'Barbell_Shrug', license: 'Unlicense', recordUrl: 'https://github.com/yuhonas/free-exercise-db/blob/main/exercises/Barbell_Shrug.json', recordBlobSha: '4dd9077ce17ceeb99b15495a9dd31874a979fbfd' },
  },
  {
    slug: 'hip-thrust-barra',
    name: 'Elevação pélvica com barra',
    equipment: 'Barra olímpica e banco',
    pattern: 'Extensão de quadril',
    muscles: { primary: ['glutes'], secondary: ['hamstrings', 'calves'] },
    cue: 'Apoie as escápulas no banco, mantenha o queixo recolhido e estenda o quadril sem hiperestender a lombar.',
    source: { repository: 'yuhonas/free-exercise-db', recordId: 'Barbell_Hip_Thrust', license: 'Unlicense', recordUrl: 'https://github.com/yuhonas/free-exercise-db/blob/main/exercises/Barbell_Hip_Thrust.json', recordBlobSha: '35ec313a5cb0fa388643700c48018ae83860f4dd' },
  },
  {
    slug: 'flexora-deitada',
    name: 'Flexora deitada',
    equipment: 'Máquina',
    pattern: 'Flexão de joelho',
    muscles: { primary: ['hamstrings'], secondary: [] },
    cue: 'Mantenha o quadril apoiado, flexione os joelhos sob controle e retorne sem soltar a carga.',
    source: { repository: 'yuhonas/free-exercise-db', recordId: 'Lying_Leg_Curls', license: 'Unlicense', recordUrl: 'https://github.com/yuhonas/free-exercise-db/blob/main/exercises/Lying_Leg_Curls.json', recordBlobSha: '703e394cc72748f8b07940d703a2b6372100239c' },
  },
  {
    slug: 'extensora-unilateral',
    name: 'Cadeira extensora unilateral',
    equipment: 'Máquina',
    pattern: 'Extensão de joelho',
    muscles: { primary: ['quadriceps'], secondary: [] },
    cue: 'Alinhe o eixo da máquina ao joelho e estenda uma perna por vez sem impulso.',
    source: { repository: 'yuhonas/free-exercise-db', recordId: 'Single-Leg_Leg_Extension', license: 'Unlicense', recordUrl: 'https://github.com/yuhonas/free-exercise-db/blob/main/exercises/Single-Leg_Leg_Extension.json', recordBlobSha: 'fcafab105215c710aad6a28258e07d56ff01c8ca' },
  },
  {
    slug: 'panturrilha-sentada-barra',
    name: 'Panturrilha sentada com barra',
    equipment: 'Barra olímpica e banco',
    pattern: 'Flexão plantar',
    muscles: { primary: ['calves'], secondary: [] },
    cue: 'Apoie a região anterior dos pés, desça o calcanhar com controle e suba até a contração máxima confortável.',
    source: { repository: 'yuhonas/free-exercise-db', recordId: 'Barbell_Seated_Calf_Raise', license: 'Unlicense', recordUrl: 'https://github.com/yuhonas/free-exercise-db/blob/main/exercises/Barbell_Seated_Calf_Raise.json', recordBlobSha: '043cdd65893107367511f1cc6418bbe3c4c800a4' },
  },
];

const ENRICHED_BASE_CATALOG = BASE_EXERCISE_CATALOG.map((exercise): ExerciseLibraryItem => {
  const guide = EXERCISE_CATALOG_GUIDES[exercise.slug];
  if (!guide) return exercise;
  const { sources: guideSources, ...guideFields } = guide;
  const existingSources = exercise.sources ?? [];
  return {
    ...exercise,
    ...guideFields,
    sources: [...existingSources, ...(guideSources ?? [])],
  };
});

export const EXERCISE_CATALOG: readonly ExerciseLibraryItem[] = [
  ...ENRICHED_BASE_CATALOG,
  ...EXERCISE_CATALOG_ADDITIONS,
];

export function getExerciseBySlug(slug: string): ExerciseLibraryItem | undefined {
  return EXERCISE_CATALOG.find((exercise) => exercise.slug === slug);
}
