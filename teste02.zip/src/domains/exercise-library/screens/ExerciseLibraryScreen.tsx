import { useDeferredValue, useMemo, useState } from 'react';
import { ArrowLeft, Search, SlidersHorizontal, ChevronDown, ChevronUp, Dumbbell } from 'lucide-react';
import type { ExerciseCategory, ExerciseLevel, ExerciseMechanic } from '../domain/entities/exercise-item';
import type { MuscleGroupId } from '@/src/shared/types/common';
import { setWorkoutMuscleHighlights } from '@/src/domains/anatomy/application/anatomy-public';
import { MUSCLE_REGISTRY } from '@/src/domains/anatomy/mapping/muscle-registry';
import { ExerciseRegistry } from '../application/exercise-library-public';
import { EXERCISE_DATA_SOURCES } from '../data/repositories/exercise-source-registry';
import { listExerciseFilterOptions } from '../application/filter-exercises';
import type { ExerciseCatalogFilters } from '../application/filter-exercises';
import { Surface } from '@/src/shared/ui/Surface';

interface ExerciseLibraryScreenProps {
  onBack: () => void;
  onInspectIn3D?: () => void;
  muscleFilter?: MuscleGroupId | 'all';
  onMuscleFilterChange?: (muscle: MuscleGroupId | 'all') => void;
}

const LEVEL_LABELS: Record<ExerciseLevel, string> = {
  beginner: 'Iniciante',
  intermediate: 'Intermediário',
  advanced: 'Avançado',
};

const CATEGORY_LABELS: Record<ExerciseCategory, string> = {
  strength: 'Força',
  core: 'Core',
  mobility: 'Mobilidade',
  cardio: 'Cardio',
};

const MECHANIC_LABELS: Record<ExerciseMechanic, string> = {
  compound: 'Multiarticular',
  isolation: 'Isolador',
  isometric: 'Isométrico',
  mobility: 'Mobilidade',
};

const selectClass = 'titan-input min-h-[42px] px-3 text-xs';

function RelatedExercises({ slugs, label }: { slugs: readonly string[]; label: string }) {
  if (slugs.length === 0) return null;
  const names = slugs.map((slug) => ExerciseRegistry.find(slug)?.name).filter((name): name is string => Boolean(name));
  if (names.length === 0) return null;
  return (
    <div>
      <span className="block text-[9px] uppercase tracking-[0.12em] text-[var(--titan-text-muted)] mb-1">{label}</span>
      <div className="flex flex-wrap gap-1.5">
        {names.map((name) => (
          <span key={name} className="rounded-lg px-2 py-1 text-[11px] bg-[var(--titan-surface-raised)] border border-[var(--titan-border)] text-[var(--titan-text-secondary)]">{name}</span>
        ))}
      </div>
    </div>
  );
}

export function ExerciseLibraryScreen({
  onBack,
  onInspectIn3D,
  muscleFilter: controlledMuscleFilter,
  onMuscleFilterChange,
}: ExerciseLibraryScreenProps) {
  const [query, setQuery] = useState('');
  const [internalMuscleFilter, setInternalMuscleFilter] = useState<MuscleGroupId | 'all'>(
    controlledMuscleFilter ?? 'all',
  );
  const muscleFilter = controlledMuscleFilter ?? internalMuscleFilter;
  const setMuscleFilter = (nextMuscle: MuscleGroupId | 'all') => {
    if (onMuscleFilterChange) {
      onMuscleFilterChange(nextMuscle);
    } else {
      setInternalMuscleFilter(nextMuscle);
    }
  };
  const [equipmentFilter, setEquipmentFilter] = useState('all');
  const [levelFilter, setLevelFilter] = useState<ExerciseLevel | 'all'>('all');
  const [categoryFilter, setCategoryFilter] = useState<ExerciseCategory | 'all'>('all');
  const [mechanicFilter, setMechanicFilter] = useState<ExerciseMechanic | 'all'>('all');
  const [showFilters, setShowFilters] = useState(
    Boolean(controlledMuscleFilter && controlledMuscleFilter !== 'all'),
  );
  const [expandedExerciseSlug, setExpandedExerciseSlug] = useState<string | null>(null);

  const deferredQuery = useDeferredValue(query);
  const filterOptions = useMemo(() => listExerciseFilterOptions(), []);
  const filters: ExerciseCatalogFilters = {
    muscle: muscleFilter,
    equipment: equipmentFilter,
    level: levelFilter,
    category: categoryFilter,
    mechanic: mechanicFilter,
  };
  const filtered = useMemo(
    () => ExerciseRegistry.search(deferredQuery, filters),
    [deferredQuery, muscleFilter, equipmentFilter, levelFilter, categoryFilter, mechanicFilter],
  );

  const activeFilterCount = [muscleFilter, equipmentFilter, levelFilter, categoryFilter, mechanicFilter]
    .filter((value) => value !== 'all').length;
  const clearFilters = () => {
    setMuscleFilter('all');
    setEquipmentFilter('all');
    setLevelFilter('all');
    setCategoryFilter('all');
    setMechanicFilter('all');
    setQuery('');
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-2.5">
        <button
          type="button"
          onClick={onBack}
          aria-label="Voltar"
          className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl bg-[var(--titan-surface)] border border-[var(--titan-border)] text-[var(--titan-text-primary)]"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div className="titan-page-heading titan-page-heading--compact mb-0">
          <p className="titan-eyebrow">Movimento e anatomia</p>
          <h1 className="text-xl font-semibold text-[var(--titan-text-primary)]">Biblioteca de Exercícios</h1>
          <p className="text-xs text-[var(--titan-text-secondary)]">
            Catálogo técnico · Guias de execução · Músculos no holograma 3D
          </p>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-2">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-[var(--titan-text-muted)] absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Buscar exercício, músculo, equipamento, instrução..."
            aria-label="Buscar exercício"
            className="titan-input pl-10 pr-4"
          />
        </div>
        <button
          type="button"
          onClick={() => setShowFilters((value) => !value)}
          aria-expanded={showFilters}
          className="min-h-[44px] px-3 rounded-xl bg-[var(--titan-surface)] border border-[var(--titan-border)] text-xs font-medium text-[var(--titan-text-primary)] flex items-center justify-center gap-2"
        >
          <SlidersHorizontal className="w-4 h-4" />
          Filtros{activeFilterCount ? ` (${activeFilterCount})` : ''}
          {showFilters ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
        </button>
      </div>

      {showFilters && (
        <Surface className="p-3 sm:p-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
            <label className="space-y-1">
              <span className="text-[10px] uppercase tracking-wider text-[var(--titan-text-muted)]">Músculo</span>
              <select aria-label="Filtrar por músculo" value={muscleFilter} onChange={(event) => setMuscleFilter(event.target.value as MuscleGroupId | 'all')} className={selectClass}>
                <option value="all">Todos</option>
                {Object.values(MUSCLE_REGISTRY).map((muscle) => <option key={muscle.id} value={muscle.id}>{muscle.label}</option>)}
              </select>
            </label>
            <label className="space-y-1">
              <span className="text-[10px] uppercase tracking-wider text-[var(--titan-text-muted)]">Equipamento</span>
              <select aria-label="Filtrar por equipamento" value={equipmentFilter} onChange={(event) => setEquipmentFilter(event.target.value)} className={selectClass}>
                <option value="all">Todos</option>
                {filterOptions.equipment.map((equipment) => <option key={equipment} value={equipment}>{equipment}</option>)}
              </select>
            </label>
            <label className="space-y-1">
              <span className="text-[10px] uppercase tracking-wider text-[var(--titan-text-muted)]">Nível</span>
              <select aria-label="Filtrar por nível" value={levelFilter} onChange={(event) => setLevelFilter(event.target.value as ExerciseLevel | 'all')} className={selectClass}>
                <option value="all">Todos</option>
                {filterOptions.levels.map((level) => <option key={level} value={level}>{LEVEL_LABELS[level]}</option>)}
              </select>
            </label>
            <label className="space-y-1">
              <span className="text-[10px] uppercase tracking-wider text-[var(--titan-text-muted)]">Categoria</span>
              <select aria-label="Filtrar por categoria" value={categoryFilter} onChange={(event) => setCategoryFilter(event.target.value as ExerciseCategory | 'all')} className={selectClass}>
                <option value="all">Todas</option>
                {filterOptions.categories.map((category) => <option key={category} value={category}>{CATEGORY_LABELS[category]}</option>)}
              </select>
            </label>
            <label className="space-y-1">
              <span className="text-[10px] uppercase tracking-wider text-[var(--titan-text-muted)]">Mecânica</span>
              <select aria-label="Filtrar por mecânica" value={mechanicFilter} onChange={(event) => setMechanicFilter(event.target.value as ExerciseMechanic | 'all')} className={selectClass}>
                <option value="all">Todas</option>
                {filterOptions.mechanics.map((mechanic) => <option key={mechanic} value={mechanic}>{MECHANIC_LABELS[mechanic]}</option>)}
              </select>
            </label>
          </div>
          <div className="flex justify-end mt-3">
            <button type="button" onClick={clearFilters} className="min-h-[36px] px-3 rounded-lg text-xs text-[var(--titan-text-secondary)] border border-[var(--titan-border)]">Limpar busca e filtros</button>
          </div>
        </Surface>
      )}

      <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[var(--titan-text-secondary)]">
        <span>{filtered.length} de {ExerciseRegistry.list().length} exercícios</span>
        <div className="flex items-center gap-3">
          {muscleFilter !== 'all' && (
            <button
              type="button"
              onClick={() => setMuscleFilter('all')}
              className="text-xs font-medium text-[var(--titan-accent)] hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70 rounded"
            >
              Músculo: {MUSCLE_REGISTRY[muscleFilter].label} · Limpar
            </button>
          )}
          <span className="flex items-center gap-1.5"><Dumbbell className="w-3.5 h-3.5" /> {activeFilterCount ? 'Filtros aplicados' : 'Catálogo unificado'}</span>
        </div>
      </div>

      {filtered.length === 0 ? (
        <Surface className="p-5 text-center">
          <p className="text-sm font-medium text-[var(--titan-text-primary)]">Nenhum exercício encontrado</p>
          <p className="text-xs text-[var(--titan-text-secondary)] mt-1">Tente outro termo ou remova algum filtro.</p>
          <button type="button" onClick={clearFilters} className="mt-3 min-h-[40px] px-3 rounded-xl bg-[var(--titan-surface-raised)] border border-[var(--titan-border)] text-xs text-[var(--titan-text-primary)]">Limpar filtros</button>
        </Surface>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {filtered.map((item) => {
            const isExpanded = expandedExerciseSlug === item.slug;
            const primaryNames = item.muscles.primary.map((id) => MUSCLE_REGISTRY[id].label);
            const secondaryNames = item.muscles.secondary.map((id) => MUSCLE_REGISTRY[id].label);
            const stabilizerNames = (item.stabilizers ?? []).map((id) => MUSCLE_REGISTRY[id].label);
            return (
              <Surface key={item.slug} className="p-4 flex flex-col gap-3 titan-virtual-card">
                <div>
                  <div className="flex flex-wrap gap-1.5 text-[10px] text-[var(--titan-text-muted)]">
                    <span>{item.equipment}</span><span>·</span><span>{item.pattern}</span>
                    {item.level && <><span>·</span><span>{LEVEL_LABELS[item.level]}</span></>}
                    {item.category && <><span>·</span><span>{CATEGORY_LABELS[item.category]}</span></>}
                  </div>
                  <h2 className="text-base font-semibold text-[var(--titan-text-primary)] mt-1">{item.name}</h2>
                  <p className="text-xs text-[var(--titan-text-secondary)] mt-1.5 leading-relaxed">{item.cue}</p>
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {item.mechanic && <span className="rounded-md px-2 py-1 text-[10px] bg-[var(--titan-surface-raised)] text-[var(--titan-text-secondary)]">{MECHANIC_LABELS[item.mechanic]}</span>}
                    {item.force && <span className="rounded-md px-2 py-1 text-[10px] bg-[var(--titan-surface-raised)] text-[var(--titan-text-secondary)]">{item.force === 'push' ? 'Empurrar' : item.force === 'pull' ? 'Puxar' : item.force === 'static' ? 'Estático' : 'Misto'}</span>}
                  </div>
                </div>

                <div className="pt-2 border-t border-[var(--titan-border)]/60 space-y-2">
                  <div>
                    <span className="block text-[9px] uppercase tracking-[0.12em] text-[var(--titan-text-muted)] mb-0.5">Principais</span>
                    <span className="text-xs text-[var(--titan-accent)]">{primaryNames.join(' · ')}</span>
                  </div>
                  {secondaryNames.length > 0 && (
                    <div>
                      <span className="block text-[9px] uppercase tracking-[0.12em] text-[var(--titan-text-muted)] mb-0.5">Secundários</span>
                      <span className="text-xs text-[var(--titan-text-secondary)]">{secondaryNames.join(' · ')}</span>
                    </div>
                  )}
                  {stabilizerNames.length > 0 && (
                    <div>
                      <span className="block text-[9px] uppercase tracking-[0.12em] text-[var(--titan-text-muted)] mb-0.5">Estabilizadores</span>
                      <span className="text-xs text-[var(--titan-text-secondary)]">{stabilizerNames.join(' · ')}</span>
                    </div>
                  )}
                </div>

                {isExpanded && (
                  <div className="pt-3 border-t border-[var(--titan-border)]/60 space-y-3">
                    {item.instructions && item.instructions.length > 0 && (
                      <div>
                        <h3 className="text-[10px] font-semibold uppercase tracking-[0.12em] text-[var(--titan-text-muted)] mb-1.5">Como executar</h3>
                        <ol className="list-decimal pl-4 space-y-1.5 text-xs leading-relaxed text-[var(--titan-text-secondary)]">
                          {item.instructions.map((step, index) => <li key={`${item.slug}-step-${index}`}>{step}</li>)}
                        </ol>
                      </div>
                    )}
                    {item.breathing && <p className="text-xs"><strong className="text-[var(--titan-text-primary)]">Respiração:</strong> <span className="text-[var(--titan-text-secondary)]">{item.breathing}</span></p>}
                    {item.tips && item.tips.length > 0 && (
                      <div>
                        <h3 className="text-[10px] font-semibold uppercase tracking-[0.12em] text-[var(--titan-text-muted)] mb-1">Dicas técnicas</h3>
                        <ul className="list-disc pl-4 space-y-1 text-xs text-[var(--titan-text-secondary)]">{item.tips.map((tip) => <li key={tip}>{tip}</li>)}</ul>
                      </div>
                    )}
                    {item.commonErrors && item.commonErrors.length > 0 && (
                      <div>
                        <h3 className="text-[10px] font-semibold uppercase tracking-[0.12em] text-[var(--titan-text-muted)] mb-1">Erros comuns</h3>
                        <ul className="list-disc pl-4 space-y-1 text-xs text-[var(--titan-text-secondary)]">{item.commonErrors.map((error) => <li key={error}>{error}</li>)}</ul>
                      </div>
                    )}
                    <RelatedExercises slugs={item.regressions ?? []} label="Regressões" />
                    <RelatedExercises slugs={item.progressions ?? []} label="Progressões" />
                    <RelatedExercises slugs={item.alternatives ?? []} label="Alternativas" />
                    {item.tempoGuidance && <p className="text-xs text-[var(--titan-text-secondary)]"><strong className="text-[var(--titan-text-primary)]">Ritmo:</strong> {item.tempoGuidance}</p>}
                    <div>
                      <h3 className="text-[10px] font-semibold uppercase tracking-[0.12em] text-[var(--titan-text-muted)] mb-1">Fonte e licença dos dados</h3>
                      {(item.source || item.sources?.length) ? (
                        <ul className="space-y-1 text-[11px] text-[var(--titan-text-secondary)]">
                          {[...(item.source ? [item.source] : []), ...(item.sources ?? [])].map((source) => (
                            <li key={`${source.repository}:${source.recordId}`}>
                              <a href={source.recordUrl} target="_blank" rel="noreferrer" className="underline underline-offset-2 hover:text-[var(--titan-text-primary)]">{source.repository} · {source.recordId}</a>
                              <span> · {source.license}</span>
                            </li>
                          ))}
                        </ul>
                      ) : <p className="text-[11px] text-[var(--titan-text-secondary)]">Ficha técnica original do TITAN.</p>}
                    </div>
                  </div>
                )}

                <div className="flex flex-wrap justify-between gap-2 mt-auto pt-1">
                  <button
                    type="button"
                    onClick={() => setExpandedExerciseSlug(isExpanded ? null : item.slug)}
                    aria-expanded={isExpanded}
                    className="min-h-[42px] px-3 rounded-xl bg-[var(--titan-surface-raised)] border border-[var(--titan-border)] text-xs font-medium text-[var(--titan-text-primary)] flex items-center gap-1.5"
                  >
                    {isExpanded ? 'Fechar guia' : 'Guia completo'}
                    {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setWorkoutMuscleHighlights(item.muscles);
                      onInspectIn3D?.();
                    }}
                    className="min-h-[42px] px-3 rounded-xl bg-[var(--titan-surface-raised)] border border-[var(--titan-border)] text-xs font-medium text-[var(--titan-text-primary)] whitespace-nowrap shrink-0 transition-colors hover:border-[var(--titan-champagne)]/45 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-focus)]/70"
                  >
                    Ver no 3D
                  </button>
                </div>
              </Surface>
            );
          })}
        </div>
      )}
      <details className="rounded-xl border border-[var(--titan-border)] bg-[var(--titan-surface)] p-3">
        <summary className="cursor-pointer text-xs font-medium text-[var(--titan-text-primary)]">Fontes do catálogo e política de licenças</summary>
        <div className="space-y-3 mt-3">
          {EXERCISE_DATA_SOURCES.map((source) => (
            <div key={source.id} className="border-t border-[var(--titan-border)]/60 pt-2 first:border-0 first:pt-0">
              <a href={source.url} target="_blank" rel="noreferrer" className="text-xs font-semibold text-[var(--titan-text-primary)] underline underline-offset-2">{source.id}</a>
              <p className="text-[10px] text-[var(--titan-text-muted)] mt-0.5">{source.starsAtReview.toLocaleString('pt-BR')} estrelas · {source.recordsAdvertised ? `${source.recordsAdvertised.toLocaleString('pt-BR')} registros anunciados` : 'API/plataforma'}</p>
              <p className="text-[11px] text-[var(--titan-text-secondary)] mt-1">Dados: {source.dataLicense}. Mídia: {source.mediaLicense}.</p>
            </div>
          ))}
        </div>
      </details>
      <p className="text-[10px] leading-relaxed text-[var(--titan-text-muted)]">
        Guias educacionais de execução. Ajuste carga e amplitude à sua capacidade e interrompa o exercício se surgir dor. A seleção muscular representa os grupos mapeados no modelo anatômico TITAN, não percentuais medidos de ativação. Imagens e GIFs de terceiros não são incorporados sem licença de mídia verificada.
      </p>
    </div>
  );
}
