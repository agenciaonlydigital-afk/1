import { memo, useEffect, useMemo, useRef, useState } from 'react';
import { ArrowRight } from 'lucide-react';
import {
  computeDailyMacroAndEnergyBreakdown,
  type MealConsumptionStatus,
  useNutritionStore,
} from '@/src/domains/nutrition/application/nutrition-public';
import {
  getSharedFluidEngine,
  interpolateRatio,
  prefersReducedMotion,
  type FluidDrawJob,
} from '@/src/shared/graphics/fluid-shader-engine';
import { motion, TITAN_DURATIONS, TITAN_EASE } from '@/src/shared/motion/titan-motion';
import { BottomSheet } from '@/src/shared/ui/BottomSheet';
import { formatKcal } from '@/src/shared/utils/formatters';

type MacroKey = 'carbs' | 'protein' | 'fat';

interface MetallicTheme {
  metalRgb: [number, number, number];
  highlightRgb: [number, number, number];
  fallbackColor: string;
}

const MACRO_METALS: Record<MacroKey, MetallicTheme> = {
  carbs: {
    metalRgb: [0.44, 0.68, 0.80],
    highlightRgb: [0.92, 0.97, 1.0],
    fallbackColor: '#91AFBE',
  },
  protein: {
    metalRgb: [0.46, 0.72, 0.62],
    highlightRgb: [0.93, 0.99, 0.96],
    fallbackColor: '#A0B7A8',
  },
  fat: {
    metalRgb: [0.66, 0.50, 0.37],
    highlightRgb: [0.95, 0.86, 0.77],
    fallbackColor: '#B89579',
  },
};

const MACRO_META: Record<MacroKey, { label: string; field: 'carbsG' | 'proteinG' | 'fatG'; color: string }> = {
  carbs: { label: 'Carboidratos', field: 'carbsG', color: MACRO_METALS.carbs.fallbackColor },
  protein: { label: 'Proteínas', field: 'proteinG', color: MACRO_METALS.protein.fallbackColor },
  fat: { label: 'Gorduras', field: 'fatG', color: MACRO_METALS.fat.fallbackColor },
};

const MACRO_TABS: MacroKey[] = ['carbs', 'protein', 'fat'];

const MEAL_STATUS_LABELS: Record<MealConsumptionStatus, string> = {
  planned: 'Planejada',
  consumed: 'Consumida',
  partial: 'Parcial',
  substituted: 'Substituída',
  skipped: 'Pulada',
};

const GAUGE_W = 116;
const GAUGE_H = 68;
const INTERPOLATION_TIME_CONSTANT_SECONDS = 0.14;
const MACRO_GRAMS_FORMATTER = new Intl.NumberFormat('pt-BR', { maximumFractionDigits: 0 });
const MACRO_FINE_GRAMS_FORMATTER = new Intl.NumberFormat('pt-BR', { maximumFractionDigits: 1 });

function formatMacroGrams(amount: number): string {
  if (amount > 0 && amount < 0.05) return '<0,1 g';
  const formatter = amount > 0 && amount < 10
    ? MACRO_FINE_GRAMS_FORMATTER
    : MACRO_GRAMS_FORMATTER;
  return `${formatter.format(amount)} g`;
}

interface MacroGaugeProps {
  label: string;
  consumedG: number;
  goalG: number;
  plannedRemainingG?: number;
  metal: MetallicTheme;
  isSelected: boolean;
  onSelect: () => void;
}

function drawMacroFallback(
  canvas: HTMLCanvasElement,
  ratio: number,
  color: string,
) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
  const pixelWidth = Math.round(GAUGE_W * dpr);
  const pixelHeight = Math.round(GAUGE_H * dpr);
  if (canvas.width !== pixelWidth) canvas.width = pixelWidth;
  if (canvas.height !== pixelHeight) canvas.height = pixelHeight;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, GAUGE_W, GAUGE_H);

  const cx = GAUGE_W * 0.5;
  const cy = 59;
  const radius = 45;
  ctx.lineCap = 'round';
  ctx.lineWidth = 10;
  ctx.strokeStyle = '#091013';
  ctx.beginPath();
  ctx.arc(cx, cy, radius, Math.PI, 0, false);
  ctx.stroke();

  if (ratio > 0) {
    const gradient = ctx.createLinearGradient(0, 10, 0, 54);
    gradient.addColorStop(0, '#F4F8F5');
    gradient.addColorStop(0.32, color);
    gradient.addColorStop(0.68, '#344D47');
    gradient.addColorStop(1, color);
    ctx.strokeStyle = gradient;
    ctx.beginPath();
    ctx.arc(cx, cy, radius, Math.PI, Math.PI * (1 + ratio), false);
    ctx.stroke();
  }
}

function MacroSemicircle({
  label,
  consumedG,
  goalG,
  plannedRemainingG = 0,
  metal,
  isSelected,
  onSelect,
}: MacroGaugeProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const safeConsumed = Number.isFinite(consumedG) ? Math.max(0, consumedG) : 0;
  const hasValidGoal = Number.isFinite(goalG) && goalG > 0;
  const safeGoal = hasValidGoal ? goalG : 1;
  const ratio = hasValidGoal
    ? Math.min(1, Math.max(0, safeConsumed / safeGoal))
    : 0;
  const percent = hasValidGoal ? Math.round((safeConsumed / safeGoal) * 100) : 0;
  const progressValue = Math.min(100, Math.max(0, percent));
  const remaining = hasValidGoal ? Math.max(0, safeGoal - safeConsumed) : 0;
  const excess = hasValidGoal ? Math.max(0, safeConsumed - safeGoal) : 0;

  const targetRatioRef = useRef(ratio);
  const currentRatioRef = useRef(ratio);
  const lastFrameAtRef = useRef(0);
  const metalRef = useRef(metal);
  const isVisibleRef = useRef(true);
  const providerRef = useRef<(() => FluidDrawJob | null) | null>(null);

  useEffect(() => {
    targetRatioRef.current = ratio;
    metalRef.current = metal;
    const engine = getSharedFluidEngine();

    if (
      typeof window !== 'undefined' &&
      prefersReducedMotion()
    ) {
      currentRatioRef.current = ratio;
      lastFrameAtRef.current = 0;
      if (providerRef.current) {
        const rendered = engine.renderSinglePass(providerRef.current);
        if (!rendered && canvasRef.current) {
          drawMacroFallback(canvasRef.current, ratio, metal.fallbackColor);
        }
      }
      return;
    }

    lastFrameAtRef.current = 0;
    if (providerRef.current) {
      const rendered = engine.renderSinglePass(providerRef.current);
      if (!rendered && canvasRef.current) {
        drawMacroFallback(canvasRef.current, ratio, metal.fallbackColor);
      }
    }
    engine.wake();
  }, [ratio, metal]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const engine = getSharedFluidEngine();

    const provider = (): FluidDrawJob | null => {
      const now = performance.now();
      const elapsed = lastFrameAtRef.current
        ? Math.min(0.05, Math.max(0, (now - lastFrameAtRef.current) / 1000))
        : 1 / 60;
      lastFrameAtRef.current = now;

      currentRatioRef.current = interpolateRatio(
        currentRatioRef.current,
        targetRatioRef.current,
        elapsed,
        INTERPOLATION_TIME_CONSTANT_SECONDS,
      );

      return {
        kind: 'metal',
        targetCanvas: canvas,
        width: GAUGE_W,
        height: GAUGE_H,
        fill: currentRatioRef.current,
        isAnimating: Math.abs(targetRatioRef.current - currentRatioRef.current) > 0.0005,
        metalColor: metalRef.current.metalRgb,
        metalHighlight: metalRef.current.highlightRgb,
        isVisible: isVisibleRef.current,
      };
    };
    providerRef.current = provider;

    const renderCurrent = () => {
      const rendered = engine.renderSinglePass(provider);
      if (!rendered) {
        drawMacroFallback(canvas, currentRatioRef.current, metalRef.current.fallbackColor);
      }
    };

    const intersectionObserver =
      typeof IntersectionObserver !== 'undefined'
        ? new IntersectionObserver(
            (entries) => {
              isVisibleRef.current = entries[0]?.isIntersecting ?? true;
              if (isVisibleRef.current) {
                renderCurrent();
                if (Math.abs(targetRatioRef.current - currentRatioRef.current) > 0.0005) {
                  engine.wake();
                }
              }
            },
            { threshold: 0.05 },
          )
        : null;
    intersectionObserver?.observe(canvas);

    renderCurrent();
    const unsubscribe = engine.subscribe(provider, true);
    const motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    const handleMotionPreference = (event: MediaQueryListEvent) => {
      if (event.matches) {
        currentRatioRef.current = targetRatioRef.current;
        lastFrameAtRef.current = 0;
        renderCurrent();
      } else if (Math.abs(targetRatioRef.current - currentRatioRef.current) > 0.0005) {
        lastFrameAtRef.current = 0;
        engine.wake();
      }
    };
    motionQuery.addEventListener('change', handleMotionPreference);

    return () => {
      providerRef.current = null;
      unsubscribe();
      intersectionObserver?.disconnect();
      motionQuery.removeEventListener('change', handleMotionPreference);
    };
  }, []);

  const valueText = hasValidGoal
    ? `${formatMacroGrams(safeConsumed)} de ${formatMacroGrams(safeGoal)}; ${percent}% da meta`
    : `${formatMacroGrams(safeConsumed)} consumidos; meta não definida`;

  return (
    <div
      className={`relative rounded-2xl px-1 py-2 transition-[background-color,transform] duration-100 active:scale-[0.985] ${
        isSelected
          ? 'bg-[var(--titan-surface-raised)]/65'
          : 'hover:bg-[var(--titan-surface-raised)]/35'
      }`}
    >
      <button
        type="button"
        onClick={onSelect}
        aria-label={`Detalhar ${label}: ${valueText}`}
        className="absolute inset-0 z-[1] rounded-2xl focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
      />
      <div
        className="pointer-events-none flex flex-col items-center text-center"
        role={hasValidGoal ? 'progressbar' : 'group'}
        aria-label={
          hasValidGoal
            ? label
            : `${label}: ${formatMacroGrams(safeConsumed)} consumidos; meta não definida`
        }
        aria-valuemin={hasValidGoal ? 0 : undefined}
        aria-valuemax={hasValidGoal ? 100 : undefined}
        aria-valuenow={hasValidGoal ? progressValue : undefined}
        aria-valuetext={hasValidGoal ? valueText : undefined}
      >
        <div className="relative w-[116px] h-[68px] flex items-end justify-center">
          <canvas
            ref={canvasRef}
            width={GAUGE_W}
            height={GAUGE_H}
            className="w-[116px] h-[68px] block"
            aria-hidden="true"
          />

          <span
            aria-hidden="true"
            className={`absolute bottom-0.5 text-lg sm:text-xl font-semibold font-mono-metric leading-none ${
              safeConsumed <= 0 ? 'text-[var(--titan-text-muted)]' : 'text-[var(--titan-text-primary)]'
            }`}
          >
            {Math.round(safeConsumed)} g
          </span>
        </div>

        <span
          aria-hidden="true"
          className="mt-2 text-xs font-semibold tracking-tight"
          style={{ color: metal.fallbackColor }}
        >
          {label}
        </span>

        <span aria-hidden="true" className="text-xs font-mono-metric text-[var(--titan-text-muted)] mt-0.5">
          {!hasValidGoal
            ? 'Meta não definida'
            : excess > 0.0001
              ? `+${formatMacroGrams(excess)} acima da meta`
              : remaining > 0.0001
                ? `${formatMacroGrams(remaining)} restantes`
                : 'Meta atingida'}
        </span>
        {plannedRemainingG > 0 && (
          <span aria-hidden="true" className="text-[11px] font-mono-metric text-[var(--titan-text-muted)]/80">
            +{Math.round(plannedRemainingG)} g planej.
          </span>
        )}
      </div>
    </div>
  );
}

interface MacroDetailSheetProps {
  selectedMacro: MacroKey;
  onSelectMacro: (macro: MacroKey) => void;
  onClose: () => void;
  values: Record<MacroKey, { consumedG: number; goalG: number; plannedRemainingG: number }>;
  onOpenNutrition?: (section?: 'cardapio' | 'receitas' | 'alimentos') => void;
}

function MacroDetailSheet({
  selectedMacro,
  onSelectMacro,
  onClose,
  values,
  onOpenNutrition,
}: MacroDetailSheetProps) {
  const meals = useNutritionStore((s) => s.meals);
  const activeDateKey = useNutritionStore((s) => s.activeDateKey);

  const breakdown = useMemo(
    () => computeDailyMacroAndEnergyBreakdown(meals, activeDateKey),
    [meals, activeDateKey],
  );

  const meta = MACRO_META[selectedMacro];
  const activeStats = values[selectedMacro];
  const hasValidGoal = Number.isFinite(activeStats.goalG) && activeStats.goalG > 0;
  const safeConsumed = Number.isFinite(activeStats.consumedG) ? Math.max(0, activeStats.consumedG) : 0;
  const ratio = hasValidGoal ? Math.min(1, Math.max(0, safeConsumed / activeStats.goalG)) : 0;
  const percent = hasValidGoal ? Math.round((safeConsumed / activeStats.goalG) * 100) : 0;
  const remaining = hasValidGoal ? Math.max(0, activeStats.goalG - safeConsumed) : 0;
  const excess = hasValidGoal ? Math.max(0, safeConsumed - activeStats.goalG) : 0;
  const plannedTotalG = breakdown.plannedTotals[meta.field];

  const topFoods = useMemo(
    () =>
      [...breakdown.consumedFoods]
        .filter((f) => f.macros[meta.field] > 0)
        .sort((a, b) => b.macros[meta.field] - a.macros[meta.field]),
    [breakdown.consumedFoods, meta.field],
  );

  return (
    <BottomSheet
      open
      onClose={onClose}
      animateOpen
      title={meta.label}
      subtitle="Consumido vs meta e distribuição pelas refeições do dia"
    >
      <div className="space-y-4">
        <div className="titan-segmented w-full grid grid-cols-3" role="tablist" aria-label="Selecionar macronutriente">
          {MACRO_TABS.map((key) => {
            const tabMeta = MACRO_META[key];
            const active = key === selectedMacro;
            return (
              <button
                key={key}
                type="button"
                role="tab"
                aria-selected={active}
                aria-pressed={active}
                onClick={() => onSelectMacro(key)}
                className="titan-segment text-xs"
              >
                {tabMeta.label}
              </button>
            );
          })}
        </div>

        <div className="rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)]/70 p-3.5 space-y-3">
          <div className="flex items-baseline justify-between gap-2">
            <div>
              <div className="text-[11px] uppercase tracking-[0.08em] text-[var(--titan-text-muted)]">
                Consumido
              </div>
              <div className="text-2xl font-semibold font-mono-metric text-[var(--titan-text-primary)]">
                {formatMacroGrams(safeConsumed)}
              </div>
            </div>
            <div className="text-right font-mono-metric">
              <div className="text-xs font-semibold" style={{ color: meta.color }}>
                {hasValidGoal ? `${percent}% da meta` : 'Meta não definida'}
              </div>
              <div className="text-xs text-[var(--titan-text-muted)]">
                {hasValidGoal ? `Meta: ${formatMacroGrams(activeStats.goalG)}` : 'Configure em Metas'}
              </div>
            </div>
          </div>

          <div className="h-2 w-full rounded-full bg-[var(--titan-track)] overflow-hidden">
            <motion.div
              className="h-full w-full rounded-full origin-left"
              style={{ backgroundColor: meta.color }}
              initial={false}
              animate={{ scaleX: ratio }}
              transition={{ duration: TITAN_DURATIONS.progress, ease: TITAN_EASE }}
            />
          </div>

          <div className="grid grid-cols-3 gap-2 pt-1 text-center font-mono-metric text-xs">
            <div>
              <div className="text-[11px] text-[var(--titan-text-muted)]">
                {excess > 0.0001 ? 'Excedente' : 'Restante'}
              </div>
              <div className="font-semibold text-[var(--titan-text-primary)] mt-0.5">
                {!hasValidGoal ? '—' : excess > 0.0001 ? `+${formatMacroGrams(excess)}` : formatMacroGrams(remaining)}
              </div>
            </div>
            <div>
              <div className="text-[11px] text-[var(--titan-text-muted)]">Planejado</div>
              <div className="font-semibold text-[var(--titan-text-secondary)] mt-0.5">
                {formatMacroGrams(plannedTotalG)}
              </div>
            </div>
            <div>
              <div className="text-[11px] text-[var(--titan-text-muted)]">A consumir</div>
              <div className="font-semibold text-[var(--titan-accent)] mt-0.5">
                {activeStats.plannedRemainingG > 0 ? `+${formatMacroGrams(activeStats.plannedRemainingG)}` : '0 g'}
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <h3 className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-secondary)]">
            Por refeição
          </h3>
          {breakdown.meals.length === 0 ? (
            <p className="text-xs text-[var(--titan-text-muted)]">Nenhuma refeição programada nesta data.</p>
          ) : (
            <div className="divide-y divide-[var(--titan-border)]/45 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)]/70 px-3">
              {breakdown.meals.map((meal) => (
                <div key={meal.mealId} className="py-2.5 flex items-center justify-between gap-2 text-xs">
                  <div className="min-w-0">
                    <div className="font-medium text-[var(--titan-text-primary)] truncate">
                      {meal.time} · {meal.title}
                    </div>
                    <div className="text-[11px] text-[var(--titan-text-muted)]">
                      {MEAL_STATUS_LABELS[meal.status]} · planejado {formatMacroGrams(meal.planned[meta.field])}
                    </div>
                  </div>
                  <span
                    className={`font-mono-metric font-semibold shrink-0 ${
                      meal.isRecorded ? 'text-[var(--titan-text-primary)]' : 'text-[var(--titan-text-muted)]'
                    }`}
                  >
                    {meal.isRecorded ? formatMacroGrams(meal.consumed[meta.field]) : '0 g reg.'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="space-y-2">
          <h3 className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-secondary)]">
            Alimentos que mais contribuíram
          </h3>
          {topFoods.length === 0 ? (
            <p className="text-xs text-[var(--titan-text-muted)]">
              Nenhum alimento registrado ainda para este macronutriente.
            </p>
          ) : (
            <div className="max-h-48 overflow-y-auto divide-y divide-[var(--titan-border)]/45 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)]/70 px-3">
              {topFoods.map((food, idx) => (
                <div key={`${food.mealId}-${food.foodId}-${idx}`} className="py-2 flex items-center justify-between gap-2 text-xs">
                  <div className="min-w-0">
                    <div className="font-medium text-[var(--titan-text-primary)] truncate">
                      {food.foodName}
                    </div>
                    <div className="text-[11px] text-[var(--titan-text-muted)] truncate">
                      {food.mealTitle} · {food.quantityG} g · {formatKcal(Math.round(food.macros.kcal))} kcal
                    </div>
                  </div>
                  <span className="font-mono-metric font-semibold shrink-0" style={{ color: meta.color }}>
                    {formatMacroGrams(food.macros[meta.field])}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {onOpenNutrition && (
          <button
            type="button"
            onClick={() => {
              onClose();
              onOpenNutrition('cardapio');
            }}
            className="w-full min-h-[44px] rounded-xl border border-[var(--titan-border)] bg-[var(--titan-surface)] text-xs font-semibold text-[var(--titan-accent)] inline-flex items-center justify-center gap-1.5 hover:border-[var(--titan-accent)]/50"
          >
            <span>Ajustar refeições no Cardápio</span>
            <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
          </button>
        )}
      </div>
    </BottomSheet>
  );
}

interface MacroOverviewProps {
  carbsG: number;
  proteinG: number;
  fatG: number;
  goals: {
    carbsG: number;
    proteinG: number;
    fatG: number;
  };
  plannedRemaining?: {
    carbsG: number;
    proteinG: number;
    fatG: number;
  };
  isEstimatedGoal?: boolean;
  onOpenNutrition?: (section?: 'cardapio' | 'receitas' | 'alimentos') => void;
}

export const MacroOverview = memo(function MacroOverview({
  carbsG,
  proteinG,
  fatG,
  goals,
  plannedRemaining,
  isEstimatedGoal = false,
  onOpenNutrition,
}: MacroOverviewProps) {
  const [selectedMacro, setSelectedMacro] = useState<MacroKey | null>(null);

  const macroValues = useMemo(
    () => ({
      carbs: {
        consumedG: carbsG,
        goalG: goals.carbsG,
        plannedRemainingG: plannedRemaining?.carbsG ?? 0,
      },
      protein: {
        consumedG: proteinG,
        goalG: goals.proteinG,
        plannedRemainingG: plannedRemaining?.proteinG ?? 0,
      },
      fat: {
        consumedG: fatG,
        goalG: goals.fatG,
        plannedRemainingG: plannedRemaining?.fatG ?? 0,
      },
    }),
    [carbsG, proteinG, fatG, goals.carbsG, goals.proteinG, goals.fatG, plannedRemaining],
  );

  return (
    <section aria-label="Macronutrientes" className="px-0.5 py-1">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-baseline gap-2">
          <h2 className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-secondary)]">
            MACRONUTRIENTES
          </h2>
          <span className="text-[11px] text-[var(--titan-text-muted)]">
            Consumido vs meta{isEstimatedGoal ? ' inicial' : ''}
          </span>
        </div>
        {onOpenNutrition && (
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => onOpenNutrition('receitas')}
              className="text-xs font-medium text-[var(--titan-text-secondary)] hover:text-[var(--titan-text-primary)] hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70 rounded"
            >
              Receitas
            </button>
            <button
              type="button"
              onClick={() => onOpenNutrition('alimentos')}
              className="text-xs font-medium text-[var(--titan-text-secondary)] hover:text-[var(--titan-text-primary)] hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70 rounded"
            >
              Alimentos
            </button>
          </div>
        )}
      </div>

      <div className="grid grid-cols-3 gap-2 sm:gap-4">
        <MacroSemicircle
          label="Carboidratos"
          consumedG={carbsG}
          goalG={goals.carbsG}
          plannedRemainingG={plannedRemaining?.carbsG}
          metal={MACRO_METALS.carbs}
          isSelected={selectedMacro === 'carbs'}
          onSelect={() => setSelectedMacro('carbs')}
        />
        <MacroSemicircle
          label="Proteínas"
          consumedG={proteinG}
          goalG={goals.proteinG}
          plannedRemainingG={plannedRemaining?.proteinG}
          metal={MACRO_METALS.protein}
          isSelected={selectedMacro === 'protein'}
          onSelect={() => setSelectedMacro('protein')}
        />
        <MacroSemicircle
          label="Gorduras"
          consumedG={fatG}
          goalG={goals.fatG}
          plannedRemainingG={plannedRemaining?.fatG}
          metal={MACRO_METALS.fat}
          isSelected={selectedMacro === 'fat'}
          onSelect={() => setSelectedMacro('fat')}
        />
      </div>

      {selectedMacro && (
        <MacroDetailSheet
          selectedMacro={selectedMacro}
          onSelectMacro={setSelectedMacro}
          onClose={() => setSelectedMacro(null)}
          values={macroValues}
          onOpenNutrition={onOpenNutrition}
        />
      )}
    </section>
  );
});
