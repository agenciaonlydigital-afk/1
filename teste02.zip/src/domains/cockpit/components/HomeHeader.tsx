import { memo, startTransition, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Calendar, CalendarClock, ChevronDown, Target } from 'lucide-react';
import {
  formatNumericDateBR,
  getFirstRecordDateKey,
  MonthlyCalendar,
  resolveCalendarDay,
} from '@/src/domains/calendar/application/calendar-days';
import { useHydrationStore } from '@/src/domains/hydration/application/hydration-actions';
import { getDailyEnergyIntakeHistory, useNutritionStore } from '@/src/domains/nutrition/application/nutrition-public';
import { useEvolutionStore } from '@/src/domains/evolution/application/evolution-public';
import {
  ACTIVITY_LEVEL_OPTIONS,
  calculatePhysiologicalGoalTargets,
  estimateAdaptiveTdee,
  GOAL_OPTIONS,
  resolveAutomaticRmrMethod,
  type BiologicalSex,
  type DailyActivityLevel,
  type FitnessGoalType,
  type FatFreeMassSource,
  useProfileStore,
  validateProfileGoals,
} from '@/src/domains/profile/application/profile-public';
import { AnimatePresence, motion, TITAN_DURATIONS, TITAN_EASE } from '@/src/shared/motion/titan-motion';
import { getLocalDateKey } from '@/src/shared/utils/local-date';
import { BottomSheet } from '@/src/shared/ui/BottomSheet';
import { Button } from '@/src/shared/ui/Button';
import { formatKcal, formatMilliliters, parseLocaleNumber } from '@/src/shared/utils/formatters';

function addDaysToDateKey(dateKey: string, days: number): string {
  const [y, m, d] = dateKey.split('-').map(Number);
  const base = new Date(Date.UTC(y!, m! - 1, d!));
  base.setUTCDate(base.getUTCDate() + days);
  return base.toISOString().slice(0, 10);
}

const EMPTY_MARKED_DATE_KEYS = new Set<string>();

interface HomeHeaderProps {
  openGoalsRequestKey?: number;
}

export const HomeHeader = memo(function HomeHeader({ openGoalsRequestKey = 0 }: HomeHeaderProps) {
  const [calendarOpen, setCalendarOpen] = useState(false);
  const [goalsOpen, setGoalsOpen] = useState(false);
  const [deadlinePickerOpen, setDeadlinePickerOpen] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const activeDateKey = useNutritionStore((s) => s.activeDateKey);
  const setActiveDateKey = useNutritionStore((s) => s.setActiveDateKey);
  const meals = useNutritionStore((s) => s.meals);
  const intakeDayConfirmations = useNutritionStore((s) => s.intakeDayConfirmations);
  const evolutionRecords = useEvolutionStore((s) => s.records);
  const latestObservedWeight = useMemo(() => {
    let latestRecord: (typeof evolutionRecords)[number] | undefined;
    for (const record of evolutionRecords) {
      if (!latestRecord || record.dateKey >= latestRecord.dateKey) {
        latestRecord = record;
      }
    }
    return latestRecord?.weightKg;
  }, [evolutionRecords]);
  const profile = useProfileStore((s) => s.profile);
  const profileConfigured = useProfileStore((s) => s.profileConfigured);
  const updateProfile = useProfileStore((s) => s.updateProfile);
  const adaptiveTdee = useMemo(
    () => {
      if (!goalsOpen) return undefined;
      return estimateAdaptiveTdee(getDailyEnergyIntakeHistory(), evolutionRecords, 28, {
        sex: profile.sex, age: profile.age, heightCm: profile.heightCm,
        weightKg: latestObservedWeight ?? profile.currentWeightKg,
        ...(profile.bodyFatPercent !== undefined ? { bodyFatPercent: profile.bodyFatPercent } : {}),
      });
    },
    [goalsOpen, goalsOpen ? meals : null, goalsOpen ? intakeDayConfirmations : null, evolutionRecords, profile.sex, profile.age, profile.heightCm, profile.currentWeightKg, profile.bodyFatPercent, latestObservedWeight],
  );
  const updateDailyGoals = useNutritionStore((s) => s.updateDailyGoals);
  const setReferenceProfileId = useNutritionStore((s) => s.setReferenceProfileId);

  const hydrationEntries = useHydrationStore((s) => s.entries);
  const setDailyGoalMl = useHydrationStore((s) => s.setDailyGoalMl);

  const firstRecordDateKey = useMemo(
    () => getFirstRecordDateKey([
      ...evolutionRecords.map((record) => record.dateKey),
      ...meals.map((meal) => meal.dateKey),
      ...hydrationEntries.map((entry) => entry.dateKey),
    ]),
    [evolutionRecords, meals, hydrationEntries],
  );
  const [draftSex, setDraftSex] = useState<BiologicalSex>(profile.sex);
  const [draftGoal, setDraftGoal] = useState<FitnessGoalType>(profile.goal);
  const [draftCurrentWeight, setDraftCurrentWeight] = useState(
    profileConfigured ? String(profile.currentWeightKg) : '',
  );
  const [draftTargetWeight, setDraftTargetWeight] = useState(
    profileConfigured ? String(profile.targetWeightKg) : '',
  );
  const [draftActivity, setDraftActivity] = useState<DailyActivityLevel>(
    profile.activityLevel,
  );
  const [draftDeadline, setDraftDeadline] = useState(profile.deadlineDateKey);
  const [draftHeight, setDraftHeight] = useState(profileConfigured ? String(profile.heightCm) : '');
  const [draftAge, setDraftAge] = useState(profileConfigured ? String(profile.age) : '');
  const [draftMeasuredRmr, setDraftMeasuredRmr] = useState(profile.measuredRmrKcal === undefined ? '' : String(profile.measuredRmrKcal));
  const [draftBodyFat, setDraftBodyFat] = useState(profile.bodyFatPercent === undefined ? '' : String(profile.bodyFatPercent));
  const [draftFatFreeMassSource, setDraftFatFreeMassSource] = useState<FatFreeMassSource | ''>(profile.fatFreeMassSource ?? '');

  const [todayGreeting, setTodayGreeting] = useState('Visão diária');
  useEffect(() => {
    const hour = new Date().getHours();
    setTodayGreeting(hour < 12 ? 'Bom dia' : hour < 18 ? 'Boa tarde' : 'Boa noite');
  }, []);

  useEffect(() => {
    if (goalsOpen) return;
    setDraftSex(profile.sex);
    setDraftGoal(profile.goal);
    setDraftCurrentWeight(profileConfigured ? String(profile.currentWeightKg) : '');
    setDraftTargetWeight(profileConfigured ? String(profile.targetWeightKg) : '');
    setDraftActivity(profile.activityLevel);
    setDraftDeadline(profile.deadlineDateKey);
    setDraftHeight(profileConfigured ? String(profile.heightCm) : '');
    setDraftAge(profileConfigured ? String(profile.age) : '');
    setDraftMeasuredRmr(profile.measuredRmrKcal === undefined ? '' : String(profile.measuredRmrKcal));
    setDraftBodyFat(profile.bodyFatPercent === undefined ? '' : String(profile.bodyFatPercent));
    setDraftFatFreeMassSource(profile.fatFreeMassSource ?? '');
  }, [profile, profileConfigured, goalsOpen]);

  const activeDay = resolveCalendarDay(activeDateKey);
  const todayKey = getLocalDateKey();
  const contextLabel =
    activeDateKey === todayKey
      ? todayGreeting
      : activeDateKey < todayKey
        ? 'Histórico observado'
        : 'Planejamento futuro';

  const markedDateKeys = useMemo(() => {
    if (!calendarOpen) return EMPTY_MARKED_DATE_KEYS;
    const set = new Set<string>();
    for (const m of meals) {
      if (m.status !== 'planned') set.add(m.dateKey);
    }
    for (const h of hydrationEntries) {
      set.add(h.dateKey);
    }
    for (const record of evolutionRecords) {
      set.add(record.dateKey);
    }
    return set;
  }, [calendarOpen, calendarOpen ? meals : null, calendarOpen ? hydrationEntries : null, calendarOpen ? evolutionRecords : null]);

  const autoRmrSelection = useMemo(
    () =>
      resolveAutomaticRmrMethod({
        age: draftAge.trim() ? parseLocaleNumber(draftAge) : undefined,
        activityLevel: draftActivity,
        bodyFatPercent: draftBodyFat.trim() ? parseLocaleNumber(draftBodyFat) : undefined,
        fatFreeMassSource: draftFatFreeMassSource || undefined,
        measuredRmrKcal: draftMeasuredRmr.trim() ? parseLocaleNumber(draftMeasuredRmr) : undefined,
      }),
    [draftAge, draftActivity, draftBodyFat, draftFatFreeMassSource, draftMeasuredRmr],
  );

  const previewValidation = useMemo(() => {
    if (!goalsOpen) return null;
    return validateProfileGoals({
      sex: draftSex,
      goal: draftGoal,
      currentWeightKg: draftCurrentWeight,
      targetWeightKg: draftTargetWeight,
      activityLevel: draftActivity,
      deadlineDateKey: draftDeadline,
      heightCm: draftHeight,
      age: draftAge,
      rmrMethod: autoRmrSelection.method,
      measuredRmrKcal: draftMeasuredRmr,
      bodyFatPercent: draftBodyFat,
      fatFreeMassSource: draftFatFreeMassSource || undefined,
    });
  }, [
    goalsOpen,
    draftSex,
    draftGoal,
    draftCurrentWeight,
    draftTargetWeight,
    draftActivity,
    draftDeadline,
    draftHeight,
    draftAge,
    autoRmrSelection.method,
    draftMeasuredRmr,
    draftBodyFat,
    draftFatFreeMassSource,
  ]);

  const previewTargets = useMemo(
    () =>
      previewValidation?.ok
        ? calculatePhysiologicalGoalTargets(previewValidation.data, activeDateKey, adaptiveTdee)
        : null,
    [previewValidation, activeDateKey, adaptiveTdee],
  );

  const lastGoalsRequestRef = useRef(openGoalsRequestKey);

  const openGoalsModal = useCallback(() => {
    setDraftSex(profile.sex);
    setDraftGoal(profile.goal);
    setDraftCurrentWeight(latestObservedWeight !== undefined
      ? String(latestObservedWeight)
      : profileConfigured ? String(profile.currentWeightKg) : '');
    setDraftTargetWeight(profileConfigured ? String(profile.targetWeightKg) : '');
    setDraftActivity(profile.activityLevel);
    setDraftDeadline(profile.deadlineDateKey);
    setDraftHeight(profileConfigured ? String(profile.heightCm) : '');
    setDraftAge(profileConfigured ? String(profile.age) : '');
    setDraftMeasuredRmr(profile.measuredRmrKcal === undefined ? '' : String(profile.measuredRmrKcal));
    setDraftBodyFat(profile.bodyFatPercent === undefined ? '' : String(profile.bodyFatPercent));
    setDraftFatFreeMassSource(profile.fatFreeMassSource ?? '');
    setDeadlinePickerOpen(false);
    setFormError(null);
    setGoalsOpen(true);
  }, [profile, profileConfigured, latestObservedWeight]);

  useEffect(() => {
    if (openGoalsRequestKey > lastGoalsRequestRef.current) {
      lastGoalsRequestRef.current = openGoalsRequestKey;
      openGoalsModal();
    }
  }, [openGoalsRequestKey, openGoalsModal]);

  const saveGoals = () => {
    if (!previewValidation) return;
    if (!previewValidation.ok) {
      setFormError(previewValidation.error);
      return;
    }

    const targets = calculatePhysiologicalGoalTargets(
      previewValidation.data,
      activeDateKey,
      adaptiveTdee,
    );

    updateProfile(previewValidation.data);
    updateDailyGoals({
      kcal: targets.kcal,
      proteinG: targets.proteinG,
      carbsG: targets.carbsG,
      fatG: targets.fatG,
    });
    setDailyGoalMl(targets.waterMl);
    setReferenceProfileId(targets.driProfileId);
    setFormError(null);
    setGoalsOpen(false);
  };

  return (
    <>
      <header className="titan-home-header">
        <div className="min-w-0">
          <div className="flex items-center gap-3">
            <span className="titan-brand-wordmark md:hidden">TITAN</span>
            <span className="titan-eyebrow">{contextLabel}</span>
          </div>
          <AnimatePresence mode="wait" initial={false}>
            <motion.p
              key={activeDateKey}
              initial={{ opacity: 0, y: 3 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -3 }}
              transition={{ duration: TITAN_DURATIONS.quick, ease: TITAN_EASE }}
              className="titan-home-header-date mt-1 truncate"
            >
              {activeDay.fullLabel}
            </motion.p>
          </AnimatePresence>
          {!profileConfigured && (
            <p className="mt-1 text-[10px] text-[var(--titan-status-warning)]">
              Configure seus dados para personalizar as metas
            </p>
          )}
        </div>

        <div className="titan-home-header-actions shrink-0">
          <button
            type="button"
            onClick={() => setCalendarOpen(true)}
            aria-label="Selecionar data no calendário"
            aria-expanded={calendarOpen}
            className="min-h-[44px] min-w-[44px] px-3 rounded-xl bg-[var(--titan-surface-raised)] border border-[var(--titan-border)]/75 shadow-[inset_0_1px_0_rgba(241,240,232,0.04)] text-[var(--titan-text-secondary)] flex items-center justify-center gap-1.5 text-xs font-medium transition-colors hover:border-[var(--titan-info)]/55 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
          >
            <Calendar className="w-4 h-4 shrink-0" />
            <span className="hidden sm:inline">Calendário</span>
          </button>

          <button
            type="button"
            onClick={openGoalsModal}
            aria-label="Configurar metas e variáveis do objetivo"
            aria-expanded={goalsOpen}
            className="min-h-[44px] min-w-[44px] px-3 rounded-xl bg-[var(--titan-surface-raised)] border border-[var(--titan-accent)]/40 shadow-[inset_0_1px_0_rgba(241,240,232,0.04)] text-[var(--titan-text-primary)] flex items-center justify-center gap-1.5 text-xs font-medium whitespace-nowrap transition-transform active:scale-[0.97] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
          >
            <Target className="w-4 h-4 text-[var(--titan-accent)] shrink-0" />
            <span>{profileConfigured ? 'Metas' : 'Configurar'}</span>
          </button>
        </div>
      </header>

      {/* Calendário mensal real ancorado no primeiro registro */}
      <BottomSheet
        open={calendarOpen}
        onClose={() => setCalendarOpen(false)}
        title="Calendário"
      >
        <MonthlyCalendar
          selectedDateKey={activeDateKey}
          minDateKey={firstRecordDateKey}
          markedDateKeys={markedDateKeys}
          anchorLabel="Data do primeiro registro"
          onSelectDate={(dateKey) => {
            startTransition(() => setActiveDateKey(dateKey));
            setCalendarOpen(false);
          }}
        />
      </BottomSheet>

      {/* Aba de Metas com micro-animação suave e variáveis fisiológicas completas */}
      <BottomSheet
        open={goalsOpen}
        onClose={() => setGoalsOpen(false)}
        animateOpen
        title={profileConfigured ? 'Metas' : 'Configurar perfil'}
        subtitle="Defina seus dados para calibrar energia, macronutrientes e hidratação"
      >
        <div className="space-y-4">
          {!profileConfigured && (
            <p className="rounded-xl border border-[var(--titan-status-warning)]/35 bg-[var(--titan-bg-canvas)] p-3 text-xs text-[var(--titan-text-secondary)]" role="note">
              Os valores iniciais do TITAN são parâmetros temporários, não medições suas. Informe peso, altura e idade; confira sexo, objetivo, atividade e prazo antes de salvar.
            </p>
          )}
          <div className="grid grid-cols-2 gap-3">
            <label className="block">
              <span className="text-xs text-[var(--titan-text-secondary)]">Sexo</span>
              <select
                value={draftSex}
                onChange={(e) => setDraftSex(e.target.value as BiologicalSex)}
                className="mt-1 w-full min-h-[44px] px-3 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)] text-sm text-[var(--titan-text-primary)]"
              >
                <option value="male">Masculino</option>
                <option value="female">Feminino</option>
              </select>
            </label>

            <label className="block">
              <span className="text-xs text-[var(--titan-text-secondary)]">Objetivo</span>
              <select
                value={draftGoal}
                onChange={(e) => setDraftGoal(e.target.value as FitnessGoalType)}
                className="mt-1 w-full min-h-[44px] px-3 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)] text-sm text-[var(--titan-text-primary)]"
              >
                {GOAL_OPTIONS.map((opt) => (
                  <option key={opt.id} value={opt.id}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </label>

            <label className="block">
              <span className="text-xs text-[var(--titan-text-secondary)]">Peso Atual (kg)</span>
              <input
                type="number"
                step="0.1"
                inputMode="decimal"
                value={draftCurrentWeight}
                onChange={(e) => setDraftCurrentWeight(e.target.value)}
                className="mt-1 w-full min-h-[44px] px-3 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)] text-sm font-mono-metric text-[var(--titan-text-primary)]"
              />
            </label>

            <label className="block">
              <span className="text-xs text-[var(--titan-text-secondary)]">Peso Desejado (kg)</span>
              <input
                type="number"
                step="0.1"
                inputMode="decimal"
                value={draftTargetWeight}
                onChange={(e) => setDraftTargetWeight(e.target.value)}
                className="mt-1 w-full min-h-[44px] px-3 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)] text-sm font-mono-metric text-[var(--titan-text-primary)]"
              />
            </label>

            <label className="block">
              <span className="text-xs text-[var(--titan-text-secondary)]">Altura (cm)</span>
              <input
                type="number"
                inputMode="numeric"
                value={draftHeight}
                onChange={(e) => setDraftHeight(e.target.value)}
                className="mt-1 w-full min-h-[44px] px-3 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)] text-sm font-mono-metric text-[var(--titan-text-primary)]"
              />
            </label>

            <label className="block">
              <span className="text-xs text-[var(--titan-text-secondary)]">Idade (anos)</span>
              <input
                type="number"
                inputMode="numeric"
                value={draftAge}
                onChange={(e) => setDraftAge(e.target.value)}
                className="mt-1 w-full min-h-[44px] px-3 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)] text-sm font-mono-metric text-[var(--titan-text-primary)]"
              />
            </label>
          </div>

          {/* Movimento Diário compacto */}
          <div className="space-y-1.5">
            <span className="text-xs text-[var(--titan-text-secondary)]">Movimento diário</span>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5">
              {ACTIVITY_LEVEL_OPTIONS.map((option) => {
                const active = draftActivity === option.id;
                return (
                  <button
                    key={option.id}
                    type="button"
                    onClick={() => setDraftActivity(option.id)}
                    aria-pressed={active}
                    className={`min-h-[44px] px-2.5 py-2 rounded-xl border text-center transition-colors ${
                      active
                        ? 'bg-[var(--titan-surface-elevated)] border-[var(--titan-accent)] text-[var(--titan-text-primary)] font-semibold'
                        : 'bg-[var(--titan-bg-canvas)] border-[var(--titan-border)]/80 text-[var(--titan-text-secondary)]'
                    }`}
                  >
                    <span className="block text-xs">{option.label}</span>
                  </button>
                );
              })}
            </div>
            <p className="text-[11px] text-[var(--titan-text-muted)] leading-snug">
              {ACTIVITY_LEVEL_OPTIONS.find((item) => item.id === draftActivity)?.description}
            </p>
          </div>

          {/* Dados opcionais de composição corporal / calorimetria com seleção automática do método */}
          <details
            className="rounded-2xl border border-[var(--titan-border)]/75 bg-[var(--titan-bg-canvas)]/55 p-3"
            open={Boolean(draftBodyFat.trim() || draftMeasuredRmr.trim())}
          >
            <summary className="cursor-pointer list-none flex items-center justify-between gap-2 text-xs font-semibold text-[var(--titan-text-primary)]">
              <span>Refinar precisão (opcional)</span>
              <span className="font-mono-metric text-[11px] font-medium text-[var(--titan-accent)]">
                Auto: {autoRmrSelection.label}
              </span>
            </summary>
            <div className="mt-3 space-y-3">
              <p className="text-[11px] text-[var(--titan-text-muted)]">
                O método de estimativa é escolhido automaticamente conforme os dados informados: {autoRmrSelection.reason}
              </p>
              <div className="grid grid-cols-2 gap-3">
                <label className="block">
                  <span className="text-xs text-[var(--titan-text-secondary)]">Gordura corporal (%)</span>
                  <input type="number" min="2" max="70" step="0.1" inputMode="decimal" value={draftBodyFat} onChange={(e) => setDraftBodyFat(e.target.value)} placeholder="Opcional" className="mt-1 w-full min-h-[44px] px-3 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)] text-sm font-mono-metric text-[var(--titan-text-primary)]" />
                </label>
                <label className="block">
                  <span className="text-xs text-[var(--titan-text-secondary)]">Origem da medição</span>
                  <select value={draftFatFreeMassSource} onChange={(e) => setDraftFatFreeMassSource(e.target.value as FatFreeMassSource | '')} className="mt-1 w-full min-h-[44px] px-2 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)] text-xs text-[var(--titan-text-primary)]">
                    <option value="">Não informada</option>
                    <option value="dexa">DXA</option>
                    <option value="bod_pod">Bod Pod</option>
                    <option value="isotope_dilution">Diluição isotópica</option>
                    <option value="validated_bioimpedance">Bioimpedância validada</option>
                    <option value="other">Outra fonte</option>
                  </select>
                </label>
              </div>
              <label className="block">
                <span className="text-xs text-[var(--titan-text-secondary)]">RMR medido por calorimetria indireta (kcal/dia)</span>
                <input type="number" min="300" max="5000" step="1" inputMode="numeric" value={draftMeasuredRmr} onChange={(e) => setDraftMeasuredRmr(e.target.value)} placeholder="Opcional — substitui a equação" className="mt-1 w-full min-h-[44px] px-3 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)] text-sm font-mono-metric text-[var(--titan-text-primary)]" />
              </label>
            </div>
          </details>

          {/* Prazo via Calendário + atalhos */}
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs text-[var(--titan-text-secondary)]">Prazo</span>
              <div className="flex items-center gap-1.5">
                {[30, 90, 180].map((days) => {
                  const presetKey = addDaysToDateKey(getLocalDateKey(), days);
                  const active = draftDeadline === presetKey;
                  return (
                    <button
                      key={days}
                      type="button"
                      onClick={() => {
                        setDraftDeadline(presetKey);
                        setDeadlinePickerOpen(false);
                      }}
                      className={`min-h-[30px] rounded-lg px-2 text-[11px] font-mono-metric border transition-colors ${
                        active
                          ? 'border-[var(--titan-accent)] bg-[var(--titan-surface-elevated)] text-[var(--titan-text-primary)]'
                          : 'border-[var(--titan-border-subtle)] bg-[var(--titan-bg-canvas)] text-[var(--titan-text-muted)] hover:text-[var(--titan-text-primary)]'
                      }`}
                    >
                      +{days}d
                    </button>
                  );
                })}
              </div>
            </div>
            <button
              type="button"
              onClick={() => setDeadlinePickerOpen((v) => !v)}
              aria-expanded={deadlinePickerOpen}
              className="w-full min-h-[44px] px-3 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)] text-sm text-[var(--titan-text-primary)] flex items-center justify-between gap-2"
            >
              <span className="flex items-center gap-2 font-mono-metric">
                <CalendarClock className="w-4 h-4 text-[var(--titan-accent)]" />
                {formatNumericDateBR(draftDeadline)}
              </span>
              <ChevronDown
                className={`w-4 h-4 text-[var(--titan-text-muted)] transition-transform ${
                  deadlinePickerOpen ? 'rotate-180' : ''
                }`}
              />
            </button>

            {deadlinePickerOpen && (
              <div className="p-3 rounded-2xl bg-[var(--titan-bg-canvas)]/95 border border-[var(--titan-border)]/80">
                <MonthlyCalendar
                  selectedDateKey={draftDeadline}
                  minDateKey={getLocalDateKey()}
                  anchorLabel="Início"
                  onSelectDate={(dateKey) => {
                    setDraftDeadline(dateKey);
                    setDeadlinePickerOpen(false);
                  }}
                />
              </div>
            )}
          </div>

          {previewTargets && (
            <div className="p-3 rounded-xl bg-[var(--titan-bg-canvas)]/90 border border-[var(--titan-border)]/70 space-y-1">
              <div className="flex items-center justify-between text-xs text-[var(--titan-text-muted)]">
                <span>Meta diária ({autoRmrSelection.label})</span>
                <span className="font-mono-metric text-[var(--titan-accent)]">
                  RMR {formatKcal(previewTargets.bmr)} · TDEE{' '}
                  {formatKcal(previewTargets.tdee)}
                </span>
              </div>
              <p className="text-[10px] text-[var(--titan-text-muted)]">
                {previewTargets.tdeeSource === 'observed_adaptive'
                  ? `TDEE calibrado pelo histórico · faixa ${formatKcal(previewTargets.tdeeRangeKcal?.lower ?? previewTargets.tdee)}–${formatKcal(previewTargets.tdeeRangeKcal?.upper ?? previewTargets.tdee)}.`
                  : `Método escolhido automaticamente (${autoRmrSelection.label}) + NASEM 2023.`}
              </p>
              <div className="grid grid-cols-4 gap-2 pt-1 text-center font-mono-metric">
                <div>
                  <div className="text-xs font-semibold text-[var(--titan-text-primary)]">
                    {formatKcal(previewTargets.kcal)}
                  </div>
                  <div className="text-xs text-[var(--titan-text-muted)]">kcal</div>
                </div>
                <div>
                  <div className="text-xs font-semibold text-[var(--titan-info)]">
                    {previewTargets.carbsG} g
                  </div>
                  <div className="text-xs text-[var(--titan-text-muted)]">Carb</div>
                </div>
                <div>
                  <div className="text-xs font-semibold text-[var(--titan-accent)]">
                    {previewTargets.proteinG} g
                  </div>
                  <div className="text-xs text-[var(--titan-text-muted)]">Prot</div>
                </div>
                <div>
                  <div className="text-xs font-semibold text-[var(--titan-champagne)]">
                    {previewTargets.fatG} g
                  </div>
                  <div className="text-xs text-[var(--titan-text-muted)]">Gord</div>
                </div>
              </div>
              <div className="text-xs text-[var(--titan-info)] text-center pt-1 font-mono-metric">
                Hidratação sugerida: {formatMilliliters(previewTargets.waterMl)}
              </div>
            </div>
          )}

          {formError && (
            <p className="text-xs text-[var(--titan-status-error)]" role="alert">
              {formError}
            </p>
          )}

          <div className="flex justify-end gap-2 pt-1">
            <Button variant="ghost" onClick={() => setGoalsOpen(false)}>
              Cancelar
            </Button>
            <Button variant="primary" onClick={saveGoals}>
              Salvar metas
            </Button>
          </div>
        </div>
      </BottomSheet>
    </>
  );
});
