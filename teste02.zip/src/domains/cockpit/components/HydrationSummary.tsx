import { memo, useEffect, useMemo, useRef, useState } from 'react';
import { Plus, RotateCcw, Trash2 } from 'lucide-react';
import {
  correctValidatedLastWater,
  getHydrationSummary,
  logValidatedWater,
  useHydrationStore,
} from '@/src/domains/hydration/application/hydration-actions';
import { useNutritionStore } from '@/src/domains/nutrition/application/nutrition-public';
import {
  createSpringArray,
  DEFAULT_WATER_OPTICAL_CONFIG,
  getSharedFluidEngine,
  interpolateRatio,
  prefersReducedMotion,
  type FluidDrawJob,
} from '@/src/shared/graphics/fluid-shader-engine';
import { BottomSheet } from '@/src/shared/ui/BottomSheet';
import { Button } from '@/src/shared/ui/Button';
import { Surface } from '@/src/shared/ui/Surface';
import { formatMilliliters } from '@/src/shared/utils/formatters';

const DROPLET_W = 84;
const DROPLET_H = 100;
const TANK_HEIGHT = 54;

function drawFallbackDroplet(
  canvas: HTMLCanvasElement,
  ratio: number,
  hasRecords: boolean,
) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const pixelWidth = Math.round(DROPLET_W * dpr);
  const pixelHeight = Math.round(DROPLET_H * dpr);
  if (canvas.width !== pixelWidth) canvas.width = pixelWidth;
  if (canvas.height !== pixelHeight) canvas.height = pixelHeight;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, DROPLET_W, DROPLET_H);

  const shape = () => {
    ctx.beginPath();
    ctx.moveTo(42, 4);
    ctx.bezierCurveTo(39, 8, 13, 43, 13, 62);
    ctx.bezierCurveTo(13, 79, 25, 92, 42, 92);
    ctx.bezierCurveTo(59, 92, 71, 79, 71, 62);
    ctx.bezierCurveTo(71, 43, 45, 8, 42, 4);
    ctx.closePath();
  };

  ctx.save();
  shape();
  ctx.clip();

  // Optical volume: the unfilled glass remains transparent and cool.
  const shell = ctx.createLinearGradient(8, 10, 76, 90);
  shell.addColorStop(0, 'rgba(242, 252, 255, 0.12)');
  shell.addColorStop(0.42, 'rgba(105, 170, 194, 0.035)');
  shell.addColorStop(1, 'rgba(18, 50, 66, 0.18)');
  ctx.fillStyle = shell;
  ctx.fillRect(0, 0, DROPLET_W, DROPLET_H);

  const fill = Math.min(1, Math.max(0, ratio));
  if (fill > 0.002) {
    const surfaceY = 88 - fill * 76;
    const water = ctx.createLinearGradient(0, surfaceY - 4, 0, 96);
    water.addColorStop(0, 'rgba(223, 247, 255, 0.72)');
    water.addColorStop(0.12, 'rgba(128, 196, 219, 0.48)');
    water.addColorStop(0.52, 'rgba(61, 132, 164, 0.56)');
    water.addColorStop(1, 'rgba(23, 65, 87, 0.72)');
    ctx.fillStyle = water;
    ctx.fillRect(0, surfaceY, DROPLET_W, DROPLET_H - surfaceY);

    // One static meniscus with a restrained curved highlight.
    ctx.beginPath();
    ctx.moveTo(10, surfaceY + 2);
    ctx.bezierCurveTo(22, surfaceY - 3, 29, surfaceY - 1, 42, surfaceY + 1);
    ctx.bezierCurveTo(55, surfaceY - 1, 63, surfaceY - 3, 74, surfaceY + 2);
    ctx.strokeStyle = 'rgba(237, 251, 255, 0.92)';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(18, surfaceY + 5);
    ctx.bezierCurveTo(30, surfaceY + 3, 53, surfaceY + 3, 66, surfaceY + 5);
    ctx.strokeStyle = 'rgba(103, 190, 223, 0.42)';
    ctx.lineWidth = 1;
    ctx.stroke();

    // Subtle refracted light concentrated toward the rounded lower volume.
    const caustic = ctx.createRadialGradient(42, 76, 2, 42, 76, 28);
    caustic.addColorStop(0, 'rgba(219, 248, 255, 0.22)');
    caustic.addColorStop(1, 'rgba(145, 214, 236, 0)');
    ctx.fillStyle = caustic;
    ctx.fillRect(10, 52, 64, 42);
  }
  ctx.restore();

  // Thick optical edge and two softbox reflections define the glass droplet.
  shape();
  const edge = ctx.createLinearGradient(10, 8, 72, 91);
  edge.addColorStop(0, 'rgba(248, 254, 255, 0.96)');
  edge.addColorStop(0.28, 'rgba(166, 220, 238, 0.62)');
  edge.addColorStop(0.7, 'rgba(63, 130, 157, 0.52)');
  edge.addColorStop(1, 'rgba(226, 246, 252, 0.88)');
  ctx.strokeStyle = edge;
  ctx.lineWidth = 2;
  ctx.stroke();

  ctx.save();
  ctx.globalAlpha = hasRecords ? 0.9 : 0.48;
  ctx.lineCap = 'round';
  ctx.strokeStyle = 'rgba(247, 253, 255, 0.88)';
  ctx.lineWidth = 3.2;
  ctx.beginPath();
  ctx.moveTo(31, 24);
  ctx.bezierCurveTo(24, 34, 20, 43, 19, 51);
  ctx.stroke();

  ctx.strokeStyle = 'rgba(163, 224, 242, 0.55)';
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.moveTo(60, 58);
  ctx.bezierCurveTo(65, 69, 61, 79, 54, 84);
  ctx.stroke();
  ctx.restore();
}

function drawFallbackTank(
  canvas: HTMLCanvasElement,
  width: number,
  height: number,
  ratio: number,
) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const dpr = Math.min(window.devicePixelRatio || 1, 1.75);
  const w = Math.max(120, width);
  const h = Math.max(40, height);
  const pixelWidth = Math.round(w * dpr);
  const pixelHeight = Math.round(h * dpr);
  if (canvas.width !== pixelWidth) canvas.width = pixelWidth;
  if (canvas.height !== pixelHeight) canvas.height = pixelHeight;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);

  const inset = 1.5;
  const x = inset;
  const y = inset;
  const trackW = w - inset * 2;
  const trackH = h - inset * 2;
  const radius = trackH / 2;

  ctx.save();
  ctx.beginPath();
  ctx.roundRect(x, y, trackW, trackH, radius);
  ctx.clip();

  const cavity = ctx.createLinearGradient(0, y, 0, y + trackH);
  cavity.addColorStop(0, 'rgba(238, 250, 255, 0.10)');
  cavity.addColorStop(0.24, 'rgba(111, 161, 180, 0.035)');
  cavity.addColorStop(0.72, 'rgba(5, 17, 24, 0.12)');
  cavity.addColorStop(1, 'rgba(204, 236, 247, 0.08)');
  ctx.fillStyle = cavity;
  ctx.fillRect(x, y, trackW, trackH);

  const fill = Math.min(1, Math.max(0, ratio));
  const liquidW = trackW * fill;
  if (liquidW > 0.5) {
    const water = ctx.createLinearGradient(0, y + 2, 0, y + trackH - 2);
    water.addColorStop(0, 'rgba(222, 247, 255, 0.68)');
    water.addColorStop(0.12, 'rgba(113, 184, 211, 0.56)');
    water.addColorStop(0.48, 'rgba(54, 126, 160, 0.66)');
    water.addColorStop(0.84, 'rgba(31, 86, 117, 0.78)');
    water.addColorStop(1, 'rgba(17, 54, 76, 0.72)');

    ctx.fillStyle = water;
    ctx.fillRect(x, y, liquidW, trackH);

    // Curved front meniscus at the fill boundary.
    const frontX = x + liquidW;
    ctx.beginPath();
    ctx.moveTo(frontX - 1, y + 7);
    ctx.bezierCurveTo(frontX + 4, y + 14, frontX + 4, y + trackH - 14, frontX - 1, y + trackH - 7);
    ctx.strokeStyle = 'rgba(233, 250, 255, 0.85)';
    ctx.lineWidth = 1.4;
    ctx.stroke();

    // Single broad softbox reflection, not animated texture.
    const reflection = ctx.createLinearGradient(0, y + 4, 0, y + 17);
    reflection.addColorStop(0, 'rgba(255, 255, 255, 0.28)');
    reflection.addColorStop(1, 'rgba(255, 255, 255, 0)');
    ctx.fillStyle = reflection;
    ctx.fillRect(x + 4, y + 3, Math.max(0, liquidW - 8), 14);

    const lens = ctx.createLinearGradient(0, y + trackH - 12, 0, y + trackH);
    lens.addColorStop(0, 'rgba(137, 219, 245, 0)');
    lens.addColorStop(1, 'rgba(186, 237, 250, 0.26)');
    ctx.fillStyle = lens;
    ctx.fillRect(x, y + trackH - 12, liquidW, 12);
  }
  ctx.restore();

  // Outer mineral-glass bevel and inner edge reflections.
  ctx.beginPath();
  ctx.roundRect(x, y, trackW, trackH, radius);
  const shell = ctx.createLinearGradient(0, y, 0, y + trackH);
  shell.addColorStop(0, 'rgba(244, 253, 255, 0.78)');
  shell.addColorStop(0.18, 'rgba(146, 198, 215, 0.28)');
  shell.addColorStop(0.52, 'rgba(73, 119, 139, 0.22)');
  shell.addColorStop(0.84, 'rgba(163, 213, 229, 0.34)');
  shell.addColorStop(1, 'rgba(240, 252, 255, 0.72)');
  ctx.strokeStyle = shell;
  ctx.lineWidth = 1.35;
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(x + radius, y + 2.5);
  ctx.lineTo(x + trackW - radius, y + 2.5);
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.38)';
  ctx.lineWidth = 1;
  ctx.stroke();
}
interface DropletGaugeProps {
  percent: number;
  barPercent: number;
  hasRecords: boolean;
}

function WaterDropletGauge({ percent, barPercent, hasRecords }: DropletGaugeProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const normalizedPercent = Number.isFinite(barPercent)
    ? Math.min(100, Math.max(0, barPercent))
    : 0;
  const targetRatioRef = useRef(normalizedPercent / 100);
  const currentRatioRef = useRef(targetRatioRef.current);
  const lastInterpolationAtRef = useRef(0);
  const hasRecordsRef = useRef(hasRecords);
  const isVisibleRef = useRef(true);
  const waveRef = useRef(createSpringArray(24));
  const providerRef = useRef<(() => FluidDrawJob | null) | null>(null);

  useEffect(() => {
    const nextRatio = normalizedPercent / 100;
    const delta = nextRatio - targetRatioRef.current;
    targetRatioRef.current = nextRatio;
    hasRecordsRef.current = hasRecords;
    if (
      typeof window !== 'undefined' &&
      prefersReducedMotion()
    ) {
      currentRatioRef.current = nextRatio;
      const rendered = providerRef.current
        ? getSharedFluidEngine().renderSinglePass(providerRef.current)
        : false;
      if (!rendered && canvasRef.current) {
        drawFallbackDroplet(canvasRef.current, nextRatio, hasRecords);
      }
      return;
    }
    if (Math.abs(delta) > 0.005) {
      const wave = waveRef.current;
      const mid = wave[12];
      if (mid) mid.velocity += delta > 0 ? -3.4 : 2.2;
      const rendered = providerRef.current
        ? getSharedFluidEngine().renderSinglePass(providerRef.current)
        : false;
      if (!rendered && canvasRef.current) {
        drawFallbackDroplet(canvasRef.current, nextRatio, hasRecords);
      }
      getSharedFluidEngine().wake();
    }
  }, [normalizedPercent, hasRecords]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const engine = getSharedFluidEngine();
    const drawFallback = () => drawFallbackDroplet(canvas, targetRatioRef.current, hasRecordsRef.current);
    const onEngineFallback = () => drawFallback();
    const onEngineRestored = () => {
      if (providerRef.current) engine.renderSinglePass(providerRef.current);
    };
    window.addEventListener('fluid-engine-fallback', onEngineFallback);
    window.addEventListener('fluid-engine-restored', onEngineRestored);

    const io =
      typeof IntersectionObserver !== 'undefined'
        ? new IntersectionObserver(
            (entries) => {
              isVisibleRef.current = entries[0]?.isIntersecting ?? true;
              if (isVisibleRef.current && providerRef.current) {
                engine.renderSinglePass(providerRef.current);
                engine.wake();
              }
            },
            { threshold: 0.05 },
          )
        : null;
    io?.observe(canvas);

    const provider = (): FluidDrawJob | null => {
      if (prefersReducedMotion()) {
        currentRatioRef.current = targetRatioRef.current;
        lastInterpolationAtRef.current = 0;
      }
      const diff = targetRatioRef.current - currentRatioRef.current;
      const isAnimating = Math.abs(diff) > 0.0005;
      if (isAnimating) {
        const now = performance.now();
        const dt = lastInterpolationAtRef.current
          ? Math.min(0.05, Math.max(0, (now - lastInterpolationAtRef.current) / 1000))
          : 1 / 60;
        currentRatioRef.current = interpolateRatio(
          currentRatioRef.current,
          targetRatioRef.current,
          dt,
          1 / 10.5,
        );
        lastInterpolationAtRef.current = now;
      } else {
        currentRatioRef.current = targetRatioRef.current;
        lastInterpolationAtRef.current = 0;
      }
      return {
        kind: 'droplet',
        targetCanvas: canvas,
        width: DROPLET_W,
        height: DROPLET_H,
        fill: currentRatioRef.current,
        active: hasRecordsRef.current,
        isAnimating,
        wave: waveRef.current,
        opticalConfig: DEFAULT_WATER_OPTICAL_CONFIG,
        isVisible: isVisibleRef.current,
      };
    };
    providerRef.current = provider;

    const rendered = engine.renderSinglePass(provider);
    if (!rendered) {
      drawFallbackDroplet(canvas, targetRatioRef.current, hasRecordsRef.current);
    }

    const unsubscribe = engine.subscribe(provider, true);
    return () => {
      providerRef.current = null;
      unsubscribe();
      io?.disconnect();
      window.removeEventListener('fluid-engine-fallback', onEngineFallback);
      window.removeEventListener('fluid-engine-restored', onEngineRestored);
    };
  }, []);



  return (
    <div className="flex flex-col items-center shrink-0">
      <canvas
        ref={canvasRef}
        width={DROPLET_W}
        height={DROPLET_H}
        className="w-[84px] h-[100px] block"
        aria-hidden="true"
      />
      <span className="mt-1 text-xs font-semibold font-mono-metric text-[var(--titan-info)] leading-none">
        {percent}%
      </span>
    </div>
  );
}

interface CrystalWaterTankProps {
  barPercent: number;
  currentMl: number;
  goalMl: number;
}

function CrystalWaterTank({
  barPercent,
  currentMl,
  goalMl,
}: CrystalWaterTankProps) {
  const normalizedPercent = Number.isFinite(barPercent)
    ? Math.min(100, Math.max(0, barPercent))
    : 0;
  const hasValidGoal = Number.isFinite(goalMl) && goalMl > 0;
  const accessiblePercent = normalizedPercent;
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const targetRatioRef = useRef(normalizedPercent / 100);
  const currentRatioRef = useRef(targetRatioRef.current);
  const lastInterpolationAtRef = useRef(0);
  const sizeRef = useRef({ w: 220, h: TANK_HEIGHT });
  const isVisibleRef = useRef(true);
  const waveRef = useRef(createSpringArray(24));
  const providerRef = useRef<(() => FluidDrawJob | null) | null>(null);

  useEffect(() => {
    const nextRatio = normalizedPercent / 100;
    const delta = nextRatio - targetRatioRef.current;
    targetRatioRef.current = nextRatio;
    if (
      typeof window !== 'undefined' &&
      prefersReducedMotion()
    ) {
      currentRatioRef.current = nextRatio;
      const rendered = providerRef.current
        ? getSharedFluidEngine().renderSinglePass(providerRef.current)
        : false;
      if (!rendered && canvasRef.current) {
        drawFallbackTank(canvasRef.current, sizeRef.current.w, sizeRef.current.h, nextRatio);
      }
      return;
    }
    if (Math.abs(delta) > 0.005) {
      const wave = waveRef.current;
      const idx = Math.min(23, Math.max(0, Math.round(nextRatio * 23)));
      const node = wave[idx];
      if (node) node.velocity += delta > 0 ? -3.6 : 2.3;
      const rendered = providerRef.current
        ? getSharedFluidEngine().renderSinglePass(providerRef.current)
        : false;
      if (!rendered && canvasRef.current) {
        drawFallbackTank(canvasRef.current, sizeRef.current.w, sizeRef.current.h, nextRatio);
      }
      getSharedFluidEngine().wake();
    }
  }, [normalizedPercent]);

  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;
    const engine = getSharedFluidEngine();
    const drawFallback = () =>
      drawFallbackTank(canvas, sizeRef.current.w, sizeRef.current.h, targetRatioRef.current);
    const onEngineFallback = () => drawFallback();
    const onEngineRestored = () => {
      if (providerRef.current) engine.renderSinglePass(providerRef.current);
    };
    window.addEventListener('fluid-engine-fallback', onEngineFallback);
    window.addEventListener('fluid-engine-restored', onEngineRestored);

    sizeRef.current.w = Math.max(120, container.clientWidth);

    const provider = (): FluidDrawJob | null => {
      if (prefersReducedMotion()) {
        currentRatioRef.current = targetRatioRef.current;
        lastInterpolationAtRef.current = 0;
      }
      const diff = targetRatioRef.current - currentRatioRef.current;
      const isAnimating = Math.abs(diff) > 0.0005;
      if (isAnimating) {
        const now = performance.now();
        const dt = lastInterpolationAtRef.current
          ? Math.min(0.05, Math.max(0, (now - lastInterpolationAtRef.current) / 1000))
          : 1 / 60;
        currentRatioRef.current = interpolateRatio(
          currentRatioRef.current,
          targetRatioRef.current,
          dt,
          1 / 10.5,
        );
        lastInterpolationAtRef.current = now;
      } else {
        currentRatioRef.current = targetRatioRef.current;
        lastInterpolationAtRef.current = 0;
      }
      return {
        kind: 'tank',
        targetCanvas: canvas,
        width: sizeRef.current.w,
        height: sizeRef.current.h,
        fill: currentRatioRef.current,
        isAnimating,
        wave: waveRef.current,
        opticalConfig: DEFAULT_WATER_OPTICAL_CONFIG,
        isVisible: isVisibleRef.current,
      };
    };
    providerRef.current = provider;

    const ro =
      typeof ResizeObserver !== 'undefined'
        ? new ResizeObserver(() => {
            sizeRef.current.w = Math.max(120, container.clientWidth);
            const rendered = engine.renderSinglePass(provider);
            if (!rendered) {
              drawFallbackTank(canvas, sizeRef.current.w, sizeRef.current.h, targetRatioRef.current);
            }
          })
        : null;
    ro?.observe(container);

    const io =
      typeof IntersectionObserver !== 'undefined'
        ? new IntersectionObserver(
            (entries) => {
              isVisibleRef.current = entries[0]?.isIntersecting ?? true;
              if (isVisibleRef.current) {
                const rendered = engine.renderSinglePass(provider);
                if (!rendered) {
                  drawFallbackTank(canvas, sizeRef.current.w, sizeRef.current.h, targetRatioRef.current);
                }
                engine.wake();
              }
            },
            { threshold: 0.05 },
          )
        : null;
    io?.observe(container);

    const rendered = engine.renderSinglePass(provider);
    if (!rendered) {
      drawFallbackTank(canvas, sizeRef.current.w, sizeRef.current.h, targetRatioRef.current);
    }

    const unsubscribe = engine.subscribe(provider, true);
    return () => {
      providerRef.current = null;
      unsubscribe();
      ro?.disconnect();
      io?.disconnect();
      window.removeEventListener('fluid-engine-fallback', onEngineFallback);
      window.removeEventListener('fluid-engine-restored', onEngineRestored);
    };
  }, []);

  return (
    <div
      ref={containerRef}
      className="relative h-[54px] w-full rounded-full bg-gradient-to-b from-[var(--titan-track)]/90 via-[var(--titan-water-mid)]/30 to-[var(--titan-water-deep)] border border-[var(--titan-water-edge)]/40 shadow-[inset_0_2px_2px_rgba(244,252,255,0.17),inset_0_-4px_8px_rgba(0,0,0,0.72),0_0_0_1px_rgba(92,157,181,0.08)] overflow-hidden"
      role={hasValidGoal ? 'progressbar' : 'group'}
      aria-valuenow={hasValidGoal ? accessiblePercent : undefined}
      aria-valuemin={hasValidGoal ? 0 : undefined}
      aria-valuemax={hasValidGoal ? 100 : undefined}
      aria-valuetext={
        hasValidGoal ? `${currentMl} ml de ${goalMl} ml (${accessiblePercent}%)` : undefined
      }
      aria-label={
        hasValidGoal
          ? `Hidratação diária: ${currentMl} ml de ${goalMl} ml`
          : `Hidratação registrada: ${currentMl} ml; meta não definida`
      }
    >
      <canvas
        ref={canvasRef}
        className="relative z-[1] block w-full h-full touch-pan-y"
        aria-hidden="true"
      />
      <span
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-[9px] top-[2px] z-[2] h-px rounded-full bg-gradient-to-r from-transparent via-white/45 to-transparent"
      />
      <span
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-[12px] bottom-[2px] z-[2] h-px rounded-full bg-gradient-to-r from-transparent via-[var(--titan-water-light)]/25 to-transparent"
      />
    </div>
  );
}

interface HydrationSummaryProps {
  isEstimatedGoal?: boolean;
  onOpenGoals?: () => void;
}

export const HydrationSummary = memo(function HydrationSummary({
  isEstimatedGoal = false,
  onOpenGoals,
}: HydrationSummaryProps) {
  const activeDateKey = useNutritionStore((s) => s.activeDateKey);
  const entries = useHydrationStore((s) => s.entries);
  const dailyGoalMl = useHydrationStore((s) => s.dailyGoalMl);
  const logWater = useHydrationStore((s) => s.logWater);
  const removeEntry = useHydrationStore((s) => s.removeEntry);

  const summary = useMemo(
    () => getHydrationSummary(entries, dailyGoalMl, activeDateKey),
    [entries, dailyGoalMl, activeDateKey],
  );

  const [sheetOpen, setSheetOpen] = useState(false);
  const [customMl, setCustomMl] = useState('');
  const [correctionMl, setCorrectionMl] = useState('');
  const [formError, setFormError] = useState<string | null>(null);
  const [inlineFeedback, setInlineFeedback] = useState<string | null>(null);

  const handleQuickAdd = (ml: number) => {
    logWater(ml, activeDateKey);
    setFormError(null);
    setInlineFeedback(`+${ml} ml registrado`);
    setSheetOpen(false);
  };

  const handleCustomSubmit = () => {
    const res = logValidatedWater(customMl, activeDateKey);
    if (!res.ok) {
      setFormError(res.error);
      return;
    }
    setCustomMl('');
    setFormError(null);
    setSheetOpen(false);
  };

  const handleCorrectLast = () => {
    const res = correctValidatedLastWater(correctionMl, activeDateKey);
    if (!res.ok) {
      setFormError(res.error);
      return;
    }
    setCorrectionMl('');
    setFormError(null);
  };

  const lastEntry = summary.dayEntries[summary.dayEntries.length - 1] ?? null;

  useEffect(() => {
    if (!inlineFeedback) return;
    const timer = window.setTimeout(() => setInlineFeedback(null), 2400);
    return () => window.clearTimeout(timer);
  }, [inlineFeedback]);

  return (
    <>
      <div id="cockpit-hydration">
        <Surface className="p-4 sm:p-5">
        {/* Título no canto superior esquerdo + ação rápida +250 ml / Desfazer + modal completo */}
        <div className="flex flex-wrap items-center justify-between gap-2 mb-2.5">
          <div className="flex items-baseline gap-2 min-w-0">
            <h2 className="text-sm font-semibold text-[var(--titan-text-primary)] tracking-tight">Hidratação</h2>
            {inlineFeedback && (
              <span role="status" className="text-[11px] font-mono-metric text-[var(--titan-info)]">
                {inlineFeedback}
              </span>
            )}
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {lastEntry && (
              <button
                type="button"
                onClick={() => {
                  removeEntry(lastEntry.id);
                  setInlineFeedback(`-${lastEntry.amountMl} ml desfeito`);
                }}
                aria-label={`Desfazer último registro de ${lastEntry.amountMl} ml`}
                className="min-h-[44px] px-2.5 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)]/75 text-xs font-medium text-[var(--titan-text-secondary)] hover:text-[var(--titan-text-primary)] flex items-center gap-1 whitespace-nowrap active:scale-[0.98] transition-transform duration-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
              >
                <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
                <span className="hidden sm:inline">Desfazer</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => handleQuickAdd(250)}
              aria-label="Adicionar 250 ml de água rapidamente"
              className="min-h-[44px] px-2.5 rounded-xl bg-[var(--titan-surface-raised)] border border-[var(--titan-info)]/45 text-xs font-semibold font-mono-metric text-[var(--titan-info)] hover:border-[var(--titan-info)]/75 active:scale-[0.98] transition-transform duration-100 whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
            >
              +250 ml
            </button>
            <button
              type="button"
              onClick={() => {
                setCorrectionMl(lastEntry ? String(lastEntry.amountMl) : '');
                setFormError(null);
                setSheetOpen(true);
              }}
              className="min-h-[44px] px-2.5 sm:px-3 rounded-xl bg-[var(--titan-surface-raised)] border border-[var(--titan-border)]/80 shadow-[inset_0_1px_0_rgba(241,240,233,0.06)] text-xs font-medium text-[var(--titan-text-primary)] flex items-center gap-1.5 whitespace-nowrap shrink-0 active:scale-[0.98] transition-transform duration-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
            >
              <span>Registrar água</span>
              <Plus className="w-3.5 h-3.5 text-[var(--titan-info)]" />
            </button>
          </div>
        </div>

        {/* Gota cristalina à esquerda + 1.250 ml alinhado com o início da barra de água */}
        <div className="grid grid-cols-[84px_minmax(0,1fr)] gap-x-2 items-end">
          <WaterDropletGauge
            percent={summary.percent}
            barPercent={summary.barPercent}
            hasRecords={summary.hasRecords}
          />

          <div className="min-w-0 flex flex-col justify-end">
            <div className="text-2xl font-semibold font-mono-metric text-[var(--titan-text-primary)] leading-none mb-2 tracking-tight">
              {formatMilliliters(summary.currentMl)}
            </div>

            <CrystalWaterTank
              barPercent={summary.barPercent}
              currentMl={summary.currentMl}
              goalMl={summary.goalMl}
            />

            <div className="mt-1.5 flex flex-wrap items-center justify-between gap-1.5 text-xs">
              <span className="text-[var(--titan-text-muted)]">
                {!summary.hasRecords
                  ? 'Sem registros'
                  : summary.goalMl > 0 && summary.currentMl > summary.goalMl
                  ? `+${formatMilliliters(summary.currentMl - summary.goalMl)} acima`
                  : summary.goalMl > 0 && summary.currentMl < summary.goalMl
                  ? `Restam ${formatMilliliters(summary.goalMl - summary.currentMl)}`
                  : `${summary.dayEntries.length} ${summary.dayEntries.length === 1 ? 'registro' : 'registros'}`}
              </span>
              <span className="font-mono-metric text-[var(--titan-text-muted)]">
                {summary.goalMl > 0
                  ? `Meta ${formatMilliliters(summary.goalMl)}${isEstimatedGoal ? ' · inicial' : ''}`
                  : 'Meta não definida'}
                {isEstimatedGoal && onOpenGoals && (
                  <>
                    {' '}
                    <button
                      type="button"
                      onClick={onOpenGoals}
                      className="text-[var(--titan-accent)] hover:underline ml-1"
                    >
                      Ajustar
                    </button>
                  </>
                )}
              </span>
            </div>
          </div>
        </div>
        </Surface>
      </div>

      <BottomSheet
        open={sheetOpen}
        onClose={() => setSheetOpen(false)}
        title="Registrar hidratação"
        subtitle={`Meta diária: ${formatMilliliters(summary.goalMl)} · ${activeDateKey}`}
      >
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-2.5">
            <Button variant="mineral" className="focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70" onClick={() => handleQuickAdd(150)}>
              +150 ml
            </Button>
            <Button variant="primary" className="focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70" onClick={() => handleQuickAdd(250)}>
              +250 ml
            </Button>
          </div>

          <form
            className="flex items-end gap-2"
            onSubmit={(event) => {
              event.preventDefault();
              handleCustomSubmit();
            }}
          >
            <label className="flex-1 block min-w-0">
              <span className="text-xs text-[var(--titan-text-secondary)]">Quantidade personalizada (ml)</span>
              <input
                type="number"
                inputMode="numeric"
                min={10}
                max={5000}
                step={1}
                placeholder="Ex.: 350"
                value={customMl}
                onChange={(e) => setCustomMl(e.target.value)}
                aria-invalid={Boolean(formError)}
                aria-describedby={formError ? 'hydration-form-error' : undefined}
                className="mt-1 w-full min-h-[44px] px-3 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)] text-sm font-mono-metric text-[var(--titan-text-primary)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
              />
            </label>
            <Button type="submit" variant="secondary" className="focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70">
              Registrar
            </Button>
          </form>

          {formError && (
            <p id="hydration-form-error" className="text-xs text-[var(--titan-status-error)]" role="alert">
              {formError}
            </p>
          )}

          {lastEntry && (
            <div className="pt-3 border-t border-[var(--titan-border)]/60 space-y-2">
              <div className="text-xs text-[var(--titan-text-secondary)]">
                Corrigir último registro ({lastEntry.timeLabel} · {lastEntry.amountMl} ml)
              </div>
              <form
                className="flex items-center gap-2"
                onSubmit={(event) => {
                  event.preventDefault();
                  handleCorrectLast();
                }}
              >
                <input
                  type="number"
                  inputMode="numeric"
                  min={0}
                  max={5000}
                  step={1}
                  value={correctionMl}
                  onChange={(e) => setCorrectionMl(e.target.value)}
                  aria-label="Corrigir volume do último registro em ml"
                  aria-invalid={Boolean(formError)}
                  aria-describedby={formError ? 'hydration-form-error' : undefined}
                  className="flex-1 min-w-0 min-h-[44px] px-3 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)] text-sm font-mono-metric text-[var(--titan-text-primary)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
                />
                <Button type="submit" variant="secondary" className="focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70">
                  Corrigir
                </Button>
              </form>
            </div>
          )}

          <div className="pt-3 border-t border-[var(--titan-border)]/60 space-y-2">
            <div className="text-xs font-medium text-[var(--titan-text-secondary)]">
              Histórico do dia ({formatMilliliters(summary.currentMl)})
            </div>
            {summary.dayEntries.length === 0 ? (
              <p className="text-xs text-[var(--titan-text-muted)]">Nenhum registro para esta data.</p>
            ) : (
              <div className="max-h-40 overflow-y-auto divide-y divide-[var(--titan-border)]/40">
                {[...summary.dayEntries].reverse().map((entry) => (
                  <div
                    key={entry.id}
                    className="py-2 flex items-center justify-between text-xs"
                  >
                    <span className="font-mono-metric text-[var(--titan-text-primary)]">
                      {entry.timeLabel} · {formatMilliliters(entry.amountMl)}
                    </span>
                    <button
                      type="button"
                      onClick={() => removeEntry(entry.id)}
                      aria-label={`Remover registro de ${entry.amountMl} ml às ${entry.timeLabel}`}
                      className="min-h-[44px] min-w-[44px] -mr-1.5 flex items-center justify-center rounded-xl text-[var(--titan-text-muted)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </BottomSheet>
    </>
  );
});
