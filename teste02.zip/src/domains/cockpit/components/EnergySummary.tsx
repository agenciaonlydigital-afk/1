import { memo, useEffect, useMemo, useRef, useState } from 'react';
import { ArrowRight, ChevronRight } from 'lucide-react';
import {
  computeDailyMacroAndEnergyBreakdown,
  type MealConsumptionStatus,
  useNutritionStore,
} from '@/src/domains/nutrition/application/nutrition-public';
import {
  getSharedFluidEngine,
  interpolateRatio,
  prefersReducedMotion,
  type FluidDrawJob,
} from '@/src/shared/graphics/fluid-shader-engine';
import { BottomSheet } from '@/src/shared/ui/BottomSheet';
import { formatKcal } from '@/src/shared/utils/formatters';

interface EnergySummaryProps {
  consumedKcal: number;
  goalKcal: number;
  plannedRemainingKcal?: number;
  plannedMealsCount?: number;
  isEstimatedGoal?: boolean;
  dataCoveragePercent?: number | null;
  unresolvedFoodCount?: number;
  lowConfidenceFoodCount?: number;
  onOpenNutrition?: (section?: 'cardapio' | 'receitas' | 'alimentos') => void;
}

const BAR_HEIGHT = 18;
const MIN_RENDER_WIDTH = 120;
const INTERPOLATION_TIME_CONSTANT_SECONDS = 0.14;

function drawEnergyFallback(
  canvas: HTMLCanvasElement,
  width: number,
  ratio: number,
) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
  const pixelWidth = Math.max(2, Math.round(width * dpr));
  const pixelHeight = Math.max(2, Math.round(BAR_HEIGHT * dpr));
  if (canvas.width !== pixelWidth) canvas.width = pixelWidth;
  if (canvas.height !== pixelHeight) canvas.height = pixelHeight;

  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, width, BAR_HEIGHT);
  ctx.save();
  ctx.beginPath();
  ctx.roundRect(0, 0, width, BAR_HEIGHT, BAR_HEIGHT / 2);
  ctx.clip();

  const cavity = ctx.createLinearGradient(0, 0, 0, BAR_HEIGHT);
  cavity.addColorStop(0, '#1B2927');
  cavity.addColorStop(0.5, '#0D1716');
  cavity.addColorStop(1, '#060C0B');
  ctx.fillStyle = cavity;
  ctx.fillRect(0, 0, width, BAR_HEIGHT);

  const fillWidth = Math.max(0, Math.min(width, width * ratio));
  if (fillWidth > 0.5) {
    const fluid = ctx.createLinearGradient(0, 1, 0, BAR_HEIGHT - 1);
    fluid.addColorStop(0, '#6E9582');
    fluid.addColorStop(0.22, '#426D59');
    fluid.addColorStop(0.68, '#234B3A');
    fluid.addColorStop(1, '#153126');
    ctx.fillStyle = fluid;
    ctx.fillRect(0, 0, fillWidth, BAR_HEIGHT);

    const softbox = ctx.createLinearGradient(0, 1, 0, 8);
    softbox.addColorStop(0, 'rgba(226, 244, 233, 0.30)');
    softbox.addColorStop(1, 'rgba(226, 244, 233, 0)');
    ctx.fillStyle = softbox;
    ctx.fillRect(2, 1, Math.max(0, fillWidth - 4), 8);

    if (ratio > 0.015 && ratio < 0.99) {
      const edgeX = Math.min(width - 1, fillWidth);
      const meniscus = ctx.createLinearGradient(edgeX - 2, 0, edgeX + 2, 0);
      meniscus.addColorStop(0, 'rgba(177, 211, 190, 0)');
      meniscus.addColorStop(0.5, 'rgba(208, 235, 218, 0.72)');
      meniscus.addColorStop(1, 'rgba(177, 211, 190, 0)');
      ctx.fillStyle = meniscus;
      ctx.fillRect(edgeX - 2, 1, 4, BAR_HEIGHT - 2);
    }
  }

  ctx.restore();
}

const MEAL_STATUS_LABELS: Record<MealConsumptionStatus, string> = {
  planned: 'Planejada',
  consumed: 'Consumida',
  partial: 'Parcial',
  substituted: 'Substituída',
  skipped: 'Pulada',
};

interface EnergyDetailSheetProps {
  open: boolean;
  onClose: () => void;
  consumedKcal: number;
  goalKcal: number;
  hasValidGoal: boolean;
  onOpenNutrition?: (section?: 'cardapio' | 'receitas' | 'alimentos') => void;
}

function EnergyDetailSheet({
  open,
  onClose,
  consumedKcal,
  goalKcal,
  hasValidGoal,
  onOpenNutrition,
}: EnergyDetailSheetProps) {
  const meals = useNutritionStore((s) => s.meals);
  const activeDateKey = useNutritionStore((s) => s.activeDateKey);

  const breakdown = useMemo(
    () => computeDailyMacroAndEnergyBreakdown(meals, activeDateKey),
    [meals, activeDateKey],
  );

  const topFoods = useMemo(
    () =>
      [...breakdown.consumedFoods]
        .filter((f) => f.macros.kcal > 0)
        .sort((a, b) => b.macros.kcal - a.macros.kcal),
    [breakdown.consumedFoods],
  );

  const diff = hasValidGoal ? goalKcal - consumedKcal : null;

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      animateOpen
      title="Análise energética do dia"
      subtitle="Comparativo rigoroso entre planejado, consumido e meta"
    >
      <div className="space-y-4">
        <div className="grid grid-cols-3 gap-2.5 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)]/70 p-3 text-center font-mono-metric">
          <div>
            <div className="text-[11px] text-[var(--titan-text-muted)]">Consumido</div>
            <div className="text-sm font-semibold text-[var(--titan-text-primary)] mt-0.5">
              {formatKcal(consumedKcal)} kcal
            </div>
          </div>
          <div>
            <div className="text-[11px] text-[var(--titan-text-muted)]">Planejado</div>
            <div className="text-sm font-semibold text-[var(--titan-text-secondary)] mt-0.5">
              {formatKcal(Math.round(breakdown.plannedTotals.kcal))} kcal
            </div>
          </div>
          <div>
            <div className="text-[11px] text-[var(--titan-text-muted)]">
              {diff !== null && diff < 0 ? 'Excedente' : 'Restante'}
            </div>
            <div
              className={`text-sm font-semibold mt-0.5 ${
                diff !== null && diff < 0 ? 'text-[var(--titan-champagne)]' : 'text-[var(--titan-accent)]'
              }`}
            >
              {diff === null ? '—' : `${formatKcal(Math.abs(diff))} kcal`}
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <h3 className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-secondary)]">
            Contribuição por refeição
          </h3>
          {breakdown.meals.length === 0 ? (
            <p className="text-xs text-[var(--titan-text-muted)]">
              Nenhuma refeição cadastrada nesta data.
            </p>
          ) : (
            <div className="divide-y divide-[var(--titan-border)]/45 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)]/70 px-3">
              {breakdown.meals.map((item) => (
                <div key={item.mealId} className="py-2.5 flex items-center justify-between gap-2 text-xs">
                  <div className="min-w-0">
                    <div className="font-medium text-[var(--titan-text-primary)] truncate">
                      {item.time} · {item.title}
                    </div>
                    <div className="text-[11px] text-[var(--titan-text-muted)]">
                      {MEAL_STATUS_LABELS[item.status]} · planejado {formatKcal(Math.round(item.planned.kcal))} kcal
                    </div>
                  </div>
                  <span
                    className={`font-mono-metric font-semibold shrink-0 ${
                      item.isRecorded ? 'text-[var(--titan-accent)]' : 'text-[var(--titan-text-muted)]'
                    }`}
                  >
                    {item.isRecorded ? `${formatKcal(Math.round(item.consumed.kcal))} kcal` : '0 kcal reg.'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="space-y-2">
          <h3 className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-secondary)]">
            Alimentos registrados
          </h3>
          {topFoods.length === 0 ? (
            <p className="text-xs text-[var(--titan-text-muted)]">
              Nenhum alimento consumido foi registrado ainda hoje.
            </p>
          ) : (
            <div className="max-h-52 overflow-y-auto divide-y divide-[var(--titan-border)]/45 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)]/70 px-3">
              {topFoods.map((food, idx) => (
                <div key={`${food.mealId}-${food.foodId}-${idx}`} className="py-2 flex items-center justify-between gap-2 text-xs">
                  <div className="min-w-0">
                    <div className="font-medium text-[var(--titan-text-primary)] truncate">
                      {food.foodName}
                    </div>
                    <div className="text-[11px] text-[var(--titan-text-muted)] truncate">
                      {food.mealTitle} · {food.quantityG} g
                    </div>
                  </div>
                  <span className="font-mono-metric text-[var(--titan-text-primary)] shrink-0">
                    {formatKcal(Math.round(food.macros.kcal))} kcal
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {onOpenNutrition && (
          <button
            type="button"
            onClick={() => {
              onClose();
              onOpenNutrition('cardapio');
            }}
            className="w-full min-h-[44px] rounded-xl border border-[var(--titan-border)] bg-[var(--titan-surface)] text-xs font-semibold text-[var(--titan-accent)] inline-flex items-center justify-center gap-1.5 hover:border-[var(--titan-accent)]/50"
          >
            <span>Gerenciar refeições no Cardápio</span>
            <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
          </button>
        )}
      </div>
    </BottomSheet>
  );
}

export const EnergySummary = memo(function EnergySummary({
  consumedKcal,
  goalKcal,
  plannedRemainingKcal = 0,
  plannedMealsCount = 0,
  isEstimatedGoal = false,
  dataCoveragePercent = null,
  unresolvedFoodCount = 0,
  lowConfidenceFoodCount = 0,
  onOpenNutrition,
}: EnergySummaryProps) {
  const [detailOpen, setDetailOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const safeConsumed = Number.isFinite(consumedKcal)
    ? Math.max(0, consumedKcal)
    : 0;
  const hasValidGoal = Number.isFinite(goalKcal) && goalKcal > 0;
  const safeGoal = hasValidGoal ? goalKcal : 1;
  const ratio = hasValidGoal
    ? Math.min(1, Math.max(0, safeConsumed / safeGoal))
    : 0;
  const rawPercent = hasValidGoal ? Math.round((safeConsumed / safeGoal) * 100) : 0;
  const progressValue = Math.min(100, Math.max(0, rawPercent));
  const diff = hasValidGoal ? safeGoal - safeConsumed : null;

  const targetRatioRef = useRef(ratio);
  const currentRatioRef = useRef(ratio);
  const lastFrameAtRef = useRef(0);
  const sizeRef = useRef({ w: 280, h: BAR_HEIGHT });
  const isVisibleRef = useRef(true);
  const providerRef = useRef<(() => FluidDrawJob | null) | null>(null);

  useEffect(() => {
    targetRatioRef.current = ratio;
    const engine = getSharedFluidEngine();

    if (
      typeof window !== 'undefined' &&
      prefersReducedMotion()
    ) {
      currentRatioRef.current = ratio;
      lastFrameAtRef.current = 0;
      if (providerRef.current) {
        const rendered = engine.renderSinglePass(providerRef.current);
        if (!rendered && canvasRef.current) {
          drawEnergyFallback(canvasRef.current, sizeRef.current.w, ratio);
        }
      }
      return;
    }

    lastFrameAtRef.current = 0;
    if (providerRef.current) {
      const rendered = engine.renderSinglePass(providerRef.current);
      if (!rendered && canvasRef.current) {
        drawEnergyFallback(canvasRef.current, sizeRef.current.w, ratio);
      }
    }
    // A mudança de dado precisa acordar o loop compartilhado por conta própria.
    engine.wake();
  }, [ratio]);

  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;

    const engine = getSharedFluidEngine();
    sizeRef.current.w = Math.max(MIN_RENDER_WIDTH, container.clientWidth);

    const provider = (): FluidDrawJob | null => {
      const now = performance.now();
      const elapsed = lastFrameAtRef.current
        ? Math.min(0.05, Math.max(0, (now - lastFrameAtRef.current) / 1000))
        : 1 / 60;
      lastFrameAtRef.current = now;

      currentRatioRef.current = interpolateRatio(
        currentRatioRef.current,
        targetRatioRef.current,
        elapsed,
        INTERPOLATION_TIME_CONSTANT_SECONDS,
      );

      return {
        kind: 'energy',
        targetCanvas: canvas,
        width: sizeRef.current.w,
        height: sizeRef.current.h,
        fill: currentRatioRef.current,
        isAnimating: Math.abs(targetRatioRef.current - currentRatioRef.current) > 0.0005,
        isVisible: isVisibleRef.current,
      };
    };
    providerRef.current = provider;

    const renderCurrent = () => {
      const rendered = engine.renderSinglePass(provider);
      if (!rendered) {
        drawEnergyFallback(canvas, sizeRef.current.w, currentRatioRef.current);
      }
    };

    const resizeObserver =
      typeof ResizeObserver !== 'undefined'
        ? new ResizeObserver(() => {
            sizeRef.current.w = Math.max(MIN_RENDER_WIDTH, container.clientWidth);
            renderCurrent();
          })
        : null;
    resizeObserver?.observe(container);

    const intersectionObserver =
      typeof IntersectionObserver !== 'undefined'
        ? new IntersectionObserver(
            (entries) => {
              isVisibleRef.current = entries[0]?.isIntersecting ?? true;
              if (isVisibleRef.current) {
                renderCurrent();
                if (Math.abs(targetRatioRef.current - currentRatioRef.current) > 0.0005) {
                  engine.wake();
                }
              }
            },
            { threshold: 0.05 },
          )
        : null;
    intersectionObserver?.observe(container);

    renderCurrent();
    const unsubscribe = engine.subscribe(provider, true);
    const motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    const handleMotionPreference = (event: MediaQueryListEvent) => {
      if (event.matches) {
        currentRatioRef.current = targetRatioRef.current;
        lastFrameAtRef.current = 0;
        renderCurrent();
      } else if (Math.abs(targetRatioRef.current - currentRatioRef.current) > 0.0005) {
        lastFrameAtRef.current = 0;
        engine.wake();
      }
    };
    motionQuery.addEventListener('change', handleMotionPreference);

    return () => {
      providerRef.current = null;
      unsubscribe();
      resizeObserver?.disconnect();
      intersectionObserver?.disconnect();
      motionQuery.removeEventListener('change', handleMotionPreference);
    };
  }, []);

  const isPartialData =
    unresolvedFoodCount > 0 ||
    lowConfidenceFoodCount > 0 ||
    (dataCoveragePercent !== null && dataCoveragePercent < 100);

  return (
    <section aria-label="Consumo energético" className="px-0.5 py-1">
      <div className="flex items-baseline justify-between gap-2">
        <div className="flex flex-wrap items-baseline gap-2 min-w-0">
          <span className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-secondary)]">
            ENERGIA CONSUMIDA
          </span>
          {isPartialData && (
            <span className="text-[11px] font-medium text-[var(--titan-status-warning)]">
              Parcial{dataCoveragePercent !== null ? ` · ${Math.round(dataCoveragePercent)}%` : ''}
            </span>
          )}
        </div>
        <span className="text-sm font-semibold font-mono-metric text-[var(--titan-accent)]">
          {hasValidGoal ? `${rawPercent}%` : '—'}
        </span>
      </div>

      <div className="mt-1.5 flex items-baseline justify-between gap-2">
        <span className="font-display text-3xl sm:text-4xl font-semibold tabular-nums text-[var(--titan-text-primary)] tracking-tight">
          {formatKcal(safeConsumed)} kcal
        </span>
        <span className="text-sm font-medium font-mono-metric text-[var(--titan-text-muted)] text-right">
          {hasValidGoal
            ? `${formatKcal(safeGoal)} kcal${isEstimatedGoal ? ' · inicial' : ''}`
            : 'Meta não definida'}
        </span>
      </div>

      {/* Fluido mineral luminoso: o valor é o dado; o brilho é apenas sua representação visual. */}
      <div
        ref={containerRef}
        className="mt-3 relative h-[20px] w-full rounded-full bg-[var(--titan-track)] shadow-[inset_0_4px_9px_rgba(0,0,0,0.92),inset_0_-1.5px_2px_rgba(241,240,233,0.11),0_1px_0_rgba(241,240,233,0.06)] p-[1px] overflow-hidden"
        role={hasValidGoal ? 'progressbar' : 'group'}
        aria-valuenow={hasValidGoal ? progressValue : undefined}
        aria-valuemin={hasValidGoal ? 0 : undefined}
        aria-valuemax={hasValidGoal ? 100 : undefined}
        aria-valuetext={
          hasValidGoal
            ? `${formatKcal(safeConsumed)} de ${formatKcal(safeGoal)} quilocalorias; ${rawPercent}% da meta`
            : undefined
        }
        aria-label={
          hasValidGoal
            ? 'Progresso de energia consumida no dia'
            : 'Energia consumida; meta diária não definida'
        }
      >
        <canvas
          ref={canvasRef}
          className="block w-full h-full rounded-full"
          aria-hidden="true"
        />
      </div>

      <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-[var(--titan-text-muted)]">
          {plannedRemainingKcal > 0 && plannedMealsCount > 0 && (
            <span className="font-mono-metric">
              Planejado restante: +{formatKcal(plannedRemainingKcal)} kcal ({plannedMealsCount}{' '}
              {plannedMealsCount === 1 ? 'ref.' : 'refs.'})
            </span>
          )}
          <button
            type="button"
            onClick={() => setDetailOpen(true)}
            className="inline-flex items-center gap-0.5 text-xs font-medium text-[var(--titan-accent)] hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70 rounded"
          >
            <span>Detalhar</span>
            <ChevronRight className="w-3.5 h-3.5" aria-hidden="true" />
          </button>
          {onOpenNutrition && (
            <button
              type="button"
              onClick={() => onOpenNutrition('cardapio')}
              className="text-xs font-medium text-[var(--titan-text-secondary)] hover:text-[var(--titan-text-primary)] hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70 rounded"
            >
              Abrir Cardápio
            </button>
          )}
        </div>
        <span
          className={`text-xs font-mono-metric ${
            diff !== null && diff < 0 ? 'text-[var(--titan-champagne)]' : 'text-[var(--titan-text-muted)]'
          }`}
        >
          {diff === null
            ? 'Defina uma meta diária'
            : diff > 0
              ? `${diff < 1 ? 'Menos de 1' : formatKcal(diff)} kcal restantes`
              : diff < 0
                ? `+${Math.abs(diff) < 1 ? '<1' : formatKcal(Math.abs(diff))} kcal além da meta`
                : 'Meta atingida'}
        </span>
      </div>

      {detailOpen && (
        <EnergyDetailSheet
          open={detailOpen}
          onClose={() => setDetailOpen(false)}
          consumedKcal={safeConsumed}
          goalKcal={safeGoal}
          hasValidGoal={hasValidGoal}
          onOpenNutrition={onOpenNutrition}
        />
      )}
    </section>
  );
});
