import { useCallback, useMemo, useState } from 'react';
import { AnatomyViewport } from '@/src/domains/anatomy/application/anatomy-public';
import {
  sortMeasurementsChronologically,
  useEvolutionStore,
} from '@/src/domains/evolution/application/evolution-public';
import {
  computeDayPlanSummary,
  computeNutritionTotals,
  useNutritionStore,
} from '@/src/domains/nutrition/application/nutrition-public';
import { useProfileStore } from '@/src/domains/profile/application/profile-public';
import type { MuscleGroupId } from '@/src/shared/types/common';
import { DailyStatusStrip } from '../components/DailyStatusStrip';
import { EnergySummary } from '../components/EnergySummary';
import { EvolutionOverview } from '../components/EvolutionOverview';
import { ExerciseHydrationCalculator } from '../components/ExerciseHydrationCalculator';
import { HomeHeader } from '../components/HomeHeader';
import { HydrationSummary } from '../components/HydrationSummary';
import { MacroOverview } from '../components/MacroOverview';
import { MicronutrientSummary } from '../components/MicronutrientSummary';
import { NextMeal } from '../components/NextMeal';
import { TodayWorkout } from '../components/TodayWorkout';

interface CockpitScreenProps {
  onOpenTraining: () => void;
  onOpenTrainingPlans?: () => void;
  onOpenExerciseLibrary?: (muscleId?: MuscleGroupId) => void;
  onOpenNutrition?: (section?: 'cardapio' | 'receitas' | 'alimentos') => void;
  onOpenEvolution?: () => void;
}

export function CockpitScreen({
  onOpenTraining,
  onOpenTrainingPlans,
  onOpenExerciseLibrary,
  onOpenNutrition,
  onOpenEvolution,
}: CockpitScreenProps) {
  const meals = useNutritionStore((s) => s.meals);
  const activeDateKey = useNutritionStore((s) => s.activeDateKey);
  const dailyGoals = useNutritionStore((s) => s.dailyGoals);
  const profileConfigured = useProfileStore((s) => s.profileConfigured);
  const profileCurrentWeightKg = useProfileStore((s) => s.profile.currentWeightKg);
  const profileTargetWeightKg = useProfileStore((s) => s.profile.targetWeightKg);
  const evolutionRecords = useEvolutionStore((s) => s.records);
  const [openGoalsRequestKey, setOpenGoalsRequestKey] = useState(0);

  const bodyComparison = useMemo(() => {
    const chronological = sortMeasurementsChronologically(evolutionRecords);
    const latestWeight = chronological[chronological.length - 1]?.weightKg;
    const currentWeightKg = Number.isFinite(latestWeight)
      ? latestWeight ?? null
      : profileConfigured && Number.isFinite(profileCurrentWeightKg)
      ? profileCurrentWeightKg
      : null;
    const targetWeightKg =
      profileConfigured && Number.isFinite(profileTargetWeightKg)
        ? profileTargetWeightKg
        : null;
    return {
      currentWeightKg,
      targetWeightKg,
      profileConfigured,
    };
  }, [evolutionRecords, profileConfigured, profileCurrentWeightKg, profileTargetWeightKg]);

  const totals = useMemo(
    () => computeNutritionTotals(meals, activeDateKey),
    [meals, activeDateKey],
  );
  const daySummary = useMemo(
    () => computeDayPlanSummary(meals, activeDateKey),
    [meals, activeDateKey],
  );
  const macroGoals = useMemo(
    () => ({
      carbsG: dailyGoals.carbsG,
      proteinG: dailyGoals.proteinG,
      fatG: dailyGoals.fatG,
    }),
    [dailyGoals.carbsG, dailyGoals.proteinG, dailyGoals.fatG],
  );

  const handleOpenGoals = useCallback(() => {
    setOpenGoalsRequestKey((prev) => prev + 1);
  }, []);

  const handleFocusHydration = useCallback(() => {
    if (typeof document === 'undefined') return;
    const target = document.getElementById('cockpit-hydration');
    target?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }, []);

  const handleOpenExerciseLibrary = useMemo(
    () => (onOpenExerciseLibrary ? (muscleId?: MuscleGroupId) => onOpenExerciseLibrary(muscleId) : undefined),
    [onOpenExerciseLibrary],
  );

  return (
    <div className="space-y-5 sm:space-y-6">
      <HomeHeader openGoalsRequestKey={openGoalsRequestKey} />

      <DailyStatusStrip
        activeDateKey={activeDateKey}
        daySummary={daySummary}
        onOpenNutrition={onOpenNutrition}
        onOpenTraining={onOpenTraining}
        onOpenEvolution={onOpenEvolution}
        onFocusHydration={handleFocusHydration}
        onOpenGoals={handleOpenGoals}
      />

      {/* Product hierarchy: anatomy leads; metrics and actions support it. */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-5 items-start">
        <div className="lg:col-span-7 min-w-0 space-y-4 sm:space-y-5">
          <AnatomyViewport
            onOpenExerciseLibrary={handleOpenExerciseLibrary}
            bodyComparison={bodyComparison}
          />
          <section aria-label="Resumo nutricional do dia" className="grid grid-cols-1 gap-4 sm:gap-5">
            <EnergySummary
              consumedKcal={totals.kcal}
              goalKcal={dailyGoals.kcal}
              plannedRemainingKcal={daySummary.plannedRemainingKcal}
              plannedMealsCount={daySummary.plannedMealsCount}
              isEstimatedGoal={!profileConfigured}
              dataCoveragePercent={totals.dataCoveragePercent}
              unresolvedFoodCount={totals.unresolvedFoodCount}
              lowConfidenceFoodCount={totals.lowConfidenceFoodCount}
              onOpenNutrition={onOpenNutrition}
            />
            <MacroOverview
              carbsG={totals.carbsG}
              proteinG={totals.proteinG}
              fatG={totals.fatG}
              goals={macroGoals}
              plannedRemaining={daySummary.plannedRemainingMacros}
              isEstimatedGoal={!profileConfigured}
              onOpenNutrition={onOpenNutrition}
            />
          </section>
          <EvolutionOverview onOpenEvolution={onOpenEvolution} />
        </div>

        <div className="lg:col-span-5 min-w-0 space-y-4 sm:space-y-5">
          <TodayWorkout
            onOpenTraining={onOpenTraining}
            onOpenTrainingPlans={onOpenTrainingPlans}
            onOpenExerciseLibrary={onOpenExerciseLibrary}
          />
          <HydrationSummary
            isEstimatedGoal={!profileConfigured}
            onOpenGoals={handleOpenGoals}
          />
          <ExerciseHydrationCalculator />
          <NextMeal
            meal={daySummary.nextPlannedMeal}
            daySummary={daySummary}
            onOpenNutrition={onOpenNutrition}
          />
          <MicronutrientSummary onOpenNutrition={onOpenNutrition} />
        </div>
      </div>
    </div>
  );
}
