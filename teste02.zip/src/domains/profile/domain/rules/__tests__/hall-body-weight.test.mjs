import assert from 'node:assert/strict';
import { estimateHallBodyFatPercent, estimateHallEffectiveEnergyDensityKcalPerKg, simulateHallBodyWeight, solveHallDailyIntakeForTarget } from '../hall-body-weight.ts';

const base = {
  sex: 'male', age: 29, heightCm: 179, initialWeightKg: 79.1,
  baselineTdeeKcal: 2_700, targetWeightKg: 82, days: 90,
};

const estimatedBodyFat = estimateHallBodyFatPercent(base);
assert.ok(estimatedBodyFat > 10 && estimatedBodyFat < 30);
const density = estimateHallEffectiveEnergyDensityKcalPerKg({
  sex: 'male', age: 29, heightCm: 179, weightKg: 79.1,
});
assert.ok(density > 4_000 && density < 8_000, `Unexpected Hall-derived energy density ${density}`);
assert.throws(() => estimateHallBodyFatPercent({ ...base, age: 1 }), /faixa plausível/);
assert.throws(() => simulateHallBodyWeight(base, 100), /Ingestão diária/);

const maintenance = simulateHallBodyWeight({ ...base, targetWeightKg: 79.1, days: 180 }, 2_700);
assert.ok(Math.abs(maintenance.predictedWeightKg - 79.1) < 0.02,
  `Maintenance simulation should be stable, got ${maintenance.predictedWeightKg}`);
const femaleMaintenance = simulateHallBodyWeight({ sex: 'female', age: 35, heightCm: 165, initialWeightKg: 63, baselineTdeeKcal: 2_200, targetWeightKg: 63, days: 180 }, 2_200);
assert.ok(Math.abs(femaleMaintenance.predictedWeightKg - 63) < 0.02, `Female maintenance simulation should be stable, got ${femaleMaintenance.predictedWeightKg}`);
assert.equal(maintenance.model, 'hall_2011_adult_energy_balance_core_v1');
assert.equal(maintenance.bodyFatInitialization, 'jackson_equation_estimate');
assert.ok(maintenance.warnings.some((warning) => warning.includes('45%')));

const loss = simulateHallBodyWeight({ ...base, targetWeightKg: 75, days: 90 }, 2_300);
const gain = simulateHallBodyWeight({ ...base, targetWeightKg: 83, days: 90 }, 3_100);
assert.ok(loss.predictedWeightKg < maintenance.predictedWeightKg, 'Lower daily intake should reduce predicted weight.');
assert.ok(gain.predictedWeightKg > maintenance.predictedWeightKg, 'Higher daily intake should increase predicted weight.');

const solved = solveHallDailyIntakeForTarget({ ...base, targetWeightKg: 78, days: 90 });
assert.ok(solved.dailyIntakeKcal >= 700 && solved.dailyIntakeKcal <= 8_000);
assert.ok(solved.absoluteTargetErrorKg >= 0);
assert.equal(solved.targetWeightKg, 78);
assert.equal(solved.model, 'hall_2011_adult_energy_balance_core_v1');
assert.throws(() => solveHallDailyIntakeForTarget({ ...base, days: 4_000 }), /prazo máximo/);

const measuredComposition = simulateHallBodyWeight({ ...base, bodyFatPercent: 18, days: 90 }, 2_700);
assert.equal(measuredComposition.bodyFatInitialization, 'user_supplied');
assert.ok(!measuredComposition.warnings.some((warning) => warning.includes('composição corporal inicial estimada')));
console.log('PASS Hall 2011 dynamic body-weight model: maintenance, directionality, intake solver and validation');
