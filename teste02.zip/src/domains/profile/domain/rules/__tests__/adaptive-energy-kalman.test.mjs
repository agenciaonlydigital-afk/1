import assert from 'node:assert/strict';
import { estimateAdaptiveTdee } from '../adaptive-energy.ts';
const start = Date.UTC(2026, 0, 1);
const intake = Array.from({ length: 84 }, (_, index) => ({
  dateKey: new Date(start + index * 86_400_000).toISOString().slice(0, 10),
  consumedKcal: 2500 + Math.round(80 * Math.sin(index * 1.7)),
  completeness: 'complete',
}));
let weight = 80;
const weights = [];
for (let day = 0; day < 84; day += 2) {
  const noise = 0.08 * Math.sin(day * 2.1) + 0.04 * Math.cos(day * 0.7);
  weights.push({
    id: `w-${day}`,
    dateKey: new Date(start + day * 86_400_000).toISOString().slice(0, 10),
    dateLabel: '', weightKg: weight + noise, waistCm: 85, armCm: 35, thighCm: 55,
  });
  weight -= 0.01 * 2;
}
const estimate = estimateAdaptiveTdee(intake, weights, 28);
assert.ok(estimate);
assert.ok(estimate.measurementWindows >= 5);
assert.ok(Math.abs(estimate.estimateKcal - 2570) < 130, `estimate=${estimate.estimateKcal}`);
assert.ok(estimate.lowerBoundKcal <= estimate.estimateKcal && estimate.estimateKcal <= estimate.upperBoundKcal);
assert.equal(estimate.estimator, 'robust_rolling_energy_balance_kalman_v2_hall_composition_density');
const compositionAware = estimateAdaptiveTdee(intake, weights, 28, { sex: 'male', age: 30, heightCm: 180, weightKg: 80, bodyFatPercent: 18 });
assert.ok(compositionAware);
assert.notEqual(compositionAware.energyDensityAssumptionKcalPerKg, 7000);
assert.ok(!compositionAware.warnings.some((warning) => warning.includes('aproximação legada')));
const noComposition = estimateAdaptiveTdee(intake, weights, 28);
assert.ok(noComposition?.warnings.some((warning) => warning.includes('7.000 kcal/kg')));
const oneOutlier = [...weights, { ...weights[10], id: 'outlier', dateKey: weights[10].dateKey, weightKg: 120 }];
const robust = estimateAdaptiveTdee(intake, oneOutlier, 28);
assert.ok(robust);
assert.ok(Math.abs(robust.estimateKcal - estimate.estimateKcal) < 100, 'same-day extreme duplicate weigh-in should be robustly consolidated');
console.log('PASS adaptive Kalman convergence, uncertainty band, repeated windows and same-day outlier resistance');
