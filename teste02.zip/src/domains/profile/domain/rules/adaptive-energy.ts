import type { BodyMeasurementRecord } from '@/src/shared/types/body-measurement';
import { estimateHallEffectiveEnergyDensityKcalPerKg } from './hall-body-weight.ts';
import type { BiologicalSex } from '../contracts/user-profile';

export interface DailyEnergyIntakeRecord {
  dateKey: string;
  consumedKcal: number;
  completeness: 'complete' | 'partial' | 'fasted';
}

export interface AdaptiveTdeeEstimate {
  estimateKcal: number;
  lowerBoundKcal: number;
  upperBoundKcal: number;
  meanIntakeKcal: number;
  observedWeightChangeKgPerWeek: number;
  energyDensityAssumptionKcalPerKg: number;
  coveredDays: number;
  expectedDays: number;
  coveragePercent: number;
  confidence: 'low' | 'moderate' | 'higher';
  method: 'observed_intake_plus_weight_trend';
  intervalKind: 'kalman_model_based_95pct_not_externally_calibrated';
  estimator: 'robust_rolling_energy_balance_kalman_v2_hall_composition_density';
  uncertaintyKcal: number;
  measurementWindows: number;
  warnings: string[];
}

const LEGACY_ENERGY_DENSITY_KCAL_PER_KG = 7_000;

export interface AdaptiveEnergyBodyComposition {
  sex: BiologicalSex;
  age: number;
  heightCm: number;
  weightKg: number;
  bodyFatPercent?: number;
}
const DAY_MS = 86_400_000;
const WINDOW_DAYS = 28;
const UPDATE_INTERVAL_DAYS = 7;
const MIN_INTAKE_DAYS = 14;
const MIN_WEIGHT_DAYS = 4;
const MIN_WEIGHT_SPAN_DAYS = 14;
const INITIAL_UNCERTAINTY_KCAL = 250;
const PROCESS_NOISE_KCAL_PER_SQRT_DAY = 80;
const INTAKE_LOG_NOISE_KCAL = 250;
const SYSTEMATIC_INTAKE_FLOOR_KCAL = 90;
const WEIGHT_NOISE_FLOOR_KG = 0.25;
const OVERLAP_INFLATION = 2.0;

function isRealDateKey(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [year, month, day] = value.split('-').map(Number);
  const date = new Date(Date.UTC(year!, month! - 1, day!));
  return date.getUTCFullYear() === year && date.getUTCMonth() === month! - 1 && date.getUTCDate() === day;
}

function median(values: readonly number[]): number {
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[mid]! : (sorted[mid - 1]! + sorted[mid]!) / 2;
}

function dateTime(dateKey: string): number {
  return Date.parse(`${dateKey}T00:00:00Z`);
}

function theilSenSlope(points: readonly { x: number; y: number }[]): { slope: number; residualSigma: number; sxx: number } | null {
  if (points.length < 2) return null;
  const slopes: number[] = [];
  for (let i = 0; i < points.length; i += 1) {
    for (let j = i + 1; j < points.length; j += 1) {
      const dx = points[j]!.x - points[i]!.x;
      if (dx > 0) slopes.push((points[j]!.y - points[i]!.y) / dx);
    }
  }
  if (!slopes.length) return null;
  const slope = median(slopes);
  const intercept = median(points.map((point) => point.y - slope * point.x));
  const residuals = points.map((point) => Math.abs(point.y - (intercept + slope * point.x)));
  const residualSigma = Math.max(WEIGHT_NOISE_FLOOR_KG, 1.4826 * median(residuals));
  const meanX = points.reduce((sum, point) => sum + point.x, 0) / points.length;
  const sxx = points.reduce((sum, point) => sum + (point.x - meanX) ** 2, 0);
  return { slope, residualSigma, sxx };
}

interface WindowMeasurement {
  anchorTime: number;
  meanIntakeKcal: number;
  weightSlopeKgPerDay: number;
  rawTdeeKcal: number;
  varianceKcal2: number;
  coveredDays: number;
  weightDays: number;
}

function buildWindowMeasurement(
  anchorTime: number,
  periodDays: number,
  intakeByDay: ReadonlyMap<string, number>,
  weightsByDay: ReadonlyMap<string, number>,
  energyDensityKcalPerKg: number,
): WindowMeasurement | null {
  const startTime = anchorTime - (periodDays - 1) * DAY_MS;
  const intakeValues: number[] = [];
  for (const [dateKey, kcal] of intakeByDay) {
    const time = dateTime(dateKey);
    if (time >= startTime && time <= anchorTime) intakeValues.push(kcal);
  }
  if (intakeValues.length < Math.max(MIN_INTAKE_DAYS, Math.ceil(periodDays * 0.6))) return null;

  const weightPoints = [...weightsByDay.entries()]
    .filter(([dateKey]) => dateTime(dateKey) >= startTime && dateTime(dateKey) <= anchorTime)
    .map(([dateKey, kg]) => ({ x: (dateTime(dateKey) - startTime) / DAY_MS, y: kg }))
    .sort((a, b) => a.x - b.x);
  if (weightPoints.length < MIN_WEIGHT_DAYS || weightPoints.at(-1)!.x - weightPoints[0]!.x < MIN_WEIGHT_SPAN_DAYS) return null;

  const regression = theilSenSlope(weightPoints);
  if (!regression) return null;
  const meanIntakeKcal = intakeValues.reduce((sum, value) => sum + value, 0) / intakeValues.length;
  const rawTdeeKcal = meanIntakeKcal - energyDensityKcalPerKg * regression.slope;
  if (!Number.isFinite(rawTdeeKcal) || rawTdeeKcal < 500 || rawTdeeKcal > 8_000) return null;

  const intakeSampleVariance = intakeValues.length > 1
    ? intakeValues.reduce((sum, value) => sum + (value - meanIntakeKcal) ** 2, 0) / (intakeValues.length - 1)
    : 0;
  const intakeVarianceOfMean = Math.max(
    (INTAKE_LOG_NOISE_KCAL ** 2) / intakeValues.length,
    intakeSampleVariance / intakeValues.length,
  );
  const slopeVariance = (regression.residualSigma ** 2) / Math.max(1, regression.sxx);
  const weightEnergyVariance = (energyDensityKcalPerKg ** 2) * slopeVariance;
  const systematicFloorVariance = SYSTEMATIC_INTAKE_FLOOR_KCAL ** 2;
  const varianceKcal2 = (intakeVarianceOfMean + weightEnergyVariance + systematicFloorVariance) * OVERLAP_INFLATION;
  return {
    anchorTime,
    meanIntakeKcal,
    weightSlopeKgPerDay: regression.slope,
    rawTdeeKcal,
    varianceKcal2,
    coveredDays: intakeValues.length,
    weightDays: weightPoints.length,
  };
}

/**
 * Robust adaptive TDEE estimator. Daily duplicates are consolidated by median,
 * weight slope uses Theil–Sen robust regression, and non-overlapping weekly
 * Kalman updates learn the latent expenditure. The model-based interval is not
 * externally calibrated and must not be presented as a clinical confidence interval.
 */
export function estimateAdaptiveTdee(
  intake: readonly DailyEnergyIntakeRecord[],
  weights: readonly BodyMeasurementRecord[],
  periodDays = WINDOW_DAYS,
  bodyComposition?: AdaptiveEnergyBodyComposition,
): AdaptiveTdeeEstimate | null {
  if (!Number.isInteger(periodDays) || periodDays < 21 || periodDays > 90) {
    throw new RangeError('A janela adaptativa deve ficar entre 21 e 90 dias.');
  }
  const validIntake = intake.filter((entry) => {
    const validFastedDay = entry.completeness === 'fasted' && entry.consumedKcal === 0;
    const validLoggedDay = entry.completeness === 'complete' && Number.isFinite(entry.consumedKcal) && entry.consumedKcal >= 500 && entry.consumedKcal <= 8_000;
    return isRealDateKey(entry.dateKey) && Number.isFinite(entry.consumedKcal) && (validFastedDay || validLoggedDay);
  });
  const intakeValuesByDay = new Map<string, number[]>();
  for (const entry of validIntake) {
    const values = intakeValuesByDay.get(entry.dateKey) ?? [];
    values.push(entry.consumedKcal);
    intakeValuesByDay.set(entry.dateKey, values);
  }
  let conflictingIntakeDays = 0;
  const intakeByDay = new Map<string, number>();
  for (const [dateKey, values] of intakeValuesByDay) {
    if (Math.max(...values) - Math.min(...values) > 500) { conflictingIntakeDays += 1; continue; }
    intakeByDay.set(dateKey, median(values));
  }
  const validWeights = weights.filter((record) => isRealDateKey(record.dateKey) &&
    Number.isFinite(record.weightKg) && record.weightKg >= 30 && record.weightKg <= 300);
  const weightValuesByDay = new Map<string, number[]>();
  for (const record of validWeights) {
    const values = weightValuesByDay.get(record.dateKey) ?? [];
    values.push(record.weightKg);
    weightValuesByDay.set(record.dateKey, values);
  }
  let conflictingWeightDays = 0;
  const weightsByDay = new Map<string, number>();
  for (const [dateKey, values] of weightValuesByDay) {
    if (Math.max(...values) - Math.min(...values) > 2) { conflictingWeightDays += 1; continue; }
    weightsByDay.set(dateKey, median(values));
  }
  if (intakeByDay.size < MIN_INTAKE_DAYS || weightsByDay.size < MIN_WEIGHT_DAYS) return null;

  const latestIntakeTime = Math.max(...[...intakeByDay.keys()].map(dateTime));
  const latestWeightTime = Math.max(...[...weightsByDay.keys()].map(dateTime));
  const anchorTime = Math.min(latestIntakeTime, latestWeightTime);
  const firstTime = Math.min(...[...intakeByDay.keys(), ...weightsByDay.keys()].map(dateTime));
  if (anchorTime - firstTime < (periodDays - 1) * DAY_MS) return null;

  let energyDensityKcalPerKg = LEGACY_ENERGY_DENSITY_KCAL_PER_KG;
  let compositionWarning: string | null = null;
  if (bodyComposition) {
    const latestWeightKg = weightsByDay.get(new Date(anchorTime).toISOString().slice(0, 10)) ?? bodyComposition.weightKg;
    try {
      energyDensityKcalPerKg = estimateHallEffectiveEnergyDensityKcalPerKg({
        sex: bodyComposition.sex, age: bodyComposition.age, heightCm: bodyComposition.heightCm,
        weightKg: latestWeightKg, bodyFatPercent: bodyComposition.bodyFatPercent,
      });
      if (bodyComposition.bodyFatPercent === undefined) {
        compositionWarning = 'A densidade energética adaptativa usa percentual de gordura estimado pela equação antropométrica de Hall, não composição medida.';
      }
    } catch (error) {
      compositionWarning = `Não foi possível estimar densidade energética por composição corporal (${error instanceof Error ? error.message : 'entrada inválida'}); foi usada a aproximação legada de 7.000 kcal/kg.`;
    }
  } else {
    compositionWarning = 'Sem sexo, idade, altura e composição corporal, foi mantida a aproximação legada de 7.000 kcal/kg; forneça o perfil para usar a densidade derivada do modelo de Hall.';
  }
  const firstCheckpoint = firstTime + (periodDays - 1) * DAY_MS;
  const measurements: WindowMeasurement[] = [];
  for (let time = firstCheckpoint; time <= anchorTime; time += UPDATE_INTERVAL_DAYS * DAY_MS) {
    const measurement = buildWindowMeasurement(time, periodDays, intakeByDay, weightsByDay, energyDensityKcalPerKg);
    if (measurement) measurements.push(measurement);
  }
  const finalWindow = buildWindowMeasurement(anchorTime, periodDays, intakeByDay, weightsByDay, energyDensityKcalPerKg);
  if (finalWindow && measurements.at(-1)?.anchorTime !== anchorTime) measurements.push(finalWindow);
  if (!measurements.length) return null;

  let estimate = measurements[0]!.rawTdeeKcal;
  let variance = INITIAL_UNCERTAINTY_KCAL ** 2;
  let lastUpdateTime = measurements[0]!.anchorTime;
  let rejectedMeasurements = 0;
  for (let index = 1; index < measurements.length; index += 1) {
    const measurement = measurements[index]!;
    const elapsedDays = Math.max(1, (measurement.anchorTime - lastUpdateTime) / DAY_MS);
    variance += PROCESS_NOISE_KCAL_PER_SQRT_DAY ** 2 * elapsedDays;
    const innovation = measurement.rawTdeeKcal - estimate;
    const innovationSigma = Math.sqrt(variance + measurement.varianceKcal2);
    // Grossly inconsistent windows are down-weighted by rejecting the observation;
    // this prevents one bad log/import from dominating a stable personal baseline.
    if (Math.abs(innovation) > 4 * innovationSigma) {
      rejectedMeasurements += 1;
      lastUpdateTime = measurement.anchorTime;
      continue;
    }
    const gain = variance / (variance + measurement.varianceKcal2);
    estimate += gain * innovation;
    variance *= 1 - gain;
    lastUpdateTime = measurement.anchorTime;
  }

  if (!Number.isFinite(estimate) || estimate < 500 || estimate > 8_000) return null;
  const latest = measurements.at(-1)!;
  const coveragePercent = Math.min(100, latest.coveredDays / periodDays * 100);
  const uncertaintyKcal = 1.96 * Math.sqrt(variance);
  const lowerBoundKcal = Math.max(500, Math.round(estimate - uncertaintyKcal));
  const upperBoundKcal = Math.min(8_000, Math.round(estimate + uncertaintyKcal));
  const observedWeightChangeKgPerWeek = latest.weightSlopeKgPerDay * 7;
  const warnings = [
    'O TDEE é inferido de ingestão registrada e tendência de peso; sub-registro alimentar e mudanças de água/glicogênio podem enviesar a estimativa.',
    'Dias sem registro são ignorados; dias explicitamente marcados como jejum completo entram como 0 kcal; dias parciais são excluídos.',
    'A faixa apresentada é derivada da variância interna do filtro de Kalman; ainda não foi calibrada externamente e não é intervalo de confiança clínico.',
    'O modelo estima gasto energético total observado; não separa metabolismo basal, NEAT, exercício e termogênese adaptativa sem dados adicionais.',
    'A densidade energética por composição é uma aproximação local derivada da partição de tecido do modelo de Hall; não substitui a simulação dinâmica completa nem corrige mudanças transitórias de água/glicogênio.',
  ];
  if (compositionWarning) warnings.push(compositionWarning);
  if (validIntake.length > intakeByDay.size) warnings.push('Foram encontradas entradas diárias duplicadas de ingestão; elas foram consolidadas por mediana por data.');
  if (validWeights.length > weightsByDay.size) warnings.push('Pesagens duplicadas no mesmo dia foram consolidadas por mediana; dias com divergência superior a 2 kg foram excluídos.');
  if (conflictingIntakeDays > 0) warnings.push(`${conflictingIntakeDays} dia(s) com totais de ingestão duplicados divergindo mais de 500 kcal foram excluídos da calibração.`);
  if (conflictingWeightDays > 0) warnings.push(`${conflictingWeightDays} dia(s) com pesagens duplicadas divergindo mais de 2 kg foram excluídos da calibração.`);
  if (coveragePercent < 80) warnings.push('Cobertura alimentar abaixo de 80%; a incerteza real pode ser maior que a faixa calculada.');
  if (rejectedMeasurements > 0) warnings.push(`${rejectedMeasurements} janela(s) muito discrepante(s) foram rejeitadas pelo filtro; verifique ingestão e pesagens.`);
  const confidence = coveragePercent >= 85 && latest.weightDays >= 20 && measurements.length >= 6 && uncertaintyKcal <= 350
    ? 'higher'
    : coveragePercent >= 70 && latest.weightDays >= 4 && uncertaintyKcal <= 550 ? 'moderate' : 'low';
  return {
    estimateKcal: Math.round(estimate),
    lowerBoundKcal,
    upperBoundKcal,
    meanIntakeKcal: Math.round(latest.meanIntakeKcal),
    observedWeightChangeKgPerWeek: Number(observedWeightChangeKgPerWeek.toFixed(3)),
    energyDensityAssumptionKcalPerKg: Number(energyDensityKcalPerKg.toFixed(0)),
    coveredDays: latest.coveredDays,
    expectedDays: periodDays,
    coveragePercent: Number(coveragePercent.toFixed(1)),
    confidence,
    method: 'observed_intake_plus_weight_trend',
    intervalKind: 'kalman_model_based_95pct_not_externally_calibrated',
    estimator: 'robust_rolling_energy_balance_kalman_v2_hall_composition_density',
    uncertaintyKcal: Math.round(uncertaintyKcal),
    measurementWindows: measurements.length,
    warnings,
  };
}
