import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { safeStorageAdapter } from '@/src/infrastructure/storage/local-storage';
import type { UserPhysiologicalProfile } from '../domain/contracts/user-profile';
import { mergeProfilePersistedState, type PersistedProfileState } from './profile-persistence';

interface ProfileState {
  profile: UserPhysiologicalProfile;
  profileConfigured: boolean;
  updateProfile: (next: UserPhysiologicalProfile) => void;
}

const DEFAULT_PROFILE: UserPhysiologicalProfile = {
  sex: 'male',
  goal: 'gain_muscle',
  currentWeightKg: 79.1,
  targetWeightKg: 82.0,
  activityLevel: 'moderate',
  deadlineDateKey: '2027-02-20',
  heightCm: 179,
  age: 29,
};

export const useProfileStore = create<ProfileState>()(persist<ProfileState, [], [], PersistedProfileState>(
  (set) => ({
    profile: DEFAULT_PROFILE,
    profileConfigured: false,
    updateProfile: (next) => set({ profile: next, profileConfigured: true }),
  }),
  {
    name: 'titan:profile:v1',
    version: 1,
    storage: createJSONStorage(() => safeStorageAdapter),
    partialize: (state) => ({ profile: state.profile, profileConfigured: state.profileConfigured }),
    migrate: (persisted) => mergeProfilePersistedState(persisted, { profile: DEFAULT_PROFILE, profileConfigured: false }),
    merge: (persisted, current) => ({
      ...current,
      ...mergeProfilePersistedState(persisted, current),
    }),
  },
));
