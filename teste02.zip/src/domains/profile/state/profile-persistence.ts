import { isValidLocalDateKey } from '../../../shared/utils/local-date.ts';
import type { UserPhysiologicalProfile } from '../domain/contracts/user-profile';

export interface PersistedProfileState {
  profile: UserPhysiologicalProfile;
  profileConfigured: boolean;
}

const SEXES = ['male', 'female'] as const;
const GOALS = ['gain_muscle', 'lose_weight', 'recomposition', 'maintain'] as const;
const ACTIVITY_LEVELS = ['sedentary', 'light', 'moderate', 'high', 'very_high'] as const;
const RMR_METHODS = ['mifflin_st_jeor', 'pavlidou_2023', 'cunningham_1980', 'katch_mcardle', 'ten_haaf_2014'] as const;
const FFM_SOURCES = ['dexa', 'bod_pod', 'isotope_dilution', 'validated_bioimpedance', 'other'] as const;

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function isFiniteInRange(value: unknown, min: number, max: number): value is number {
  return typeof value === 'number' && Number.isFinite(value) && value >= min && value <= max;
}

function isValidProfile(value: unknown): value is UserPhysiologicalProfile {
  if (!isRecord(value)) return false;
  return (
    SEXES.includes(value.sex as typeof SEXES[number]) &&
    GOALS.includes(value.goal as typeof GOALS[number]) &&
    isFiniteInRange(value.currentWeightKg, 30, 300) &&
    isFiniteInRange(value.targetWeightKg, 30, 300) &&
    ACTIVITY_LEVELS.includes(value.activityLevel as typeof ACTIVITY_LEVELS[number]) &&
    typeof value.deadlineDateKey === 'string' && isValidLocalDateKey(value.deadlineDateKey) &&
    isFiniteInRange(value.heightCm, 110, 245) &&
    isFiniteInRange(value.age, 19, 105) && Number.isInteger(value.age) &&
    (value.rmrMethod === undefined || RMR_METHODS.includes(value.rmrMethod as typeof RMR_METHODS[number])) &&
    (value.measuredRmrKcal === undefined || isFiniteInRange(value.measuredRmrKcal, 300, 5000)) &&
    (value.bodyFatPercent === undefined || isFiniteInRange(value.bodyFatPercent, 2, 70)) &&
    (value.fatFreeMassSource === undefined || FFM_SOURCES.includes(value.fatFreeMassSource as typeof FFM_SOURCES[number])) &&
    (value.bodyFatPercent === undefined || value.fatFreeMassSource !== undefined) &&
    (!['cunningham_1980', 'katch_mcardle'].includes(String(value.rmrMethod ?? 'mifflin_st_jeor')) || value.measuredRmrKcal !== undefined ||
      (value.bodyFatPercent !== undefined && value.fatFreeMassSource !== undefined))
  );
}

function sameProfile(a: UserPhysiologicalProfile, b: UserPhysiologicalProfile): boolean {
  return a.sex === b.sex && a.goal === b.goal && a.currentWeightKg === b.currentWeightKg &&
    a.targetWeightKg === b.targetWeightKg && a.activityLevel === b.activityLevel &&
    a.deadlineDateKey === b.deadlineDateKey && a.heightCm === b.heightCm && a.age === b.age &&
    a.rmrMethod === b.rmrMethod && a.measuredRmrKcal === b.measuredRmrKcal &&
    a.bodyFatPercent === b.bodyFatPercent && a.fatFreeMassSource === b.fatFreeMassSource;
}

export function mergeProfilePersistedState(
  persisted: unknown,
  current: PersistedProfileState,
): PersistedProfileState {
  if (!isRecord(persisted) || !isValidProfile(persisted.profile)) return current;
  // V1 profiles had no explicit setup flag. Treat the old hard-coded default as a placeholder,
  // but preserve profiles that differ from it as user-configured data.
  const configured = typeof persisted.profileConfigured === 'boolean'
    ? persisted.profileConfigured
    : !sameProfile(persisted.profile, current.profile);
  return { profile: persisted.profile, profileConfigured: configured };
}
