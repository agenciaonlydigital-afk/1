import { parseLocalDateKey } from '@/src/shared/utils/local-date';

export interface CalendarDayDescriptor {
  key: string;
  shortLabel: string;
  fullLabel: string;
}

export interface CalendarCell {
  dateKey: string;
  dayNumber: number;
  inCurrentMonth: boolean;
}

const WEEKDAYS_FULL = [
  'Domingo',
  'Segunda',
  'Terça',
  'Quarta',
  'Quinta',
  'Sexta',
  'Sábado',
] as const;

const WEEKDAYS_SHORT = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'] as const;

const MONTHS_SHORT = [
  'jan',
  'fev',
  'mar',
  'abr',
  'mai',
  'jun',
  'jul',
  'ago',
  'set',
  'out',
  'nov',
  'dez',
] as const;

export const MONTHS_FULL = [
  'Janeiro',
  'Fevereiro',
  'Março',
  'Abril',
  'Maio',
  'Junho',
  'Julho',
  'Agosto',
  'Setembro',
  'Outubro',
  'Novembro',
  'Dezembro',
] as const;

export function parseDateKeyParts(dateKey: string): {
  year: number;
  month: number;
  day: number;
} {
  const parts = parseLocalDateKey(dateKey);
  if (!parts) throw new RangeError(`Data do calendário inválida: ${dateKey}`);
  return parts;
}

export function toDateKey(year: number, month: number, day: number): string {
  return `${String(year).padStart(4, '0')}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
}

export function formatCalendarLabels(dateKey: string): CalendarDayDescriptor {
  const { year, month, day } = parseDateKeyParts(dateKey);
  const utc = new Date(Date.UTC(year, month - 1, day));
  const weekdayIdx = utc.getUTCDay();
  const weekdayFull = WEEKDAYS_FULL[weekdayIdx] ?? 'Dia';
  const weekdayShort = WEEKDAYS_SHORT[weekdayIdx] ?? 'Dia';
  const monthShort = MONTHS_SHORT[month - 1] ?? 'mês';

  return {
    key: dateKey,
    shortLabel: `${weekdayShort} · ${day}`,
    fullLabel: `${weekdayFull}, ${day} ${monthShort}`,
  };
}

export function formatNumericDateBR(dateKey: string): string {
  const { year, month, day } = parseDateKeyParts(dateKey);
  return `${String(day).padStart(2, '0')}/${String(month).padStart(2, '0')}/${year}`;
}

export function buildMonthMatrix(year: number, month: number): CalendarCell[] {
  const firstDayUtc = new Date(Date.UTC(year, month - 1, 1));
  const startOffset = firstDayUtc.getUTCDay();
  const gridStart = new Date(Date.UTC(year, month - 1, 1 - startOffset));

  const cells: CalendarCell[] = [];
  for (let i = 0; i < 42; i += 1) {
    const d = new Date(gridStart.getTime() + i * 86_400_000);
    const y = d.getUTCFullYear();
    const m = d.getUTCMonth() + 1;
    const dayNum = d.getUTCDate();
    cells.push({
      dateKey: toDateKey(y, m, dayNum),
      dayNumber: dayNum,
      inCurrentMonth: y === year && m === month,
    });
  }
  return cells;
}
