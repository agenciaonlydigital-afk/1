import { lazy, startTransition, Suspense, useEffect, useMemo, useState } from 'react';
import { Apple, BookOpen, CalendarDays, Check, RotateCcw, SkipForward, Utensils } from 'lucide-react';
import { Surface } from '@/src/shared/ui/Surface';
import { formatKcal } from '@/src/shared/utils/formatters';
import {
  computeNutritionTotals,
  getMealMacros,
  useNutritionStore,
} from '../state/nutrition.store';
import type { MealConsumptionStatus } from '../domain/entities/nutrient';
import { CustomMealEditor } from '../components/CustomMealEditor';
import { resolveDriProfileId, useProfileStore } from '@/src/domains/profile/application/profile-public';

const FoodCatalogBrowser = lazy(() =>
  import('../components/FoodCatalogBrowser').then((m) => ({ default: m.FoodCatalogBrowser })),
);
const RecipeCatalogBrowser = lazy(() =>
  import('../components/RecipeCatalogBrowser').then((m) => ({ default: m.RecipeCatalogBrowser })),
);

const STATUS_LABELS: Record<MealConsumptionStatus, string> = {
  planned: 'Planejada',
  consumed: 'Consumida',
  partial: 'Parcial',
  substituted: 'Substituída',
  skipped: 'Pulada',
};

function MealThumbnail({ src, title }: { src?: string; title: string }) {
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    setFailed(false);
  }, [src]);

  if (!src || failed) {
    return (
      <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)]/70 flex items-center justify-center shrink-0">
        <Utensils className="w-6 h-6 text-[var(--titan-accent)]" />
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={title}
      referrerPolicy="no-referrer"
      loading="lazy"
      decoding="async"
      onError={() => setFailed(true)}
      className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover shrink-0 border border-[var(--titan-border)]/70"
    />
  );
}

export type NutritionSection = 'cardapio' | 'receitas' | 'alimentos';

interface NutritionWorkspaceProps {
  section?: NutritionSection;
  onSectionChange?: (section: NutritionSection) => void;
}

export function NutritionWorkspace({
  section,
  onSectionChange,
}: NutritionWorkspaceProps = {}) {
  const [internalSection, setInternalSection] = useState<NutritionSection>('cardapio');
  const activeSection = section ?? internalSection;
  const handleSectionChange = (nextSection: NutritionSection) => {
    startTransition(() => {
      if (onSectionChange) {
        onSectionChange(nextSection);
      } else {
        setInternalSection(nextSection);
      }
    });
  };
  const meals = useNutritionStore((s) => s.meals);
  const activeDateKey = useNutritionStore((s) => s.activeDateKey);
  const dailyGoals = useNutritionStore((s) => s.dailyGoals);
  const confirmMealConsumed = useNutritionStore((s) => s.confirmMealConsumed);
  const setMealPartial = useNutritionStore((s) => s.setMealPartial);
  const skipMeal = useNutritionStore((s) => s.skipMeal);
  const restoreMealPlanned = useNutritionStore((s) => s.restoreMealPlanned);
  const confirmIntakeDay = useNutritionStore((s) => s.confirmIntakeDay);
  const intakeDayConfirmations = useNutritionStore((s) => s.intakeDayConfirmations);
  const [intakeFeedback, setIntakeFeedback] = useState<string | null>(null);
  const setReferenceProfileId = useNutritionStore((s) => s.setReferenceProfileId);
  const physiologicalProfile = useProfileStore((s) => s.profile);
  const profileConfigured = useProfileStore((s) => s.profileConfigured);
  const driProfileId = resolveDriProfileId(physiologicalProfile.sex, physiologicalProfile.age);

  useEffect(() => {
    if (!profileConfigured) return;
    setReferenceProfileId(driProfileId);
  }, [profileConfigured, driProfileId, setReferenceProfileId]);

  const dayMeals = useMemo(
    () => meals.filter((m) => m.dateKey === activeDateKey),
    [meals, activeDateKey],
  );
  const totals = useMemo(
    () => computeNutritionTotals(meals, activeDateKey),
    [meals, activeDateKey],
  );
  const isIntakeDayConfirmed = intakeDayConfirmations.includes(activeDateKey);
  const canConfirmIntakeDay = dayMeals.length > 0 && dayMeals.every((meal) => meal.status !== 'planned');

  return (
    <div className="space-y-6">
      <div className="titan-page-heading">
        <p className="titan-eyebrow">Nutrição diária</p>
        <h1 className="text-2xl font-semibold text-[var(--titan-text-primary)]">Nutrição</h1>
        <p className="text-xs text-[var(--titan-text-secondary)] mt-0.5">
          Cardápios → Receitas → Alimentos · Cálculo com dados rastreáveis ({activeDateKey})
        </p>
      </div>

      <div className="titan-segmented grid grid-cols-3 w-full" role="tablist" aria-label="Biblioteca de nutrição">
        {([
          { id: 'cardapio', label: 'Cardápios', icon: CalendarDays },
          { id: 'receitas', label: 'Receitas', icon: BookOpen },
          { id: 'alimentos', label: 'Alimentos', icon: Apple },
        ] as const).map((item) => {
          const Icon = item.icon;
          return <button key={item.id} type="button" role="tab" aria-selected={activeSection === item.id} className={`titan-segment flex items-center justify-center gap-1.5 ${activeSection === item.id ? 'is-active' : ''}`} onClick={() => handleSectionChange(item.id)}><Icon className="w-3.5 h-3.5" />{item.label}</button>;
        })}
      </div>

      {activeSection === 'cardapio' && <>
        {!profileConfigured && <p className="text-[11px] text-[var(--titan-status-warning)]" role="note">Configure sexo e idade em Metas para interpretar as referências de micronutrientes. Os valores iniciais são apenas parâmetros temporários.</p>}
      {/* Macro Summary with fixed V1.1 semantic consistency */}
      <Surface className="p-4">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div>
            <div className="text-xs text-[var(--titan-text-secondary)]">Energia</div>
            <div className="text-xl font-semibold font-mono-metric text-[var(--titan-text-primary)] mt-0.5">
              {formatKcal(totals.kcal)}
            </div>
            <div className="text-xs text-[var(--titan-text-muted)] font-mono-metric">
              meta {formatKcal(dailyGoals.kcal)} kcal
            </div>
          </div>
          <div>
            <div className="text-xs text-[var(--titan-text-secondary)]">Carboidratos</div>
            <div className="text-xl font-semibold font-mono-metric text-[var(--titan-info)] mt-0.5">
              {totals.carbsG} g
            </div>
            <div className="text-xs text-[var(--titan-text-muted)] font-mono-metric">
              meta {dailyGoals.carbsG} g
            </div>
          </div>
          <div>
            <div className="text-xs text-[var(--titan-text-secondary)]">Proteínas</div>
            <div className="text-xl font-semibold font-mono-metric text-[var(--titan-accent)] mt-0.5">
              {totals.proteinG} g
            </div>
            <div className="text-xs text-[var(--titan-text-muted)] font-mono-metric">
              meta {dailyGoals.proteinG} g
            </div>
          </div>
          <div>
            <div className="text-xs text-[var(--titan-text-secondary)]">Gorduras</div>
            <div className="text-xl font-semibold font-mono-metric text-[var(--titan-copper)] mt-0.5">
              {totals.fatG} g
            </div>
            <div className="text-xs text-[var(--titan-text-muted)] font-mono-metric">
              meta {dailyGoals.fatG} g
            </div>
          </div>
        </div>
        <p className="mt-3 text-[11px] text-[var(--titan-text-muted)]">
          {totals.dataCoveragePercent === null
            ? 'Confirme refeições consumidas para calcular a cobertura dos dados.'
            : `Cobertura dos alimentos registrados: ${totals.dataCoveragePercent.toFixed(0)}%${totals.unresolvedFoodCount > 0 ? ` · ${totals.unresolvedFoodCount} alimento(s) sem composição` : ''}${totals.lowConfidenceFoodCount > 0 ? ` · ${totals.lowConfidenceFoodCount} rótulo(s) parcial(is)` : ''}`}
        </p>
      </Surface>

      <CustomMealEditor meals={dayMeals} />

      {/* Meal List */}
      <div className="space-y-3">
        {dayMeals.filter((meal) => !meal.id.startsWith('custom-meal-')).length === 0 ? (
          <Surface className="p-5 text-sm text-[var(--titan-text-secondary)]">
            Nenhuma refeição registrada para esta data.
          </Surface>
        ) : (
          dayMeals.filter((meal) => !meal.id.startsWith('custom-meal-')).map((meal) => {
            const macros = getMealMacros(meal);
            const isLogged =
              meal.status === 'consumed' ||
              meal.status === 'partial' ||
              meal.status === 'substituted';

            return (
              <Surface
                key={meal.id}
                className={`p-4 ${isLogged ? 'border-[var(--titan-status-success)]/45' : ''}`}
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                  <div className="flex items-start gap-3.5 min-w-0">
                    <MealThumbnail src={meal.imageUrl} title={meal.title} />
                    <div className="min-w-0">
                      <div className="text-xs text-[var(--titan-text-secondary)] font-mono-metric">
                        {meal.time} · {STATUS_LABELS[meal.status]} · {macros.kcal} kcal
                      </div>
                      <h2 className="text-base font-semibold text-[var(--titan-text-primary)] mt-0.5">
                        {meal.title}
                      </h2>
                      <p className="text-xs text-[var(--titan-text-secondary)] mt-0.5 leading-relaxed">
                        {meal.substitutionNote ?? meal.description}
                      </p>
                      <div className="flex flex-wrap items-center gap-3 mt-2 text-xs font-mono-metric">
                        <span className="text-[var(--titan-accent)]">{macros.proteinG} g Prot.</span>
                        <span className="text-[var(--titan-info)]">{macros.carbsG} g Carb.</span>
                        <span className="text-[var(--titan-copper)]">{macros.fatG} g Gord.</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    {meal.status !== 'consumed' ? (
                      <button
                        type="button"
                        onClick={() => confirmMealConsumed(meal.id)}
                        className="min-h-[44px] px-3.5 rounded-xl border bg-[var(--titan-accent)] border-[var(--titan-accent-strong)]/45 text-[var(--titan-bg-canvas)] flex items-center gap-1.5 text-xs font-semibold whitespace-nowrap"
                      >
                        <Check className="w-4 h-4" />
                        <span>Consumida</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => restoreMealPlanned(meal.id)}
                        className="min-h-[44px] px-3 rounded-xl border bg-[var(--titan-surface-raised)] border-[var(--titan-status-success)]/50 text-[var(--titan-text-primary)] flex items-center gap-1.5 text-xs font-medium whitespace-nowrap"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>Desfazer</span>
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => setMealPartial(meal.id, 0.5)}
                      className={`min-h-[44px] px-3 rounded-xl border text-xs font-medium whitespace-nowrap ${
                        meal.status === 'partial'
                          ? 'bg-[var(--titan-surface-elevated)] border-[var(--titan-accent)] text-[var(--titan-text-primary)]'
                          : 'bg-[var(--titan-surface-raised)] border-[var(--titan-border)] text-[var(--titan-text-secondary)]'
                      }`}
                    >
                      50%
                    </button>

                    <button
                      type="button"
                      onClick={() => skipMeal(meal.id)}
                      aria-label={`Pular ${meal.title}`}
                      className={`min-h-[44px] px-3 rounded-xl border text-xs font-medium flex items-center gap-1 whitespace-nowrap ${
                        meal.status === 'skipped'
                          ? 'bg-[var(--titan-surface-elevated)] border-[var(--titan-status-error)]/60 text-[var(--titan-status-error)]'
                          : 'bg-[var(--titan-surface-raised)] border-[var(--titan-border)] text-[var(--titan-text-secondary)]'
                      }`}
                    >
                      <SkipForward className="w-3.5 h-3.5" />
                      <span>Pular</span>
                    </button>
                  </div>
                </div>
              </Surface>
            );
          })
        )}
      </div>
      <Surface className="p-4 space-y-2">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div><h2 className="text-sm font-semibold text-[var(--titan-text-primary)]">Fechamento do registro alimentar</h2><p className="text-[11px] text-[var(--titan-text-muted)]">Confirme apenas quando todas as refeições e substituições do dia estiverem registradas. Isso ajuda a calibrar o gasto energético com o histórico real.</p></div>
          {isIntakeDayConfirmed ? <span className="text-xs font-semibold text-[var(--titan-status-success)]">Dia confirmado</span> : <button type="button" disabled={!canConfirmIntakeDay} onClick={() => { const result = confirmIntakeDay(activeDateKey); setIntakeFeedback(result.ok ? 'Dia confirmado. Será usado quando houver histórico suficiente.' : result.error); }} className="min-h-[40px] px-3 rounded-xl border border-[var(--titan-border)] text-xs font-semibold text-[var(--titan-text-primary)] disabled:opacity-40 disabled:cursor-not-allowed">Confirmar dia completo</button>}
        </div>
        {intakeFeedback && <p className="text-[11px] text-[var(--titan-text-secondary)]" role="status">{intakeFeedback}</p>}
      </Surface>
      </>}

      {activeSection === 'receitas' && (
        <Suspense fallback={<Surface className="p-4 text-xs text-[var(--titan-text-secondary)]">Carregando catálogo de receitas…</Surface>}>
          <RecipeCatalogBrowser />
        </Suspense>
      )}

      {activeSection === 'alimentos' && (
        <Suspense fallback={<Surface className="p-4 text-xs text-[var(--titan-text-secondary)]">Carregando catálogo de alimentos TBCA…</Surface>}>
          <FoodCatalogBrowser />
        </Suspense>
      )}
    </div>
  );
}


/** Compatibility export for the existing lazy route; nutrition lives in one unified workspace. */
export const CardapioScreen = NutritionWorkspace;
