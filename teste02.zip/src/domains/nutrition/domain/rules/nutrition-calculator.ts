import { DRI_REFERENCE_PROFILES } from '../../data/references/dri-profiles.ts';
import { OPEN_FOOD_FACTS_PRODUCTS } from '../../data/sources/open-food-facts-adapter.ts';
import { TBCA_FOODS } from '../../data/sources/tbca-adapter.ts';
import {
  MICRONUTRIENT_ORDER,
  type DailyReferenceEntry,
  type FoodNutrientRecord,
  type FoodQualityStatus,
  type FoodSourceId,
  type FoodSourceItem,
  type MealFoodPortion,
  type MealItem,
  type NutrientDataStatus,
  type NutrientId,
  type ReferenceKind,
  type ReferenceProfileId,
  type ReferenceProfileSpec,
} from '../entities/nutrient';

export interface FoodContribution {
  foodId: string;
  foodName: string;
  mealTitle: string;
  mealTime: string;
  quantityG: number;
  amount: number | null;
  unit: string;
  originalValue: number | null;
  originalUnit: string;
  sourceId: FoodSourceId;
  sourceVersion: string;
  sourceRecordId: string;
  dataStatus: NutrientDataStatus;
  qualityStatus: FoodQualityStatus;
  conversionMethod: string;
}

export interface AggregatedNutrient {
  nutrientId: NutrientId;
  consumedValue: number | null;
  unit: string;
  dataStatus: NutrientDataStatus;
  contributions: FoodContribution[];
  hasUnquantifiedSources: boolean;
}

export interface ResolvedNutrientDisplay {
  nutrientId: NutrientId;
  consumedValue: number | null;
  unit: string;
  dataStatus: NutrientDataStatus;
  referenceValue: number | null;
  referenceUnit: string;
  referenceKind: ReferenceKind | null;
  referenceSystem: string;
  referenceVersion: string;
  profileLabel: string;
  rawPercent: number | null;
  barPercent: number;
  isExceeded: boolean;
  isLimitMetric: boolean;
  hasUnquantifiedSources: boolean;
  displayMode:
    | 'quantified_progress'
    | 'limit_cdrr'
    | 'trace'
    | 'not_analyzed'
    | 'no_reference';
  contributions: FoodContribution[];
}

export interface ComputedMealMacros {
  kcal: number;
  proteinG: number;
  carbsG: number;
  fatG: number;
}

/** FoodIdentityResolver: resolves food item strictly from its designated single source without mixing bases */
export function resolveFoodById(foodId: string): FoodSourceItem | null {
  if (TBCA_FOODS[foodId]) return TBCA_FOODS[foodId];
  if (OPEN_FOOD_FACTS_PRODUCTS[foodId]) return OPEN_FOOD_FACTS_PRODUCTS[foodId];
  return null;
}

/** NutrientNormalizer: preserves original value/unit and returns traceable normalized record */
export function normalizeNutrientEntry(
  food: FoodSourceItem,
  nutrientId: NutrientId,
): FoodNutrientRecord {
  const entry = food.micronutrients[nutrientId];
  if (!entry) {
    return {
      food_id: food.food_id,
      source_id: food.source_id,
      source_record_id: food.source_record_id,
      nutrient_id: nutrientId,
      original_value: null,
      original_unit: '',
      normalized_value: null,
      normalized_unit: '',
      basis_quantity: food.macros.basisQuantityG,
      data_status: food.source_id === 'OPEN_FOOD_FACTS' ? 'missing' : 'not_analyzed',
      quality_status: food.quality_status,
      source_version: food.source_version,
      conversion_method: 'unavailable',
    };
  }
  return {
    food_id: food.food_id,
    source_id: food.source_id,
    source_record_id: food.source_record_id,
    nutrient_id: nutrientId,
    ...entry,
    quality_status: food.quality_status,
    source_version: food.source_version,
  };
}

export interface PortionMacroQuality {
  macros: ComputedMealMacros;
  requestedGrams: number;
  quantifiedGrams: number;
  coveragePercent: number;
  unresolvedFoodIds: string[];
  lowConfidenceFoodIds: string[];
}

/** Computes macro totals and explicitly reports how much of the requested mass was quantified. */
export function computePortionsMacrosWithQuality(portions: readonly MealFoodPortion[]): PortionMacroQuality {
  const result: PortionMacroQuality = {
    macros: { kcal: 0, proteinG: 0, carbsG: 0, fatG: 0 },
    requestedGrams: 0,
    quantifiedGrams: 0,
    coveragePercent: 100,
    unresolvedFoodIds: [],
    lowConfidenceFoodIds: [],
  };
  for (const portion of portions) {
    if (!Number.isFinite(portion.quantityG) || portion.quantityG <= 0) continue;
    result.requestedGrams += portion.quantityG;
    const food = resolveFoodById(portion.foodId);
    if (!food) {
      result.unresolvedFoodIds.push(portion.foodId);
      continue;
    }
    const macros = food.macros;
    const values = [macros.kcalPerBasis, macros.proteinGPerBasis, macros.carbsGPerBasis, macros.fatGPerBasis, macros.basisQuantityG];
    if (!values.every((value) => Number.isFinite(value) && value >= 0) || macros.basisQuantityG <= 0) {
      result.unresolvedFoodIds.push(portion.foodId);
      continue;
    }
    const ratio = portion.quantityG / macros.basisQuantityG;
    result.macros.kcal += macros.kcalPerBasis * ratio;
    result.macros.proteinG += macros.proteinGPerBasis * ratio;
    result.macros.carbsG += macros.carbsGPerBasis * ratio;
    result.macros.fatG += macros.fatGPerBasis * ratio;
    result.quantifiedGrams += portion.quantityG;
    if (food.quality_status === 'unverified' || food.quality_status === 'label_partial') {
      result.lowConfidenceFoodIds.push(portion.foodId);
    }
  }
  result.coveragePercent = result.requestedGrams > 0
    ? Number(((result.quantifiedGrams / result.requestedGrams) * 100).toFixed(1))
    : 0;
  return result;
}

/** Compute macros for a portion list (planned or consumed). Use the quality-aware variant when displaying confidence. */
export function computePortionsMacros(portions: MealFoodPortion[]): ComputedMealMacros {
  return computePortionsMacrosWithQuality(portions).macros;
}

/** MealConsumptionCalculator: planned & skipped meals yield 0 consumed nutrients */
export function getEffectiveConsumedPortions(meal: MealItem): MealFoodPortion[] {
  if (meal.status === 'planned' || meal.status === 'skipped') {
    return [];
  }
  if (meal.status === 'partial') {
    // Prefer the exact consumed ingredient masses; the scalar quantity may be rounded for display.
    if (meal.consumed_foods.length > 0) return meal.consumed_foods;
    const plannedQuantity = Number.isFinite(meal.planned_quantity) ? meal.planned_quantity : 0;
    const consumedQuantity = Number.isFinite(meal.consumed_quantity) ? Math.max(0, meal.consumed_quantity) : 0;
    const ratio = plannedQuantity > 0 ? Math.min(2, consumedQuantity / plannedQuantity) : 0;
    return meal.planned_foods.map((p) => ({ foodId: p.foodId, quantityG: p.quantityG * ratio }));
  }
  if (meal.status === 'substituted') {
    return meal.consumed_foods;
  }
  return meal.consumed_foods.length > 0 ? meal.consumed_foods : meal.planned_foods;
}

export function computeMealDisplayMacros(meal: MealItem): ComputedMealMacros {
  if (meal.status === 'planned' || meal.status === 'skipped') {
    return computePortionsMacros(meal.planned_foods);
  }
  return computePortionsMacros(getEffectiveConsumedPortions(meal));
}

export function computeMealConsumedMacros(meal: MealItem): ComputedMealMacros {
  return computePortionsMacros(getEffectiveConsumedPortions(meal));
}

export function aggregateDailyMacros(meals: MealItem[], dateKey: string): ComputedMealMacros {
  return meals
    .filter((m) => m.dateKey === dateKey)
    .reduce(
      (acc, meal) => {
        const consumed = computeMealConsumedMacros(meal);
        acc.kcal += consumed.kcal;
        acc.proteinG += consumed.proteinG;
        acc.carbsG += consumed.carbsG;
        acc.fatG += consumed.fatG;
        return acc;
      },
      { kcal: 0, proteinG: 0, carbsG: 0, fatG: 0 },
    );
}

/** DailyNutritionAggregator: N_dia = sum((N_i / B_i) * Q_i) preserving trace & NA */
export function aggregateDailyMicronutrients(
  meals: MealItem[],
  dateKey: string,
  profileId: ReferenceProfileId,
): Record<NutrientId, AggregatedNutrient> {
  const profile = resolveReferenceProfile(profileId);
  const dayMeals = meals.filter((m) => m.dateKey === dateKey);

  const result = {} as Record<NutrientId, AggregatedNutrient>;

  for (const nutrientId of MICRONUTRIENT_ORDER) {
    const refUnit = profile.entries[nutrientId].unit;
    let sum = 0;
    let hasQuantified = false;
    let hasTrace = false;
    let hasAnySource = false;
    let hasNotAnalyzed = false;
    let hasUnquantifiedSources = false;
    const contributions: FoodContribution[] = [];

    for (const meal of dayMeals) {
      const portions = getEffectiveConsumedPortions(meal);
      for (const portion of portions) {
        const food = resolveFoodById(portion.foodId);
        if (!food) continue;
        hasAnySource = true;
        const record = normalizeNutrientEntry(food, nutrientId);

        let scaledAmount: number | null = null;
        if (record.data_status === 'quantified' && record.normalized_value !== null) {
          const safeQuantity = Number.isFinite(portion.quantityG) ? Math.max(0, portion.quantityG) : 0;
          if (Number.isFinite(record.basis_quantity) && record.basis_quantity > 0 && safeQuantity > 0) {
            scaledAmount = (record.normalized_value / record.basis_quantity) * safeQuantity;
            sum += scaledAmount;
            hasQuantified = true;
          } else {
            hasUnquantifiedSources = true;
          }
        } else if (record.data_status === 'trace') {
          hasTrace = true;
          hasUnquantifiedSources = true;
        } else {
          if (record.data_status === 'not_analyzed') hasNotAnalyzed = true;
          hasUnquantifiedSources = true;
        }

        if (record.data_status === 'quantified' || record.data_status === 'trace') {
          contributions.push({
            foodId: food.food_id,
            foodName: food.name,
            mealTitle: meal.title,
            mealTime: meal.time,
            quantityG: Math.round(portion.quantityG),
            amount: scaledAmount,
            unit: record.normalized_unit || refUnit,
            originalValue: record.original_value,
            originalUnit: record.original_unit || refUnit,
            sourceId: record.source_id,
            sourceVersion: record.source_version,
            sourceRecordId: record.source_record_id,
            dataStatus: record.data_status,
            qualityStatus: record.quality_status,
            conversionMethod: record.conversion_method,
          });
        }
      }
    }

    let finalStatus: NutrientDataStatus = 'missing';
    if (hasQuantified) {
      finalStatus = 'quantified';
    } else if (hasTrace) {
      finalStatus = 'trace';
    } else if (hasAnySource && hasNotAnalyzed) {
      finalStatus = 'not_analyzed';
    }

    result[nutrientId] = {
      nutrientId,
      consumedValue: hasQuantified ? sum : null,
      unit: refUnit,
      dataStatus: finalStatus,
      contributions,
      hasUnquantifiedSources,
    };
  }

  return result;
}

export function resolveReferenceProfile(profileId: ReferenceProfileId): ReferenceProfileSpec {
  return DRI_REFERENCE_PROFILES[profileId];
}

export function resolveNutrientDisplay(
  aggregated: AggregatedNutrient,
  reference: DailyReferenceEntry,
  profile: ReferenceProfileSpec,
): ResolvedNutrientDisplay {
  const isLimitMetric = reference.kind === 'CDRR' || reference.kind === 'UL';

  if (aggregated.dataStatus === 'trace') {
    return {
      nutrientId: aggregated.nutrientId,
      consumedValue: null,
      unit: aggregated.unit,
      dataStatus: 'trace',
      referenceValue: reference.referenceValue,
      referenceUnit: reference.unit,
      referenceKind: reference.kind,
      referenceSystem: profile.systemName,
      referenceVersion: profile.systemVersion,
      profileLabel: profile.label,
      rawPercent: null,
      barPercent: 0,
      isExceeded: false,
      isLimitMetric,
      hasUnquantifiedSources: aggregated.hasUnquantifiedSources,
      displayMode: 'trace',
      contributions: aggregated.contributions,
    };
  }

  if (aggregated.dataStatus === 'not_analyzed' || aggregated.dataStatus === 'missing') {
    return {
      nutrientId: aggregated.nutrientId,
      consumedValue: null,
      unit: aggregated.unit,
      dataStatus: aggregated.dataStatus,
      referenceValue: reference.referenceValue,
      referenceUnit: reference.unit,
      referenceKind: reference.kind,
      referenceSystem: profile.systemName,
      referenceVersion: profile.systemVersion,
      profileLabel: profile.label,
      rawPercent: null,
      barPercent: 0,
      isExceeded: false,
      isLimitMetric,
      hasUnquantifiedSources: aggregated.hasUnquantifiedSources,
      displayMode: 'not_analyzed',
      contributions: aggregated.contributions,
    };
  }

  if (reference.referenceValue === null || reference.referenceValue <= 0) {
    return {
      nutrientId: aggregated.nutrientId,
      consumedValue: aggregated.consumedValue,
      unit: aggregated.unit,
      dataStatus: aggregated.dataStatus,
      referenceValue: null,
      referenceUnit: reference.unit,
      referenceKind: reference.kind,
      referenceSystem: profile.systemName,
      referenceVersion: profile.systemVersion,
      profileLabel: profile.label,
      rawPercent: null,
      barPercent: 0,
      isExceeded: false,
      isLimitMetric,
      hasUnquantifiedSources: aggregated.hasUnquantifiedSources,
      displayMode: 'no_reference',
      contributions: aggregated.contributions,
    };
  }

  const consumed = aggregated.consumedValue ?? 0;
  const rawPercent = Math.round((consumed / reference.referenceValue) * 100);
  const barPercent = Math.min(100, Math.max(0, rawPercent));
  const isExceeded = consumed > reference.referenceValue;

  return {
    nutrientId: aggregated.nutrientId,
    consumedValue: consumed,
    unit: aggregated.unit,
    dataStatus: 'quantified',
    referenceValue: reference.referenceValue,
    referenceUnit: reference.unit,
    referenceKind: reference.kind,
    referenceSystem: profile.systemName,
    referenceVersion: profile.systemVersion,
    profileLabel: profile.label,
    rawPercent,
    barPercent,
    isExceeded,
    isLimitMetric,
    hasUnquantifiedSources: aggregated.hasUnquantifiedSources,
    displayMode: isLimitMetric ? 'limit_cdrr' : 'quantified_progress',
    contributions: aggregated.contributions,
  };
}

export interface DayPlanSummary {
  totalMealsCount: number;
  plannedMealsCount: number;
  recordedMealsCount: number;
  skippedMealsCount: number;
  plannedRemainingKcal: number;
  plannedRemainingMacros: ComputedMealMacros;
  nextPlannedMeal: MealItem | undefined;
  latestRecordedMeal: MealItem | undefined;
}

/** Summarizes planned vs recorded meals for a date without conflating planned meals with intake. */
export function computeDayPlanSummary(
  meals: readonly MealItem[],
  dateKey: string,
): DayPlanSummary {
  const dayMeals = meals
    .filter((meal) => meal.dateKey === dateKey)
    .sort((a, b) => a.time.localeCompare(b.time));

  const plannedMeals = dayMeals.filter((meal) => meal.status === 'planned');
  const recordedMeals = dayMeals.filter(
    (meal) => meal.status === 'consumed' || meal.status === 'partial' || meal.status === 'substituted',
  );
  const skippedMeals = dayMeals.filter((meal) => meal.status === 'skipped');

  const plannedRemainingMacros = plannedMeals.reduce<ComputedMealMacros>(
    (acc, meal) => {
      const planned = computePortionsMacros(meal.planned_foods);
      acc.kcal += planned.kcal;
      acc.proteinG += planned.proteinG;
      acc.carbsG += planned.carbsG;
      acc.fatG += planned.fatG;
      return acc;
    },
    { kcal: 0, proteinG: 0, carbsG: 0, fatG: 0 },
  );

  return {
    totalMealsCount: dayMeals.length,
    plannedMealsCount: plannedMeals.length,
    recordedMealsCount: recordedMeals.length,
    skippedMealsCount: skippedMeals.length,
    plannedRemainingKcal: Math.round(plannedRemainingMacros.kcal),
    plannedRemainingMacros: {
      kcal: Math.round(plannedRemainingMacros.kcal),
      proteinG: Math.round(plannedRemainingMacros.proteinG),
      carbsG: Math.round(plannedRemainingMacros.carbsG),
      fatG: Math.round(plannedRemainingMacros.fatG),
    },
    nextPlannedMeal: plannedMeals[0],
    latestRecordedMeal: recordedMeals[recordedMeals.length - 1],
  };
}

export interface FoodMacroBreakdownItem {
  foodId: string;
  foodName: string;
  mealId: string;
  mealTitle: string;
  mealTime: string;
  quantityG: number;
  sourceId: FoodSourceId | 'UNRESOLVED';
  macros: ComputedMealMacros;
}

export interface MealMacroBreakdownItem {
  mealId: string;
  title: string;
  time: string;
  status: MealItem['status'];
  planned: ComputedMealMacros;
  consumed: ComputedMealMacros;
  isRecorded: boolean;
}

export interface DailyMacroAndEnergyBreakdown {
  plannedTotals: ComputedMealMacros;
  consumedTotals: ComputedMealMacros;
  meals: MealMacroBreakdownItem[];
  consumedFoods: FoodMacroBreakdownItem[];
}

export function computeDailyMacroAndEnergyBreakdown(
  meals: readonly MealItem[],
  dateKey: string,
): DailyMacroAndEnergyBreakdown {
  const dayMeals = meals
    .filter((meal) => meal.dateKey === dateKey)
    .sort((a, b) => a.time.localeCompare(b.time));

  const plannedTotals: ComputedMealMacros = { kcal: 0, proteinG: 0, carbsG: 0, fatG: 0 };
  const consumedTotals: ComputedMealMacros = { kcal: 0, proteinG: 0, carbsG: 0, fatG: 0 };
  const mealItems: MealMacroBreakdownItem[] = [];
  const consumedFoods: FoodMacroBreakdownItem[] = [];

  for (const meal of dayMeals) {
    const planned = computePortionsMacros(meal.planned_foods);
    const effectivePortions = getEffectiveConsumedPortions(meal);
    const consumed = computePortionsMacros(effectivePortions);
    const isRecorded =
      meal.status === 'consumed' || meal.status === 'partial' || meal.status === 'substituted';

    plannedTotals.kcal += planned.kcal;
    plannedTotals.proteinG += planned.proteinG;
    plannedTotals.carbsG += planned.carbsG;
    plannedTotals.fatG += planned.fatG;

    consumedTotals.kcal += consumed.kcal;
    consumedTotals.proteinG += consumed.proteinG;
    consumedTotals.carbsG += consumed.carbsG;
    consumedTotals.fatG += consumed.fatG;

    mealItems.push({
      mealId: meal.id,
      title: meal.title,
      time: meal.time,
      status: meal.status,
      planned,
      consumed,
      isRecorded,
    });

    if (isRecorded) {
      for (const portion of effectivePortions) {
        if (!Number.isFinite(portion.quantityG) || portion.quantityG <= 0) continue;
        const food = resolveFoodById(portion.foodId);
        const macros = computePortionsMacros([portion]);
        consumedFoods.push({
          foodId: portion.foodId,
          foodName: food?.name ?? portion.foodId,
          mealId: meal.id,
          mealTitle: meal.title,
          mealTime: meal.time,
          quantityG: Math.round(portion.quantityG),
          sourceId: food?.source_id ?? 'UNRESOLVED',
          macros,
        });
      }
    }
  }

  return {
    plannedTotals,
    consumedTotals,
    meals: mealItems,
    consumedFoods,
  };
}

