import type { RecipeItem } from '../../domain/entities/nutrient';

/**
 * Catálogo de Receitas (Camada intermediária entre Ingredientes TBCA/OFF e o Cardápio diário).
 * Cada receita referencia exclusivamente IDs verificados de ingredientes e quantidades em gramas.
 */
export const RECIPE_CATALOG: readonly RecipeItem[] = [
  {
    id: 'rec-cafe-completo',
    name: 'Ovos mexidos, pão integral e mamão com aveia',
    description: 'Ovos mexidos, pão integral e mamão com aveia',
    category: 'cafe',
    ingredients: [
      { ingredientId: 'tbca-ovo-mexido', quantityG: 140 },
      { ingredientId: 'tbca-pao-integral', quantityG: 100 },
      { ingredientId: 'tbca-mamao-aveia', quantityG: 150 },
    ],
  },
  {
    id: 'rec-almoco-frango',
    name: 'Peito de frango grelhado, arroz e legumes',
    description: 'Frango, arroz e legumes',
    category: 'almoco',
    imageUrl: '/src/assets/images/meal_chicken_rice_bowl_1795297143937.jpg',
    ingredients: [
      { ingredientId: 'tbca-frango-arroz-legumes', quantityG: 400 },
    ],
  },
  {
    id: 'rec-lanche-iogurte',
    name: 'Iogurte proteico, banana e pasta de amendoim',
    description: 'Iogurte proteico, banana e pasta de amendoim',
    category: 'lanche',
    imageUrl: '/src/assets/images/meal_protein_yogurt_bowl_1795297143970.jpg',
    ingredients: [
      { ingredientId: 'off-iogurte-proteico', quantityG: 200 },
      { ingredientId: 'tbca-banana-prata', quantityG: 100 },
      { ingredientId: 'off-pasta-amendoim', quantityG: 25 },
    ],
  },
  {
    id: 'rec-jantar-salmao',
    name: 'Salmão assado, batata-doce e brócolis',
    description: 'Salmão assado, batata-doce e brócolis',
    category: 'jantar',
    imageUrl: '/src/assets/images/meal_salmon_sweet_potato_1795297143668.jpg',
    ingredients: [
      { ingredientId: 'tbca-salmao-batata-doce', quantityG: 380 },
    ],
  },
  {
    id: 'rec-sub-iogurte-leve',
    name: 'Bowl de iogurte proteico com banana',
    description: 'Iogurte proteico (220 g) e banana prata (120 g)',
    category: 'lanche',
    imageUrl: '/src/assets/images/meal_protein_yogurt_bowl_1795297143970.jpg',
    ingredients: [
      { ingredientId: 'off-iogurte-proteico', quantityG: 220 },
      { ingredientId: 'tbca-banana-prata', quantityG: 120 },
    ],
  },
  {
    id: 'rec-sub-frango-leve',
    name: 'Frango grelhado com legumes (porção leve)',
    description: 'Peito de frango grelhado, arroz e legumes (300 g)',
    category: 'almoco',
    imageUrl: '/src/assets/images/meal_chicken_rice_bowl_1795297143937.jpg',
    ingredients: [
      { ingredientId: 'tbca-frango-arroz-legumes', quantityG: 300 },
    ],
  },
  {
    id: 'rec-sub-salmao-power',
    name: 'Salmão assado com batata-doce e banana pós-treino',
    description: 'Salmão assado, batata-doce e brócolis (340 g) + banana (90 g)',
    category: 'jantar',
    imageUrl: '/src/assets/images/meal_salmon_sweet_potato_1795297143668.jpg',
    ingredients: [
      { ingredientId: 'tbca-salmao-batata-doce', quantityG: 340 },
      { ingredientId: 'tbca-banana-prata', quantityG: 90 },
    ],
  },
  {
    id: 'rec-sub-sanduiche-ovos',
    name: 'Ovos mexidos com pão integral e mamão',
    description: 'Ovos mexidos (160 g), pão integral (80 g) e mamão com aveia (120 g)',
    category: 'cafe',
    ingredients: [
      { ingredientId: 'tbca-ovo-mexido', quantityG: 160 },
      { ingredientId: 'tbca-pao-integral', quantityG: 80 },
      { ingredientId: 'tbca-mamao-aveia', quantityG: 120 },
    ],
  },
] as const;

export function findRecipeById(recipeId: string): RecipeItem | undefined {
  return RECIPE_CATALOG.find((r) => r.id === recipeId);
}
