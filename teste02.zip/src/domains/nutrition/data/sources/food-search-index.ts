import { buildFoodSearchIndex, type FoodSearchEntry } from '../../domain/rules/food-search';
import { OPEN_FOOD_FACTS_PRODUCTS } from './open-food-facts-adapter';
import { TBCA_FOODS } from './tbca-adapter';

let sharedFoodSearchIndex: FoodSearchEntry[] | null = null;

/** Lazily builds and shares one search index across FoodCatalogBrowser and CustomMealEditor. */
export function getSharedFoodSearchIndex(): readonly FoodSearchEntry[] {
  if (!sharedFoodSearchIndex) {
    sharedFoodSearchIndex = buildFoodSearchIndex([
      ...Object.values(TBCA_FOODS),
      ...Object.values(OPEN_FOOD_FACTS_PRODUCTS),
    ]);
  }
  return sharedFoodSearchIndex;
}
