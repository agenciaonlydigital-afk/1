import { Timer, Plus, X } from 'lucide-react';
import { formatSecondsClock } from '@/src/shared/utils/formatters';
import { useRestTimerSnapshot } from '../hooks/use-rest-snapshot';

export function RestTimer() {
  const { restTimer, snapshot: snap, extendRestTarget, stopRestTimer } =
    useRestTimerSnapshot();

  if (!restTimer?.active || !snap) return null;

  return (
    <div
      className={`p-4 rounded-2xl border ${
        snap.isOvertime
          ? 'bg-[var(--titan-accent-deep)]/35 border-[var(--titan-accent)]/60'
          : 'bg-[var(--titan-surface)] border-[var(--titan-border)]'
      }`}
      role="group"
      aria-label={`Descanso de ${restTimer.exerciseName}`}
      aria-live="off"
    >
      <span className="sr-only" aria-live="polite">
        Descanso iniciado para {restTimer.exerciseName}; alvo de {formatSecondsClock(snap.targetSeconds)}.
      </span>
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)] flex items-center justify-center text-[var(--titan-accent)] shrink-0">
            <Timer className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <div className="text-xs text-[var(--titan-text-secondary)] truncate">
              Descanso · {restTimer.exerciseName}
            </div>
            <div className="flex flex-wrap items-baseline gap-2 mt-0.5">
              <span className="text-2xl font-semibold font-mono-metric text-[var(--titan-text-primary)]">
                {formatSecondsClock(snap.elapsedSeconds)}
              </span>
              <span className="text-xs font-mono-metric text-[var(--titan-text-secondary)]">
                / alvo {formatSecondsClock(snap.targetSeconds)}
              </span>
              {snap.isOvertime && (
                <span className="text-xs font-medium text-[var(--titan-champagne)]">
                  +{formatSecondsClock(snap.overtimeSeconds)} além do alvo
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={() => extendRestTarget(15)}
            className="min-h-[44px] px-3 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)] text-xs font-medium text-[var(--titan-text-primary)] inline-flex items-center gap-1 transition-colors hover:border-[var(--titan-accent)]/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-focus)]"
          >
            <Plus className="w-3.5 h-3.5" />
            15s
          </button>
          <button
            type="button"
            onClick={stopRestTimer}
            aria-label="Encerrar descanso"
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)] text-[var(--titan-text-secondary)] transition-colors hover:text-[var(--titan-text-primary)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-focus)]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
