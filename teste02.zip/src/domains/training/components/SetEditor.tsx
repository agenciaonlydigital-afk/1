import { memo, useEffect, useState } from 'react';
import { Check } from 'lucide-react';
import type { SetRecord } from '../domain/entities/workout';
import { registerWorkoutSet } from '../application/register-set';

interface SetEditorProps {
  exerciseId: string;
  setRecord: SetRecord;
}

export const SetEditor = memo(function SetEditor({ exerciseId, setRecord }: SetEditorProps) {
  const [weight, setWeight] = useState(String(setRecord.weightKg));
  const [reps, setReps] = useState(String(setRecord.reps));
  const [repsInReserve, setRepsInReserve] = useState(setRecord.repsInReserve == null ? '' : String(setRecord.repsInReserve));
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setWeight(String(setRecord.weightKg));
    setReps(String(setRecord.reps));
    setRepsInReserve(setRecord.repsInReserve == null ? '' : String(setRecord.repsInReserve));
    setError(null);
  }, [setRecord.id, setRecord.weightKg, setRecord.reps, setRecord.repsInReserve]);

  const handleConfirm = () => {
    if (weight.trim() === '' || reps.trim() === '') {
      setError('Preencha carga e repetições.');
      return;
    }
    const parsedWeight = Number(weight.replace(',', '.'));
    const parsedReps = Number(reps.replace(',', '.'));
    if (!Number.isFinite(parsedWeight) || !Number.isFinite(parsedReps)) {
      setError('Informe valores numéricos válidos.');
      return;
    }

    const res = registerWorkoutSet(
      exerciseId,
      setRecord.id,
      parsedWeight,
      parsedReps,
      repsInReserve === '' ? null : Number(repsInReserve),
    );
    if (!res.ok) {
      setError(res.error);
    } else {
      setError(null);
    }
  };

  return (
    <div
      className={`p-3 rounded-xl border ${
        setRecord.completed
          ? 'bg-[var(--titan-accent-deep)]/25 border-[var(--titan-status-success)]/45'
          : 'bg-[var(--titan-bg-canvas)] border-[var(--titan-border)]/80'
      }`}
    >
      <div className="grid grid-cols-[32px_1fr_1fr_1fr_auto] items-end gap-2">
        <div className="text-xs font-mono-metric text-[var(--titan-text-secondary)]">
          S{setRecord.setNumber}
        </div>

        <div>
          <label className="block text-xs text-[var(--titan-text-muted)] mb-1">Carga (kg)</label>
          <input
            type="number"
            inputMode="decimal"
            min={0}
            step={0.5}
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
            aria-label={`Carga da série ${setRecord.setNumber} em quilogramas`}
            className="w-full min-h-[44px] px-2.5 rounded-lg bg-[var(--titan-surface)] border border-[var(--titan-border)] focus:border-[var(--titan-accent)] text-sm font-mono-metric text-[var(--titan-text-primary)]"
          />
        </div>

        <div>
          <label className="block text-xs text-[var(--titan-text-muted)] mb-1">
            Reps ({setRecord.targetReps})
          </label>
          <input
            type="number"
            inputMode="numeric"
            min={1}
            step={1}
            value={reps}
            onChange={(e) => setReps(e.target.value)}
            aria-label={`Repetições da série ${setRecord.setNumber}`}
            className="w-full min-h-[44px] px-2.5 rounded-lg bg-[var(--titan-surface)] border border-[var(--titan-border)] focus:border-[var(--titan-accent)] text-sm font-mono-metric text-[var(--titan-text-primary)]"
          />
        </div>

        <div>
          <label className="block text-xs text-[var(--titan-text-muted)] mb-1">RIR</label>
          <select
            value={repsInReserve}
            onChange={(event) => setRepsInReserve(event.target.value)}
            aria-label={`Repetições em reserva da série ${setRecord.setNumber}`}
            className="w-full min-h-[44px] px-2 rounded-lg bg-[var(--titan-surface)] border border-[var(--titan-border)] focus:border-[var(--titan-accent)] text-sm text-[var(--titan-text-primary)]"
          >
            <option value="">—</option>
            <option value="0">0</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
          </select>
        </div>

        <button
          type="button"
          onClick={handleConfirm}
          aria-label={
            setRecord.completed
              ? `Atualizar série ${setRecord.setNumber}`
              : `Registrar série ${setRecord.setNumber}`
          }
          className={`min-h-[44px] min-w-[44px] px-3 mt-4 rounded-xl flex items-center justify-center gap-1.5 text-xs font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-focus)] focus-visible:ring-offset-2 focus-visible:ring-offset-[var(--titan-surface)] ${
            setRecord.completed
              ? 'bg-[var(--titan-status-success)] text-[var(--titan-bg-canvas)]'
              : 'bg-[var(--titan-accent)] text-[var(--titan-bg-canvas)]'
          }`}
        >
          <Check className="w-4 h-4" />
          <span className="hidden sm:inline">
            {setRecord.completed ? 'Registrada' : 'Registrar'}
          </span>
        </button>
      </div>
      {error && (
        <p className="text-xs text-[var(--titan-status-error)] mt-2" role="alert">
          {error}
        </p>
      )}
    </div>
  );
});
