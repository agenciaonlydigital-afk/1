import { computeRestSnapshot, type RestProgressSnapshot } from '../domain/rules/rest-timer';

export function calculateRestSnapshot(
  startedAtMs: number,
  targetSeconds: number,
): RestProgressSnapshot {
  return computeRestSnapshot(startedAtMs, Date.now(), targetSeconds);
}
