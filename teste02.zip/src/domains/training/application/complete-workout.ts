import { computeWorkoutCompletion } from '../domain/rules/rest-timer';
import { useTrainingSessionStore } from '../state/training-session.store';

export function completeActiveWorkout(): void {
  const store = useTrainingSessionStore.getState();
  const plan = store.plans.find((p) => p.id === store.activePlanId);
  if (!plan) return;

  const { completedSets } = computeWorkoutCompletion(plan);
  const now = new Date();
  const finishedAtLabel = `${String(now.getHours()).padStart(2, '0')}:${String(
    now.getMinutes(),
  ).padStart(2, '0')}`;
  store.markPlanCompleted(plan.id, completedSets, finishedAtLabel);
}
