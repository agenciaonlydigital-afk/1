import type { WorkoutPlan } from '../domain/entities/workout';

export function isWorkoutSetTargetValid(
  plan: WorkoutPlan | undefined,
  exerciseId: string,
  setId: string,
): boolean {
  const exercise = plan?.exercises.find((item) => item.id === exerciseId);
  const set = exercise?.sets.find((item) => item.id === setId);
  return Boolean(set && !set.completed);
}
