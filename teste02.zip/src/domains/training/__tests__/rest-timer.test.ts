import assert from 'node:assert/strict';
import { computeRestSnapshot, computeWorkoutCompletion } from '../domain/rules/rest-timer';
import { INITIAL_WORKOUT_PLANS } from '../data/repositories/workout-seed';

const withinTarget = computeRestSnapshot(1000, 31000, 60);
assert.equal(withinTarget.elapsedSeconds, 30);
assert.equal(withinTarget.isOvertime, false);
assert.equal(withinTarget.overtimeSeconds, 0);

const overtime = computeRestSnapshot(1000, 91000, 60);
assert.equal(overtime.elapsedSeconds, 90);
assert.equal(overtime.isOvertime, true);
assert.equal(overtime.overtimeSeconds, 30);

const firstPlan = INITIAL_WORKOUT_PLANS[0];
assert.ok(firstPlan);
const progress = computeWorkoutCompletion(firstPlan);
assert.equal(progress.completedSets, 0);
assert.equal(progress.totalSets, 19);
assert.equal(progress.percent, 0);
assert.equal(progress.nextExerciseName, 'Supino reto');
