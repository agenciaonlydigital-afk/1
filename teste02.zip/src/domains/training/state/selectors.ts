import { useMemo } from 'react';
import type { WorkoutPlan } from '../domain/entities/workout';
import { computeWorkoutCompletion } from '../domain/rules/rest-timer';
import { summarizeWorkoutPlan } from '../domain/rules/strength-calculations';
import { useTrainingSessionStore } from './training-session.store';

const EMPTY_PLAN_FALLBACK: WorkoutPlan = {
  id: 'fallback',
  title: 'Treino',
  splitLabel: 'Sessão',
  status: 'pending',
  exercises: [],
};

export function useActiveWorkoutPlan(): WorkoutPlan {
  const plans = useTrainingSessionStore((s) => s.plans);
  const activePlanId = useTrainingSessionStore((s) => s.activePlanId);
  return useMemo(
    () => plans.find((p) => p.id === activePlanId) ?? plans[0] ?? EMPTY_PLAN_FALLBACK,
    [plans, activePlanId],
  );
}

export function useActiveWorkoutProgress() {
  const plan = useActiveWorkoutPlan();
  return useMemo(
    () => ({
      plan,
      ...computeWorkoutCompletion(plan),
      calculations: summarizeWorkoutPlan(plan),
    }),
    [plan],
  );
}
