import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { safeStorageAdapter } from '../../../infrastructure/storage/local-storage';
import type { CompletedWorkoutSession, WorkoutPlan } from '../domain/entities/workout';
import { createCompletedWorkoutSession, resetWorkoutPlanForNextSession } from '../domain/rules/workout-session';
import { INITIAL_WORKOUT_PLANS } from '../data/repositories/workout-seed';
import { mergeTrainingPersistedState, type PersistedTrainingState } from './training-persistence';
import { findExerciseDefinition } from '../../exercise-library/application/exercise-library-public';

export interface ActiveRestTimerState {
  active: boolean;
  startedAtMs: number;
  targetSeconds: number;
  exerciseName: string;
}

interface TrainingSessionState {
  plans: WorkoutPlan[];
  activePlanId: string;
  focusedExerciseId: string;
  restTimer: ActiveRestTimerState | null;
  sessionStartedAtMs: number | null;
  completedSessions: CompletedWorkoutSession[];
  sessionCompletedSummary: {
    planTitle: string;
    completedSets: number;
    finishedAtLabel: string;
  } | null;
  selectPlan: (planId: string) => void;
  beginSession: (planId: string, startedAtMs?: number) => void;
  focusExercise: (exerciseId: string) => void;
  updateSetValues: (exerciseId: string, setId: string, weightKg: number, reps: number, repsInReserve?: number | null) => void;
  markSetCompleted: (exerciseId: string, setId: string) => void;
  startRestTimer: (exerciseName: string, targetSeconds: number) => void;
  extendRestTarget: (deltaSeconds: number) => void;
  stopRestTimer: () => void;
  markPlanCompleted: (planId: string, completedSets: number, finishedAtLabel: string) => void;
  dismissSummary: () => void;
  createPlan: (title: string) => string | null;
  duplicatePlan: (planId: string) => string | null;
  deletePlan: (planId: string) => void;
  renamePlan: (planId: string, title: string) => void;
  addExerciseToPlan: (planId: string, exerciseSlug: string) => boolean;
  removeExerciseFromPlan: (planId: string, exerciseId: string) => void;
  updateExerciseRestSeconds: (planId: string, exerciseId: string, seconds: number) => void;
  updateSetPrescription: (planId: string, exerciseId: string, setId: string, values: { weightKg?: number; reps?: number; targetReps?: string }) => void;
  addSetToExercise: (planId: string, exerciseId: string) => void;
  removeSetFromExercise: (planId: string, exerciseId: string, setId: string) => void;
  moveExerciseInPlan: (planId: string, exerciseId: string, direction: -1 | 1) => void;
}

export const useTrainingSessionStore = create<TrainingSessionState>()(persist<TrainingSessionState, [], [], PersistedTrainingState>((set) => ({
  plans: INITIAL_WORKOUT_PLANS,
  activePlanId: 'upper-a',
  focusedExerciseId: 'ex-1',
  restTimer: null,
  sessionStartedAtMs: null,
  completedSessions: [],
  sessionCompletedSummary: null,

  selectPlan: (planId) =>
    set((state) => {
      const plan = state.plans.find((p) => p.id === planId);
      if (!plan) return state;
      return {
        activePlanId: planId,
        focusedExerciseId: plan.exercises[0]?.id ?? state.focusedExerciseId,
      };
    }),

  beginSession: (planId, startedAtMs = Date.now()) =>
    set((state) => {
      const selected = state.plans.find((plan) => plan.id === planId);
      if (!selected) return state;
      // A completed plan starts a new cycle. An in-progress plan is resumed even when
      // its final set was marked complete but the user has not closed the session yet.
      const shouldReset = selected.status === 'completed';
      const nextPlan = shouldReset
        ? resetWorkoutPlanForNextSession(selected)
        : { ...selected, status: 'in_progress' as const };
      const plans = state.plans.map((plan) => plan.id === planId ? nextPlan : plan);
      const focused = nextPlan.exercises.find((exercise) => exercise.sets.some((set) => !set.completed)) ?? nextPlan.exercises[0];
      return {
        plans,
        activePlanId: planId,
        focusedExerciseId: focused?.id ?? state.focusedExerciseId,
        sessionStartedAtMs: state.activePlanId === planId && state.sessionStartedAtMs !== null && !shouldReset
          ? state.sessionStartedAtMs
          : startedAtMs,
        restTimer: null,
        sessionCompletedSummary: null,
      };
    }),

  focusExercise: (exerciseId) => set({ focusedExerciseId: exerciseId }),

  updateSetValues: (exerciseId, setId, weightKg, reps, repsInReserve = null) =>
    set((state) => ({
      plans: state.plans.map((plan) =>
        plan.id !== state.activePlanId
          ? plan
          : {
              ...plan,
              exercises: plan.exercises.map((ex) =>
                ex.id !== exerciseId
                  ? ex
                  : {
                      ...ex,
                      sets: ex.sets.map((s) =>
                        s.id !== setId ? s : { ...s, weightKg, reps, repsInReserve },
                      ),
                    },
              ),
            },
      ),
    })),

  markSetCompleted: (exerciseId, setId) =>
    set((state) => ({
      plans: state.plans.map((plan) =>
        plan.id !== state.activePlanId
          ? plan
          : {
              ...plan,
              status: 'in_progress',
              exercises: plan.exercises.map((ex) =>
                ex.id !== exerciseId
                  ? ex
                  : {
                      ...ex,
                      sets: ex.sets.map((s) =>
                        s.id !== setId
                          ? s
                          : { ...s, completed: true, completedAtMs: Date.now() },
                      ),
                    },
              ),
            },
      ),
    })),

  startRestTimer: (exerciseName, targetSeconds) =>
    set({
      restTimer: {
        active: true,
        startedAtMs: Date.now(),
        targetSeconds,
        exerciseName,
      },
    }),

  extendRestTarget: (deltaSeconds) =>
    set((state) =>
      state.restTimer
        ? {
            restTimer: {
              ...state.restTimer,
              targetSeconds: Math.max(15, state.restTimer.targetSeconds + deltaSeconds),
            },
          }
        : state,
    ),

  stopRestTimer: () => set({ restTimer: null }),

  markPlanCompleted: (planId, completedSets, finishedAtLabel) =>
    set((state) => {
      const plan = state.plans.find((p) => p.id === planId);
      if (!plan) return state;
      const completedAtMs = Date.now();
      const snapshot = createCompletedWorkoutSession(plan, state.sessionStartedAtMs, completedAtMs);
      return {
        restTimer: null,
        sessionStartedAtMs: null,
        completedSessions: [snapshot, ...state.completedSessions.filter((session) => session.id !== snapshot.id)].slice(0, 100),
        plans: state.plans.map((p) =>
          p.id !== planId ? p : { ...p, status: 'completed' },
        ),
        sessionCompletedSummary: {
          planTitle: plan.title,
          completedSets,
          finishedAtLabel,
        },
      };
    }),

  dismissSummary: () => set({ sessionCompletedSummary: null }),

  createPlan: (title) => {
    const normalized = title.trim().slice(0, 80);
    if (!normalized || useTrainingSessionStore.getState().plans.filter((plan) => plan.id.startsWith('custom-')).length >= 30) return null;
    const id = `custom-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
    set((state) => ({ plans: [...state.plans, { id, title: normalized, splitLabel: 'Personalizado', status: 'pending', exercises: [] }], activePlanId: id, focusedExerciseId: '' }));
    return id;
  },

  duplicatePlan: (planId) => {
    const source = useTrainingSessionStore.getState().plans.find((plan) => plan.id === planId);
    if (!source || useTrainingSessionStore.getState().plans.filter((plan) => plan.id.startsWith('custom-')).length >= 30) return null;
    const id = `custom-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
    const copy: WorkoutPlan = { ...source, id, title: `${source.title} (cópia)`.slice(0, 80), status: 'pending',
      exercises: source.exercises.map((exercise, index) => ({ ...exercise, id: `${id}-ex-${index + 1}`,
        sets: exercise.sets.map((record, setIndex) => ({ ...record, id: `${id}-ex-${index + 1}-s-${setIndex + 1}`, completed: false, completedAtMs: undefined })) })) };
    set((state) => ({ plans: [...state.plans, copy], activePlanId: id, focusedExerciseId: copy.exercises[0]?.id ?? '' }));
    return id;
  },

  deletePlan: (planId) => set((state) => {
    if (!planId.startsWith('custom-')) return state;
    const plans = state.plans.filter((plan) => plan.id !== planId);
    const active = state.activePlanId === planId ? plans[0] : plans.find((plan) => plan.id === state.activePlanId);
    return { plans, activePlanId: active?.id ?? '', focusedExerciseId: active?.exercises[0]?.id ?? '',
      sessionStartedAtMs: state.activePlanId === planId ? null : state.sessionStartedAtMs,
      restTimer: state.activePlanId === planId ? null : state.restTimer };
  }),

  renamePlan: (planId, title) => {
    const normalized = title.trim().slice(0, 80);
    if (!normalized) return;
    set((state) => ({ plans: state.plans.map((plan) => plan.id === planId && plan.id.startsWith('custom-') ? { ...plan, title: normalized } : plan) }));
  },

  addExerciseToPlan: (planId, exerciseSlug) => {
    const definition = findExerciseDefinition(exerciseSlug);
    if (!definition) return false;
    const state = useTrainingSessionStore.getState();
    const plan = state.plans.find((item) => item.id === planId);
    if (!plan || !plan.id.startsWith('custom-') || plan.exercises.length >= 30 || plan.exercises.some((item) => item.exerciseSlug === exerciseSlug)) return false;
    const exerciseId = `${planId}-ex-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
    const exercise = { id: exerciseId, exerciseSlug: definition.slug, name: definition.name, equipment: definition.equipment,
      targetRestSeconds: 90, muscles: { primary: [...definition.muscles.primary], secondary: [...definition.muscles.secondary] },
      sets: Array.from({ length: 3 }, (_, index) => ({ id: `${exerciseId}-s-${index + 1}`, setNumber: index + 1, targetReps: '8–12', weightKg: 0, reps: 8, completed: false })) };
    set((current) => ({ plans: current.plans.map((item) => item.id === planId ? { ...item, exercises: [...item.exercises, exercise] } : item), focusedExerciseId: exerciseId }));
    return true;
  },

  removeExerciseFromPlan: (planId, exerciseId) => set((state) => ({ plans: state.plans.map((plan) => plan.id === planId && plan.id.startsWith('custom-')
    ? { ...plan, exercises: plan.exercises.filter((exercise) => exercise.id !== exerciseId) } : plan),
    focusedExerciseId: state.focusedExerciseId === exerciseId ? '' : state.focusedExerciseId })),

  updateExerciseRestSeconds: (planId, exerciseId, seconds) => {
    if (!Number.isFinite(seconds) || seconds < 15 || seconds > 600) return;
    set((state) => ({ plans: state.plans.map((plan) => plan.id !== planId || !plan.id.startsWith('custom-') ? plan : {
      ...plan, exercises: plan.exercises.map((exercise) => exercise.id === exerciseId ? { ...exercise, targetRestSeconds: Math.round(seconds) } : exercise),
    }) }));
  },

  updateSetPrescription: (planId, exerciseId, setId, values) => {
    set((state) => ({ plans: state.plans.map((plan) => plan.id !== planId || !plan.id.startsWith('custom-') ? plan : {
      ...plan, exercises: plan.exercises.map((exercise) => exercise.id !== exerciseId ? exercise : {
        ...exercise, sets: exercise.sets.map((record) => record.id !== setId ? record : {
          ...record,
          weightKg: values.weightKg === undefined ? record.weightKg : Number.isFinite(values.weightKg) ? Math.max(0, Math.min(500, values.weightKg)) : record.weightKg,
          reps: values.reps === undefined ? record.reps : Number.isInteger(values.reps) ? Math.max(1, Math.min(100, values.reps)) : record.reps,
          targetReps: values.targetReps === undefined ? record.targetReps : values.targetReps.trim().slice(0, 20) || record.targetReps,
          repsInReserve: null,
          completed: false, completedAtMs: undefined,
        }),
      }),
    }) }));
  },

  addSetToExercise: (planId, exerciseId) => set((state) => ({ plans: state.plans.map((plan) => plan.id !== planId || !plan.id.startsWith('custom-') ? plan : {
    ...plan, exercises: plan.exercises.map((exercise) => {
      if (exercise.id !== exerciseId || exercise.sets.length >= 20) return exercise;
      const previous = exercise.sets[exercise.sets.length - 1];
      const setNumber = exercise.sets.length + 1;
      return { ...exercise, sets: [...exercise.sets, { id: `${exercise.id}-s-${setNumber}-${Date.now().toString(36)}`, setNumber,
        targetReps: previous?.targetReps ?? '8–12', weightKg: previous?.weightKg ?? 0, reps: previous?.reps ?? 8, completed: false }] };
    }),
  }) })),

  removeSetFromExercise: (planId, exerciseId, setId) => set((state) => ({ plans: state.plans.map((plan) => plan.id !== planId || !plan.id.startsWith('custom-') ? plan : {
    ...plan, exercises: plan.exercises.map((exercise) => {
      if (exercise.id !== exerciseId || exercise.sets.length <= 1) return exercise;
      return { ...exercise, sets: exercise.sets.filter((record) => record.id !== setId).map((record, index) => ({ ...record, setNumber: index + 1 })) };
    }),
  }) })),

  moveExerciseInPlan: (planId, exerciseId, direction) => set((state) => ({ plans: state.plans.map((plan) => {
    if (plan.id !== planId || !plan.id.startsWith('custom-')) return plan;
    const from = plan.exercises.findIndex((exercise) => exercise.id === exerciseId);
    const to = from + direction;
    if (from < 0 || to < 0 || to >= plan.exercises.length) return plan;
    const exercises = [...plan.exercises];
    const [moved] = exercises.splice(from, 1);
    if (!moved) return plan;
    exercises.splice(to, 0, moved);
    return { ...plan, exercises };
  }) })),
}), {
  name: 'titan:training:v1',
  version: 1,
  storage: createJSONStorage(() => safeStorageAdapter),
  partialize: (state) => ({
    plans: state.plans,
    activePlanId: state.activePlanId,
    focusedExerciseId: state.focusedExerciseId,
    restTimer: state.restTimer,
    sessionStartedAtMs: state.sessionStartedAtMs,
    completedSessions: state.completedSessions,
  }),
  migrate: (persisted) => mergeTrainingPersistedState(persisted, INITIAL_WORKOUT_PLANS),
  merge: (persisted, current) => ({
    ...current,
    ...mergeTrainingPersistedState(persisted, current.plans),
  }),
}));
