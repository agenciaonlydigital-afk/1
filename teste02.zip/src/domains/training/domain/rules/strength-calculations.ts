import type { MuscleGroupId, MuscleHighlightPayload } from '@/src/shared/types/common';
import type { WorkoutPlan } from '../entities/workout';

export const MAX_ESTIMATED_1RM_REPS = 10;

export type OneRepMaxFormula = 'epley' | 'brzycki' | 'lombardi' | 'mayhew' | 'oconner' | 'wathan' | 'lander';
export type EstimateQualityBand = 'single_rep_observed' | 'low_rep_estimate' | 'higher_rep_estimate' | 'effort_unverified_estimate';

export interface OneRepMaxEstimate {
  oneRepMaxKg: number;
  minEstimateKg: number;
  maxEstimateKg: number;
  formulaEstimatesKg: Record<OneRepMaxFormula, number>;
  qualityBand: EstimateQualityBand;
  repetitionsUsed: number;
  repetitionsToFailureEstimate: number;
  repsInReserveUsed: number | null;
  effortBasis: 'reported_rir' | 'assumed_to_failure';
}

const FORMULAS: Record<OneRepMaxFormula, (weightKg: number, reps: number) => number> = {
  epley: (weight, reps) => weight * (1 + reps / 30),
  brzycki: (weight, reps) => weight * (36 / (37 - reps)),
  lombardi: (weight, reps) => weight * Math.pow(reps, 0.1),
  mayhew: (weight, reps) => (100 * weight) / (52.2 + 41.9 * Math.exp(-0.055 * reps)),
  oconner: (weight, reps) => weight * (1 + reps / 40),
  wathan: (weight, reps) => (100 * weight) / (48.8 + 53.8 * Math.exp(-0.075 * reps)),
  lander: (weight, reps) => (100 * weight) / (101.3 - 2.67123 * reps),
};

function round1(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Number(value.toFixed(1));
}

function isValidDateKey(dateKey: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateKey)) return false;
  const [year, month, day] = dateKey.split('-').map(Number);
  const parsed = new Date(Date.UTC(year!, month! - 1, day!));
  return parsed.getUTCFullYear() === year && parsed.getUTCMonth() === month! - 1 && parsed.getUTCDate() === day;
}

function median(values: number[]): number {
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 === 0
    ? (sorted[middle - 1]! + sorted[middle]!) / 2
    : sorted[middle]!;
}

/**
 * Ensemble estimate from seven common equations. Sets above 10 reps are
 * excluded: high-repetition endurance sets make strength extrapolations unstable.
 */
export function estimateOneRepMax(
  weightKg: number,
  reps: number,
  repsInReserve?: number | null,
): OneRepMaxEstimate | null {
  if (!Number.isFinite(weightKg) || weightKg <= 0) throw new RangeError('A carga deve ser positiva e finita.');
  if (!Number.isInteger(reps) || reps < 1) throw new RangeError('As repetições devem ser um inteiro positivo.');
  if (repsInReserve !== undefined && repsInReserve !== null &&
      (!Number.isInteger(repsInReserve) || repsInReserve < 0 || repsInReserve > 5)) {
    throw new RangeError('RIR deve ser um inteiro de 0 a 5 ou não informado.');
  }
  const hasReportedRir = repsInReserve !== undefined && repsInReserve !== null;
  // Legacy sets without RIR remain calculable, but are explicitly marked as
  // assumed-to-failure rather than silently treated as verified effort.
  const effectiveRir = hasReportedRir ? repsInReserve : 0;
  const repetitionsToFailureEstimate = reps + effectiveRir;
  if (repetitionsToFailureEstimate > MAX_ESTIMATED_1RM_REPS) return null;

  const values = Object.fromEntries(
    Object.entries(FORMULAS).map(([name, formula]) => [
      name, repetitionsToFailureEstimate === 1 ? weightKg : formula(weightKg, repetitionsToFailureEstimate),
    ]),
  ) as Record<OneRepMaxFormula, number>;
  const estimates = Object.values(values);
  const center = repetitionsToFailureEstimate === 1 ? weightKg : median(estimates);
  const qualityBand: EstimateQualityBand = !hasReportedRir
    ? 'effort_unverified_estimate'
    : repetitionsToFailureEstimate === 1 && effectiveRir === 0
      ? 'single_rep_observed'
      : repetitionsToFailureEstimate <= 5 ? 'low_rep_estimate' : 'higher_rep_estimate';

  return {
    oneRepMaxKg: round1(center),
    minEstimateKg: round1(Math.min(...estimates)),
    maxEstimateKg: round1(Math.max(...estimates)),
    formulaEstimatesKg: Object.fromEntries(
      Object.entries(values).map(([name, value]) => [name, round1(value)]),
    ) as Record<OneRepMaxFormula, number>,
    qualityBand,
    repetitionsUsed: reps,
    repetitionsToFailureEstimate,
    repsInReserveUsed: hasReportedRir ? effectiveRir : null,
    effortBasis: hasReportedRir ? 'reported_rir' : 'assumed_to_failure',
  };
}

export function buildOneRepMaxLoadTable(oneRepMaxKg: number): Array<{ percent: number; loadKg: number }> {
  if (!Number.isFinite(oneRepMaxKg) || oneRepMaxKg <= 0) throw new RangeError('1RM deve ser positivo e finito.');
  return Array.from({ length: 11 }, (_, index) => {
    const percent = 100 - index * 5;
    return { percent, loadKg: round1(oneRepMaxKg * percent / 100) };
  });
}

export interface LoggedTrainingSet {
  weightKg: number;
  reps: number;
  completed: boolean;
  repsInReserve?: number | null;
}

export interface ExercisePerformanceSummary {
  completedSetCount: number;
  totalReps: number;
  volumeLoadKg: number;
  averageLoadKg: number | null;
  estimatedOneRepMaxKg: number | null;
  bestSetEstimate: OneRepMaxEstimate | null;
}

export function summarizeExercisePerformance(sets: readonly LoggedTrainingSet[]): ExercisePerformanceSummary {
  const completed = sets.filter((set) => set.completed && Number.isFinite(set.weightKg) && set.weightKg >= 0 && Number.isInteger(set.reps) && set.reps > 0);
  const totalReps = completed.reduce((sum, set) => sum + set.reps, 0);
  const volumeLoadKg = round1(completed.reduce((sum, set) => {
    const setVolume = set.weightKg * set.reps;
    return Number.isFinite(setVolume) ? sum + setVolume : sum;
  }, 0));
  const loadedSets = completed.filter((set) => set.weightKg > 0);
  const estimates = loadedSets
    .map((set) => estimateOneRepMax(set.weightKg, set.reps, set.repsInReserve))
    .filter((estimate): estimate is OneRepMaxEstimate => estimate !== null);
  const bestSetEstimate = estimates.length > 0
    ? estimates.reduce((best, current) => current.oneRepMaxKg > best.oneRepMaxKg ? current : best)
    : null;

  return {
    completedSetCount: completed.length,
    totalReps,
    volumeLoadKg,
    averageLoadKg: loadedSets.length > 0
      ? round1(loadedSets.reduce((sum, set) => sum + set.weightKg, 0) / loadedSets.length)
      : null,
    estimatedOneRepMaxKg: bestSetEstimate?.oneRepMaxKg ?? null,
    bestSetEstimate,
  };
}

export interface WorkoutCalculationSummary {
  completedSets: number;
  exerciseCount: number;
  totalReps: number;
  totalVolumeLoadKg: number;
  estimatedOneRepMaxByExercise: Record<string, number>;
  oneRepMaxEffortBasisByExercise: Record<string, 'reported_rir' | 'assumed_to_failure'>;
}

export function summarizeWorkoutPlan(plan: WorkoutPlan): WorkoutCalculationSummary {
  const estimatedOneRepMaxByExercise: Record<string, number> = {};
  const oneRepMaxEffortBasisByExercise: Record<string, 'reported_rir' | 'assumed_to_failure'> = {};
  let completedSets = 0;
  let totalReps = 0;
  let totalVolumeLoadKg = 0;

  for (const exercise of plan.exercises) {
    const summary = summarizeExercisePerformance(exercise.sets);
    completedSets += summary.completedSetCount;
    totalReps += summary.totalReps;
    totalVolumeLoadKg += summary.volumeLoadKg;
    if (summary.estimatedOneRepMaxKg !== null) {
      estimatedOneRepMaxByExercise[exercise.exerciseSlug] = summary.estimatedOneRepMaxKg;
      if (summary.bestSetEstimate) {
        oneRepMaxEffortBasisByExercise[exercise.exerciseSlug] = summary.bestSetEstimate.effortBasis;
      }
    }
  }

  return {
    completedSets,
    exerciseCount: plan.exercises.length,
    totalReps,
    totalVolumeLoadKg: round1(totalVolumeLoadKg),
    estimatedOneRepMaxByExercise,
    oneRepMaxEffortBasisByExercise,
  };
}

export interface DoubleProgressionInput {
  currentLoadKg: number;
  completedSetReps: readonly number[];
  minimumReps: number;
  maximumReps: number;
  loadIncrementKg?: number;
}

export interface DoubleProgressionSuggestion {
  action: 'increase_load' | 'maintain_load' | 'insufficient_data';
  currentLoadKg: number;
  suggestedLoadKg: number;
  reason: string;
}

/** Conservative double progression: increase only after all logged sets hit the top of the rep range. */
export function suggestDoubleProgression(input: DoubleProgressionInput): DoubleProgressionSuggestion {
  const increment = input.loadIncrementKg ?? 2.5;
  if (!Number.isFinite(input.currentLoadKg) || input.currentLoadKg < 0 ||
      !Number.isFinite(increment) || increment <= 0 ||
      !Number.isInteger(input.minimumReps) || !Number.isInteger(input.maximumReps) ||
      input.minimumReps < 1 || input.maximumReps < input.minimumReps) {
    throw new RangeError('Parâmetros de progressão inválidos.');
  }
  if (input.completedSetReps.length === 0 || input.completedSetReps.some((reps) => !Number.isInteger(reps) || reps < 0)) {
    return {
      action: 'insufficient_data',
      currentLoadKg: input.currentLoadKg,
      suggestedLoadKg: input.currentLoadKg,
      reason: 'Registre séries concluídas com repetições válidas antes de sugerir progressão.',
    };
  }
  if (input.currentLoadKg <= 0) {
    return {
      action: 'insufficient_data',
      currentLoadKg: input.currentLoadKg,
      suggestedLoadKg: input.currentLoadKg,
      reason: 'A progressão automática de carga externa não se aplica a exercícios sem carga registrada.',
    };
  }
  const allSetsReachedTop = input.completedSetReps.every((reps) => reps >= input.maximumReps);
  if (!allSetsReachedTop) {
    return {
      action: 'maintain_load',
      currentLoadKg: input.currentLoadKg,
      suggestedLoadKg: input.currentLoadKg,
      reason: 'Mantenha a carga até alcançar o topo da faixa em todas as séries registradas.',
    };
  }
  return {
    action: 'increase_load',
    currentLoadKg: input.currentLoadKg,
    suggestedLoadKg: round1(input.currentLoadKg + increment),
    reason: 'Todas as séries registradas alcançaram o topo da faixa de repetições; avance pelo menor incremento configurado.',
  };
}

export interface WeeklyMuscleSetSession {
  dateKey: string;
  exercises: Array<{
    muscles: MuscleHighlightPayload;
    sets: Array<{ completed: boolean }>;
  }>;
}

export interface MuscleSetVolume {
  primarySets: number;
  secondarySets: number;
  effectiveSets: number;
}

/** Counts direct sets as 1.0 and secondary mapped sets as 0.5; no biological claim is implied. */
export function calculateWeeklyMuscleSetVolume(
  sessions: readonly WeeklyMuscleSetSession[],
  weekStartDateKey: string,
): Record<MuscleGroupId, MuscleSetVolume> {
  if (!isValidDateKey(weekStartDateKey)) throw new RangeError('Data inicial da semana inválida.');
  const start = Date.parse(`${weekStartDateKey}T00:00:00Z`);
  if (!Number.isFinite(start)) throw new RangeError('Data inicial da semana inválida.');
  const end = start + 7 * 86_400_000;
  const result = {} as Record<MuscleGroupId, MuscleSetVolume>;
  const ids: MuscleGroupId[] = [
    'pectoralis', 'anterior_deltoid', 'lateral_deltoid', 'posterior_deltoid', 'biceps',
    'triceps', 'forearms', 'abdominals', 'latissimus', 'trapezius', 'glutes',
    'quadriceps', 'hamstrings', 'calves',
  ];
  for (const id of ids) result[id] = { primarySets: 0, secondarySets: 0, effectiveSets: 0 };

  for (const session of sessions) {
    if (!isValidDateKey(session.dateKey)) continue;
    const sessionTime = Date.parse(`${session.dateKey}T00:00:00Z`);
    if (!Number.isFinite(sessionTime) || sessionTime < start || sessionTime >= end) continue;
    for (const exercise of session.exercises) {
      const completedCount = exercise.sets.filter((set) => set.completed).length;
      const primary = new Set(exercise.muscles.primary);
      const secondary = new Set(exercise.muscles.secondary);
      for (const id of ids) {
        const volume = result[id]!;
        if (primary.has(id)) {
          volume.primarySets += completedCount;
          volume.effectiveSets += completedCount;
        } else if (secondary.has(id)) {
          volume.secondarySets += completedCount;
          volume.effectiveSets += completedCount * 0.5;
        }
      }
    }
  }
  for (const id of ids) result[id]!.effectiveSets = round1(result[id]!.effectiveSets);
  return result;
}
