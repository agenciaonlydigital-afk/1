import type { MuscleHighlightPayload } from '@/src/shared/types/common';

export interface SetRecord {
  id: string;
  setNumber: number;
  targetReps: string;
  weightKg: number;
  reps: number;
  /** Self-reported repetitions in reserve; null means not recorded. */
  repsInReserve?: number | null;
  completed: boolean;
  completedAtMs?: number;
}

export interface WorkoutExercise {
  id: string;
  exerciseSlug: string;
  name: string;
  equipment: string;
  targetRestSeconds: number;
  muscles: MuscleHighlightPayload;
  sets: SetRecord[];
}

export interface WorkoutPlan {
  id: string;
  title: string;
  splitLabel: string;
  status: 'pending' | 'in_progress' | 'completed';
  exercises: WorkoutExercise[];
}


export interface CompletedWorkoutSetSnapshot {
  exerciseId: string;
  exerciseName: string;
  setNumber: number;
  weightKg: number;
  reps: number;
  repsInReserve?: number | null;
}

export interface CompletedWorkoutSession {
  id: string;
  planId: string;
  planTitle: string;
  dateKey: string;
  startedAtMs: number | null;
  completedAtMs: number;
  completedSets: number;
  totalSets: number;
  sets: CompletedWorkoutSetSnapshot[];
}
