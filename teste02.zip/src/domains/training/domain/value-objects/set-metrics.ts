export interface SetLoadMetrics {
  weightKg: number;
  reps: number;
  volumeKg: number;
}

export function createSetLoadMetrics(weightKg: number, reps: number): SetLoadMetrics {
  const safeWeight = Math.max(0, weightKg);
  const safeReps = Math.max(0, Math.round(reps));
  return {
    weightKg: safeWeight,
    reps: safeReps,
    volumeKg: Number((safeWeight * safeReps).toFixed(1)),
  };
}
