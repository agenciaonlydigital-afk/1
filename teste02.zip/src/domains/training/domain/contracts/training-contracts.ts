import type { MuscleHighlightPayload } from '@/src/shared/types/common';

export interface MuscleHighlightDispatcher {
  applyHighlights: (payload: MuscleHighlightPayload) => void;
}
