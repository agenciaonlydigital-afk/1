import type { HydrationLogEntry } from '../../domain/entities/hydration-entry';

// Fresh installs start with an empty diary; only user-entered events are treated as facts.
export const INITIAL_HYDRATION_ENTRIES: HydrationLogEntry[] = [];
