import { z } from 'zod';

export const waterAmountSchema = z
  .number()
  .finite('Informe um volume válido.')
  .min(10, 'Informe um volume entre 10 e 5000 ml.')
  .max(5000, 'Informe um volume entre 10 e 5000 ml.');

export const waterCorrectionSchema = z
  .number()
  .finite('Informe um volume válido para correção.')
  .min(0, 'O valor de correção deve ficar entre 0 e 5000 ml.')
  .max(5000, 'O valor de correção deve ficar entre 0 e 5000 ml.');

export const waterGoalSchema = z
  .number()
  .finite('A meta de hidratação deve ser numérica.')
  .min(500, 'A meta de hidratação deve ficar entre 500 e 8000 ml.')
  .max(8000, 'A meta de hidratação deve ficar entre 500 e 8000 ml.');
