import { Droplets, Dumbbell, BookOpen, Ruler, Download, Upload } from 'lucide-react';
import { useRef, useState } from 'react';
import { BottomSheet } from '@/src/shared/ui/BottomSheet';
import { useHydrationStore } from '@/src/domains/hydration/state/hydration.store';
import { useNutritionStore } from '@/src/domains/nutrition/state/nutrition.store';
import { startWorkoutSession } from '@/src/domains/training/application/start-workout';
import { useTrainingSessionStore } from '@/src/domains/training/state/training-session.store';
import { useNavigationStore } from './navigation.store';
import { safeStorageAdapter } from '@/src/infrastructure/storage/local-storage';
import { createTitanBackup, parseTitanBackup, restoreTitanBackup, type TitanBackupEnvelope } from '../backup/titan-backup';
import { getLocalDateKey } from '@/src/shared/utils/local-date';

export function ActionSheet() {
  const open = useNavigationStore((s) => s.actionSheetOpen);
  const setActionSheetOpen = useNavigationStore((s) => s.setActionSheetOpen);
  const openSubView = useNavigationStore((s) => s.openSubView);
  const setTab = useNavigationStore((s) => s.setTab);
  const logWater = useHydrationStore((s) => s.logWater);
  const activeDateKey = useNutritionStore((s) => s.activeDateKey);
  const activePlanId = useTrainingSessionStore((s) => s.activePlanId);
  const backupInputRef = useRef<HTMLInputElement>(null);
  const [backupFeedback, setBackupFeedback] = useState<string | null>(null);
  const [pendingBackup, setPendingBackup] = useState<{ fileName: string; envelope: TitanBackupEnvelope } | null>(null);

  const close = () => {
    setPendingBackup(null);
    setActionSheetOpen(false);
  };

  const exportBackup = () => {
    try {
      const backup = createTitanBackup(safeStorageAdapter);
      const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `titan-backup-${getLocalDateKey()}.json`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1_000);
      setBackupFeedback('Backup exportado. Guarde o arquivo fora deste dispositivo.');
    } catch (error) {
      setBackupFeedback(error instanceof Error ? error.message : 'Falha ao exportar backup.');
    }
  };

  const importBackup = async (file: File) => {
    // The storage adapter intentionally falls back to memory when localStorage is blocked.
    // A restore must not report durable success in that mode, because the next reload would lose it.
    try {
      const probeKey = `titan:backup-probe:${Date.now()}`;
      window.localStorage.setItem(probeKey, '1');
      window.localStorage.removeItem(probeKey);
    } catch {
      setPendingBackup(null);
      setBackupFeedback('Este navegador não permite armazenamento local persistente. A restauração foi cancelada para evitar perda dos dados após atualizar a página.');
      return;
    }
    const parsed = parseTitanBackup(await file.text());
    if (!parsed.ok) {
      setPendingBackup(null);
      setBackupFeedback(parsed.error);
      return;
    }
    setBackupFeedback(null);
    setPendingBackup({ fileName: file.name, envelope: parsed.value });
  };

  const confirmRestoreBackup = () => {
    if (!pendingBackup) return;
    const restored = restoreTitanBackup(pendingBackup.envelope, safeStorageAdapter);
    if (!restored.ok) {
      setPendingBackup(null);
      setBackupFeedback(restored.error);
      return;
    }
    setPendingBackup(null);
    setBackupFeedback('Backup restaurado. Atualizando os dados…');
    window.location.reload();
  };

  const actions = [
    {
      id: 'water',
      icon: Droplets,
      title: 'Registrar copo de água',
      subtitle: 'Adiciona +250 ml ao registro do dia ativo',
      onClick: () => {
        logWater(250, activeDateKey);
        close();
      },
    },
    {
      id: 'workout',
      icon: Dumbbell,
      title: 'Abrir sessão de treino ativa',
      subtitle: 'Registrar séries e iniciar descanso automático',
      onClick: () => {
        startWorkoutSession(activePlanId);
        setTab('treino');
        openSubView('active-workout');
      },
    },
    {
      id: 'library',
      icon: BookOpen,
      title: 'Biblioteca anatômica de exercícios',
      subtitle: 'Consultar movimentos e músculos envolvidos',
      onClick: () => {
        setTab('treino');
        openSubView('exercise-library');
      },
    },
    {
      id: 'evolution',
      icon: Ruler,
      title: 'Registrar peso e medidas',
      subtitle: 'Atualizar registro observado em Evolução',
      onClick: () => {
        setTab('evolucao');
        close();
      },
    },
    {
      id: 'export-backup',
      icon: Download,
      title: 'Exportar backup',
      subtitle: 'Salvar seus dados locais em um arquivo JSON',
      onClick: exportBackup,
    },
    {
      id: 'import-backup',
      icon: Upload,
      title: 'Restaurar backup',
      subtitle: 'Importar um backup anterior e substituir os dados locais',
      onClick: () => backupInputRef.current?.click(),
    },
  ];

  return (
    <BottomSheet
      open={open}
      onClose={close}
      title="Ação rápida"
      subtitle="Atalhos contextuais sem sair do fluxo"
    >
      <div className="space-y-2">
        <input
          ref={backupInputRef}
          type="file"
          accept="application/json,.json"
          className="hidden"
          onChange={(event) => {
            const file = event.currentTarget.files?.[0];
            if (file) void importBackup(file).catch(() => setBackupFeedback('Não foi possível ler o arquivo de backup.'));
            event.currentTarget.value = '';
          }}
        />
        {actions.map((action) => {
          const Icon = action.icon;
          return (
            <button
              key={action.id}
              type="button"
              onClick={action.onClick}
              className="w-full min-h-[56px] p-3.5 rounded-2xl bg-[var(--titan-surface-raised)] border border-[var(--titan-border)]/80 shadow-[inset_0_1px_0_rgba(241,240,233,0.055)] flex items-center gap-3.5 text-left"
            >
              <div className="w-10 h-10 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)] flex items-center justify-center text-[var(--titan-accent)] shrink-0">
                <Icon className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <div className="text-sm font-medium text-[var(--titan-text-primary)] truncate">
                  {action.title}
                </div>
                <div className="text-xs text-[var(--titan-text-secondary)] truncate mt-0.5">
                  {action.subtitle}
                </div>
              </div>
            </button>
          );
        })}
        {pendingBackup && (
          <div
            role="alertdialog"
            aria-label="Confirmar restauração de backup"
            className="rounded-2xl border border-[var(--titan-status-warning)]/45 bg-[var(--titan-bg-canvas)] p-3.5 space-y-2.5"
          >
            <p className="text-xs leading-relaxed text-[var(--titan-text-primary)]">
              Restaurar <strong>{pendingBackup.fileName}</strong> substituirá os registros TITAN salvos neste navegador. Continuar?
            </p>
            <div className="flex flex-wrap gap-2 justify-end">
              <button
                type="button"
                onClick={() => {
                  setPendingBackup(null);
                  setBackupFeedback('Restauração cancelada.');
                }}
                className="min-h-[40px] px-3 rounded-xl border border-[var(--titan-border)] text-xs font-medium text-[var(--titan-text-secondary)]"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={confirmRestoreBackup}
                className="min-h-[40px] px-3.5 rounded-xl bg-[var(--titan-accent)] text-xs font-semibold text-[var(--titan-bg-canvas)]"
              >
                Confirmar restauração
              </button>
            </div>
          </div>
        )}
        {backupFeedback && <p className="px-1 pt-1 text-xs text-[var(--titan-text-secondary)]" role="status">{backupFeedback}</p>}
        <p className="px-1 text-[10px] text-[var(--titan-text-muted)]">O backup é local e manual; não há sincronização em nuvem. Armazene o arquivo em local seguro.</p>
      </div>
    </BottomSheet>
  );
}
