/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { MotionConfig } from './shared/motion/titan-motion';
import { AppProviders } from './app-core/providers/AppProviders';
import { AppShell } from './app-core/navigation/AppShell';

export default function App() {
  return (
    <MotionConfig reducedMotion="user">
      <AppProviders>
        <AppShell />
      </AppProviders>
    </MotionConfig>
  );
}
