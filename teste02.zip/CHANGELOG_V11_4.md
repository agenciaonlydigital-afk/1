# TITAN V.MAX V11.4

## Correções e melhorias

- Picking anatômico respeita a oclusão da superfície corporal visível.
- Regra de oclusão isolada e coberta por testes de distância, tolerância e entradas inválidas.
- Busca de exercícios ampliada com aliases em português para os mesmos 14 grupos musculares.
- Contratos públicos adicionados para leitura do catálogo muscular e do catálogo de exercícios entre domínios.
- Testes de fronteira para os fluxos de treino e biblioteca.
- Pipeline de testes consolidado sem repetir o conjunto de anatomia.
- CI adicionada com Bun lockfile congelado, typecheck, testes e build.
- README atualizado para refletir a versão e o gerenciador de pacotes reais.

## Preservado

- Todos os 14 IDs musculares estáveis.
- Corpo completo incluindo cabeça, pescoço, tronco, braços, mãos, pernas e pés.
- Dados, exercícios, séries, cargas, repetições e estados de treino existentes.
- Renderer Three.js, batching, atributos GPU, shader holográfico, materiais, lifecycle e limites de pixel.

## Validação

`npm run test:anatomy` executado no ambiente de edição. Typecheck completo, build Vite e testes que dependem de `tsx`/dependências externas não foram executados porque a instalação do npm registry expirou por indisponibilidade de rede. O workflow GitHub Actions foi adicionado para executar essas verificações em CI.
