import assert from 'node:assert/strict';
import { EXERCISE_CATALOG, getExerciseBySlug } from '../src/domains/exercise-library/data/repositories/exercise-catalog.ts';
import { EXERCISE_MUSCLE_MAP } from '../src/domains/anatomy/mapping/exercise-muscle-map.ts';
import { ExerciseRegistry } from '../src/domains/exercise-library/application/exercise-library-public.ts';
import { MUSCLE_REGISTRY } from '../src/domains/anatomy/mapping/muscle-registry.ts';
import { INITIAL_WORKOUT_PLANS } from '../src/domains/training/data/repositories/workout-seed.ts';
import { EXERCISE_DATA_SOURCES } from '../src/domains/exercise-library/data/repositories/exercise-source-registry.ts';

const catalogBySlug = new Map(EXERCISE_CATALOG.map((exercise) => [exercise.slug, exercise]));
assert.equal(catalogBySlug.size, EXERCISE_CATALOG.length, 'Exercise catalog contains duplicate slugs.');
assert.equal(EXERCISE_CATALOG.length, 32, 'Expected the 17 canonical exercises plus 15 selected imported records.');
assert.equal(ExerciseRegistry.list().length, EXERCISE_CATALOG.length, 'Public registry and canonical catalog differ.');

for (const exercise of EXERCISE_CATALOG) {
  assert.equal(getExerciseBySlug(exercise.slug), exercise, `Canonical slug lookup failed for ${exercise.slug}.`);
  assert.equal(ExerciseRegistry.find(exercise.slug), exercise, `Public registry lookup failed for ${exercise.slug}.`);
}

const validMuscles = new Set(Object.keys(MUSCLE_REGISTRY));
const sourceRegistryIds = new Set(EXERCISE_DATA_SOURCES.map((source) => source.id));
for (const exercise of EXERCISE_CATALOG) {
  assert.ok(exercise.slug.trim(), 'Exercise slug must not be empty.');
  assert.ok(exercise.name.trim(), `${exercise.slug} must have a name.`);
  assert.ok(exercise.equipment.trim(), `${exercise.slug} must have equipment metadata.`);
  assert.ok(exercise.pattern.trim(), `${exercise.slug} must have a movement pattern.`);
  assert.ok(exercise.cue.trim(), `${exercise.slug} must have a short execution cue.`);
  assert.ok(exercise.instructions?.length >= 2, `${exercise.slug} must have at least two execution steps.`);
  assert.ok(exercise.tips?.length, `${exercise.slug} must have at least one technical tip.`);
  assert.ok(exercise.commonErrors?.length, `${exercise.slug} must have at least one common-error warning.`);
  assert.ok(exercise.level && exercise.force && exercise.mechanic && exercise.category, `${exercise.slug} must expose its basic taxonomy.`);

  const allIds = [...exercise.muscles.primary, ...exercise.muscles.secondary];
  assert.ok(exercise.muscles.primary.length > 0, `${exercise.slug} must define at least one primary muscle.`);
  for (const id of [...allIds, ...(exercise.stabilizers ?? [])]) {
    assert.ok(validMuscles.has(id), `${exercise.slug} references unknown TITAN muscle ID: ${id}`);
  }
  assert.equal(new Set(allIds).size, allIds.length, `${exercise.slug} repeats a muscle across primary/secondary lists.`);
  assert.equal(new Set(exercise.stabilizers ?? []).size, (exercise.stabilizers ?? []).length, `${exercise.slug} repeats stabilizer IDs.`);

  const sourceReferences = [...(exercise.source ? [exercise.source] : []), ...(exercise.sources ?? [])];
  for (const source of sourceReferences) {
    assert.ok(sourceRegistryIds.has(source.repository), `${exercise.slug} references source absent from registry: ${source.repository}`);
    assert.ok(source.recordId && source.recordUrl && source.license, `${exercise.slug} must retain source identity, URL and data license.`);
    if (source.repository === 'yuhonas/free-exercise-db') {
      assert.equal(source.license, 'Unlicense');
      assert.match(source.recordUrl, /github\.com\/yuhonas\/free-exercise-db\/blob\/main\/exercises\//);
      assert.match(source.recordBlobSha ?? '', /^[a-f0-9]{40}$/i, `${exercise.slug} source SHA must be a 40-character Git blob hash.`);
    }
  }

  for (const relatedSlug of [
    ...(exercise.progressions ?? []),
    ...(exercise.regressions ?? []),
    ...(exercise.alternatives ?? []),
  ]) {
    assert.notEqual(relatedSlug, exercise.slug, `${exercise.slug} cannot relate to itself.`);
    assert.ok(catalogBySlug.has(relatedSlug), `${exercise.slug} points to unknown related exercise ${relatedSlug}.`);
  }
}

const missing = [];
for (const plan of INITIAL_WORKOUT_PLANS) {
  for (const exercise of plan.exercises) {
    const catalogItem = catalogBySlug.get(exercise.exerciseSlug);
    if (!catalogItem) missing.push(`${plan.id}:${exercise.exerciseSlug}`);
    else {
      assert.equal(exercise.name, catalogItem.name, `Workout and catalog names differ for ${exercise.exerciseSlug}.`);
      assert.equal(exercise.equipment, catalogItem.equipment, `Workout and catalog equipment differ for ${exercise.exerciseSlug}.`);
      assert.deepEqual(catalogItem.muscles, exercise.muscles, `Workout and catalog muscle mappings differ for ${exercise.exerciseSlug}.`);
    }
  }
}
assert.deepEqual(missing, [], `Workout exercises missing from the library: ${missing.join(', ')}`);

const catalogMuscles = new Set(EXERCISE_CATALOG.flatMap((exercise) => [...exercise.muscles.primary, ...exercise.muscles.secondary]));
assert.deepEqual([...catalogMuscles].sort(), [...validMuscles].sort(), 'The catalog should provide at least one exercise example for every supported TITAN workout muscle group.');

assert.deepEqual(Object.keys(EXERCISE_MUSCLE_MAP).sort(), [...catalogBySlug.keys()].sort(), 'Compatibility map must be derived from every catalog item.');
for (const [slug, muscles] of Object.entries(EXERCISE_MUSCLE_MAP)) {
  assert.deepEqual(muscles, catalogBySlug.get(slug)?.muscles, `Derived map diverged for ${slug}.`);
  assert.notEqual(muscles.primary, catalogBySlug.get(slug)?.muscles.primary, `Derived map must not expose mutable primary arrays for ${slug}.`);
  assert.notEqual(muscles.secondary, catalogBySlug.get(slug)?.muscles.secondary, `Derived map must not expose mutable secondary arrays for ${slug}.`);
  assert.deepEqual(ExerciseRegistry.highlights(slug), muscles, `Registry highlight contract diverged for ${slug}.`);
}
assert.equal(EXERCISE_MUSCLE_MAP['unknown-slug'], undefined, 'Unknown exercise must not return an anatomy mapping.');

console.log(`OK: ${EXERCISE_CATALOG.length} exercises; all ${validMuscles.size} muscle groups covered; ${sourceRegistryIds.size} reviewed data sources; all workout entries and exercise relationships resolve.`);
