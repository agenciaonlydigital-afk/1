import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const read = (path) => readFileSync(new URL(path, import.meta.url), 'utf8');
const css = read('../src/index.css');
const fluid = read('../src/shared/graphics/fluid-shader-engine.ts');
const anatomyMaterials = read('../src/domains/anatomy/engine/materials/anatomy-materials.ts');
const anatomyShader = read('../src/domains/anatomy/engine/shaders/anatomy-material-shader.ts');
const packageJson = JSON.parse(read('../package.json'));

const hero = css.match(/\.titan-surface--hero\s*\{([\s\S]*?)\n\}/)?.[1] ?? '';
const topbar = css.match(/\.titan-topbar\s*\{([\s\S]*?)\n\}/)?.[1] ?? '';
const bottomNav = css.match(/\.titan-bottom-nav\s*\{([\s\S]*?)\n\}/)?.[1] ?? '';
const primaryButton = css.match(/\.titan-button--primary\s*\{([\s\S]*?)\n\}/)?.[1] ?? '';
const metal = fluid.match(/const METAL_FRAGMENT_300 = `([\s\S]*?)`;\n/)?.[1] ?? '';

assert.ok(hero.includes('repeating-linear-gradient'), 'hero finish should use an ultra-low-contrast satin microtexture');
assert.ok(hero.includes('var(--titan-satin-line)'), 'hero texture must be tokenized');
assert.ok(hero.includes('var(--titan-satin-gap)'), 'hero texture spacing must be tokenized');
const satinAlpha = Number(css.match(/--titan-satin-line:\s*rgba\([^,]+,[^,]+,[^,]+,\s*([0-9.]+)\)/)?.[1] ?? NaN);
assert.ok(Number.isFinite(satinAlpha) && satinAlpha <= 0.015, 'hero microtexture must stay below 1.5% opacity to avoid visual noise');
assert.ok(!css.includes('body::before') && !css.includes('body::after'), 'grain must not be layered over every screen');
assert.ok(primaryButton.includes('linear-gradient(180deg'), 'primary action must retain a restrained softbox sheen');
assert.ok(topbar.includes('-webkit-backdrop-filter: blur(12px)') && topbar.includes('backdrop-filter: blur(12px)'), 'topbar blur must have prefixed support and reduced radius');
assert.ok(bottomNav.includes('-webkit-backdrop-filter: blur(14px)') && bottomNav.includes('backdrop-filter: blur(14px)'), 'bottom navigation blur must have prefixed support and reduced radius');
assert.ok(topbar.includes('rgba(14, 20, 18, 0.95)'), 'topbar must use a stronger opaque fallback surface');
assert.ok(bottomNav.includes('rgba(16, 23, 20, 0.985)'), 'bottom navigation must use a stronger opaque fallback surface');

assert.ok(anatomyMaterials.includes("roughness: 0.74"), 'skin/body material should keep a soft matte finish');
assert.ok(anatomyMaterials.includes("roughness: 0.68"), 'muscle surfaces should have slightly more form-defining specular response');
assert.ok(anatomyMaterials.includes('MeshStandardMaterial'), 'anatomy should keep the standard PBR cost profile');
assert.ok(!anatomyMaterials.includes('MeshPhysicalMaterial') && !anatomyMaterials.includes('clearcoat:'), 'do not add expensive clearcoat lobes to the anatomical surface');
assert.ok(anatomyShader.includes('applyAnatomyMaterialEnhancements'), 'shader enhancement path must remain attached to anatomy materials');

assert.ok(metal.includes('float t = u_time * 0.30'), 'metal ripple animation should remain restrained');
assert.ok(metal.includes('float roughness = mix(0.24, 0.32, satinNoise)'), 'macro metal should keep a satin, not chrome, roughness range');
assert.ok(metal.includes('roughness, 0.28'), 'macro metal should use a stronger brushed anisotropy response');
assert.ok(metal.includes('roughness + 0.045, 0.21'), 'secondary studio strip should remain softer than the main reflection');
assert.ok(metal.includes('fbm3(mUv * 0.82'), 'retain one bounded procedural microfinish sample');
assert.ok(fluid.includes('const MIN_FLUID_FRAME_INTERVAL_MS = 1000 / 60'), 'shared fluid renderer must cap submissions at 60 fps');
assert.ok(fluid.includes('if (now - prevAt >= MIN_FLUID_FRAME_INTERVAL_MS)'), 'all shared gauge jobs must use the same frame budget');
assert.ok(fluid.includes('if (!job.isAnimating && !waveActive) continue'), 'static fluid must remain idle');
assert.ok(fluid.includes('prefersReducedMotion()'), 'motion preference support must remain active');
assert.ok(packageJson.scripts.test.includes('check-materials-v10.mjs'), 'V10 material checks must be part of npm test');

console.log('Material V10 checks passed (hero satin, PBR anatomy, macro anisotropy, reduced navigation blur and 60 FPS render budget).');
