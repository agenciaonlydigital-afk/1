import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const read = (path) => readFileSync(new URL(path, import.meta.url), 'utf8');
const trainingSeed = read('../src/domains/training/data/repositories/workout-seed.ts');
const exerciseFilter = read('../src/domains/exercise-library/application/filter-exercises.ts');
const anatomyCatalog = read('../src/domains/anatomy/application/muscle-catalog-public.ts');
const exercisePublic = read('../src/domains/exercise-library/application/exercise-library-public.ts');
const evolutionMetrics = read('../src/domains/evolution/domain/rules/evolution-metrics.ts');
const adaptiveEnergy = read('../src/domains/profile/domain/rules/adaptive-energy.ts');

assert.match(trainingSeed, /exercise-library\/application\/exercise-library-public/);
assert.doesNotMatch(trainingSeed, /exercise-library\/data\/repositories/);
assert.match(exerciseFilter, /anatomy\/application\/muscle-catalog-public/);
assert.doesNotMatch(exerciseFilter, /anatomy\/mapping\/muscle-registry/);
assert.match(anatomyCatalog, /export \{ MUSCLE_REGISTRY \}/);
assert.match(exercisePublic, /findExerciseDefinition/);
assert.doesNotMatch(evolutionMetrics, /state\/.*store/);
assert.doesNotMatch(adaptiveEnergy, /evolution\/state\/.*store/);
console.log('Domain boundary tests passed (cross-domain contracts do not depend on Zustand store implementations).');
