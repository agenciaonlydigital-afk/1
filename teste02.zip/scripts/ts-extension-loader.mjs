import { access } from 'node:fs/promises';
import { fileURLToPath, pathToFileURL } from 'node:url';
import path from 'node:path';

export async function resolve(specifier, context, nextResolve) {
  try {
    return await nextResolve(specifier, context);
  } catch (error) {
    if (error?.code !== 'ERR_MODULE_NOT_FOUND' || !specifier.startsWith('.') || path.extname(specifier)) throw error;
    const parentUrl = context.parentURL;
    if (!parentUrl?.startsWith('file:')) throw error;
    const candidatePath = path.resolve(path.dirname(fileURLToPath(parentUrl)), `${specifier}.ts`);
    try {
      await access(candidatePath);
      return nextResolve(pathToFileURL(candidatePath).href, context);
    } catch {
      throw error;
    }
  }
}
