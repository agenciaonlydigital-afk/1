import { estimateAdaptiveTdee } from '../src/domains/profile/domain/rules/adaptive-energy.ts';
import { estimateHallEffectiveEnergyDensityKcalPerKg } from '../src/domains/profile/domain/rules/hall-body-weight.ts';

let seed = 20261123;
function random() { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 2 ** 32; }
function normal() {
  const u1 = Math.max(1e-12, random());
  const u2 = random();
  return Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
}
const DAY_MS = 86_400_000;
const results = [];
for (let person = 0; person < 200; person += 1) {
  const trueBaseTdee = 2100 + random() * 800;
  const intakeMean = trueBaseTdee - (150 + random() * 200);
  let trueWeight = 70 + random() * 30;
  const profile = { sex: random() < 0.5 ? 'male' : 'female', age: 20 + Math.floor(random() * 45), heightCm: 155 + random() * 35, bodyFatPercent: 12 + random() * 23 };
  const start = Date.UTC(2026, 0, 1);
  const intake = [];
  const weights = [];
  let tdee = trueBaseTdee;
  for (let day = 0; day < 90; day += 1) {
    if (day >= 45 && day < 60) tdee = trueBaseTdee - 200 * ((day - 44) / 15);
    if (day >= 60) tdee = trueBaseTdee - 200;
    const consumed = intakeMean + normal() * 350;
    const density = estimateHallEffectiveEnergyDensityKcalPerKg({ ...profile, weightKg: trueWeight });
    trueWeight += (consumed - tdee) / density;
    const dateKey = new Date(start + day * DAY_MS).toISOString().slice(0, 10);
    intake.push({ dateKey, consumedKcal: Math.max(500, consumed), completeness: 'complete' });
    weights.push({ id: `${person}-${day}`, dateKey, dateLabel: '', weightKg: trueWeight + normal() * 0.6, waistCm: 85, armCm: 35, thighCm: 55 });
    if (day >= 27 && day % 7 === 6) {
      const estimate = estimateAdaptiveTdee(intake, weights, 28, { ...profile, weightKg: weights.at(-1).weightKg });
      if (estimate) {
        results.push({ person, day, truth: tdee, estimate: estimate.estimateKcal, uncertainty: estimate.uncertaintyKcal,
          lower: estimate.lowerBoundKcal, upper: estimate.upperBoundKcal });
      }
    }
  }
}
const steady = results.filter((r) => r.day >= 27 && r.day < 45);
const adapted = results.filter((r) => r.day >= 70 && r.day <= 89);
const metrics = (rows) => {
  const errors = rows.map((r) => r.estimate - r.truth);
  const rmse = Math.sqrt(errors.reduce((sum, e) => sum + e * e, 0) / errors.length);
  const bias = errors.reduce((sum, e) => sum + e, 0) / errors.length;
  const coverage = rows.filter((r) => r.lower <= r.truth && r.truth <= r.upper).length / rows.length;
  const meanBand = rows.reduce((sum, r) => sum + r.uncertainty, 0) / rows.length;
  return { n: rows.length, rmse: Number(rmse.toFixed(1)), bias: Number(bias.toFixed(1)), intervalCoverage: Number((coverage * 100).toFixed(1)), mean95HalfWidth: Number(meanBand.toFixed(1)) };
};
const report = { steady: metrics(steady), afterAdaptation: metrics(adapted) };
if (report.steady.rmse > 110 || report.afterAdaptation.rmse > 110 ||
    Math.abs(report.steady.bias) > 40 || Math.abs(report.afterAdaptation.bias) > 50 ||
    report.steady.intervalCoverage < 95 || report.afterAdaptation.intervalCoverage < 95) {
  throw new Error(`Adaptive TDEE simulation regression: ${JSON.stringify(report)}`);
}
console.log(JSON.stringify(report, null, 2));
