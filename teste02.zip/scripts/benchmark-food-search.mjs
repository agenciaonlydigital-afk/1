import { performance } from 'node:perf_hooks';
import { TBCA_FOODS } from '../src/domains/nutrition/data/sources/tbca-adapter.ts';
import { OPEN_FOOD_FACTS_PRODUCTS } from '../src/domains/nutrition/data/sources/open-food-facts-adapter.ts';
import { buildFoodSearchIndex, searchFoodIndex } from '../src/domains/nutrition/domain/rules/food-search.ts';

const foods = Object.values({ ...TBCA_FOODS, ...OPEN_FOOD_FACTS_PRODUCTS });
const buildStart = performance.now();
const index = buildFoodSearchIndex(foods);
const indexBuildMs = performance.now() - buildStart;
const queries = ['arroz integral', 'ovo mexido', 'frango', 'banana prata', '7891025118345', 'vitamina c'];
for (let i = 0; i < 10; i += 1) for (const query of queries) searchFoodIndex(index, query, 20);
const samples = [];
for (let i = 0; i < 30; i += 1) {
  for (const query of queries) {
    const start = performance.now();
    const results = searchFoodIndex(index, query, 20);
    samples.push(performance.now() - start);
    if (results.length > 20) throw new Error('Search exceeded the configured result limit.');
  }
}
samples.sort((a, b) => a - b);
const median = samples[Math.floor(samples.length * 0.5)];
const p95 = samples[Math.floor(samples.length * 0.95)];
console.log(JSON.stringify({ records: foods.length, indexBuildMs: Number(indexBuildMs.toFixed(2)), queryCount: samples.length, medianQueryMs: Number(median.toFixed(2)), p95QueryMs: Number(p95.toFixed(2)) }, null, 2));
if (p95 > 250) throw new Error(`Food search p95 ${p95.toFixed(1)} ms exceeded 250 ms budget.`);
