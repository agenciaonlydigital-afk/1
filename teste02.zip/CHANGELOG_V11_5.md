# TITAN V.MAX V11.5 — Nutrition & Evolution Engine

## Nutrition

- Unified Cardápios, Receitas and Alimentos in the `NutritionWorkspace` component while preserving the existing lazy route export.
- Imported 5,830 eligible, complete TBCA 7.2 food records from the user's final nutrition workbook; preserved source identifiers and source URLs. Added a reproducible catalog generator and SHA-256 provenance manifest.
- Excluded 47 TBCA records blocked by the workbook's eligibility/quality flags. Missing nutrient values remain `not_analyzed`; true zeros remain zero.
- Preserved legacy food identifiers used by existing recipes and fixtures.
- Added fiber, saturated fat, cholesterol and sodium fields to the food macro composition.
- Preserved fractional gram precision throughout recipe calculations.
- Added data coverage, unresolved-food and lower-confidence reporting to macro calculations and recipe cards.
- Prevented partial-meal calculations from reconstructing consumed grams from rounded display quantities.
- Added explicit day-complete confirmation to qualify food logs for adaptive expenditure calibration.

## Energy and evolution

- Added robust daily-median + Theil–Sen weight trend estimation.
- Added target distance, weekly and daily required pace, observed trend, deadline status and a labelled target-date projection.
- Made body circumferences optional on a weigh-in so weight can be logged daily and circumferences independently; added optional chest, hip, neck, forearm and calf capture in an advanced section.
- Added adaptive TDEE calibration from confirmed intake plus aligned weight history, with a sensitivity range and strict data-coverage gates.
- Integrated adaptive TDEE into goal preview/save when confidence is sufficient; otherwise retain the equation/activity baseline.
- Corrected DRI profile routing for male/female adult bands 19–50, 51–70 and 71+.

## Data durability and safety

- Added versioned Zustand persistence for profile, nutrition and evolution records.
- Meal changes invalidate the day's intake-complete confirmation.
- Preserved existing records, recipes, meal slots, goals, profile fields and existing app domains.

## Validation

- Passed targeted profile, evolution, TBCA catalog, domain-boundary and anatomy regression checks.
- Transpiled 128 TypeScript/TSX source files with zero syntax diagnostics.
- Full typecheck/build/E2E remain unverified because package installation timed out in this environment; see `docs/NUTRITION_EVOLUTION_ENGINE_VMAX_V11_5.md`.
