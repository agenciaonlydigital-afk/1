# Implementações e prioridades — V11.16

## Implementado no código

| Frente | Código entregue | Estado | Limite explícito |
|---|---|---|---|
| Modelo dinâmico de peso | `profile/domain/rules/hall-body-weight.ts`; solver de ingestão por peso-alvo/prazo | Implementado e testado por simulação determinística/unitária | Core Hall 2011 independente; não é o aplicativo oficial NIDDK; há pressupostos para carboidratos, sódio e RMR; prazos acima de 10 anos não são extrapolados. |
| Densidade adaptativa | `adaptive-energy.ts` recebe composição demográfica e deriva densidade por partição de gordura/massa magra | Implementado; fallback legado 7.000 kcal/kg explícito quando faltam dados | Não elimina impacto de água/glicogênio nem validação real. |
| Perfil RMR | Campos de RMR selecionável, gordura corporal, origem da FFM e calorimetria indireta em `HomeHeader.tsx`, schema e persistência | Implementado; V1 continua compatível | Dados informados pelo usuário não são verificados contra laudos; o perfil exige origem declarada para qualquer percentual de gordura registrado. |
| Reconciliação | `activity-reconciliation.ts` e `sync-native-activity-energy.ts` | Implementado e testado com cenários sintéticos; conflitos parciais são isolados e não contabilizados até revisão | A camada ainda não recebe automaticamente registros de uma bridge real no app web. |
| Catálogo MET | `activity-met-catalog.ts`, validação versionada, consistência de fonte e allowlist de licenças | Importador/validador implementado | Nenhum dataset completo está embarcado; licenças devem ser revisadas por publicação. |
| Android | `native/android/titan-healthconnect` | Scaffold Kotlin/Health Connect | Host Android, UI de permissões, build e device tests pendentes. |
| iOS | `native/ios/TitanHealthKit` | Scaffold Swift/HealthKit | Host iOS, capability, privacy string, build e device tests pendentes. |
| Filtro adaptativo | Density awareness, warnings e gate de qualidade já existente | Otimizado | Intervalos ainda não calibrados contra referência externa. |

## Top 5 que ainda precisam ser fechados

1. **Validação de campo do TDEE:** coletar dados consentidos, anonimizados e com referência independente. Reportar MAE/RMSE, viés, Bland–Altman e calibração das bandas por sexo, idade, IMC, composição corporal e nível de atividade.
2. **Port nativo OpenMetabolics:** implementar aquisição 50 Hz, filtro/feature extraction, inferência e paridade com o pipeline de referência. Não incluir pesos ou datasets até resolver direitos separadamente.
3. **Completar hosts nativos:** integrar o scaffold ao app Android/iOS real, autorização, background scheduling, retenção mínima, privacidade e E2E em dispositivos reais.
4. **Catálogo MET com licença comercialmente compatível:** adquirir ou montar catálogo de fonte aberta compatível, fazer revisão por linha e adicionar teste de versão/checksum; o Compendium 2024 não deve ser redistribuído/derivado sem autorização.
5. **Calibração do modelo de Hall:** substituir hipóteses de 45% de carboidrato e sódio estável por médias alimentares/medidas quando disponíveis; comparar previsões por horizonte e composição com coorte independente e implementar cenários probabilísticos.

## Recomendação operacional

Não adicionar calorias de exercício ao TDEE observado por ingestão + tendência de peso: esse TDEE já representa o gasto total efetivamente observado. A reconciliação de atividade serve para histórico por sessão, auditoria e produtos de atividade; só pode compor outra estimativa se a definição do alvo energético e a política de dupla contagem forem explicitamente diferentes.
