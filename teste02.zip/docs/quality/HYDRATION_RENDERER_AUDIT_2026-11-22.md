# Hydration renderer — engineering corrections

**Baseline:** `titan-hydration-ultra-realista.zip` (latest available artifact in the Library at the time of this revision).  
**Scope:** hydration visuals, shared WebGL scheduler, fallback behavior, validation contract and focused regression checks. Existing hydration state model, history and add/correct/remove flows are preserved.

## Corrections applied

1. Reordered two GLSL `smoothstep` ramps whose literal edges were reversed. GLSL defines the result as undefined when `edge0 >= edge1`; the intended descending masks are expressed as `1.0 - smoothstep(low, high, x)`.
2. Preserved the shared demand-driven RAF model. Static water is rendered once; the loop wakes only for a value transition or active spring impulse. This remains shared with the energy and macro visual jobs.
3. Replaced per-step spring `Float32Array` allocations with per-wave reusable scratch buffers.
4. Made the offscreen render target grow-only rather than resizing to every job's dimensions. The viewport/scissor still restrict each pass to its own dimensions.
5. Removed `bitmaprenderer` from visible canvases. A stable 2D target context allows the same canvas to accept the Canvas2D fallback after a WebGL context failure. Offscreen `ImageBitmap`s are drawn and explicitly closed.
6. Added context-lost fallback notification, stopped the animation loop during loss, and added context-restored reinitialization notification. Fallback rendering is redrawn immediately when the shared context is lost.
7. Added shader compile and program link diagnostics and cleanup for partially created shaders.
8. Corrected progressbar accessibility: `aria-valuenow` uses the clamped 0–100 visual value; `aria-valuetext` preserves the actual ml and over-goal percentage.
9. Removed decorative click-to-splash behavior from the read-only progress indicator.
10. Aligned water input validation to the store's existing 10 ml minimum, eliminating the accepted-then-silently-clamped 1–9 ml case.
11. Corrected the procedural studio environment azimuth so front/back directions are not folded together.
12. Added regression assertions for 10 ml validation, over-goal progress clamping, and spring stability; added a static check for reversed literal `smoothstep` edges.

## Repository research used

- `evanw/webgl-water` — reference for height/velocity spring-like water simulation, refraction and caustic projection. Its 256×256 ping-pong texture simulation is intentionally not copied into this tiny UI gauge.
- `Aureliengmz/clearwater` — reference for WebGL2 water optics, Fresnel, absorption, caustics and adaptive quality. Its FFT ocean simulation is intentionally out of scope for a 84×100 px gauge and 54 px capsule.
- `pmndrs/react-three-fiber` — demand rendering and manual invalidation; supports keeping the shared RAF idle when no component is animating.
- `pmndrs/drei` `MeshTransmissionMaterial` — reference for IOR, thickness, attenuation, refraction and chromatic dispersion. The current custom shader remains a lightweight analytical approximation rather than a full scene transmission pipeline.
- `StarKnightt/liquid-glass` and `smirki/glasswork` — SDF-based surface normals, bounded refraction, Fresnel/rim optics and single-pass rendering. Their glass-lens effects are not treated as a substitute for liquid-volume simulation.

## Validation status

Run `npm test` for hydration assertions, spring assertions and literal shader-edge checks. Run `npm run lint` and `npm run build` in an environment with dependencies installed. The repository package has no GPU shader compiler in this environment; a real WebGL2 compile/render test is still required on a browser/GPU CI runner. Do not interpret the static edge check as GPU shader compilation or a visual approval.
