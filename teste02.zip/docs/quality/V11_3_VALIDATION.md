# TITAN V.MAX V11.3 — validation record

Validation date: 22 November 2026.

## Passed in this environment

- `node scripts/check-fluid-shaders.mjs`
- `node scripts/check-cockpit-visual-semantics.mjs`
- `node scripts/check-titan-design-system.mjs`
- `node scripts/check-anatomy-v9.mjs`
- `node scripts/check-materials-v10.mjs`
- `npm run test:anatomy`
  - loft geometry seam/cap/normal/bounds/index-width invariants
  - generated muscle normal-map dimensions and value bounds
  - shader patch contract for both body and muscle material roles
  - all 14 canonical muscle IDs, body/head preservation, and picker linkage
  - renderer lifecycle and context-loss cleanup
  - V9+ performance/lifecycle source contracts
  - V11.3 UV, normal-map, hologram, and shader-cache contracts
  - catalog/source-license/muscle-map/workout-seed contract
  - accent-insensitive exercise search, primary/secondary muscle search, and empty state
- Exact parity comparison against V11.2.1 for seeded plans, exercises, set IDs, weights, reps, completion flags, plan states, and rest targets.
- TypeScript/TSX syntax transpilation of 122 source and script files: zero syntax diagnostics.
- Archive integrity is checked after packaging with `unzip -t`.

## Not certified here

The container did not include `node_modules` and could not resolve the npm registry during the prior dependency-install attempt. Consequently:

- `npm run lint` is blocked because the `vite/client` type package is unavailable.
- `npm run build` is blocked because the local `vite` executable is unavailable.
- The 122-file syntax pass is not a substitute for a full project semantic type-check.
- Static shader injection checks do not replace compilation against the installed Three.js shader chunks or GPU execution.
- No physical iOS/Android device was available for FPS, temperature, memory, touch latency, or sustained-session profiling.

Do not interpret the static `60 FPS render budget` contract as a measured device result.
