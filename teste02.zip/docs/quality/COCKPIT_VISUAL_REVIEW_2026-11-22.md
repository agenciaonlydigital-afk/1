# Cockpit visual review — 2026-11-22

## Scope

Energy progress, macro semicircle gauges and the shared WebGL2 shader engine. The hydration component's data flow and 3D geometry were not rewritten in this pass.

## Implemented

- Replaced the nutrition energy bar's domain-warped plasma with a Mineral Sage mineral-fluid treatment: darker cavity, restrained satin volume, broad softbox reflection and a narrow meniscus.
- Reduced energy shader work from five domain-warped FBM samples to one FBM3 sample and removed the large shared optics helper block from this shader. The shader uses a minimal noise helper set.
- Renamed the renderer program kind from `plasma` to `energy` so code semantics match the UI concept.
- Made energy and macro progress interpolation exponential and frame-rate independent through `interpolateRatio`.
- Explicitly wake the shared render loop when a target value changes; a transition no longer depends on another component animating.
- Re-render on visibility entry and keep the Canvas2D fallback current after resize/value changes.
- Snap to the target when the user enables reduced motion while the page is already open; resume only if a transition remains when reduced motion is disabled.
- Changed the energy heading to `ENERGIA CONSUMIDA` and the macro heading to `MACRONUTRIENTES`.
- Corrected energy and macro progressbar ARIA values so the numeric value remains clamped to 0–100 while `aria-valuetext` preserves the real over-goal amount.
- Macro status now distinguishes remaining grams, goal reached and grams above goal. Invalid/missing goals are not represented as a false 1g goal.
- Replaced the macro shader's two redundant FBM warp calls and two extra finite-difference FBM calls with hardware derivatives of the existing height sample.
- Replaced Phong-like macro highlights with GGX microfacet highlights, reduced rainbow-like thin-film coloration and removed the metallic text gradient so the gauge carries the material effect while the label stays legible.
- Removed the redundant second initial draw when registering energy, macro and water jobs with the shared renderer; callers that already drew their initial frame now mark it as rendered.

## Quality assessment

- Energy: more coherent with the Graphite / Mineral Sage dashboard, less visually noisy and cheaper to shade. It is still a stylized visual metaphor, not a literal simulation of human metabolism.
- Macros: better controlled metallic response and more honest progress copy. The arcs are still a compact shader illustration, not a physically complete 3D metal object.
- Hydration: retain the current 2.5D/SDF optical approach. Its next realism gains should come from the environment and air/glass/water interface model, not from adding a large fluid framework.

## Validation performed

- Static GLSL checks: passed (literal `smoothstep` edge ordering, required shader blocks, balanced GLSL braces, no legacy plasma program, bounded macro FBM sample count).
- Strict standalone TypeScript check for the shared fluid engine: passed.
- Runtime assertions for spring stability and progress interpolation at 30/60Hz: passed.
- TS/TSX transpilation checks for EnergySummary, MacroOverview, engine and engine tests: passed.

## Not yet validated

- Full project `npm run lint`, `npm test` and production build were not run because project dependencies are not installed in this environment (and the repository uses `bun.lock`, while Bun is unavailable here).
- GLSL compile/link and visual output were not validated on a real WebGL2 GPU. Static shader checks do not prove driver compilation or visual quality.
- Browser-level accessibility, screenshots and GPU timings still require a browser test runner and target devices.
