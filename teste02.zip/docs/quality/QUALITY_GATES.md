# Critérios de Qualidade e Testes — TITAN

## Estratégia de Testes
1. **Regras de domínio puras** (`domain/rules/`): cronômetro de descanso em tempo real (inclusive overtime), cálculo de progresso de treino e máscara de bits anatômica.
2. **Validações de fronteira** (`schemas/`): entradas numéricas de séries e medidas corporais com Zod.
3. **Acessibilidade e Resiliência**: fallback 2D anatômico completo quando WebGL não estiver disponível e respeito a `prefers-reduced-motion`.

## Portão de Qualidade
Nenhuma dimensão crítica (identidade, ergonomia, acessibilidade, corpo 3D, treino, descanso, nutrição, evolução, arquitetura, segurança) pode compensar falhas graves de outra dimensão.


## V.MAX V7 — Design and visual gates

1. Semantic color roles are distinct: brand, data category, status and material colors do not substitute for one another.
2. Primary/secondary/muted text and semantic status colors maintain at least 4.5:1 contrast against canvas, surface, raised and elevated backgrounds in the current dark palette.
3. Every interactive anatomy muscle can be selected by pointer without treating a drag as a click; hidden anatomical layers are excluded from picking; the accessible muscle list remains available.
4. The anatomy viewport preserves on-demand rendering, shared resources, DPR limits and reduced-motion handling.
5. Food images use lazy loading/async decoding; the timer does not announce each tick to assistive technology.
6. Evolution trends use recorded values only, expose dates and units, and do not imply that a raw delta is automatically positive or negative.
7. Visual approval remains blocked until actual GPU screenshots and mobile/desktop inspection are completed.

Static check: `node scripts/check-titan-design-system.mjs`.

8. Main navigation, chart axis labels and non-decorative control labels must not fall below the 12 px reading baseline; smaller eyebrow/status microcopy is allowed only when it is not the only source of an instruction or data value.
9. Raw deltas in weight, circumference or limb measurements remain neutral unless an explicit validated goal interpretation exists. A positive number is not automatically a positive outcome.
10. The procedural anatomy mesh must never be represented as a full anatomical atlas. A future atlas requires asset-level provenance/license, structure-to-muscle mapping, download-size and device GPU budgets, and side/region QA.
