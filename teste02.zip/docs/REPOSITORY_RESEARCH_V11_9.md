# TITAN HYDRATION V.MAX — pesquisa de repositórios e decisões React V11.9

**Data da fotografia de popularidade:** 23/11/2026  
**Base revisada:** V11.8  
**Escopo:** arquitetura React/Vite, estado, dados remotos, formulários, editores, workflows, rotas, autenticação, testes, revisão estática e performance.  
**Regra:** estrelas são sinal de adoção, não prova de qualidade, adequação, manutenção, segurança ou licença.

Os números abaixo são aproximações observadas em páginas do GitHub e índices públicos entre 22 e 23/11/2026. Podem variar durante o dia. A ordem de cada lista considera popularidade aproximada; a decisão para o TITAN considera também a finalidade real do repositório e sua compatibilidade com a aplicação atual.

## 1. Dados remotos, API e cache (server state)

| Repositório | Stars aprox. | Licença | O que entrega / limite |
|---|---:|---|---|
| [TanStack Query](https://github.com/TanStack/query) | 50,6k | MIT | Cache, deduplicação, retries, refetch e ciclo de vida de dados remotos |
| [SWR](https://github.com/vercel/swr) | 32,5k | MIT | Hooks de fetching stale-while-revalidate, opção mais simples |
| [Apollo Client](https://github.com/apollographql/apollo-client) | 19,8k | MIT | Cliente GraphQL e cache normalizado; excesso para REST simples |
| [Relay](https://github.com/facebook/relay) | 18,9k | MIT | GraphQL orientado a schema/compilação; não é cache genérico REST |
| [Redux Toolkit](https://github.com/reduxjs/redux-toolkit) | 11,2k | MIT | RTK Query integrado ao ecossistema Redux; não justifica introduzir Redux junto com Zustand |

**Decisão TITAN:** escolher TanStack Query quando existir o primeiro consumidor real de endpoint remoto no frontend (por exemplo, sincronização autenticada ou dados da conta). Hoje o cliente não consome as rotas Express de receitas/TDEE e os módulos `http-client`, `event-tracker` e `sync-queue` não formam uma integração remota funcional. Instalar Query agora criaria um cache sem fonte de dados; não fazer isso.

Axios (aprox. 109k) é transporte HTTP, não substituto de TanStack Query/SWR. Não misturar transporte e cache como se fossem a mesma responsabilidade.

## 2. Estado global de interface e estado cliente

| Repositório | Stars aprox. | Licença | Perfil |
|---|---:|---|---|
| [Redux](https://github.com/reduxjs/redux) | 61,5k | MIT | Estado central previsível, reducers e ecossistema amplo |
| [Zustand](https://github.com/pmndrs/zustand) | 58,9k | MIT | Store leve, selectors e estado global simples |
| [MobX](https://github.com/mobxjs/mobx) | 28,2k | MIT | Reatividade observável e derivação automática |
| [Jotai](https://github.com/pmndrs/jotai) | 21,3k | MIT | Estado atômico e valores derivados |
| [Valtio](https://github.com/pmndrs/valtio) | 10,2k | MIT | Estado proxy reativo |

**Decisão TITAN:** manter Zustand para stores de domínio/client state que já existem. A aplicação usa selectors; não há evidência de que uma migração a Redux, MobX, Jotai ou Valtio resolveria um defeito atual. Não duplicar stores globais.

## 3. Formulários e validação

| Repositório | Stars aprox. | Licença | Perfil |
|---|---:|---|---|
| [React Hook Form](https://github.com/react-hook-form/react-hook-form) | 44,9k | MIT | Estado de formulários com subscriptions por campo; integra com Zod por resolver |
| [Formik](https://github.com/jaredpalmer/formik) | 34,3k | Apache-2.0 | Abordagem clássica; verificar atividade e roadmap antes de escolher em projeto novo |
| [React JSON Schema Form](https://github.com/rjsf-team/react-jsonschema-form) | 15,9k | Apache-2.0 | Geração de formulários a partir de JSON Schema |
| [Redux Form](https://github.com/redux-form/redux-form) | 12,5k | MIT | Histórico/legado; não recomendado para novo formulário local |
| [React Final Form](https://github.com/final-form/react-final-form) | 7,4k | MIT | Subscriptions granulares; alternativa madura |

**Challenger adicional:** [TanStack Form](https://github.com/TanStack/form), aproximadamente 6,8k stars, MIT. Apesar de estar abaixo do quinto colocado por stars, tem forte alinhamento com forms headless, TypeScript e estado de campo granular. Não escolher só pelo ranking de popularidade.

**Decisão TITAN:** React Hook Form + Zod para o editor completo de fichas, receitas e formulários de configuração extensos. O formulário atual de medição é curto e simples; a extração de componente e o estado local são suficientes. Migrá-lo para RHF agora não entregaria benefício demonstrável.

## 4. Estado atômico e cálculos interdependentes em editores

Esta é uma comparação de modelos de estado, não uma lista de cinco bibliotecas equivalentes a Jotai.

| Repositório | Stars aprox. | Licença | Modelo |
|---|---:|---|---|
| [Redux](https://github.com/reduxjs/redux) | 61,5k | MIT | Eventos/reducers e transições centralizadas |
| [MobX](https://github.com/mobxjs/mobx) | 28,2k | MIT | Derivação reativa por observables/computeds |
| [Jotai](https://github.com/pmndrs/jotai) | 21,3k | MIT | Átomos pequenos, derivados e subscriptions localizadas |
| [Valtio](https://github.com/pmndrs/valtio) | 10,2k | MIT | Proxy state com snapshots |
| [MobX-State-Tree](https://github.com/mobxjs/mobx-state-tree) | 7,1k | MIT | Árvore de estado com tipos, actions e snapshots |

**Decisão TITAN:** não introduzir Jotai ainda. Considerar um editor atômico dedicado quando existir um editor de plano/refeição com dezenas de campos dependentes (porções → macros → metas → validações) e o profiling mostrar renders ou complexidade de coordenação relevantes. Não armazenar a mesma informação em Zustand e Jotai.

## 5. Workflows, máquinas de estado e processos com várias etapas

| Repositório/candidato | Stars aprox. | Licença | Observação |
|---|---:|---|---|
| [Redux](https://github.com/reduxjs/redux) | 61,5k | MIT | Reducers/eventos, mas não é um statechart especializado |
| [XState](https://github.com/statelyai/xstate) | 30,4k | MIT | Statecharts, actors, guards e orchestration; melhor ferramenta especializada da lista |
| [JavaScript State Machine](https://github.com/jakesgordon/javascript-state-machine) | 8,7k | MIT | FSM simples, mas a atividade recente precisa ser reavaliada antes de adotar |
| [MobX-State-Tree](https://github.com/mobxjs/mobx-state-tree) | 7,1k | MIT | Árvore/actions/snapshots, não substitui XState como statechart |
| [Robot3](https://github.com/matthewp/robot) | 2,2k | BSD-2-Clause | FSM pequena; verificar a cadência de manutenção, não preferir apenas por leveza |

**Decisão TITAN:** XState somente para um fluxo realmente multi-etapas e com estados/transições não triviais — por exemplo, onboarding com permissões, sync, conflitos e retomada. Para confirmação de refeição, timer ou salvar medição, usar reducer/funções de domínio simples. Aumentar a complexidade apenas quando as transições exigirem isso.

## 6. Roteamento e estado na URL

| Repositório | Stars aprox. | Licença | Tipo |
|---|---:|---|---|
| [Next.js](https://github.com/vercel/next.js) | 143,6k | MIT | Meta-framework; não é uma dependência de roteamento para Vite |
| [React Router](https://github.com/remix-run/react-router) | 56,7k | MIT | Roteamento SPA, loaders/actions, histórico e search params |
| [Gatsby](https://github.com/gatsbyjs/gatsby) | 55,9k | MIT | Meta-framework, não alternativa direta a um router isolado |
| [Remix](https://github.com/remix-run/remix) | 33,5k | MIT | Framework e legado/ecossistema do qual evoluiu React Router; evitar contar como escolha independente sem checar versão |
| [TanStack Router](https://github.com/TanStack/router) | 15,3k | MIT | Rotas e search params com forte tipagem |

**Alternativa leve:** [Wouter](https://github.com/molefrog/wouter), aproximadamente 7,9k stars, Unlicense.

**Decisão TITAN:** React Router é a escolha simples para introduzir URL, browser back/forward, deep links e rotas privadas numa SPA Vite. TanStack Router ganha se filtros e parâmetros de busca fortemente tipados forem requisito central. Não adicionar `nuqs` antes de ter Next App Router ou um caso de query-state que justifique a dependência. A navegação atual é store-based e ainda não oferece URL/deep links.

## 7. Autenticação e sessão

| Repositório | Stars aprox. | Licença | Perfil |
|---|---:|---|---|
| [Better Auth](https://github.com/better-auth/better-auth) | 30,8k | MIT | Framework de autenticação TypeScript, adequado para auth gerenciada pela própria aplicação |
| [Auth.js](https://github.com/nextauthjs/next-auth) | 28,4k | ISC | Framework de autenticação; conferir adapters e integração com a stack específica |
| [Firebase JS SDK](https://github.com/firebase/firebase-js-sdk) | 5,2k | Apache-2.0 (há componentes com licenças próprias) | SDK de serviços Firebase, incluindo Auth |
| [Supabase JS](https://github.com/supabase/supabase-js) | 4,6k | MIT | Cliente de Supabase/Postgres/Auth/Storage/Realtime |
| [Clerk JavaScript](https://github.com/clerk/javascript) | 1,8k | MIT | SDK e UI de autenticação hospedada |

**Decisão TITAN:** React Context nativo para distribuir uma sessão que muda pouco é suficiente no frontend; o provedor real deve controlar validação no servidor e autorização nos dados. Não implementar uma sessão simulada ou guardar tokens sensíveis no Zustand/localStorage. Escolher Better Auth, Supabase Auth ou Clerk só depois de decidir backend, tenancy, recuperação de conta, retenção, políticas de privacidade e autorização.

## 8. Testes e qualidade de interface

| Repositório | Stars aprox. | Licença | Uso |
|---|---:|---|---|
| [Playwright](https://github.com/microsoft/playwright) | 100,8k | Apache-2.0 | E2E em Chromium, Firefox e WebKit |
| [Storybook](https://github.com/storybookjs/storybook) | 91,7k | MIT | Isolamento, documentação e testes visuais/interaction de componentes |
| [Cypress](https://github.com/cypress-io/cypress) | 51,0k | MIT | E2E e component testing no browser |
| [Jest](https://github.com/jestjs/jest) | 45,5k | MIT | Test runner geral e ecossistema de mocks |
| [React Testing Library](https://github.com/testing-library/react-testing-library) | 19,7k | MIT | Teste de componentes orientado ao comportamento do usuário |

**Peças adicionais que são melhores ajustes para esta stack mesmo com menos stars:** [MSW](https://github.com/mswjs/msw) (~18,4k, MIT) para simular API no limite de rede; [Vitest](https://github.com/vitest-dev/vitest) (~17,4k, MIT) como runner alinhado ao Vite; [axe-core](https://github.com/dequelabs/axe-core) (~7,9k, MPL-2.0) para checks automáticos de acessibilidade; `@testing-library/user-event` para interações reais de usuário.

**Decisão TITAN:** Playwright + Vitest + React Testing Library + user-event + MSW + axe-core. Cypress/Jest não devem ser adicionados em paralelo sem um motivo específico. Storybook é condicional ao crescimento do design system e da equipe de UI.

## 9. Revisão estática, análise e code review

| Repositório | Stars aprox. | Licença | Uso |
|---|---:|---|---|
| [ESLint](https://github.com/eslint/eslint) | 27,5k | MIT | Lint e regras de qualidade JS/TS |
| [Biome](https://github.com/biomejs/biome) | 25,9k | Apache-2.0/MIT | Formatter + linter; alternativa consolidada de toolchain |
| [Semgrep](https://github.com/semgrep/semgrep) | 16,8k | LGPL-2.1 (CE) | SAST e regras de padrões/segurança |
| [ast-grep](https://github.com/ast-grep/ast-grep) | 16,7k | MIT | Busca/refatoração estrutural baseada em AST |
| [typescript-eslint](https://github.com/typescript-eslint/typescript-eslint) | 16,5k | MIT | Regras e parser TS para ESLint |

**Revisão automatizada de PRs (ferramentas separadas de lint/SAST):** [The-PR-Agent/pr-agent](https://github.com/The-PR-Agent/pr-agent) (~12,0k, Apache-2.0), [reviewdog](https://github.com/reviewdog/reviewdog) (~9,4k, MIT), [Danger](https://github.com/danger/danger) (~5,7k, MIT), [shippie](https://github.com/side-quest/shippie) (~2,4k, MIT), [Kodus](https://github.com/kodustech/kodus) (~1,2k, AGPL-3.0). Verificar a organização/ownership atual do PR-Agent: forks antigos e links desatualizados circulam em listas.

**Decisão TITAN:** manter TypeScript strict + ESLint (se já configurado no CI) + scripts de invariantes de domínio. Escolher Biome como alternativa, não somá-lo automaticamente a uma pilha de ESLint/Prettier redundante. Introduzir Semgrep com regras de segurança específicas e revisão de PR automatizada apenas como comentário auxiliar; nunca permitir que um bot aprove sozinho uma alteração sensível.

## 10. Performance React e web

| Repositório | Stars aprox. | Licença | Uso |
|---|---:|---|---|
| [Lighthouse](https://github.com/GoogleChrome/lighthouse) | 31,2k | Apache-2.0 | Auditoria de carregamento, Core Web Vitals e boas práticas |
| [react-virtualized](https://github.com/bvaughn/react-virtualized) | 27,1k | MIT | Virtualização de listas/tabelas longas |
| [React Scan](https://github.com/aidenybai/react-scan) | 21,9k | MIT | Detectar e destacar re-renders em desenvolvimento |
| [react-window](https://github.com/bvaughn/react-window) | 17,2k | MIT | Virtualização focada e menor que react-virtualized |
| [web-vitals](https://github.com/GoogleChrome/web-vitals) | 8,7k | Apache-2.0 | Coleta programática de métricas Core Web Vitals |

**Decisão TITAN:** medir com React Profiler/React Scan no desenvolvimento e Lighthouse/web-vitals em build de produção. Virtualização só quando o número de itens renderizados e a medição de browser justificarem; a lista de alimentos limita-se hoje a 60 resultados visíveis, então não existe justificativa comprovada para adicionar react-window agora.

## Aplicação prática no V11.9

Foram aplicadas otimizações sem dependências novas:

1. Índice de busca de alimentos construído uma única vez, normalização de acentos e tokens preservando IDs e origem.
2. Ranking por relevância para que nome exato/prefixo tenha prioridade sobre sinônimos e IDs; limite de resultados defensivo.
3. Busca de alimentos isolada em componente memorizado, seletor Zustand somente para action e `useDeferredValue` para manter entrada responsiva.
4. Índice e cálculos de resumo de receitas pré-computados fora do componente; busca e atualização localizadas.
5. Formulário de medições isolado do painel de gráficos/métricas; digitar não força rerender de todo o dashboard.
6. Série cronológica e texto acessível do gráfico reutilizam dados derivados, evitando filtros/reversões repetidos.

## Não implementado de propósito nesta edição

- TanStack Query: não há consumidor real de dados remotos no frontend.
- React Hook Form: editores extensos completos ainda não existem; manter os formulários curtos simples.
- Jotai: ainda não há editor com grafo denso de dependências que justifique estado atômico adicional.
- XState: não há fluxo com estados e transições complexos suficiente.
- React Router/TanStack Router: URL/deep links ainda não foram migrados; requer plano de migração e regressões.
- Auth SDK: ainda não existe contrato de conta/sessão e autorização por usuário.
- Virtualização: a tela mostra no máximo 60 alimentos por busca e apenas 8 receitas.
- `memo`/`useMemo` indiscriminados: aplicar somente em limites com custo real identificado.

## Referências de evidência

- [TanStack Query README](https://github.com/TanStack/query): async/server-state, cache e fetch.
- [React Hook Form README](https://github.com/react-hook-form/react-hook-form): formulário e integração com resolvers.
- [TanStack Form comparison](https://tanstack.com/form/latest/docs/comparison): comparação de subscriptions, forms headless e validação (a própria página declara que a matriz está em construção).
- [XState README](https://github.com/statelyai/xstate): actors, statecharts e lógica de workflow complexa.
- [React Router README](https://github.com/remix-run/react-router) e [TanStack Router](https://github.com/TanStack/router): rotas e search params.
- [Better Auth](https://github.com/better-auth/better-auth), [Auth.js](https://github.com/nextauthjs/next-auth), [Supabase JS](https://github.com/supabase/supabase-js), [Firebase JS SDK](https://github.com/firebase/firebase-js-sdk), [Clerk JS](https://github.com/clerk/javascript): alternativas de sessão/provedor.
- [Playwright README](https://github.com/microsoft/playwright), [React Testing Library README](https://github.com/testing-library/react-testing-library), [Vitest README](https://github.com/vitest-dev/vitest), [MSW](https://github.com/mswjs/msw) e [axe-core](https://github.com/dequelabs/axe-core): base de testes.
- [React Profiler](https://react.dev/reference/react/Profiler), [useDeferredValue](https://react.dev/reference/react/useDeferredValue), [useMemo](https://react.dev/reference/react/useMemo), [React Scan](https://github.com/aidenybai/react-scan), [Lighthouse](https://github.com/GoogleChrome/lighthouse) e [web-vitals](https://github.com/GoogleChrome/web-vitals): medição e diagnóstico.
- [Bulletproof React](https://github.com/alan2207/bulletproof-react): referência de arquitetura feature-oriented, limites de domínio e organização; usada como referência, não copiada.

Nenhum código de terceiros foi copiado nesta revisão. Licença do código, licença de dataset/imagem e autorização de distribuição são coisas separadas; qualquer importação deve ser auditada por ativo.
