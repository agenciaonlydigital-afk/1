# V11.12 — acceptance and remaining gates

## Completed
- Canonical exercise registry validation during workout persistence hydration.
- Duplicate exercise/set IDs and unknown exercise slugs rejected.
- Meal persistence text/URL constraints and regression tests.
- Full `test:review` plus static contracts.

## Blocked by environment
- Bun binary absent; `node_modules` absent.
- npm registry DNS unavailable (`EAI_AGAIN registry.npmjs.org`).
- Therefore no lockfile-safe dependency install, official build, semantic typecheck, Playwright, axe-core, or Lighthouse run.

## Remaining production gates
1. Restore package registry access and install from `bun.lock` frozen.
2. Add Playwright and cover custom workout CRUD/session completion, custom meal CRUD, reload, backup/restore and mobile navigation.
3. Add Vitest + React Testing Library for editor validation and keyboard behavior; MSW only for real API contracts.
4. Integrate axe-core plus manual keyboard/screen-reader review.
5. Migrate navigation to React Router with Express fallback/deep-link tests.
6. Define backend identity, tenant ownership, authorization, encryption, conflict and recovery policy before authentication/sync.
7. Run full semantic typecheck, production build and Lighthouse mobile/desktop baseline.
