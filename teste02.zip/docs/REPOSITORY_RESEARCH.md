# Repository Research — V6

Research performed 22 Nov 2026 using direct GitHub repository metadata, GitHub code search, and source-file retrieval. Star counts are approximate snapshots; repository activity and counts change.

## Water / glass / optics

| Repository | Approx. stars | Source inspected | Reusable engineering insight | Decision |
|---|---:|---|---|---|
| [evanw/webgl-water](https://github.com/evanw/webgl-water) | 1.3k | `index.html`, feature description | Refraction/reflection, heightfield ripples, analytic AO, soft shadows, differential caustics | Adopt differential-area caustics concepts; do not port full scene |
| [Aureliengmz/clearwater](https://github.com/Aureliengmz/clearwater) | 511 | `README.md`, `index.html` | Fresnel, absorption, per-channel refraction, adaptive quality, caustic resolution controls | Use as optics/performance reference; no ocean FFT in tiny UI |
| [jeantimex/webgpu-water](https://github.com/jeantimex/webgpu-water) | 276 | `README.md`, `src/water.ts` | Heightfield simulation, ping-pong GPU textures, explicit simulation/render stages | Keep as future reference only; WebGPU and simulation complexity are not justified here |
| [HowdyKeith/swek-webgl2-water](https://github.com/HowdyKeith/swek-webgl2-water) | small | `README.md` | Differential-area caustics, wave-equation heightfield, Fresnel blending | Reinforces replacing Voronoi caustic decoration with projected area concentration |
| [Hla-aung/liquid-glass](https://github.com/Hla-aung/liquid-glass) | small | repository overview | Shared renderer/context, Snell refraction, SDF lens, Fresnel, spring-driven interactions | Use shared-context and bounded interaction patterns; do not import DOM snapshotting into this app |
| [pmndrs/drei](https://github.com/pmndrs/drei) | 10.2k | `MeshTransmissionMaterial.tsx`, docs | Transmission, thickness, roughness, chromatic aberration, controlled sample/resolution budget | Reference only; full transmission material would be disproportionate for gauges |

## 3D / rendering / performance

| Repository | Approx. stars | Source inspected | Reusable engineering insight | Decision |
|---|---:|---|---|---|
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | 119.1k | `lights_physical_pars_fragment.glsl.js`, `MeshPhysicalMaterial.js` | GGX distribution, Smith correlated visibility, anisotropic tangent frame, physical transmission properties | Applied the anisotropic GGX formulation to macro metal; existing Three.js remains anatomy engine |
| [pmndrs/react-three-fiber](https://github.com/pmndrs/react-three-fiber) | 33.8k | `docs/advanced/scaling-performance.mdx`, `store.ts` | Demand rendering, explicit invalidation for imperative mutations, geometry/material reuse, instancing | Existing controller already follows demand-rendering; retained rather than migrating to R3F |
| [pmndrs/postprocessing](https://github.com/pmndrs/postprocessing) | 3.0k | repository overview | Post-process effects must be deliberate render passes | No bloom/DOF pass added to compact dashboard visuals |

## Interaction / UX / accessibility / validation

| Repository | Approx. stars | Source inspected | Reusable engineering insight | Decision |
|---|---:|---|---|---|
| [motiondivision/motion](https://github.com/motiondivision/motion) | 35.4k | `useSpring` exports and reduced-motion changelog | Motion preferences and spring-based interaction | Existing tiny fluid spring is cheaper than adding a library to the shader engine; anatomy now honors reduced motion |
| [pmndrs/react-spring](https://github.com/pmndrs/react-spring) | 29.3k | repository metadata | Stable spring-based UI transitions | Used as conceptual reference, not dependency |
| [shadcn-ui/ui](https://github.com/shadcn-ui/ui) | 128.7k | `apps/v4/registry/new-york-v4/ui/button.tsx` | Focus-visible ring, hover/pressed/disabled states, `aria-invalid` styling without locking the design system | Applied the interaction-state pattern to native controls; did not import the component library |
| [radix-ui/primitives](https://github.com/radix-ui/primitives) | ~19k | `packages/react/progress/src/progress.tsx` and tests | Correct progressbar semantics and value attributes | Native progress semantics retained; no component dependency added |
| [DavidHDev/react-bits](https://github.com/DavidHDev/react-bits) | ~52.5k | `README.md` and component categories | Large catalogue of micro-interaction patterns (buttons, toggles, indicators) | Reference only; visual effects were not copied because most are more decorative than this product's restrained mineral language and the repo declares MIT + Commons Clause |
| [dequelabs/axe-core](https://github.com/dequelabs/axe-core) | ~7.9k | `README.md` | Automated WCAG checks integrated with existing test environments | Recommended for final CI accessibility pass; not added as runtime dependency |
| [microsoft/playwright](https://github.com/microsoft/playwright) | 100.7k | screenshot docs | Stable screenshot baselines and interaction tests; keep environment consistent | Recommended for GPU-capable CI visual regression; not added to runtime dependencies |
| [storybookjs/storybook](https://github.com/storybookjs/storybook) | 90k+ | play-function docs | Isolated component scenarios and interaction tests | Useful future workflow; not required to improve current runtime |

## GitHub code-search findings

- `react-three-fiber` scaling guide explicitly recommends `frameloop="demand"`, manual `invalidate()` for imperative mutations, and resource reuse. The existing anatomy renderer already uses an on-demand request loop, so a migration would not add meaningful value.
- Three.js physical shader source implements the same anisotropic GGX visibility and distribution terms used by the macro metal shader. V6 retains two bounded area-light approximations rather than adding a costly full environment map.
- Clearwater's code map exposes separate caustics resolution, per-channel IOR, Fresnel/absorption, and adaptive quality. The app's droplet/tank are small; V6 keeps the existing four-wave analytic surface and replaces decorative Voronoi caustics with differential-area concentration.
- WebGPU Water uses ping-pong textures and several render pipelines. This is technically strong but has more setup, GPU memory, and browser capability requirements than the UI element warrants.
- Drei transmission material uses transmission buffers and sampling controls. Its approach is valuable for a full 3D scene, not for a 84×100 droplet and 54px tank.
- Radix Progress demonstrates explicit `role`, `aria-valuenow`, and state semantics. The existing components already provide goal/no-goal states and bounded progress values.
- shadcn/ui button source provides a concise state contract: focus-visible, hover, disabled and invalid states. V6 applied these states to existing controls without importing shadcn or changing the app's visual language.
- React Bits catalogs micro-interactions, but its MIT + Commons Clause license and deliberately expressive visual style make it a pattern reference, not code to copy into this quiet-luxury dashboard.
- Playwright documents screenshot baselines and environment consistency; GPU visual regression belongs in a consistent hardware/software CI image, not a CPU-only build container.

## Dependency decision

No new package was installed. The app already includes Three.js, React, Motion, and Lucide. The highest-value changes were shader math, shared-loop behavior, canvas allocation avoidance, accessibility semantics, and deterministic tests—not adding libraries.

---

# V.MAX Visual Systems Research — V7

Research extended 22 Nov 2026. This pass used GitHub repository search plus direct retrieval of relevant source files/READMEs. The objective was not to import popular libraries indiscriminately; it was to transfer mature design rules into the existing architecture while preserving the V6 performance contract.

## Color science and palette construction

| Source | Source inspected | Finding | Applied decision |
|---|---|---|---|
| [Material Color Utilities](https://github.com/material-foundation/material-color-utilities) | `README.md` | HCT, tonal palettes, dynamic roles, contrast functions and temperature utilities | Use tonal/color-role thinking; do not hand-pick a new independent hex for every component |
| [Radix Colors](https://github.com/radix-ui/colors) | `src/light.ts`, `src/dark.ts`, README | Multi-step accessible families, including Sage, Olive, Slate and alpha/P3 ramps | Build coherent mineral roles; keep fallback sRGB hexes and optional display-P3 in a later display-tested pass |
| [Primer Primitives](https://github.com/primer/primitives) | `DESIGN_TOKENS_GUIDE.md`, `contributor-docs/adrs/adr-009-color-token-name-variants.md` | Semantic foreground/background pairing, muted/emphasis naming, contrast requirements, motion and interaction-state contracts | Consolidate semantic CSS variables; use status roles only for statuses, not decorative categories |
| [Carbon Design System](https://github.com/carbon-design-system/carbon) | `packages/styles/scss/layer/_layer-sets.scss` | Separate layer/background/selected/hover/accent/field and border hierarchies | Use distinct resting, raised, elevated, inset and hero surfaces instead of changing only the gradient |
| [HeroUI](https://github.com/heroui-inc/heroui) | `skills/heroui-theming/references/tokens.md`, `theme-recipe.md`, `components.md` | Tinted neutral families, paired foreground/background tokens, work tokens-first, component overrides only when needed | Keep one source of truth in tokens and use component overrides sparingly |

### Color psychology evidence and boundary

[Do we feel colours? A systematic review of 128 years of psychological research linking colours and emotions](https://doi.org/10.3758/s13423-024-02615-z) reviewed 132 peer-reviewed articles, 42,266 participants and 64 countries. It found many-to-many associations influenced by hue, lightness and saturation. Blue, green, green-blue and white were associated with lower-arousal positive affect, while black/dark shades were associated with more negative/high-arousal or low-valence categories in the reviewed tasks. The authors explicitly caution that abstract associations do not establish that a specific product color will cause the same experienced emotion in a health/performance interface.

**Decision:** the dark Obsidian canvas is a brand/art-direction choice, not a scientifically proven route to luxury or calm. It is balanced by Ceramic foregrounds, readable Mist secondary text and restrained low-saturation Sage/Blue. Champagne is an authored identity/material accent, not a scientific “luxury” color. Red/coral remains reserved for risk/error states; Copper denotes fat-macro data, not warning.

## Typography, hierarchy and composition

| Repository | Source inspected | Reusable principle | Applied decision |
|---|---|---|---|
| [Radix Themes](https://github.com/radix-ui/themes) | `packages/radix-ui-themes/src/styles/tokens/typography.css`, `components/card.css` | Role-driven scale with synchronized size/line-height/letter-spacing; card surface/classic/ghost variants and multiple densities | Add page-heading, eyebrow, display-number and supporting-text hierarchy; reduce monospaced text to true measurement contexts |
| [Adobe React Spectrum](https://github.com/adobe/react-spectrum) | `packages/@adobe/spectrum-css-temp/components/typography/vars.css` | Separate body, secondary, emphasis and heading text roles | Keep body, display and metric faces semantically distinct |
| [shadcn/ui](https://github.com/shadcn-ui/ui) | `apps/v4/app/globals.css`, V4 Button and Card primitives | Semantic CSS variables, consistent radius scale, compact compound card anatomy, focus/disabled/invalid states | Implemented project-native tokens/components; did not add shadcn as a dependency |

## Interactions and motion

| Repository | Source inspected | Reusable principle | Applied decision |
|---|---|---|---|
| [Primer Primitives](https://github.com/primer/primitives) | `DESIGN_TOKENS_GUIDE.md` | Hover/focus/active/disabled are explicit; short motion tokens; reduced motion is mandatory; motion must not be decoration | Central timing tokens and reduced-motion CSS remain governing contract |
| [Motion](https://github.com/motiondivision/motion) | `dev/react/src/examples/Animation-stagger.tsx`, `packages/motion-dom/src/animation/utils/calc-child-stagger.ts` | Coordinated child transitions and bounded stagger sequencing | Use only for a later, narrow screen-transition pass where it materially clarifies state; no library migration |
| [Radix UI](https://github.com/radix-ui/primitives) | Progress and control patterns inspected in V6 research | Semantic state and accessible controls should not rely on decorative styles | Keep native buttons/selects, pressed states, progress roles and accessible anatomy list |

## Anatomy, PBR materials and asset decisions

| Repository | Source inspected | Reusable principle | Applied decision |
|---|---|---|---|
| [Three.js](https://github.com/mrdoob/three.js) | `examples/webgl_materials_physical_transmission.html` | Physical materials use IOR, transmission, thickness, specular and environment lighting; studio HDRI materially affects the appearance of glass | Keep current custom anatomy renderer and water engine; add a restrained fixed directional/specular response to the body surface; HDRI remains a separate validation-driven upgrade |
| [Drei](https://github.com/pmndrs/drei) | `src/core/MeshTransmissionMaterial.tsx` | Backside rendering and transmission samples materially affect cost; resolution and sampler modes can be bounded | Do not add full transmission to every 2D water gauge or tiny material; use only when a real 3D glass object needs it |
| [React Three Fiber](https://github.com/pmndrs/react-three-fiber) | `docs/advanced/scaling-performance.mdx` | Demand rendering, invalidate-on-mutation, resource reuse, instancing, LOD | Existing imperative renderer already renders on demand and reuses/merges geometry; keep rather than migrate |
| [Khronos glTF Sample Viewer](https://github.com/KhronosGroup/glTF-Sample-Viewer) | `README.md` | Mature glTF PBR references and explicit support for material extensions | Use as benchmark for a future licensed asset pipeline, not as a new runtime dependency |
| [glTF Transform](https://github.com/donmccurdy/glTF-Transform) | `README.md`, `packages/functions/src/texture-compress.ts` | Reproducible mesh/texture packaging, resampling, texture compression and format controls | Select as the candidate offline optimization tool if/when a vetted GLB is acquired |

### Anatomy asset due diligence

[Open Anatomy Atlas](https://github.com/CognitionLabSNUC/open-anatomy-atlas) provides a concrete reference for the difference between a procedural silhouette and an actual named anatomical atlas. Its README describes BodyParts3D 4.3 (3,210 meshes, full-resolution, CC BY 4.0) and Z-Anatomy. It reports approximately 200–300 MB for BodyParts3D 4.3, compared with smaller but less detailed releases. The viewer software license is MIT, but that does **not** relicense the anatomy datasets.

[Z-Anatomy Models of Human Anatomy](https://github.com/Z-Anatomy/Models-of-human-anatomy/blob/master/License.txt) documents CC BY-SA 4.0 for its collection and attribution requirements, while its attribution section identifies individual third-party contributions with different licenses, including CC BY-NC-SA. The Open Anatomy Atlas README separately describes its Z-Anatomy data source as CC BY-NC-SA 4.0 and notes that a commercial-safe CC BY-SA build is available. This is a material licensing boundary, so the exact downloadable asset/build must be audited before distribution.

**Not imported in V7:** the current Titan anatomy remains the existing procedurally lofted/batched body. A real atlas requires mapping 3D structure IDs into TITAN muscle IDs and left/right side semantics, filtering third-party NC content, testing file size and GPU draw cost, retaining anatomical view/selection contracts, and deciding whether CC BY-SA obligations are acceptable for distribution. A 200–300 MB atlas is not silently added to a mobile-first app. V7 improves material treatment and enables direct muscle picking; it does not claim to have replaced the underlying geometry with anatomical-grade meshes.

## Charts, records and data integrity

| Repository | Source inspected | Reusable principle | Applied decision |
|---|---|---|---|
| [Recharts](https://github.com/recharts/recharts) | `README.md` | SVG-composed, declarative chart primitives; chart parts are independently composable | Implement one narrow native SVG history graph for the four observed measurements rather than adding a library for a single chart |
| [Visx](https://github.com/airbnb/visx) | Repository docs / API overview | Low-level data visualization primitives over D3 when bespoke rendering is required | Reference only; native SVG meets the current single-chart need |
| [axe-core](https://github.com/dequelabs/axe-core) | `README.md` | Automated WCAG checks in test workflows, but not complete coverage | Add static semantic/contrast gate; keep browser and manual review as remaining release gates |
| [Playwright](https://github.com/microsoft/playwright) | Screenshot/visual testing docs in V6 research | Consistent browser/device image baselines are needed for visual regression | Recommend GPU-capable visual CI before claiming final visual approval |

## Final dependency policy

No new runtime dependency was added. The current package already includes Three.js and Motion. The new evolution line chart is a deliberately narrow native SVG because only one data series family is needed. Using a full chart library, PBR transmission system, UI framework, or atlas viewer would increase bundle, runtime and maintenance cost without enough immediate product value.

## Component-level decisions finalized in the V7 implementation

| Area / sub-area | Primary sources inspected | Code decision in TITAN | Not imported / why |
|---|---|---|---|
| App shell / navigation | shadcn/ui global CSS and button patterns; Radix Themes typography/surface patterns | Native React navigation, active-page state, semantic surface tokens, touch-area sizing and focus-visible rings | No external navigation framework; the app has four main destinations and a compact action sheet |
| Anatomy viewport / interaction | Three.js renderer, R3F scaling guide, Khronos glTF viewer, Open Anatomy Atlas README and Z-Anatomy model license | Keep the batched imperative Three.js controller, connect raycast selection to the store, reject drag gestures as taps, ignore hidden ancestors, and preserve accessible muscle list | No 200–300 MB atlas or unclear/non-commercial dataset is bundled; the current geometry-to-muscle mapping is not compatible with arbitrary atlas meshes |
| Anatomy asset pipeline | Open Anatomy Atlas and Z-Anatomy model source/license | Record a future migration gate: structure ID mapping, left/right mapping, exact asset license, texture/geometry compression, mobile download and draw-call profile | Software license does not relicense anatomy data; Z-Anatomy attribution includes individual assets with differing terms |
| Energy / macro hierarchy | Radix Themes type scale, Carbon layered surfaces, Three.js physical material parameters | Enlarge core values, keep liquid/metallized gauges subordinate, assign protein/carbs/fat distinct category roles | No new chart or shader framework; current fluid and GGX renderers are specialized and already optimized |
| Hydration / glass / water | Three.js physical transmission example, Drei MeshTransmissionMaterial implementation, Clearwater and WebGL Water | Preserve the analytic fluid engine and independent water-material tokens; treat studio HDRI as a later measured comparison | No full scene transmission buffer or ocean simulation for small UI gauges |
| Food imagery / meal cards | shadcn/Radix surface hierarchy and browser native image loading behavior | Larger crop area, `loading="lazy"`, `decoding="async"`, fallback icon and image-first meal hierarchy | No image CDN or new image pipeline without a stable source catalog, rights and asset contract |
| Molecular structures | Existing SmilesDrawer API and the current chemistry domain | Preserve SVG rendering/cache and the separate scientific element palette | Do not repurpose brand/status colors for atom identities |
| Evolution / chart | Recharts README, native SVG semantics and Primer contrast principles | One measured-observation SVG chart with actual date labels, axes, units, date/value text alternative, no smoothing or extrapolation | No Recharts dependency for one chart family; do not infer progress direction from raw measurement deltas |
| Workout / timer | Primer motion/interaction guide, Motion stagger source, shadcn focus/pressed states | Keep timer updates isolated, avoid announcing each tick, use semantic focus and pressed states, preserve reduced motion | No decorative stagger or continuous animation; Motion is already in dependencies but isn't necessary for these microinteractions |
| Validation | axe-core README, Playwright visual testing docs, local static design gate | Extend static checks for palette contrast, token presence, anatomy picking and observed-data chart; syntax-transpile all TS/TSX | Browser/axe/Playwright and GPU screenshot validation remain deferred because dependencies and WebGL2 context are unavailable here |

The V7 code pass is complete within the source-level constraints above. A 9.5 release score remains blocked by actual screenshots/device review and by the anatomical-asset fidelity ceiling of the current procedural mesh.

---

# V8 — Deep research do subsistema de anatomia 3D

Pesquisa realizada em 22/11/2026 por GitHub repository search e leitura de código-fonte/README/arquivos de licença. Estrelas abaixo são fotografias aproximadas retornadas pelo GitHub nessa consulta; não são ranking global de qualidade.

| Repositório | Stars aproximadas | Licença consultada | Área/arquivo inspecionado | Decisão para o TITAN |
|---|---:|---|---|---|
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | 119,2k | MIT | `WebGLRenderer.js`, `BufferGeometryUtils.js`, `RoomEnvironment.js`, `webgl_instancing_performance.html` | Engine existente; batching, PMREM, PBR, `renderer.info`, WebGL2 e lifecycle adotados |
| [pmndrs/react-three-fiber](https://github.com/pmndrs/react-three-fiber) | ~34k | MIT | scaling performance e render loop | Não migrar; controller imperativo já faz render sob demanda |
| [ashemag/human-atlas](https://github.com/ashemag/human-atlas) | 4,63k | Código MIT; dados BodyParts3D 4.0 CC BY 4.0 segundo atribuição do projeto | README, `app/scene.tsx`, `app/anatomy.ts`, `app/model-download.ts`, `scripts/optimize-anatomy.mjs`, `public/ATTRIBUTION.md` | Adotar arquitetura/decisões; não copiar os ~33 MB de dados nem substituir por um modelo masculino sem validação |
| [Z-Anatomy/Models-of-human-anatomy](https://github.com/Z-Anatomy/Models-of-human-anatomy) | ~318 | CC BY-SA 4.0 no arquivo da coleção, com referências NC no mesmo inventário | `License.txt` | Não importar coleção indiscriminadamente; exige auditoria de licença por ativo e atribuição/share-alike |
| [Kevin-Mattheus-Moerman/BodyParts3D](https://github.com/Kevin-Mattheus-Moerman/BodyParts3D) | 194 | Código MIT, conteúdo CC BY-SA 2.1 Japan no README | README e limitações da versão3.0 | Referência histórica, não usar modelo antigo como substituição automática |
| [zeux/meshoptimizer](https://github.com/zeux/meshoptimizer) | 8,9k | MIT | README e pipeline de otimização | Adotar sequência conceitual; sem dependência para uma geometria procedural pequena |
| [donmccurdy/glTF-Transform](https://github.com/donmccurdy/glTF-Transform) | 2,1k | MIT | `join.ts`, `simplify.ts` | Não simplificar nem unir malha anatômica sem preservar atributos/IDs; não usar ainda sem asset GLB |
| [gkjohnson/three-mesh-bvh](https://github.com/gkjohnson/three-mesh-bvh) | 3,6k | MIT | README, `acceleratedRaycast`, `firstHitOnly` | Não adicionar; um raycast de toque contra uma única malha muscular combinada não justifica o custo adicional |

## Achados que mudaram o código

1. **WebGL2 real, não apenas WebGL detectado.** O código fonte do Three.js r163+ declara que WebGL1 não é mais suportado. O controller só cria o renderer quando o viewer fica visível; o próprio Three.js falha quando WebGL2 não está disponível, antes da geometria anatômica.
2. **PMREM de estúdio.** Human Atlas usa `PMREMGenerator.fromScene(new RoomEnvironment(), 0.04)` com duas luzes direcionais e hemisférica. O TITAN agora usa uma versão reduzida: hemisférica + key + rim; gera PMREM em GPU física e omite em software GL.
3. **Lotes estáticos e metadados de seleção.** O atlas demonstra milhares de estruturas agrupadas com seleção em textura. TITAN não precisa da textura pois possui apenas 14 IDs de treino e uma única malha de músculos; preserva IDs/lados em atributos inteiros compactos e resolve cores com máscaras/uniforms dentro do shader.
4. **Simplificação sem perda de mapping.** O `glTF-Transform` mostra que `simplify` é lossy e `join` ignora certos tipos de nós animados/skin/morph. A implementação manteve grupos e IDs estáveis em vez de aplicar redução genérica.
5. **BVH por evidência, não por popularidade.** `three-mesh-bvh` é apropriado para grandes malhas e consultas repetidas; não é necessário para o picker atual de uma malha agrupada e um toque.
6. **Geometria e render loop.** Lotes combinados recebem bounds calculados antes do render; resolução é limitada por orçamento de pixels; máscaras/uniforms substituem a reescrita por vértice; o loop permanece sob demanda e pausa fora da tela.
7. **Silhueta anatômica procedural.** Seções Catmull–Rom, relevos elípticos com transição nas bordas, abdômen segmentado e extremidades (mãos/dedos/pés) melhoram a forma sem criar meshes/materiais por músculo.

## Decisão sobre ativos anatômicos externos

Human Atlas informa 2.234 malhas, 3.432 conceitos, 2.288.268 triângulos, 402 malhas musculares/656.120 triângulos e aproximadamente 33 MB comprimidos para o conjunto completo. É uma referência valiosa, mas o conjunto de anatomia principal é masculino adulto; é necessário mapear cada mesh/conceito para 14 grupos TITAN, validar lateralidade e definir uma estratégia para corpos femininos/variações. O pacote V9 não redistribui esse asset e não afirma tê-lo testado no app.

Z-Anatomy inclui licenças de terceiros NC no seu próprio arquivo de atribuição. Um rótulo CC BY-SA na raiz não autoriza assumir que todas as partes de terceiros são redistribuíveis comercialmente. Não foi importado.

## Dependências

Nenhuma dependência runtime foi adicionada. Os recursos empregados já estão disponíveis via Three.js 0.187.0; instalar BVH, R3F, Meshopt ou glTF Transform sem um asset-alvo e sem benchmark seria complexidade desnecessária.


## V9 — Pesquisa complementar e redução de custo de inicialização do viewer

Pesquisa direta de fonte do GitHub aprofundou `three.js` (WebGLRenderer, BufferGeometryUtils, RoomEnvironment e exemplo de instancing), `ashemag/human-atlas` (scene, model-download, manifest, scripts de otimização e atribuição), `meshoptimizer`, `glTF-Transform` e `three-mesh-bvh`.

Decisão adicional: eliminar o WebGL preflight em canvas separado. O Three.js r163+ já exige WebGL2; criar e perder um contexto temporário antes do contexto real acrescentava inicialização e podia consumir um slot de contexto mobile. Agora o `WebGLRenderer` real é criado uma vez quando o stage entra na viewport; seu `WebGL2RenderingContext` fornece a identificação opcional de software. A geometria só é construída depois da criação bem-sucedida do renderer.

Também foi corrigido o estado pendente: mudanças de câmera, camada e destaque recebidas enquanto o viewer está fora da viewport são guardadas em memória JS e aplicadas uma vez, após a inicialização. Sem isso, a geometria lazy poderia aparecer com estado inicial depois de ignorar mudanças feitas antes da primeira interseção.

A pesquisa do Human Atlas não justifica importar o dataset inteiro (2.234 meshes, 2,29 milhões de triângulos, aproximadamente 33 MB comprimidos) para um viewer de 14 grupos e uso no cockpit. A camada muscular isolada é grande (402 peças/656.120 triângulos) e exigiria seleção de músculos fonte, redução por ativo, validação de superfícies/normais, mapeamento por lado e atribuição. A solução V9 preserva o asset atual e documenta um caminho futuro para substituição por malha real, sem declarar precisão anatômica não verificada.

Sem dependências novas. O V9 usa o contexto WebGL2 real, PMREM sob hardware, quatro lotes estáticos e `renderer.info`; não declara FPS sem benchmark em aparelhos.


### V9 — Compactação de buffers sem perda de resolução geométrica

A partir da leitura de `meshoptimizer` (quantização/vertex fetch), `glTF-Transform` (simplificação com erro limitado) e do pipeline do Human Atlas (normais signed-16), o builder passou a compactar streams que não precisam de 32-bit:

- IDs musculares: `Uint8Array` não normalizado (14 valores estáveis).
- Lateralidade: `Int8Array` não normalizado (-1, 0, +1).
- Normais: `Int16Array` normalizado, preservando posições e topologia.
- Índices: `Uint16Array` quando o lote possui até 65.535 vértices; mantém 32-bit se ultrapassar.
- Cores por músculo: removido o buffer por vértice; máscaras de primário/secundário, ID/lado selecionado e cores constantes são enviados como uniforms. O vertex shader resolve o estado sem loop CPU por vértice.
- UV removido dos lotes porque a superfície atual não usa mapas de textura. A geometria lofted aloca posições/índices em TypedArrays com tamanho pré-calculado, sem arrays temporários de números JavaScript.

Esta otimização não executa decimação nem reduz triângulos; diminui memória de atributo e transferência/upload. Também elimina a reescrita da malha inteira ao trocar seleção/destaques. A validação de aparência de normal quantizada e artefatos de banda ainda depende de screenshot em GPU/dispositivo real.


### V9 — compilação assíncrona e contexto lazy (continuação)

A leitura adicional do método `WebGLRenderer.compileAsync()` em `src/renderers/WebGLRenderer.js` confirma que Three.js inicia a compilação via `compile()` e, quando `KHR_parallel_shader_compile` está disponível, consulta prontidão dos programas sem bloquear a thread enquanto a GPU termina o trabalho. A API recomenda `compileAsync()` em vez de sincronizar o primeiro render.

Aplicação no TITAN:
- O controller usa `compileAsync(scene, camera)` e bloqueia o primeiro RAF até os programas estarem prontos; o primeiro toque não deve provocar a compilação inicial.
- A inicialização começa a 120 px antes da viewport, com threshold de 1%, conciliando carregamento antecipado com a regra de só criar o contexto quando o stage está próximo de ser visto.
- Um `contextGeneration` invalida respostas assíncronas de compilação se houver `webglcontextlost` / restauração concorrente, impedindo uma promise antiga de reativar uma cena cujo contexto já foi perdido.
- `shaderPreparationPending` separa o estado “programas ainda compilando” do estado “contexto perdido”; a renderização aguarda ambos.

Fonte: [Three.js WebGLRenderer — compileAsync](https://github.com/mrdoob/three.js/blob/dev/src/renderers/WebGLRenderer.js). Não foi adicionado runtime externo.


### V9 — classificação muscular por bitwise inteiro no shader WebGL2

A máscara dos 14 grupos já era um bitfield inteiro no TypeScript, mas a primeira variante do shader convertia cada bit para float com `exp2`/`floor`/`mod`. Como o projeto usa Three.js r187, que exige WebGL2, o shader pode consumir `uniform int` e usar deslocamento/AND (`mask >> muscleId & 1`) nativamente em GLSL ES 3.00. Isso remove exponencial, divisão/modulo em float por vértice e comparação aritmética do índice selecionado. O limite do registry permanece explícito: IDs começam em 1 e ficam abaixo de 31 para manter a máscara positiva em `int` signed de 32 bits.

Fonte de compatibilidade: [Three.js WebGLRenderer](https://github.com/mrdoob/three.js/blob/dev/src/renderers/WebGLRenderer.js) (WebGL2 only since r163); [Three.js Shader / GLSL 3 documentation](https://threejs.org/docs/#api/en/materials/ShaderMaterial). Runtime WebGL shader compilation ainda é gate de GPU, indisponível neste container.


### V9 — descarte de recursos e liberação do slot WebGL

Na leitura de `WebGLRenderer.dispose()` e `forceContextLoss()` em Three.js, confirmei que o renderer encerra seus listeners internos de `dispose` das geometrias/texturas/materiais. Portanto, objetos de cena devem emitir `dispose` enquanto o renderer ainda está ativo. O controller agora descarta body rig, materiais, recursos do palco e PMREM primeiro; remove listeners/canvas; chama `renderer.dispose()` e, por fim, `renderer.forceContextLoss()` para liberar o contexto do navegador no unmount/route change.

Fonte: [Three.js WebGLRenderer lifecycle](https://github.com/mrdoob/three.js/blob/dev/src/renderers/WebGLRenderer.js). Isso não substitui testar troca de rota e restauração de contexto em aparelhos reais.

## V10 — Materiais, texturas, shaders e performance visual (22/11/2026)

Nova leitura de código priorizou repositórios de maior adoção diretamente relevantes:
- `mrdoob/three.js` — 119.164 stars: documentação/código de `MeshPhysicalMaterial`, anisotropia para brushed metals, clearcoat e transmission; o próprio código alerta que features físicas extras aumentam o custo por pixel.
- `tailwindlabs/tailwindcss` — 98.709 stars: manter o CSS existente, sem importar um segundo sistema.
- `pmndrs/react-three-fiber` — 33.886 stars: referência de on-demand rendering; o princípio já existe no renderer imperativo do TITAN.
- `BabylonJS/Babylon.js` — 26.427 stars: segunda referência de PBR e renderização; não justifica trocar a engine.
- `pmndrs/drei` — 10.190 stars: `MeshTransmissionMaterial` usa buffer/FBO, samples e configuração de backside; não adotar em medidores de poucos pixels.
- `zeux/meshoptimizer` — 8.897 stars: base conceitual da compactação geométrica sem quebrar os 14 IDs musculares.
- `google/model-viewer` — 8.352 stars: referência de exposição de materiais glTF, sem necessidade de inserir componente no app.
- `pmndrs/postprocessing` — 2.989 stars: referência de bloom/SSAO; nenhum pass adicional é justificado agora.
- `KhronosGroup/glTF-Sample-Viewer` — 1.488 stars e `evanw/webgl-water` — 1.286 stars: referências especializadas para PBR e óptica da água.

Implementação V10: micro-satin aplicado apenas à superfície hero, sheen sutil no CTA, roughness anatômica refinada mantendo `MeshStandardMaterial`, metal macro mais acetinado, blur de navegação reduzido e limite superior de 60 submissões/s no renderer compartilhado durante transições. Todos os detalhes estão em `docs/MATERIAL_TEXTURE_EFFECT_CATALOG_VMAX_V10.md`.
