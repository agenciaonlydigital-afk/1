# Revisão sênior — TITAN V.MAX V11.7

Data da revisão: 23/11/2026  
Base auditada: `TITAN_HYDRATION_VMAX_V11_6.zip`

## Parecer executivo

A V11.6 tinha boas fronteiras de domínio, Zustand com seletores, divisão de telas por lazy routes, um motor de renderização Three.js e um conjunto de verificações específicas. A revisão encontrou defeitos que afetavam diretamente o comportamento real do app: data corrente congelada; parser de data permissivo com fallback para uma data histórica; registros de hidratação/treino voláteis; falha na leitura do fallback de armazenamento; e renderer Three.js incluído na cadeia estática de importação da tela inicial. Também encontrou uma falha operacional confirmada: `start` executava `server.ts` diretamente com `node`, que falhou no Node 22.16 testado. A auditoria aprofundada revelou ainda a janela do calendário que não alcançava as medições históricas e a necessidade de validar também payloads persistidos com a mesma versão.

V11.7 corrige os pontos com alterações localizadas. A arquitetura não foi substituída e nenhum novo framework foi adicionado.

## Achados e tratamento

| Área | Achado | Severidade | Tratamento |
|---|---|---:|---|
| Data/calendário | `APP_DAY_KEY` e labels fixos em novembro de 2026 | Crítica | Helpers de data local e janela dinâmica |
| Data/calendário | Datas como `2026-13-01` caíam em data default fictícia | Alta | Validação gregoriana estrita e rejeição |
| Hidratação | Store sem persistência; registros desapareciam ao recarregar | Alta | Zustand persist + safe storage + normalização |
| Treino | Série concluída/carga e descanso não persistidos | Alta | Snapshot versionado reconciliado com IDs atuais |
| Armazenamento | Fallback em memória não era lido quando localStorage retornava `null` | Alta | Prioriza escrita de fallback em memória, com tombstones quando a exclusão falha |
| Treino | `registerWorkoutSet` não confirmava se `setId` pertencia ao exercício | Alta | Verificação de exercício/série e bloqueio de dupla conclusão |
| Modal | Sem contenção de foco, restauração de foco ou scroll lock | Alta | Tab trap, foco inicial/retorno, ARIA e body lock |
| Calendário | Limite mínimo fixo impedia alcançar medições seed de 07/11/2026 | Alta | Limite derivado da menor data real entre evolução, refeições e hidratação; dias da evolução marcados |
| Persistência | Perfil/evolução aceitavam dados de mesmo número de versão sem validar o payload restaurado | Alta | `merge` valida enums, intervalos, chaves de data, registros e IDs duplicados |
| Renderização | Import estático do controller Three.js através do cockpit | Média | Import dinâmico com cancelamento, fallback e descarte do controller também em falhas síncronas |
| React lifecycle | Root sem StrictMode | Média | StrictMode habilitado após revisão dos cleanups e correção do import assíncrono |
| Runtime Node | `node server.ts` não é suportado pelo Node 22.16 testado | Crítica | Esbuild gera `server.js`; `start` executa JS compilado |

## Referências GitHub avaliadas

Estrelas aproximadas consultadas em 23/11/2026. São indicadores de adoção, não um ranking automático de qualidade.

| Repositório | Estrelas | Licença | Princípio avaliado | Decisão |
|---|---:|---|---|---|
| [shadcn-ui/ui](https://github.com/shadcn-ui/ui) | 128,8k | MIT | Componentes composáveis e estados acessíveis | Referência para estados e acessibilidade; não copiar biblioteca |
| [microsoft/playwright](https://github.com/microsoft/playwright) | 100,9k | Apache-2.0 | E2E cross-browser e interação real | Recomendado para a validação seguinte; sem adicionar dependência agora |
| [pmndrs/zustand](https://github.com/pmndrs/zustand) | 59,0k | MIT | Estado mínimo, seletores e middleware persist | Manter Zustand existente; persistir apenas estado cliente necessário |
| [TanStack/query](https://github.com/TanStack/query) | 50,6k | MIT | Cache de estado remoto | Não adicionar: o app não usa estado remoto frequente o bastante para justificar React Query |
| [alan2207/bulletproof-react](https://github.com/alan2207/bulletproof-react) | 36,1k | MIT | Limites por feature, fluxo unidirecional, testes por camadas, error boundaries e performance | Adotar padrões seletivos compatíveis com os domínios atuais |
| [radix-ui/primitives](https://github.com/radix-ui/primitives) | 19,6k | MIT | Dialog, foco, camadas e teclado | Usado como critério de revisão; sem acrescentar pacote para um único modal |
| [testing-library/react-testing-library](https://github.com/testing-library/react-testing-library) | 19,7k | MIT | Testar comportamento observável ao usuário | Aplicar nos próximos testes com dependências instaladas |
| [vitest-dev/vitest](https://github.com/vitest-dev/vitest) | 17,4k | MIT | Runner integrado ao Vite | Não migrar a suíte existente nesta correção |
| [adobe/react-spectrum](https://github.com/adobe/react-spectrum) | 16,1k | Apache-2.0 | Interações acessíveis e padrões de diálogo | Referência alternativa de acessibilidade |

Documentação oficial React consultada: [You Might Not Need an Effect](https://react.dev/learn/you-might-not-need-an-effect) e [StrictMode](https://react.dev/reference/react/StrictMode). Os componentes devem derivar valores em renderização quando não sincronizam um sistema externo; StrictMode ajuda a encontrar efeitos sem cleanup.

## Decisões arquiteturais

- **Não migrar Zustand para Redux Toolkit ou outra store.** A necessidade era persistência e validação local, e os middleware já estavam disponíveis.
- **Não instalar React Query.** Não há fluxo de server-state com cache/invalidação que compense a dependência.
- **Não instalar Radix para um componente.** Melhoramos a camada modal existente com foco, teclado, scroll lock e ARIA. Ainda é necessária validação real com leitor de tela e navegador.
- **Não instalar Playwright no runtime.** Deve ser usado como dev/test tooling no próximo ambiente com dependências e navegador disponíveis.
- **Não refatorar diretórios/domínios em massa.** `bulletproof-react` recomenda limites previsíveis, mas o TITAN já tem fronteiras de domínio explícitas; uma migração cosmética aumentaria risco sem benefício de produto comprovado.
- **Persistência é local, não backup.** Limpeza de dados, perfil anônimo e mudanças de navegador/dispositivo ainda podem perder registros; export/import e sincronização exigem um desenho separado.

## Limites da verificação

- Firecrawl deep search não pôde ser executado por falta de créditos conectados; pesquisa de repositórios e leitura de arquivos foi feita diretamente pelo conector GitHub.
- `npm test` e `npm run lint` não completaram porque o ZIP não contém `node_modules` (`tsx` e tipos `vite/client` ausentes).
- O build Vite + esbuild e o `node server.js` final não puderam ser executados neste container sem dependências instaladas.
- Testes de storage e normalização usam lógica pura; eles não simulam um navegador real nem confirmam a persistência do middleware Zustand em Chrome/Safari. Os normalizadores de perfil/evolução e nutrição cobrem o merge de mesma versão no código, mas ainda precisam de E2E de reidratação em browser.
- A navegação de foco do BottomSheet foi revisada estaticamente; requer E2E com teclado e leitor de tela.

A revisão final desta alteração foi feita pelo próprio executor em passes separados de estado/persistência, domínio/calendário, UI/React e scripts; não houve avaliador independente automatizado disponível nesta sessão.

## Próxima porta de qualidade

1. Instalar com `bun install --frozen-lockfile` em ambiente com registry disponível.
2. Executar `bun run lint`, `bun run test`, `bun run build` e `node server.js` com `NODE_ENV=production`.
3. Executar Playwright em Chrome, Firefox e WebKit cobrindo rehidratação dos stores, reload durante treino, bloqueio de storage, rolagem/modal, foco e fallback sem WebGL2.
4. Medir o chunk inicial e confirmar que o chunk do renderer Three.js não é solicitado antes de abrir/visualizar o cockpit.
