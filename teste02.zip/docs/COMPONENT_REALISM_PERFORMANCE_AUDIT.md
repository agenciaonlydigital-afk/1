# TITAN V.MAX — Component Realism & Performance Audit

Audit baseline: V5 ZIP, 22 Nov 2026. Scope: water/glass, energy fluid, macro-metal gauges, anatomical hologram, micro-interactions, shadows, accessibility, and idle/render performance.

## Decision rule

1. Preserve the intended visual language and component silhouette.
2. Improve the optical/material model before lowering resolution or removing detail.
3. Measure and remove duplicated work, unnecessary passes, continuous idle loops, and avoidable allocations.
4. Never trade away the visual result for a theoretical optimization without device measurements.
5. Keep native React/Canvas/WebGL and the current Three.js scene where they are already the simplest fit. No new runtime dependency was justified.

## Component matrix

| Component | Visual objective | Existing cost / risk | V6 action | Remaining validation |
|---|---|---|---|---|
| Water droplet | Clear thick glass, readable water volume, restrained meniscus, natural highlights | Per-pixel optics, caustic math, shared WebGL-to-2D copy | Added rear-interface Fresnel reflection; changed output transfer to piecewise sRGB; replaced cellular/Voronoi caustic decoration with projected differential-area concentration modulated by analytic wave curvature | Real WebGL2 compile, mobile/desktop visual comparison, HDRI evaluation |
| Water tank | Continuous liquid column inside cylindrical glass; curved meniscus and edge reflections | Three RGB refraction paths and caustic evaluation while filled | Added rear-interface Fresnel; same differential-area caustic model; kept empty-tank fast path and one shared renderer | Real GPU compile and screenshots at 0/25/50/75/100% |
| Energy | Mineral-sage liquid, not plasma or sci-fi electricity | 3-octave flow noise while the value animates | Preserved the 3-octave material and broad softbox reflection; kept the shared on-demand engine; cached reduced-motion query so it is not repeatedly queried in frame providers | Visual review of 0/50/100/>100%, especially with no daily goal |
| Macro gauges | Satin liquid metal with coherent anisotropic reflections | Two anisotropic GGX lights plus one 3-octave micro-noise sample | Preserved the two-light GGX model, one FBM sample, and no screen derivatives in the variable liquid mask | Visual review of each macro hue, low fill, full fill, and over-goal states |
| Anatomy hologram | Readable layered anatomy with subtle depth and controlled selection feedback | Transparent layered geometry; redraws on demand; DPR changes can otherwise leave stale density | Added a low-cost procedural contact shadow instead of a shadow-map pass; activated the existing muscle bitmask in GLSL; added a single 420 ms selection sweep; disabled damping/sweep under reduced-motion preference; recalculates DPR on display-density changes; uses sets for highlight membership | Validate on integrated GPU, touch device, and reduced-motion setting |
| Micronutrient summary | Dense but readable nutrient status, clear trace/missing/limit semantics | Expandable rows and SVG molecular structures | Kept lazy structure generation and cached SVGs; strengthened keyboard focus; no new chart library or per-frame work | Accessibility pass with axe-core and keyboard review |
| Molecular structure | Correct molecular diagram with no blocking work on initial render | SMILES parsing and SVG generation | Preserved singleton drawers, deferred work, and cached payloads; mineral ions now expose image semantics; no second chemistry renderer | Verify all nutrient SMILES and error fallback on actual app build |
| Today workout | Fast set editing and a clear route into the full session | A 500 ms rest-timer tick re-rendered the entire exercise list; numeric fields committed to the store on each keystroke | Isolated the rest timer in a memoized child; the list no longer re-renders every half-second; number fields commit on blur/Enter; start CTA now uses the existing navigation callback; fixed stray visible `>` | Verify decimal input, keyboard Enter/blur, timer announcements and navigation |
| Next meal | Food card and substitution sheet should load without blocking the cockpit | Food image decode competes with initial UI rendering | Food images now use lazy loading and async decode; card, search and substitution actions have focus states | Verify image failure fallback and image load on slow mobile connection |
| Home header | Calendar and goal editor should stay in sync with profile state | Goal form draft could become stale after an external profile update; closed calendar rebuilt empty marker sets | Draft fields resync when the editor is closed; closed calendar reuses one empty marker set and does not track meal/hydration array changes | Verify profile edits from other screens and calendar date marks |
| Surfaces / controls | Obsidian + Mineral Sage, tactile but restrained | Large shadow/filter layers can create extra compositing | Preserved current surface depth and focus rings; no blanket `will-change`, backdrop blur, or extra filter layers added | Profile compositing on mid-range mobile hardware |

## V6 implementation details

### Water and liquid optics

- Rear glass/liquid boundary now contributes a Schlick Fresnel reflection, instead of only returning a transmitted environment sample unless total internal reflection occurs.
- Fresnel exponent is consistently 5 for Schlick approximation.
- Linear-to-sRGB conversion now uses the piecewise sRGB transfer function rather than a single gamma 2.2 approximation.
- Caustics now rely on the projected differential-area Jacobian (`dFdx`/`dFdy`) with analytic Gerstner curvature as a restrained focus modifier. The two 3×3 Voronoi searches were removed. This is both more physically grounded and cheaper per fragment.
- Empty droplet/tank fast paths, static-at-rest rendering, shared context, cached programs, and direct CanvasImageSource blit remain intact.
- `interpolateRatio` snaps to the target on the frame that crosses the settle threshold, preventing the final rendered frame from stopping slightly short.
- Reduced-motion preference is cached and queried without calling `matchMedia` from each active frame provider.

### Anatomy and micro-interactions

- The selection sweep now uses the existing `uSweepY` uniform and is gated to a single short animation when the selected muscle/side changes. The former shader condition suppressed the sweep when reveal progress was already 1; that dead condition is removed.
- `uActiveMusclesMask` now performs a real bitmask lookup against `aMuscleId`; it is no longer multiplied by zero. Active regions receive only a restrained luminance/rim lift, while material states remain the primary selection/highlight mechanism.
- A soft elliptical contact shadow is drawn by a tiny transparent shader plane. It provides grounding without enabling a full shadow-map pass on a transparent hologram scene.
- Desktop anatomy DPR cap is 1.85, touch remains 1.5, software GL remains 1.0. The actual device-pixel ratio is refreshed when the window/display density changes.
- Orbit damping and selection sweep honor `prefers-reduced-motion` changes at runtime.
- Primary/secondary highlight membership uses `Set` lookups instead of repeated array scans for each muscle mesh.
- The workout rest timer now owns its 500 ms tick in a memoized child, so the exercise list does not redraw twice per second.
- Weight/repetition drafts remain local while typing and commit only on blur/Enter, preserving decimal editing and reducing Zustand updates.
- The cockpit's existing `onOpenTraining` callback now drives the workout start CTA; it was previously passed through but ignored.
- Food imagery is lazy-loaded and decoded asynchronously; profile goal drafts resync when their editor is closed.

## Performance model

| Workload | Idle behavior | Active behavior | Quality safeguard |
|---|---|---|---|
| Droplet / tank | One static render | Shared RAF only while ratio transition or spring wave is active | Same shader path and DPR policy |
| Energy / macros | One static render | Shared RAF while displayed ratio is moving | No CSS-only replacement; same GGX/liquid shaders |
| Workout timer | No tick while inactive | Timer-only child updates twice per second | Exercise list and parent state stay mounted without timer-driven redraws |
| Food imagery | Browser loads only as it approaches the viewport | Decode occurs asynchronously | Fallback remains available when the image fails |
| Anatomy | No continuous RAF | One render per state/input change; damping/sweep schedules only the required frames | DPR capped, not arbitrarily reduced; contact shadow avoids shadow-map cost |
| Molecular diagrams | No continuous work | Deferred parse only on cache miss/expand | SVG result cached and reused |
| Micronutrient list | React updates only when selected data changes | Expanded content rendered on demand | Existing memoization and keyed rows retained |

## Explicitly not done

- No FFT ocean solver, SPH, WebGPU port, or 256×256 heightfield simulation: the UI water volume is too small to justify the extra passes, memory, and compatibility cost.
- No `react-three-fiber` rewrite of the existing anatomy controller: it already has imperative ownership, a single scene, geometry batching, and on-demand rendering. Importing R3F would add abstraction without solving a measured bottleneck.
- No Drei `MeshTransmissionMaterial` adoption: its transmission buffer/resolution/sampling cost is designed for full 3D scenes and is excessive for a tiny gauge.
- No real HDRI was added because a correctly licensed, calibrated environment asset was not included in the source package. The current studio environment remains procedural and must not be described as HDRI-based.
- No true four-boundary air/glass/water/glass/air volume solve or physically complete ray tracing. The water remains a carefully bounded 2.5D optical approximation.
- No GPU performance numbers are claimed: this environment did not expose a working WebGL2 context for visual/GPU validation.

## Required final device validation

1. WebGL2 shader compilation on a real Chromium/Firefox/Safari GPU path.
2. Visual snapshots at 0, 25, 50, 75, 100, and 125% fill.
3. Compare droplet/tank against the same backgrounds at DPR 1, 1.5, and 2.
4. Measure idle GPU activity: no RAF should remain active when values and waves settle.
5. Measure interaction frame time with hydration + energy + all three macro gauges visible.
6. Rotate anatomy while selecting a muscle; check contact shadow, active bitmask, sweep, and context restore.
7. Repeat with reduced motion enabled and while changing display DPR.
8. Run axe-core and Playwright visual/interaction tests in a consistent CI image.

## Validation actually completed in this workspace

- Passed `scripts/check-fluid-shaders.mjs` (GLSL template structure, duplicate functions, smoothstep bounds, anisotropic GGX, optical functions, no Voronoi caustics, no per-frame ImageBitmap allocation).
- Passed `scripts/check-cockpit-visual-semantics.mjs` (goal/no-goal semantics, precision, ARIA, timer isolation, deferred images, profile draft synchronization, anatomy interactions and shadow).
- Passed strict standalone TypeScript check for `fluid-shader-engine.ts` with `noUncheckedIndexedAccess`.
- Passed TypeScript/TSX syntax transpilation for all modified React and renderer files.
- Passed runtime assertions for spring stability/settling, symmetry, 30/60 Hz interpolation consistency, exact final-target snapping, and anatomy muscle bitmask.
- Full `vite build` could not run because this extracted workspace has no `node_modules` (`vite: not found`); Bun is not installed here to consume the supplied `bun.lock`.
- WebGL2 shader compilation and screenshot review could not run: Chromium's headless ANGLE/SwiftShader could not initialize EGL in this container. No GPU FPS or visual approval is claimed.


---

## V.MAX V7 visual-direction and interaction implementation

V7 uses this document as the V6 implementation/performance baseline. The new component-level rationale, palette semantics, repository evidence and explicit remaining visual gaps are in `docs/PRODUCT_VISUAL_DIRECTION_VMAX_V7.md` and `docs/REPOSITORY_RESEARCH.md`.

Implemented in V7:
- Unified Obsidian / Graphite / Ceramic / Mist / Mineral Sage / Mineral Blue / Copper / Champagne tokens, plus independent water material tokens.
- Resting / raised / elevated / hero / inset surfaces and a more deliberate page-heading and display-number hierarchy.
- Anatomy moves to the lead cockpit region. The existing procedural lofted geometry remains, but its shader uses restrained mineral colors, lower scanline/fiber modulation, and a fixed low-cost key/specular response. Projector cone removed; subtle contact shadow and two quiet rings retained.
- The previously disconnected `MusclePicker` now reaches the renderer's pointer handler and the anatomy store; drag threshold and hidden-layer filtering protect interaction semantics.
- Meal thumbnails are enlarged and defer image loading/decoding.
- Fat uses Copper as a data-category color, while warning/error status remains semantically separate.
- Evolution has an accessible native SVG observation chart that plots only recorded measurements, and new measurements use a date label rather than a permanent `HOJE` marker.
- A design-system check validates token presence and 4.5:1 text/semantic contrast against the four dark surface levels.

Validation status:
- Passed: static shader checks, cockpit semantic checks, design-system/contrast checks and syntax transpilation of 34 recently modified TS/TSX files.
- Not completed: full TypeScript project check/build because installed dependencies and `vite/client` declarations are absent in this workspace; GPU/WebGL2 visual approval remains unavailable in this container.
- No runtime dependencies were added.

## V7 final workspace validation update

- Passed: `node scripts/check-fluid-shaders.mjs`.
- Passed: `node scripts/check-cockpit-visual-semantics.mjs`.
- Passed: `node scripts/check-titan-design-system.mjs`.
- Passed: PostCSS syntax parse of `src/index.css`.
- Passed: TypeScript `transpileModule` syntax pass for all 120 `.ts` and `.tsx` files under `src` (this is syntax transpilation, not a full semantic typecheck).
- Not available: `vite build` / `npm run lint` / full `npm test`, because `node_modules` are absent and TypeScript cannot resolve `vite/client` (`TS2688`).
- Not approved: GPU/WebGL2 shader screenshots or device FPS profiling. The container's headless GPU path did not produce a usable WebGL2 context.
- Passed: strict standalone typecheck of `src/shared/graphics/fluid-shader-engine.ts` with `noUncheckedIndexedAccess`.
- Passed: static resolution of relative and `@/` source/style imports across 121 files.


## V8 — Anatomy 3D: forma, PBR e orçamento de GPU

A revisão V8 foi concentrada no viewer anatômico, sem alteração dos IDs musculares nem troca de engine.

Implementado:
- suavização Catmull–Rom das seções da silhueta;
- volume/taper de baixo custo nos relevos musculares e segmentação discreta do reto abdominal;
- geometria adicional simplificada para mãos, dedos, pés e dedos do pé;
- quatro lotes estáticos com bounds pré-calculados;
- material PBR fosco de baixa complexidade e PMREM de estúdio em GPU de hardware;
- construção da malha adiada até a confirmação de WebGL2;
- orçamento de pixel explícito e MSAA desativado em touch/software;
- atualização direta dos buffers de cor somente em mudanças semânticas;
- reconstrução do PMREM na recuperação de context loss;
- gate de teste estático `scripts/check-anatomy-v8.mjs`.

Referências de engenharia: Three.js (`BufferGeometryUtils`, `RoomEnvironment`, `WebGLRenderer`), Human Atlas (batches, PMREM, seleção por atributos/texturas), meshoptimizer/glTF Transform (pipeline de malha e limitações de simplificação) e three-mesh-bvh (critério para só usar BVH quando picking escalar). Nenhuma dependência runtime foi adicionada.

Limites: a geometria continua procedural e de 14 regiões de treino, sem atlas/scan anatômico real. O PMREM vem de `RoomEnvironment`, não de HDRI fotográfico. Não foram validados FPS, tempos de GPU ou screenshots em GPU real; não atribuir nota visual 9,5 antes do gate de dispositivos descrito em `docs/anatomy/ANATOMY_3D.md`.


## V9 — Lazy context real, sem probe duplicado

- O canvas só cria `THREE.WebGLRenderer` após interseção de 5% do viewport e página visível.
- Removido o canvas WebGL descartável. O contexto usado pela cena também identifica renderer de software.
- A geometria só é construída após sucesso do renderer; o último estado React recebido antes disso é preservado e aplicado após a inicialização.
- O custo de contexto e construção do corpo deixa de existir quando o usuário não chega ao viewer; a montagem de tela mantém somente controller/câmera/scene vazios.
- Não houve benchmark em dispositivo físico neste ambiente; a otimização é estrutural e não uma alegação numérica de FPS.


### V9 — Buffer packing de geometria

- Normal `Float32` → `Int16` normalizado.
- Índices → `Uint16` apenas quando o lote tem no máximo 65.535 vértices; acima disso mantém `Uint32`.
- IDs musculares `Uint8`, lado `Int8`; cores de músculos resolvidas no vertex shader por masks/uniforms, removendo o buffer de cor por vértice.
- UV descartado antes do merge por não haver mapas no material anatômico atual.
- A construção lofted pré-aloca `Float32Array`/índices tipados; reduz overhead de arrays temporários do heap JavaScript. Nenhuma simplificação de triângulos ou de geometria anatômica foi feita; posições permanecem `Float32`.
- A compactação reduz bytes de atributos e remove a atualização O(n) de cores na CPU; não foi atribuído percentual de economia sem medição do `renderer.info` e captura física.


## V9 — continuação: preparação de shader sem hitch inicial

- O stage é inicializado com `IntersectionObserver` próximo da viewport (`rootMargin: 120px`, threshold 1%), só quando a página está visível.
- `WebGLRenderer.compileAsync(scene, camera)` pré-compila PBR e shader anatômico; o RAF aguarda `shaderPreparationPending=false`.
- `contextGeneration` invalida promises de preparação obsoletas se o WebGL for perdido/restaurado no meio do processo.
- A classificação de software GPU usa o contexto real, sem criar contexto descartável. A detecção é best-effort, não há garantia quando o driver oculta seu renderer string.
- Nenhuma redução de triângulos, LOD ou benchmark FPS foi inventado. O ganho validado aqui é estrutural: menos inicialização fora de tela, buffers menores e ausência de loop CPU para reescrever cores musculares.


### V9 — lifecycle de GPU

Os recursos de cena são agora descartados antes de `WebGLRenderer.dispose()`, para que os listeners internos do renderer recebam os eventos `dispose` e liberem buffers/programas. Após a limpeza, `forceContextLoss()` encerra o slot WebGL ao desmontar o componente. A reconstrução após context loss usa `contextGeneration` e `compileAsync`, ignorando promises obsoletas.


### V9 — orçamento de pixels sem piso de DPR

O pixel ratio efetivo é o menor valor entre DPR do dispositivo, limite da classe e `sqrt(pixelBudget / CSSArea)`. Foi removido o piso fixo de 0,5: em uma viewport excepcionalmente grande ele poderia fazer o canvas exceder o orçamento de pixels mesmo após a adaptação.

## V10 — Refinamento de texturas, materiais e efeitos com budget visual/GPU

O V10 é estritamente uma revisão de acabamento. As decisões e o inventário completo estão em `docs/MATERIAL_TEXTURE_EFFECT_CATALOG_VMAX_V10.md`.

Implementado:
- micro-satin mineral muito discreto somente na superfície hero (repeating-linear-gradient tokenizado); nenhuma textura global;
- softbox sheen leve no CTA primário;
- material corporal `MeshStandardMaterial` com roughness 0.74 e material muscular com roughness 0.68, sem clearcoat ou lóbulo físico adicional;
- metal dos macros com roughness 0.24–0.32, anisotropia principal/secundária 0.28/0.21, ripple temporal mais lento e hotspot menor;
- blur superior/inferior reduzido para 12/14 px, fundos mais opacos e fallback compatível com WebKit;
- limite de no máximo 60 submissões de desenho por segundo no engine de fluidos durante animação, mantendo render estático sob demanda e idle completo quando estabilizado.

Pesquisa de código e metadados do GitHub em 22/11/2026: Three.js 119.164 stars, Tailwind CSS 98.709, React Three Fiber 33.886, Babylon.js 26.427, Drei 10.190, meshoptimizer 8.897, Google model-viewer 8.352, postprocessing 2.989, Khronos glTF Sample Viewer 1.488 e evanw/webgl-water 1.286. Os detalhes de pertinência e decisão estão no catálogo V10. Não foram adicionadas dependências: o atual stack já implementa os efeitos necessários.

Novo teste estático `scripts/check-materials-v10.mjs` adicionado à cadeia `npm test`; cobre acabamento hero, shine de CTA, budgets de blur, rugosidade dos materiais, anisotropia metálica, render limit e ausência de clearcoat caro na anatomia.

### Validação V10 nesta sessão
- Passed: `node scripts/check-materials-v10.mjs`.
- Passed: `node scripts/check-fluid-shaders.mjs`.
- Passed: `node scripts/check-cockpit-visual-semantics.mjs`.
- Passed: `node scripts/check-titan-design-system.mjs`.
- Passed: `node scripts/check-anatomy-v9.mjs`.
- Não executado: `npm test` completo, `npm run lint` e `npm run build`, porque `node_modules` não está instalado no workspace.
- Não executado: shader compilation GPU, screenshots e benchmarks FPS em dispositivo real. Não há métricas de FPS medidas para declarar.
