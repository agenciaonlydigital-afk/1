# TITAN Anatomy V.MAX V11 — notas da implementação inicial

Esta nota registra a implementação inicial V11. A revisão corretiva e sua matriz completa de validação estão em [`ANATOMY_VMAX_V11_1_VALIDATION.md`](ANATOMY_VMAX_V11_1_VALIDATION.md).

A V11.1 é a versão que deve ser usada como referência porque acrescentou:

- UVs mantidos somente no lote muscular e removidos dos lotes que não usam mapas;
- verificação de preenchimento dos centros das tampas das malhas loftadas;
- média de normais na costura UV duplicada, extraída para função testável;
- coordenada Y calculada com `modelMatrix` antes de `project_vertex`, sem depender de `worldPosition` condicional;
- substituição de shader chunks com contrato de ocorrência única;
- testes diretos de topologia, normal map, injeção de shader e os 14 IDs de treino.

A figura inteira, incluindo cabeça e rosto, permanece. Somente o catálogo de seleção e de associação com treino é restrito aos 14 grupos musculares estáveis do TITAN.

Não trate as declarações de validação desta nota inicial como relatório final. Consulte o documento V11.1 para ver separadamente os testes executados, os bloqueios do ambiente e o que continua dependendo de build/GLSL/GPU/dispositivos reais.
