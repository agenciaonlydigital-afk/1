# Pesquisa de repositórios — V11.4

Data da consulta: 2026-11-23. Estrelas são sinais de adoção, não prova de qualidade ou adequação; números públicos variam entre indexadores e devem ser rechecados no GitHub antes de cada nova seleção.

## Anatomia 3D e ativos

| Repositório | Adoção observada | Licença / risco | Decisão |
|---|---:|---|---|
| [slorksmo/Human-Atlas](https://github.com/slorksmo/Human-Atlas) | ~4,3k estrelas em indexador consultado | Código MIT; dados anatômicos BodyParts3D sob CC BY (atribuição obrigatória). O conteúdo é um atlas amplo, não um pacote pronto dos 14 grupos de treino. | Melhor referência técnica recente para inspeção/seleção de malhas; não importar o atlas inteiro nem redistribuir malhas sem notices e recorte/licença auditados. |
| [thebuggeddev/anatomy](https://github.com/thebuggeddev/anatomy) | ~3,9k em indexador consultado; outro índice apresenta número divergente | Stack Three.js/R3F; licença e procedência dos ativos precisam ser conferidas por arquivo. | Referência de UX/estrutura de atlas, não dependência. |
| [nqwrc/3d-anatomy](https://github.com/nqwrc/3d-anatomy) | Baixa adoção observada | Derivado de Z-Anatomy/BodyParts3D; inclui ativos NC, share-alike e notices combinados que restringem redistribuição comercial. | Não usar os modelos no produto comercial. |
| [MervinR07/open-anatomy-3d](https://github.com/MervinR07/open-anatomy-3d) | Projeto recente, poucas estrelas | Licença de código e licença de modelos são arquivos separados; requer auditoria individual de cada ativo. | Monitorar; não substituir o corpo atual com base apenas no README. |

## Ferramentas de engenharia

| Repositório | Adoção aproximada observada | Licença | Uso recomendado |
|---|---:|---|---|
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | >100k | MIT | Manter como renderer; migrar para outro motor sem benchmark seria regressão de risco. |
| [zeux/meshoptimizer](https://github.com/zeux/meshoptimizer) | ~8,9k | MIT | Pipeline de assets futura, desde que os atributos customizados `aMuscleId` e `aMuscleSide`, UVs e morph targets sejam preservados e testados. |
| [donmccurdy/glTF-Transform](https://github.com/donmccurdy/glTF-Transform) | ~2k | MIT | Ferramenta de build para validar/comprimir GLB; não adicionar ao runtime. |
| [microsoft/playwright](https://github.com/microsoft/playwright) | >100k | Apache-2.0 | E2E/visual regression quando o ambiente de browser estiver configurado. |
| [vitest-dev/vitest](https://github.com/vitest-dev/vitest) | >17k | MIT | Alternativa de testes se o conjunto crescer; não adicionar enquanto os scripts atuais forem suficientes. |
| [ionic-team/capacitor](https://github.com/ionic-team/capacitor) | >17k | MIT | Candidato para empacotar a aplicação web em mobile sem migrar toda a UI; ainda requer configuração e testes em aparelhos reais. |

## Decisões aplicadas nesta versão

1. Não trocar Three.js: o app já usa batching, renderização sob demanda, orçamento de pixels e ciclo de vida de GPU.
2. Não adicionar biblioteca de pós-processamento: bloom/SSS/DOF aumentariam custo e não corrigiriam o principal limite atual, a geometria procedural.
3. Não importar malhas de atlas sem aprovação de licença por ativo. A prioridade é obter malhas dos 14 grupos com lateralidade correta e licença compatível com redistribuição comercial.
4. Corrigir seleção através da superfície corporal e ampliar descoberta de músculos por sinônimos, mantendo os mesmos IDs.
5. Adicionar contratos públicos entre domínios e CI, sem adicionar dependências de runtime.

## Limitações conhecidas

- A geometria muscular ainda é procedural e não constitui atlas médico, escaneamento corporal nem modelo anatômico validado.
- O app ainda precisa de integração mobile (Capacitor/alternativa), E2E visual, benchmark em dispositivos médios e testes reais de perda/restauração de contexto WebGL.
- Otimização glTF futura precisa validar atributos extras após exportação/importação real com GLTFLoader.
