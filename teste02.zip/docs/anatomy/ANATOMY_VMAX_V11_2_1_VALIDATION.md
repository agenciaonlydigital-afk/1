# TITAN Anatomy V.MAX V11.2.1 — patch de catálogo e auditoria Top 3

## Escopo do patch

Esta revisão é aditiva. O renderer Three.js, a figura completa (incluindo cabeça), o holograma, os IDs musculares e a interação de seleção não foram alterados.

### Correções aplicadas

- `exercise-catalog.ts`: adicionados `supino-reto`, `crucifixo`, `desenvolvimento` e `triceps-corda`, que já eram utilizados pelos planos iniciais, mas não existiam na biblioteca.
- `agachamento-livre`: adicionado `calves` à lista secundária, alinhando o exercício da biblioteca com o plano de treino que o usa.
- `exercise-muscle-map.ts`: o lookup de compatibilidade passa a derivar do catálogo canônico, removendo a segunda lista manual que podia divergir.
- `package.json`: `test:anatomy` executa agora também o novo contrato de catálogo.
- `scripts/check-exercise-muscle-contract.mjs`: valida slugs únicos, campos necessários, IDs válidos, cobertura de todos os exercícios de treino, igualdade do mapeamento e lookup derivado.

### Resultado do contrato

- 10 exercícios únicos no catálogo.
- 8 entradas de exercícios nos planos iniciais.
- 8/8 entradas resolvem para item de biblioteca.
- Todos os grupos usados existem em `MUSCLE_REGISTRY`.
- Mapas treino/biblioteca consistentes nos 8 exercícios utilizados.

## Repositórios pesquisados e escolhidos por prioridade

| Função | Repositório | Estrelas aprox. | Licença | Decisão |
|---|---|---:|---|---|
| Anatomia 3D | https://github.com/ashemag/human-atlas | 4,6k | Código MIT; dados BodyParts3D CC BY 4.0 | P1: extrair subset dos músculos e mapear para 14 IDs; atribuição obrigatória |
| Modelo paramétrico | https://github.com/NVlabs/SOMA-X | 903 | Apache-2.0 (modelo nativo declarado comercial-ready) | P3: backend offline para gerar forma corporal; não é hipertrofia segmentada |
| Catálogo exercício | https://github.com/hasaneyldrm/exercises-dataset | 23,7k | MIT para tooling/estrutura/texto; mídia Gym visual excluída | Fonte candidata para texto/metadados auditados; não copiar imagens/GIFs |
| Catálogo exercício alternativo | https://github.com/yuhonas/free-exercise-db | 2,2k | Unlicense | Complemento de texto e conferência de primary/secondary muscle |
| Teste cross-browser | https://github.com/microsoft/playwright | 101k | Apache-2.0 | Adicionar regressão Chromium/WebKit; não substitui hardware real |
| Otimização offline | https://github.com/zeux/meshoptimizer | 8,9k | MIT | Otimizar GLB após garantir sobrevivência dos IDs/atributos |
| Pipeline glTF | https://github.com/donmccurdy/glTF-Transform | 2,1k | MIT | Compressão e normalização do asset offline |
| Picking BVH | https://github.com/gkjohnson/three-mesh-bvh | 3,6k | MIT | Adiar até medição mostrar picking como gargalo |

### Opções não selecionadas

- Z-Anatomy e o BodyExplorer que distribui ativos Z-Anatomy/BodyParts3D Share-Alike: não usar no pipeline proprietário sem aceitar obrigações SA.
- wger/ExerciseDB API AGPL: não integrar código AGPL ao núcleo fechado do app. Dados exigem licença individualizada.
- Filament/Unity como substituição da engine: não migrar nesta etapa; a maior lacuna está no asset anatômico, não no motor.

## Top 3 pendências de maior impacto

### P1 — Malha anatômica muscular real

O `build-anatomy-body.ts` atual gera shell e músculos por lofts/patches procedurais. Human Atlas / BodyParts3D é a melhor fonte de malha encontrada com licença compatível para uso comercial sob atribuição CC BY 4.0. A malha masculina adulta é uma referência, não universal. A implementação deverá extrair só as estruturas musculares relevantes, agregar componentes anatômicos nos 14 grupos, manter lateralidade e preservar a figura/head shell. Nunca importar o viewer ou os 15 sistemas completos sem necessidade.

Critérios: anatomia legível de frente/costas/lado; sem interseções; 14 IDs originais; mapa source-FMA versionado; seleção/tap regressiva; GLB validado; atribuição da fonte.

### P2 — Catálogo exercício → músculo

**Implementado neste patch.** A biblioteca agora cobre todos os exercícios já usados nos planos de treino e o mapa duplicado deriva do catálogo. Próximo passo opcional é expandir o catálogo com uma importação curada dos dados públicos, depois auditar nome/instrução/origem e mapear primary/secondary sem inventar percentuais. Nenhuma imagem/GIF de terceiros foi importada.

### P3 — Transformação corporal real e validação mobile

O `morphFactor` anterior só deslocava os vértices em torno de 0,0015 m vezes o fator, não fazia alteração anatômica significativa. SOMA-X nativo pode parametrizar proporções e identidade e exportar uma malha para GLB offline. O próprio SOMA-X não cria hypertrofia isolada dos 14 grupos: isso deverá usar blend shapes/campos de deformação próprios e limites de deformação. O PyTorch/Warp não entra no runtime mobile.

Critérios: morph com variação mensurável; restrições e priors para não deduzir muitos coeficientes de poucas medidas; dados medidos separados dos estimados; validação de juntas e superfícies; Playwright browser tests; testes finais em iOS Safari e Android Chrome com frame-time/memória/temperatura reais.

## Testes executados neste patch

Os testes independentes disponíveis foram executados depois da alteração:

- `check-anatomy-geometry.mjs` — PASS
- `check-muscle-normal-map.mjs` — PASS
- `check-anatomy-shader-injection.mjs` — PASS
- `check-anatomy-group-contract.mjs` — PASS
- `check-anatomy-lifecycle.mjs` — PASS
- `check-anatomy-v9.mjs` — PASS
- `check-anatomy-vmax-v11.mjs` — PASS
- `check-fluid-shaders.mjs` — PASS
- `check-cockpit-visual-semantics.mjs` — PASS
- `check-titan-design-system.mjs` — PASS
- `check-materials-v10.mjs` — PASS
- `check-exercise-muscle-contract.mjs` — PASS

**Limitação:** `node_modules` não está presente. `tsc --noEmit` foi tentado e bloqueou por ausência de `vite/client`; não foi possível executar build Vite, `npm test` completo, compilação GLSL por Three.js instalado, testes E2E Playwright ou benchmark físico iOS/Android. Portanto, esta revisão passa os testes estáticos independentes do patch, mas não certifica build completo nem desempenho em aparelhos.
