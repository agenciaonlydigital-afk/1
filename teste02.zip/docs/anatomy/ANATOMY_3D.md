# TITAN — Anatomy 3D V.MAX V11.2

## 1. Objetivo visual e funcional

O viewer deve funcionar como um instrumento de estudo corporal: anatomia legível, realces musculares localizados, navegação previsível entre vistas frontal/posterior/lateral e resposta rápida. A direção é **Anatomical Precision**: escultura anatômica mineral, iluminação suave e contraste sem neon permanente.

O corpo não é um holograma, uma imagem decorativa nem uma medição de composição corporal. A visualização mantém a **figura corporal completa, incluindo cabeça, pescoço, tronco, braços, mãos, pernas e pés**, mas o conteúdo muscular funcional é intencionalmente limitado a **14 grupos relevantes para musculação e treino**. Não catalogamos todos os músculos, órgãos, nervos ou estruturas do corpo. O modelo é uma representação procedural de grupos de treino, não é um atlas médico, scan individual ou fonte diagnóstica.

## 2. Evolução V8 → V9 → V.MAX V11.2

- Seções transversais do tronco, cabeça/pescoço, braços e pernas passam por interpolação Catmull–Rom antes da criação das malhas.
- As superfícies musculares ganharam volume elíptico, afunilamento longitudinal e transição progressiva nas bordas; isso substitui patches planos com aparência de adesivo.
- Reto abdominal recebe seis relevos sutis, preservando um único ID lógico e lateralidade esquerda/direita para seleção.
- Mãos, dedos, palmas, pés e dedos dos pés completam a silhueta. Permanecem formas simplificadas; não são modelos anatômicos independentes.
- Corpo, músculos, planos profundos e esqueleto continuam em quatro lotes estáticos. O picking usa uma malha muscular combinada e atributos `aMuscleId` / `aMuscleSide`.
- Cada lote tem `boundingBox` e `boundingSphere` pré-calculados para culling e raycasting sem custo de cálculo na primeira interação.
- A superfície usa `MeshStandardMaterial` com BRDF PBR de Three.js, roughness alta e metalness zero. O shader customizado só acrescenta máscara muscular (bitwise em inteiros WebGL2), morph sutil e sweep de seleção.
- Em GPU de hardware, um `RoomEnvironment` gera PMREM para reflexos difusos e discretos de estúdio. Em renderer identificado como software, esse passe inicial é omitido.
- O controller aguarda IntersectionObserver próximo da viewport (`rootMargin: 120px`, threshold 1%) e visibilidade da página antes de criar o contexto. A instância real de `THREE.WebGLRenderer` confirma a disponibilidade de WebGL2; se falhar, a geometria não é construída. O renderer existente é usado para detectar GPU por `WEBGL_debug_renderer_info`, evitando um canvas/contexto de teste descartável. A identificação de software é best-effort: quando a extensão/nome do driver não está disponível, usa-se o orçamento conservador padrão da classe de dispositivo.
- O pixel ratio é limitado por orçamento de pixels: 520 mil (software), 1,05 milhão (pointer coarse) e 1,85 milhão (desktop), além de limites máximos de DPR. MSAA é desativado em touch; a classe de GPU é detectada no contexto ativo para escolher o orçamento de resolução e omitir PMREM em software.
- IDs musculares (`Uint8Array`), lateralidade (`Int8Array`) e normais (`Int16Array` normalizado) usam formatos compactos. Índices passam a `Uint16Array` quando o tamanho do lote permite. O V.MAX V11.2 preserva UVs somente no lote muscular (que utiliza o normal map procedural) e continua removendo UVs sem uso nos lotes de corpo, camada profunda e esqueleto. Os lofts fechados mantêm uma costura duplicada U=0/U=1, com normais médias nos vértices coincidentes, permitindo amostragem contínua do mapa sem abrir a emenda. As cores de repouso, primário, secundário e seleção continuam resolvidas no vertex shader a partir de máscaras/uniforms escalares e atributos de ID/lado; não há atributo de cor por vértice nem loop CPU de reescrita da malha.
- O V.MAX V11.2 gera um normal map procedural 256×256 para fibras musculares direcionais, em `DataTexture`, sem baixar ou redistribuir texturas de terceiros. A geração de pixels é uma função pura testável sem WebGL; o recurso é criado uma vez por conjunto de materiais e descartado no `dispose()`. Ele é aplicado somente ao lote muscular e descartado junto do material.
- O modo holográfico V.MAX V11.2 atua nos materiais PBR existentes com Fresnel, scanlines estáticas e emissão teal/champagne; o sweep de seleção existente fornece a varredura temporária. O custo das funções de Fresnel/scanline/emissão fica dentro de um branch uniforme `uHologramMode`, evitando esse trabalho no modo Natural. Não usa bloom, render target extra, partículas nem uma segunda passagem de pós-processamento. O usuário pode alternar entre Holograma e Natural.
- O Y usado pelo sweep e pelas scanlines é calculado imediatamente antes de `project_vertex` como `(modelMatrix * vec4(transformed, 1.0)).y`. Isso usa a posição final do vértice após os chunks de deformação e não depende de `worldPosition`, variável que o Three.js só declara quando certos recursos (por exemplo, environment map, sombras ou transmissão) estão habilitados. Cada substituição de chunk exige exatamente uma ocorrência; divergências falham cedo, em vez de produzir uma injeção parcial silenciosa.
- `createLoftTopology()` e `writeLoftCapPositions()` isolam a geração de UVs/índices e os dois vértices de fechamento; os testes verificam tampas, malhas abertas, limites de índice e seleção de largura 16/32 bits.
- Mantida renderização sob demanda, pausa quando a página ou viewport sai de cena, respeito a reduced motion, liberação de recursos na ordem correta (geometrias/materiais/PMREM antes do renderer), `forceContextLoss()` no unmount e recuperação de perda de contexto. O último snapshot visual enviado pelo React fica pendente durante a inicialização lazy e é aplicado quando a cena estiver pronta. `WebGLRenderer.compileAsync()` prepara os programas PBR antes do primeiro frame; um token de geração invalida conclusões assíncronas antigas depois de perda/restauração do contexto. O RAF permanece bloqueado durante a preparação para que o primeiro toque não dispute compilação síncrona de shader.

## 3. Contratos que não podem regredir

- IDs `pectoralis`, `anterior_deltoid`, `lateral_deltoid`, `posterior_deltoid`, `biceps`, `triceps`, `forearms`, `abdominals`, `latissimus`, `trapezius`, `glutes`, `quadriceps`, `hamstrings`, `calves` permanecem estáveis.
- `aMuscleId`, `aMuscleSide`, `uActiveMusclesMask`, `uMorphFactor` e `uSweepY` permanecem alinhados entre builder, material, shader, picker e store.
- Lateralidade é preservada; o highlight de exercício pode ser bilateral, mas uma seleção manual de lado não deve selecionar o lado oposto.
- Os modos `complete`, `deep` e `skeleton` mantêm seus próprios grupos de visibilidade.
- Vistas, seleção por toque, seleção pela lista acessível e limiar de arrasto continuam funcionais.
- Não adicionar auto-rotação, scroll hijacking, partículas, wireframe integral, glow permanente ou efeitos que escondam a leitura anatômica.

## 4. Pesquisa de repositórios e decisões

### Three.js — engine e pipeline PBR

[Three.js](https://github.com/mrdoob/three.js) (aprox. 119k stars; MIT) é a engine mantida. A implementação consulta `BufferGeometryUtils`, `WebGLRenderer`, `RoomEnvironment` e o exemplo de performance de instancing. Foram aproveitados PBR padrão, `mergeGeometries`, PMREM, gestão explícita de recursos e renderização sob demanda. A migração para React Three Fiber não foi adotada: o controller imperativo existente já controla uma única cena e não precisa de uma camada declarativa adicional.

- [BufferGeometryUtils](https://github.com/mrdoob/three.js/blob/dev/examples/jsm/utils/BufferGeometryUtils.js)
- [WebGLRenderer](https://github.com/mrdoob/three.js/blob/dev/src/renderers/WebGLRenderer.js)
- [RoomEnvironment](https://github.com/mrdoob/three.js/blob/dev/examples/jsm/environments/RoomEnvironment.js)
- [Instancing performance example](https://github.com/mrdoob/three.js/blob/dev/examples/webgl_instancing_performance.html)

Three.js r163+ requer WebGL2. O V9 usa o sucesso da criação do próprio `WebGLRenderer` como gate; não cria uma segunda tela/contexto de probe, evitando custo de inicialização e consumo de slots de contexto.

### Human Atlas / BodyParts3D — padrão de arquitetura anatômica

[Human Atlas](https://github.com/ashemag/human-atlas) (aprox. 4,6k stars; código MIT) documenta BodyParts3D 4.0 com 2.234 malhas selecionáveis, 3.432 conceitos e 2.288.268 triângulos; o próprio README informa cerca de 33 MB de geometria comprimida. A camada muscular possui 402 peças e 656.120 triângulos. O viewer agrupa malhas por sistema, usa estado de seleção/visibilidade na GPU, carrega chunks em paralelo e renderiza sob demanda.

Referências consultadas:
- [README e arquitetura](https://github.com/ashemag/human-atlas)
- [Scene: batches, PMREM, data textures e picking](https://github.com/ashemag/human-atlas/blob/main/app/scene.tsx)
- [Atribuição e licença dos dados](https://github.com/ashemag/human-atlas/blob/main/public/ATTRIBUTION.md)
- [Otimização do modelo](https://github.com/ashemag/human-atlas/blob/main/scripts/optimize-anatomy.mjs)

**Decisão:** usar o repositório como referência de organização por estruturas, batching, seleção por estado de GPU e PMREM; não importar o atlas completo para o TITAN nesta revisão. O conjunto publicado é uma referência masculina adulta sob CC BY 4.0 (sem taxa de licença, mas com atribuição) e exigiria validação de alinhamento, cobertura dos 14 IDs do TITAN, representatividade corporal e tamanho de download. O V.MAX V11.2 não copia nem redistribui essas malhas; mantém a geometria existente. O mapeamento continua restrito aos grupos musculares úteis ao treino.

### Z-Anatomy / BodyParts3D — procedência e licenças

[Z-Anatomy](https://github.com/Z-Anatomy/Models-of-human-anatomy) declara CC BY-SA 4.0 para seu conteúdo e suas derivações, mas seu próprio arquivo de licença lista conteúdo de terceiros sob licenças NC. Isso impede copiar o conjunto indiscriminadamente para uma aplicação redistribuída sem auditoria por ativo. O repositório [BodyParts3D](https://github.com/Kevin-Mattheus-Moerman/BodyParts3D) consultado contém dados da versão 3.0, modelo masculino e texto de licença CC BY-SA 2.1 Japan; seu README também alerta sobre limitações da geometria antiga. Nenhum desses ativos foi copiado para o TITAN.

### meshoptimizer / glTF Transform

- [meshoptimizer](https://github.com/zeux/meshoptimizer) (aprox. 8,9k stars; MIT) inspira otimização de cache de vértices, vertex fetch, indexação e simplificação com limite de erro.
- [glTF Transform](https://github.com/donmccurdy/glTF-Transform) (aprox. 2,1k stars; MIT) explica que simplificação é lossy, recomenda weld antes de simplificar e limita `join` para nós animados, skinned e morph targets.

**Decisão:** não adicionar dependência agora. A geometria procedural é pequena e já é construída em lotes estáticos; introduzir um pipeline de compressão para um ativo que não existe no projeto aumentaria complexidade sem ganho mensurado.

### three-mesh-bvh

[three-mesh-bvh](https://github.com/gkjohnson/three-mesh-bvh) (aprox. 3,6k stars; MIT) acelera raycasting e consultas espaciais em malhas grandes. Não foi adicionado: o TITAN usa uma única malha muscular combinada e um raycast por toque, não centenas de raios por frame. Deve ser reavaliado quando houver um atlas de alta resolução ou medição de picking acima do orçamento.

### Holograma — shader próprio inspirado em repositórios MIT

- [threejs-holographic-material](https://github.com/ektogamat/threejs-holographic-material) (256 stars; MIT) demonstra Fresnel, scanlines, tonalidade e emissão sem exigir post-processing.
- [threejs-vanilla-holographic-material](https://github.com/ektogamat/threejs-vanilla-holographic-material) (115 stars; MIT) é a referência mais próxima da integração imperativa usada pelo renderer TITAN.

**Decisão:** portar o padrão visual, não a dependência ou o material pronto. O TITAN injeta Fresnel, scanline e emissão no `MeshStandardMaterial` que já existe. Isso mantém o custo de um passe e não força um loop contínuo de animação. O halo é emissivo direto do material; não deve ser descrito como selective bloom físico.

### UVs e normal map de fibra — sem asset externo

O loft procedural agora gera UVs com costura duplicada, e o merge preserva esse atributo. Um `DataTexture` normal de 256×256 é gerado deterministically em runtime a partir de uma função procedural de estrias longitudinais. Não há imagem ou malha de terceiros. `normalScale` é baixo para evitar aparência de borracha/canelado.

[meshoptimizer](https://github.com/zeux/meshoptimizer) (8,9k stars; MIT) permanece referência para a pipeline de otimização de malhas; não é adicionado como dependência de runtime porque a geometria ainda é criada proceduralmente e o custo de exportar/decimar não traria benefício imediato.

## 5. Revisão corretiva V11.2 e matriz dos repositórios

A V11.2 foi construída sobre o projeto V11.1 existente. Não trocou a engine, não substituiu o modelo procedural, não modificou os 14 IDs e não adicionou dependências de runtime.

| Função | Repositório top/referência | Estrelas consultadas (aprox.) | Licença declarada | Decisão aplicada |
|---|---|---:|---|---|
| Engine/render PBR | [Three.js](https://github.com/mrdoob/three.js) | 119,1k | MIT | Manter. É a base já integrada; `MeshStandardMaterial`, PMREM, `compileAsync`, geometria e lifecycle continuam nativos. |
| Referência mobile PBR | [Google Filament](https://github.com/google/filament) | 20,8k | Apache-2.0 | Benchmark arquitetural, não migração. Substituir engine agora descartaria o controller e a integração selecionável existentes. |
| Otimização de malha | [meshoptimizer](https://github.com/zeux/meshoptimizer) | 8,9k | MIT | Não adicionar ao runtime: o corpo atual é procedural; a simplificação de GLB só faz sentido quando houver asset estático que precise de pipeline. |
| Referência anatômica | [Human Atlas](https://github.com/ashemag/human-atlas) | 4,6k | Código MIT; dados CC BY 4.0 | Usado para avaliar anatomia estruturada, seleção por sistema e batching. Não incorporar malha nesta revisão: modelo masculino adulto, ~33 MB e 402 estruturas musculares que exigiriam mapeamento/QA dos 14 grupos e atribuição. |
| Picking espacial | [three-mesh-bvh](https://github.com/gkjohnson/three-mesh-bvh) | 3,6k | MIT | Não adicionar ainda. O picker já faz um raycast por toque em um batch estático; sem evidência de latência acima do orçamento, o BVH adicionaria memória/dependência. Reavaliar com malha de alta resolução. |
| Pipeline glTF | [glTF Transform](https://github.com/donmccurdy/glTF-Transform) | 2,1k | MIT | Referência para futura exportação/otimização de malhas; sem asset GLB atual a ser transformado. |
| Holograma R3F | [threejs-holographic-material](https://github.com/ektogamat/threejs-holographic-material) | 256 | MIT | Inspiração para Fresnel, scanline e emissão; portado como shader próprio para o controller imperativo, sem novo pacote. |
| Holograma Three.js puro | [threejs-vanilla-holographic-material](https://github.com/ektogamat/threejs-vanilla-holographic-material) | 115 | MIT | Referência de integração sem React Three Fiber; manter o material e uniforms próprios do TITAN. |
| Modelo paramétrico de corpo | [MHR](https://github.com/facebookresearch/MHR) / [SOMA-X](https://github.com/NVlabs/SOMA-X) / [Anny](https://github.com/naver/anny) | 910 / 903 / 655 | Apache-2.0 para código | Candidatos a backend de identidade/deformação, não substitutos diretos dos 14 grupos musculares; assets e dependências opcionais exigem auditoria própria. Não foram integrados. |
| Anatomia CC BY-SA | [Z-Anatomy](https://github.com/LluisV/Z-Anatomy) | 418 | CC BY-SA 4.0 | Não redistribuir/derivar no app comercial fechado sem aceitar ShareAlike e auditar todos os ativos terceiros. |

Os números de estrelas são uma fotografia aproximada da consulta ao GitHub em 22/11/2026; podem variar. Licença de código não implica automaticamente a mesma licença para malhas, checkpoints ou outros assets: ativos externos não foram copiados para o bundle.

### Correções de engenharia desta revisão

1. **Contratos de injeção GLSL:** as nove chamadas de `replaceShaderChunk` agora informam explicitamente o estágio (`vertex` ou `fragment`). A V11.1 deixava duas chamadas do vertex stage sem o quarto argumento exigido pela assinatura TypeScript. O teste verifica nove chamadas: três de vertex e seis de fragment, além de falhas por chunks ausentes/duplicados.
2. **Periodicidade do normal map:** a frequência vertical da função procedural foi alterada para um múltiplo inteiro. O teste mede a diferença dos canais RGB nas bordas opostas U/V para detectar costura de textura. UVs permanecem preservados apenas no batch muscular.
3. **Lifecycle de falha:** fallback após construção/compilação GLSL incompleta cancela RAF, remove observers/listeners, descarta malha, materiais, textura, PMREM e palco, limpa a cena e libera o contexto WebGL. Callbacks RAF obsoletos verificam a identidade do renderer/recursos antes de renderizar.
4. **Falha antes de criar o contexto:** se `new THREE.WebGLRenderer()` falhar, o controller também desconecta o `IntersectionObserver`, o observer de resize e o listener de visibilidade da página; isso evita deixar observers montados sem um renderer.
5. **Contratos preservados:** cabeça e corpo inteiros permanecem visíveis; somente os 14 grupos do registro de treino têm seleção funcional e mapeamento com exercícios.
6. **Sem dependência adicional:** as melhorias usam Three.js e código procedural já existente. BVH, glTF optimizer, novo renderer e malhas de terceiros foram avaliados e deliberadamente não adicionados por falta de necessidade medida ou por impacto de licença/integração.

## 6. Arquitetura de performance

| Área | Regra V9 |
|---|---|
| Geometria | Quatro lotes estáticos, geração direta em TypedArrays, UVs preservados, bounds pré-calculados, normais compactadas, índices 16-bit quando seguro e IDs/lados compactos |
| Draw calls anatômicos | Um lote por corpo, músculos, camada profunda e esqueleto |
| Destaque | Vertex shader combina máscaras inteiras primária/secundária por shift/AND, ID/lado selecionado e uniforms de cor; fragment shader recebe a cor pronta, sem buffer de cor nem loop CPU por vértice |
| Shader | PBR nativo; máscara de grupos e seleção; V.MAX V11.2 acrescenta normal map muscular e holograma single-pass com uniforms, sem bloom |
| Ambiente | Uma PMREM de estúdio em GPU de hardware identificada; sem passe adicional em software GL conhecido |
| Resolução | Orçamento de pixels por classe de dispositivo; MSAA desligado em touch |
| Inicialização | Contexto lazy com pré-aquecimento próximo da viewport; `compileAsync`; nenhuma geometria/PMREM fora de cena |
| Recuperação | Geração de contexto evita que promises de compile antigas reativem um contexto já perdido |
| Loop | RAF apenas quando há input, damping ou sweep; nenhuma rotação contínua |
| Visibilidade | Pausar canvas fora do viewport/aba oculta |
| Lifecycle | Dispose de geometrias/materiais/PMREM antes do renderer, `forceContextLoss()` no unmount e restauração protegida por geração |
| Acessibilidade | reduced motion; lista textual alternativa; controles acessíveis fora do canvas |

`renderer.info` é exposto pelo controller para inspecionar draw calls, triângulos, geometrias e texturas. O número de draw calls esperado é pequeno (quatro lotes anatômicos mais o palco), mas deve ser medido em render real; não é uma medição de FPS.

## 7. Limitações honestas

- O corpo segue procedural; não é uma malha muscular médica validada nem um scan humano.
- Os 14 grupos são regiões de treino de alto nível. Alguns, como antebraços, quadríceps e abdômen, representam conjuntos de músculos em uma única seleção lógica.
- O modelo não possui pele/albedo/normal map anatômico de alta resolução, pelos, vasos, tendões individualizados, articulações detalhadas, rig esquelético ou animação biomecânica. O normal map atual é procedural e estilístico, não representa fibras anatômicas de cada músculo.
- `morphFactor` ainda é apenas um pequeno offset de superfície no shader (escala submilimétrica para os valores atuais), não uma deformação antropométrica real de peso, gordura ou hipertrofia. Não deve ser apresentado como previsão de corpo futuro.
- PMREM gerado por `RoomEnvironment` é iluminação de estúdio procedural, não HDRI fotografado. A classe de GPU de software só é reconhecida quando o driver expõe um renderer string identificável; não há detecção universal garantida.
- A melhoria de forma/profundidade foi inferida do código e ainda precisa de aprovação visual em GPU; nenhum FPS, tempo de frame ou qualidade 9,5 está sendo declarado.
- Um futuro ativo anatômico real deverá passar por auditoria individual de licença, cobertura de grupos/lateralidade, normais/UVs, custo de rede, memória GPU, picking e benchmark em Android/iOS antes de substituir este modelo.

## 8. Gate final de dispositivos

- [ ] Compilar shaders WebGL2 em Chromium, Firefox e Safari com GPU física.
- [ ] Capturar frontal/posterior/lateral nos modos superficial/profundo/esqueleto.
- [ ] Validar anatomia e lateralidade de cada grupo com especialista/referência anatômica.
- [ ] Medir build do viewer, primeira renderização, GPU frame time, CPU frame time e pico de memória em Android mid-tier e iPhone.
- [ ] Verificar picking com toque, arrasto, lista acessível e camadas ocultas.
- [ ] Testar perda/recuperação de contexto, tab hidden, viewport offscreen e reduced motion.
- [ ] Revisar brilho, cor e contraste em telas OLED e LCD.

Até esse gate ser concluído, V.MAX V11.2 é uma melhoria de engenharia com testes de contrato, topologia/UV, geração do normal map, injeção de shader e verificações estáticas aprovados. O build integral e a validação gráfica não foram concluídos neste ambiente, portanto isto não é uma aprovação fotográfica, médica ou de benchmark.


## 6. Auditoria Top 3 e patch V11.2.1

1. **P1 — geometria anatômica real:** o construtor atual ainda usa patches procedurais. Melhor referência de origem identificada: Human Atlas / BodyParts3D 4.0 (código MIT; dados CC BY 4.0). O modelo selecionado deve ser reduzido a somente 14 grupos TITAN, mantendo o corpo/head visual completo e a atribuição da fonte. Não importar todos os sistemas anatômicos.
2. **P2 — exercício→músculo:** V11.2.1 adiciona os quatro slugs dos treinos que faltavam na biblioteca, corrige o mapa de secundários do agachamento e deriva o lookup de compatibilidade do catálogo. Teste: `scripts/check-exercise-muscle-contract.mjs`.
3. **P3 — morph real:** o `morphFactor` original era apenas deslocamento uniforme submilimétrico na normal. Candidato de backend paramétrico: NVIDIA SOMA-X nativo (Apache 2.0, 128 coeficientes); deve gerar GLB offline e não rodar PyTorch/Warp no viewport. A hipertrofia por grupo exigirá morphs/campos próprios dos 14 grupos.

A validação automatizada de interação/viewport deve ser adicionada com Playwright (Apache 2.0), e a aprovação mobile final ainda exige aparelhos reais. Ver `docs/anatomy/ANATOMY_VMAX_V11_2_1_VALIDATION.md` para decisões de repositório/licença e critérios de aceite.
