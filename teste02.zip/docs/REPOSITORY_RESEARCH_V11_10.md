# Pesquisa de repositórios — V11.10

Estrelas são aproximações observadas em 23/11/2026, não métricas de qualidade. As licenças indicadas são as licenças dos repositórios; sempre confirmar também a licença do pacote/versão antes de adicionar dependências.

## 1. Testes e qualidade React — Top 5

| Repositório | Stars aprox. | Licença | Uso no TITAN |
|---|---:|---|---|
| microsoft/playwright | 100,9k | Apache-2.0 | E2E Chromium/WebKit/Firefox; prioridade P0 |
| vitest-dev/vitest | 17,4k | MIT | Runner de unit/component tests compatível com Vite |
| testing-library/react-testing-library | 19,7k | MIT | Testar comportamento visível dos componentes |
| mswjs/msw | 18,4k | MIT | Simular APIs de forma realista nos testes |
| dequelabs/axe-core | 7,9k | MPL-2.0 | Detectar problemas automatizáveis de acessibilidade |

Decisão: adicionar como conjunto de qualidade em um PR próprio, com versões compatíveis e lockfile regenerado por Bun. Não fingir que testes unitários substituem E2E.

## 2. Dados remotos, cache e sincronização — Top 5

| Repositório | Stars aprox. | Licença | Uso no TITAN |
|---|---:|---|---|
| TanStack/query | 50,6k | MIT | Melhor opção quando endpoints remotos forem consumidos |
| vercel/swr | 31k | MIT | Alternativa menor para fetch/cache; não instalar junto sem necessidade |
| apollographql/apollo-client | 19k | MIT | Somente se houver GraphQL real |
| urql-graphql/urql | 9k | MIT | Alternativa GraphQL mais modular |
| reduxjs/redux-toolkit | 11k | MIT | Não justificado com Zustand já presente |

Decisão: TanStack Query é o candidato padrão para server-state futuro. Hoje o cliente não tem consumo real dos endpoints do servidor, então instalar agora seria infraestrutura sem consumidor.

## 3. Estado local, atômico e workflows — Top 5

| Repositório | Stars aprox. | Licença | Uso no TITAN |
|---|---:|---|---|
| pmndrs/zustand | 59k | MIT | Manter estado de aplicação/UI e stores existentes |
| pmndrs/jotai | 21k | MIT | Considerar para editor com muitos valores derivados independentes |
| reduxjs/redux-toolkit | 11k | MIT | Alternativa estruturada, mas migração não se justifica |
| statelyai/xstate | 30k | MIT | Fluxos multi-etapas com estados e transições rígidas |
| valtio | 9k | MIT | Alternativa proxy-based; não misturar sem problema concreto |

Decisão: manter Zustand; Jotai e XState não devem ser adicionados por moda. XState só se onboarding, sincronização ou fluxos de recuperação passarem a exigir statecharts.

## 4. Formulários e validação — Top 5

| Repositório | Stars aprox. | Licença | Uso no TITAN |
|---|---:|---|---|
| react-hook-form/react-hook-form | 44,9k | MIT | Escolha preferida para formulários grandes |
| TanStack/form | 7k | MIT | Alternativa tipada e agnóstica de framework |
| final-form/react-final-form | 7k | MIT | Alternativa baseada em subscriptions |
| jaredpalmer/formik | 34k | MIT | Projeto conhecido, mas não preferência para novos formulários |
| colinhacks/zod | 40k | MIT | Manter validação de schemas já usada no app |

Decisão: RHF + Zod para editor completo de treino/nutrição; TanStack Form é alternativa, não complemento obrigatório.

## 5. Navegação e estado na URL — Top 5

| Repositório | Stars aprox. | Licença | Uso no TITAN |
|---|---:|---|---|
| remix-run/react-router | 56,7k | MIT | Opção preferida para rotas, browser history e deep links |
| TanStack/router | 15,3k | MIT | Tipagem forte e loaders; maior superfície de adoção |
| nuqs/nuqs | 4k | MIT | Estado de busca/filtros na URL, após adoção de router |
| reach/router | 5k | MIT | Não escolher para projeto novo; legado |
| wouter | 7k | MIT | Alternativa minimalista, menos completa |

Decisão: React Router é a escolha simples para Vite/React. Fazer migração incremental, mantendo os módulos de tela e validando refresh/deep-link.

## 6. Performance e arquitetura — Top 5

| Repositório | Stars aprox. | Licença | Uso no TITAN |
|---|---:|---|---|
| GoogleChrome/lighthouse | 31,2k | Apache-2.0 | Auditoria de performance e experiência |
| aidenybai/react-scan | 21,9k | MIT | Diagnóstico de renders desnecessários em desenvolvimento |
| alan2207/bulletproof-react | 36k | MIT | Referência de organização por features e fronteiras |
| vitejs/vite | 84k | MIT | Guia de profiling/build/chunks; já é o bundler do app |
| mrdoob/three.js | 119k | MIT | Referência para manter renderização 3D imperativa otimizada |

Decisão: medir com Lighthouse, React Profiler/React Scan e profiling do Vite antes de refatorações de grande escala. Não migrar Three.js para React Three Fiber sem benefício mensurável.

## Arquitetura-alvo recomendada

- Remote/server state: TanStack Query quando houver endpoints usados.
- Local/UI state: Zustand.
- Complex forms: React Hook Form + Zod.
- Atomic derived state: Jotai somente em editor com dependências granulares comprovadas.
- State machines: XState apenas para workflows realmente rígidos.
- URL/navigation: React Router.
- Auth: Context no cliente + autenticação/autorização real no servidor; não confiar em Context como barreira de segurança.
- Quality: Vitest + Testing Library + MSW + Playwright + axe-core.
- Performance: Lighthouse + React Profiler/React Scan + Vite profiling.

## Próximas prioridades

1. Completar editor de treino: séries, repetições, carga, descanso, reordenação e validação.
2. Completar editor alimentar: composição da refeição, ingredientes, porções e cálculo auditável.
3. Introduzir Playwright/Vitest/Testing Library/MSW/axe-core e CI cross-browser.
4. Adotar React Router e URL state com migração incremental.
5. Implementar proveniência e confiança dos dados (medido, informado, estimado, importado) e export/restore com testes E2E.
6. Só então avaliar IndexedDB/Dexie, Query e autenticação/sync cloud com base em requisitos concretos.
