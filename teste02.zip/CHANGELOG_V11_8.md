# TITAN HYDRATION V.MAX V11.8 — Revisão funcional e confiabilidade

## Implementado

- Removidos registros fictícios de hidratação e evolução na instalação nova.
- Removidas, durante a hidratação do estado persistido, as entradas de demonstração conhecidas da V11.7; o histórico real do usuário permanece preservado.
- Removidas as séries artificialmente concluídas do plano de treino inicial e corrigida a migração dos registros de demonstração antigos.
- Adicionado o estado explícito `profileConfigured`; os valores fisiológicos iniciais passam a ser identificados como provisórios até o usuário salvar o perfil.
- A tela Evolução deixa de renderizar gráficos, KPIs e tendências como se existissem medições reais quando o histórico está vazio.
- Corrigido o reinício de planos de treino concluídos, preservando carga/repetições como referência de progressão e zerando a execução da nova sessão.
- Adicionado histórico local de até 100 sessões de treino, com snapshot imutável das séries efetivamente concluídas.
- Adicionado registro direto de alimento do catálogo no diário por quantidade em gramas e refeição, com validação do alimento, data e faixa de quantidade.
- Adicionado backup manual em JSON com whitelist de chaves, validação de envelope/conteúdo, limite de tamanho e rollback best-effort ao falhar a restauração.
- Disponibilizado o acesso a Ações rápidas no topo desktop, além do atalho mobile.
- Adicionado `React.Profiler` por tela em desenvolvimento para sinalizar renders com duração igual ou superior a 16,7 ms. É um alerta diagnóstico, não um benchmark nem uma medição de FPS.
- Corrigido um erro de referência circular no gráfico de Evolução que podia quebrar ao abrir o histórico após a primeira medição; o cálculo do gráfico foi extraído para uma regra pura e agora trata séries com medidas esparsas por métrica.
- Extraído o contrato de medições observadas para `src/shared/types`, removendo dependência das regras de domínio sobre a implementação dos stores Zustand.
- Incluídos testes puros para migração do perfil, migração das sementes, diário de alimentos, histórico de treino e backup/restore.

## Não implementado nesta versão

- Sincronização em nuvem, login e restauração automática entre dispositivos.
- Editor completo de fichas de treino ou biblioteca ampliada de exercícios.
- Editor de refeições/receitas com ingredientes, porções e composição editável.
- Banco offline IndexedDB; o armazenamento primário continua localStorage com fallback em memória.
- Rotas URL/deep links e histórico de navegação do browser.
- Telemetria remota, crash reporting e dashboards de performance.
- Testes E2E em navegador e testes de componentes React.
- Substituição do modelo anatômico procedural por um atlas anatômico de referência.

## Compatibilidade e dados existentes

O schema persistido permanece na versão atual dos stores. As funções de merge reconhecem os IDs fixos de demonstração introduzidos pela V11.7 e os removem no próximo carregamento. Os registros locais não identificados como dados de demonstração não são apagados. O backup exporta apenas as cinco stores canônicas do TITAN: profile, training, nutrition, evolution e hydration.
