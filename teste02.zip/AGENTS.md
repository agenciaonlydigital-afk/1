# AGENTS.md — TITAN Engineering & Architecture SSOT

## 1. Stack & Verification Commands
- Runtime: Vite 8 + React 19 + TypeScript (`strict`, `noUncheckedIndexedAccess`, `verbatimModuleSyntax`), Tailwind CSS v4, Zustand 5, Zod 4, Three.js, SmilesDrawer 2.
- Dev / Build / Typecheck:
  - `npm run dev` (Express / Vite port 3000)
  - `npm run build` (`vite build`)
  - `npm run lint` (`tsc --noEmit`)
- Domain Tests:
  - `npx tsx src/domains/training/__tests__/rest-timer.test.ts`
  - `npx tsx src/domains/anatomy/tests/anatomy-mask.test.ts`
  - `npx tsx src/domains/nutrition/__tests__/nutrition-engine.test.ts`
  - `npx tsx src/domains/hydration/__tests__/hydration-store.test.ts`

## 2. Domain & Layer Boundaries
- `src/app-core/*` → mounts `bootstrap/`, `providers/`, `navigation/`, and `error-boundaries/`.
- `src/domains/*` (`identity`, `profile`, `cockpit`, `anatomy`, `training`, `exercise-library`, `nutrition`, `hydration`, `evolution`, `calendar`, `insights`, `notifications`) → isolated domain modules; never import internal files across sibling domains except via public `application/*` contracts.
- `src/shared/*` → pure `design-system/`, `ui/`, `hooks/`, `utils/`, `types/`, and `constants/`.
- `src/infrastructure/*` → `api/`, `database/`, `storage/`, `analytics/`, `monitoring/`, `sync/`.
- **No Barrel Files**: Do not create `index.ts` re-export barrels inside `src/shared/ui` or `src/domains/*`. Always import leaf modules directly to preserve tree-shaking and module-graph speed.

## 3. State Separation & Runtime Boundaries
- **UI & Session State**: Ephemeral modals/tabs/selections live in Zustand stores; never store sensitive secrets in `localStorage`.
- **Runtime Validation**: Validate numeric inputs and persistence/external payloads with Zod schemas or strict finite-number guards (`raw.trim() !== '' && Number.isFinite(val)`).

## 4. Mobile Performance & INP Rules
- Target **INP <= 200 ms** on mid-tier mobile devices.
- Heavy synchronous loops (e.g., SMILES chemical structure SVG rendering) must yield cooperatively via `enqueueYieldingTask()` / `yieldToMain()` (`scheduler.yield()` with `setTimeout(0)` fallback) so main-thread tasks stay under 16 ms.
- Wrap heavy pure derivations in `useMemo`, memoize leaf Cockpit widgets with `React.memo`, and mark non-urgent tab/day/accordion transitions with `startTransition`.
- **WebGL (Three.js)**: Keep anatomy on a small, explicit draw-call budget: one smoothed body-surface batch, one batched muscle surface with GPU-resolved color/selection via stable `aMuscleId`/`aMuscleSide` attributes, one deep-layer batch and one skeleton batch. Update muscle colors only on semantic state changes; do not create one mesh/material per muscle. Require WebGL2, defer mesh construction until capability is confirmed, use PBR/PMREM only when available and skip its setup on software GL. Render on demand, pause off-screen/hidden tabs, cap the backing-store pixel budget, precompute merged bounds, and release geometry/material/PMREM resources on unmount.
