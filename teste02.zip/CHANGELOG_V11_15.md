# V11.15 — motor de cálculo multi-equação e calibração robusta

- Criada API de RMR com Mifflin–St Jeor, Pavlidou 2023, Cunningham, Katch–McArdle, Ten Haaf 2014 e override de calorimetria indireta informada.
- Cunningham/Katch exigem FFM explícita; a API registra origem e alerta quando a qualidade da composição corporal não está clara.
- O cálculo de metas mantém Mifflin como método geral, mas corrige a nomenclatura da interface para RMR estimada, sem confundir RMR com BMR medido.
- Criado motor MET genérico com validação de catálogo externo, proveniência/licença, cálculo bruto/líquido e corrected MET como razão individual. O Compendium 2024 não foi embutido por estar associado a CC BY-NC-ND, incompatível com redistribuição/derivação irrestrita.
- Substituída a estimativa adaptativa de ponto único por janelas robustas Theil–Sen e atualizações semanais de Kalman, com faixa de incerteza model-based explicitamente não calibrada externamente.
- Criado contrato para receber e integrar saídas de potência do modelo OpenMetabolics em W, com validação de frequência, posição, cobertura, amostras e duração.
- Nenhuma dependência runtime adicionada; os módulos novos são TypeScript puro.
- Testes adicionais cobrem equações, entradas inválidas, MET, conversão de potência, convergência sintética de 84 dias, outliers e duplicatas. A simulação determinística de 200 perfis reportou RMSE 90,7 kcal no período estável e 83,8 kcal após uma queda simulada de 200 kcal/dia no TDEE; resultados sintéticos, não validação clínica.
- Limitações: sensor OpenMetabolics não está portado nem ativo no app React/Vite; modelo Hall/NIDDK completo, catálogo 1.114 completo, UI de seleção RMR/FFM, backtesting científico e validação em aparelho físico permanecem pendentes.
